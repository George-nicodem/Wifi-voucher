<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| WIFI VOUCHER ADMIN DASHBOARD
|--------------------------------------------------------------------------
| Main admin control center.
| Modules are loaded through a strict whitelist.
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/includes/admin_auth.php';

requireAdminLogin();

/*
|--------------------------------------------------------------------------
| Current Page
|--------------------------------------------------------------------------
*/

$page = getString('page', 'dashboard');

$allowedPages = [
    'dashboard',
    'vouchers',
    'packages',
    'payments',
    'wallet',
    'payment_methods',
    'payment_channels',
    'payment_routing',
    'sites',
    'router',
    'users',
    'reports',
    'settings',
    'customer_portal',
    'security',
    'trial_settings',
    'backup'
];

if (!in_array($page, $allowedPages, true)) {
    $page = 'dashboard';
}

if ($page === 'users') {
    requireMasterAdmin();
}

$pageTitles = [
    'dashboard'        => 'Dashboard',
    'vouchers'         => 'Vouchers',
    'packages'         => 'Packages',
    'payments'         => 'Payments',
    'wallet'           => 'Admin Wallet',
    'payment_methods'  => 'Payment Methods',
    'payment_channels' => 'Payment Channels',
    'payment_routing'  => 'Payment Routing',
    'sites'             => 'Sites',
    'router'           => 'Routers / TP-Link & MikroTik',
    'users'             => 'Admin Users',
    'reports'           => 'Reports',
    'settings'          => 'Settings',
    'customer_portal'   => 'Customer Portal',
    'security'          => 'Security',
    'trial_settings'    => 'Trial Wi-Fi',
    'backup'            => 'Database Backup',
];

$pageTitle = $pageTitles[$page] ?? 'Dashboard';

/*
|--------------------------------------------------------------------------
| Statistics
|--------------------------------------------------------------------------
*/

$stats = [
    'total_vouchers'   => 0,
    'active_vouchers'  => 0,
    'expired_vouchers' => 0,
    'total_packages'   => 0,
    'total_payments'   => 0,
    'successful'       => 0,
    'pending'          => 0,
    'failed'           => 0
];

if ($page === 'dashboard') {

    try {

        /*
        |--------------------------------------------------------------------------
        | Expire vouchers automatically
        |--------------------------------------------------------------------------
        */

        $conn->query("
            UPDATE vouchers
            SET status = 'expired'
            WHERE status = 'active'
              AND expires_at IS NOT NULL
              AND expires_at <= NOW()
        ");

        /*
        |--------------------------------------------------------------------------
        | Voucher statistics
        |--------------------------------------------------------------------------
        */

        $queries = [

            'total_vouchers' => "
                SELECT COUNT(*) AS total
                FROM vouchers
            ",

            'active_vouchers' => "
                SELECT COUNT(*) AS total
                FROM vouchers
                WHERE status = 'active'
            ",

            'expired_vouchers' => "
                SELECT COUNT(*) AS total
                FROM vouchers
                WHERE status = 'expired'
            ",

            'total_packages' => "
                SELECT COUNT(*) AS total
                FROM packages
            ",

            'total_payments' => "
                SELECT COUNT(*) AS total
                FROM payments
            ",

            'successful' => "
                SELECT COUNT(*) AS total
                FROM payments
                WHERE UPPER(status) = 'SUCCESS'
            ",

            'pending' => "
                SELECT COUNT(*) AS total
                FROM payments
                WHERE UPPER(status) = 'PENDING'
            ",

            'failed' => "
                SELECT COUNT(*) AS total
                FROM payments
                WHERE UPPER(status)
                IN ('FAILED','CANCELLED','CANCELED','EXPIRED')
            "
        ];

        foreach ($queries as $key => $sql) {

            $result = $conn->query($sql);

            if ($result) {

                $row = $result->fetch_assoc();

                $stats[$key] = (int)($row['total'] ?? 0);
            }
        }

    } catch (Throwable $e) {

        logException(
            $e,
            'Admin dashboard statistics'
        );
    }
}

/*
|--------------------------------------------------------------------------
| Shared Header
|--------------------------------------------------------------------------
*/

$dashboardWalletChannel = null;
$dashboardWalletBalance = null;
$dashboardWalletCheckedAt = 0;
if ($page === 'dashboard' && adminHasRole(['admin', 'super_admin', 'superadmin'])) {
    require_once __DIR__ . '/modules/wallet/functions.php';
    try {
        $walletChannels = adminWalletConfiguredChannels($conn);
        $clickPesaWalletChannels = array_values(array_filter(
            $walletChannels,
            static fn(array $channel): bool => (string)($channel['provider_key'] ?? '') === 'clickpesa'
        ));
        $dashboardWalletChannel = $clickPesaWalletChannels[0] ?? $walletChannels[0] ?? null;
        if (is_array($dashboardWalletChannel)) {
            $walletCache = $_SESSION['admin_wallet_balance_' . (int)$dashboardWalletChannel['id']] ?? null;
            if (is_array($walletCache) && is_numeric($walletCache['balance'] ?? null)
                && is_string($walletCache['currency'] ?? null)) {
                $dashboardWalletBalance = [
                    'balance' => (float)$walletCache['balance'],
                    'currency' => strtoupper((string)$walletCache['currency']),
                ];
                $dashboardWalletCheckedAt = (int)($walletCache['checked_at'] ?? 0);
            }
        }
    } catch (Throwable $exception) {
        logException($exception, 'Loading the dashboard provider balance');
    }
}

require __DIR__ . '/includes/admin_header.php';


/*
|--------------------------------------------------------------------------
| DASHBOARD HOME
|--------------------------------------------------------------------------
*/

if ($page === 'dashboard') {

    $todayKey = date('Y-m-d');
    try {
        $databaseDateResult = $conn->query('SELECT CURDATE() AS today_key');
        if ($databaseDateResult) {
            $databaseDate = $databaseDateResult->fetch_assoc();
            $todayKey = (string)($databaseDate['today_key'] ?? $todayKey);
        }
    } catch (Throwable $exception) {
        logException($exception, 'Loading dashboard date');
    }
    $todayBase = DateTimeImmutable::createFromFormat('!Y-m-d', $todayKey) ?: new DateTimeImmutable('today');
    $chartStart = $todayBase->modify('-6 days');
    $salesByDay = [];
    for ($dayOffset = 0; $dayOffset < 7; $dayOffset++) {
        $chartDay = $chartStart->modify('+' . $dayOffset . ' days');
        $salesByDay[$chartDay->format('Y-m-d')] = [
            'label' => $chartDay->format('d M'),
            'automatic' => 0.0,
            'manual' => 0.0,
            'admin_active' => 0.0,
            'automatic_count' => 0,
            'manual_count' => 0,
            'admin_active_count' => 0,
            'total' => 0.0,
        ];
    }

    try {
        $automaticTrendResult = $conn->query("SELECT DATE(COALESCE(paid_at, created_at)) AS sale_day,
                COUNT(*) AS sale_count, COALESCE(SUM(amount), 0) AS sale_total
            FROM payments
            WHERE UPPER(COALESCE(status, '')) = 'SUCCESS'
              AND COALESCE(paid_at, created_at) >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
              AND COALESCE(paid_at, created_at) < DATE_ADD(CURDATE(), INTERVAL 1 DAY)
            GROUP BY DATE(COALESCE(paid_at, created_at))");
        if ($automaticTrendResult) {
            while ($sale = $automaticTrendResult->fetch_assoc()) {
                $saleDay = (string)($sale['sale_day'] ?? '');
                if (isset($salesByDay[$saleDay])) {
                    $salesByDay[$saleDay]['automatic'] = (float)($sale['sale_total'] ?? 0);
                    $salesByDay[$saleDay]['automatic_count'] = (int)($sale['sale_count'] ?? 0);
                }
            }
        } else {
            logDatabaseError($conn, 'Loading automatic revenue trend for dashboard');
        }
    } catch (Throwable $exception) {
        logException($exception, 'Loading automatic revenue trend for dashboard');
    }

    try {
        $manualTrendResult = $conn->query("SELECT DATE(sold_at) AS sale_day,
                COUNT(*) AS sale_count, COALESCE(SUM(sold_price), 0) AS sale_total
            FROM vouchers
            WHERE source = 'manual' AND sold_at IS NOT NULL
              AND sold_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
              AND sold_at < DATE_ADD(CURDATE(), INTERVAL 1 DAY)
            GROUP BY DATE(sold_at)");
        if ($manualTrendResult) {
            while ($sale = $manualTrendResult->fetch_assoc()) {
                $saleDay = (string)($sale['sale_day'] ?? '');
                if (isset($salesByDay[$saleDay])) {
                    $salesByDay[$saleDay]['manual'] = (float)($sale['sale_total'] ?? 0);
                    $salesByDay[$saleDay]['manual_count'] = (int)($sale['sale_count'] ?? 0);
                }
            }
        } else {
            logDatabaseError($conn, 'Loading manual revenue trend for dashboard');
        }
    } catch (Throwable $exception) {
        logException($exception, 'Loading manual revenue trend for dashboard');
    }

    try {
        $adminActiveTrendResult = $conn->query("SELECT DATE(v.activated_at) AS sale_day,
                COUNT(*) AS sale_count, COALESCE(SUM(COALESCE(v.sold_price, p.price, 0)), 0) AS sale_total
            FROM vouchers v
            LEFT JOIN packages p ON p.id = v.package_id
            WHERE v.source = 'manual' AND v.sold_at IS NULL
              AND v.activated_at IS NOT NULL
              AND v.activated_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
              AND v.activated_at < DATE_ADD(CURDATE(), INTERVAL 1 DAY)
            GROUP BY DATE(v.activated_at)");
        if ($adminActiveTrendResult) {
            while ($sale = $adminActiveTrendResult->fetch_assoc()) {
                $saleDay = (string)($sale['sale_day'] ?? '');
                if (isset($salesByDay[$saleDay])) {
                    $salesByDay[$saleDay]['admin_active'] = (float)($sale['sale_total'] ?? 0);
                    $salesByDay[$saleDay]['admin_active_count'] = (int)($sale['sale_count'] ?? 0);
                }
            }
        } else {
            logDatabaseError($conn, 'Loading activated admin voucher revenue trend for dashboard');
        }
    } catch (Throwable $exception) {
        logException($exception, 'Loading activated admin voucher revenue trend for dashboard');
    }

    $salesToday = 0.0;
    $automaticSalesToday = 0.0;
    $manualSalesToday = 0.0;
    $adminActiveSalesToday = 0.0;
    $automaticCountToday = 0;
    $manualCountToday = 0;
    $adminActiveCountToday = 0;
    $maxDailyRevenue = 0.0;
    foreach ($salesByDay as &$salesDay) {
        $salesDay['total'] = $salesDay['automatic'] + $salesDay['manual'] + $salesDay['admin_active'];
        $maxDailyRevenue = max($maxDailyRevenue, $salesDay['total']);
    }
    unset($salesDay);
    if (isset($salesByDay[$todayKey])) {
        $automaticSalesToday = $salesByDay[$todayKey]['automatic'];
        $manualSalesToday = $salesByDay[$todayKey]['manual'];
        $adminActiveSalesToday = $salesByDay[$todayKey]['admin_active'];
        $automaticCountToday = $salesByDay[$todayKey]['automatic_count'];
        $manualCountToday = $salesByDay[$todayKey]['manual_count'];
        $adminActiveCountToday = $salesByDay[$todayKey]['admin_active_count'];
        $salesToday = $automaticSalesToday + $manualSalesToday + $adminActiveSalesToday;
    }

    $salesAllTime = [
        'automatic_amount' => 0.0,
        'automatic_count' => 0,
        'manual_amount' => 0.0,
        'manual_count' => 0,
        'admin_active_amount' => 0.0,
        'admin_active_count' => 0,
    ];
    try {
        $automaticAllTimeResult = $conn->query("SELECT COUNT(*) AS sale_count, COALESCE(SUM(amount), 0) AS sale_total
            FROM payments WHERE UPPER(COALESCE(status, '')) = 'SUCCESS'");
        if ($automaticAllTimeResult) {
            $automaticAllTime = $automaticAllTimeResult->fetch_assoc() ?: [];
            $salesAllTime['automatic_count'] = (int)($automaticAllTime['sale_count'] ?? 0);
            $salesAllTime['automatic_amount'] = (float)($automaticAllTime['sale_total'] ?? 0);
        } else {
            logDatabaseError($conn, 'Loading all-time automatic sales for dashboard');
        }
    } catch (Throwable $exception) {
        logException($exception, 'Loading all-time automatic sales for dashboard');
    }
    try {
        $manualAllTimeResult = $conn->query("SELECT COUNT(*) AS sale_count, COALESCE(SUM(sold_price), 0) AS sale_total
            FROM vouchers WHERE source = 'manual' AND sold_at IS NOT NULL");
        if ($manualAllTimeResult) {
            $manualAllTime = $manualAllTimeResult->fetch_assoc() ?: [];
            $salesAllTime['manual_count'] = (int)($manualAllTime['sale_count'] ?? 0);
            $salesAllTime['manual_amount'] = (float)($manualAllTime['sale_total'] ?? 0);
        } else {
            logDatabaseError($conn, 'Loading all-time manual sales for dashboard');
        }
    } catch (Throwable $exception) {
        logException($exception, 'Loading all-time manual sales for dashboard');
    }
    try {
        $adminActiveAllTimeResult = $conn->query("SELECT COUNT(*) AS sale_count, COALESCE(SUM(COALESCE(v.sold_price, p.price, 0)), 0) AS sale_total
            FROM vouchers v LEFT JOIN packages p ON p.id = v.package_id
            WHERE v.source = 'manual' AND v.sold_at IS NULL
              AND v.activated_at IS NOT NULL");
        if ($adminActiveAllTimeResult) {
            $adminActiveAllTime = $adminActiveAllTimeResult->fetch_assoc() ?: [];
            $salesAllTime['admin_active_count'] = (int)($adminActiveAllTime['sale_count'] ?? 0);
            $salesAllTime['admin_active_amount'] = (float)($adminActiveAllTime['sale_total'] ?? 0);
        } else {
            logDatabaseError($conn, 'Loading activated admin voucher sales for dashboard');
        }
    } catch (Throwable $exception) {
        logException($exception, 'Loading activated admin voucher sales for dashboard');
    }
    $salesAllTime['total_count'] = $salesAllTime['automatic_count'] + $salesAllTime['manual_count'] + $salesAllTime['admin_active_count'];
    $salesAllTime['total_amount'] = $salesAllTime['automatic_amount'] + $salesAllTime['manual_amount'] + $salesAllTime['admin_active_amount'];

    $chartPointList = [];
    $chartPointCount = count($salesByDay);
    $chartIndex = 0;
    foreach ($salesByDay as $salesDay) {
        $chartX = $chartPointCount > 1 ? (int)round($chartIndex * 1000 / ($chartPointCount - 1)) : 500;
        $chartY = 172 - (int)round(($salesDay['total'] / max(1, $maxDailyRevenue)) * 132);
        $chartPointList[] = $chartX . ',' . $chartY;
        $chartIndex++;
    }
    $chartPoints = implode(' ', $chartPointList);
    $chartAreaPath = 'M 0 176 L ' . implode(' L ', $chartPointList) . ' L 1000 176 Z';

    $recentActivity = [];
    try {
        $recentPaymentsResult = $conn->query("SELECT pay.id, pay.amount, pay.status, pay.payment_method,
                COALESCE(pay.paid_at, pay.created_at) AS activity_at, p.name AS package_name
            FROM payments pay
            LEFT JOIN packages p ON p.id = pay.package_id
            ORDER BY COALESCE(pay.paid_at, pay.created_at) DESC, pay.id DESC
            LIMIT 6");
        if ($recentPaymentsResult) {
            while ($payment = $recentPaymentsResult->fetch_assoc()) {
                $recentActivity[] = [
                    'kind' => 'Automatic',
                    'name' => trim((string)($payment['package_name'] ?? '')) !== '' ? (string)$payment['package_name'] : 'Wi-Fi voucher',
                    'detail' => trim((string)($payment['payment_method'] ?? '')) !== '' ? (string)$payment['payment_method'] : 'Online payment',
                    'status' => strtoupper(trim((string)($payment['status'] ?? 'Pending'))),
                    'amount' => (float)($payment['amount'] ?? 0),
                    'at' => (string)($payment['activity_at'] ?? ''),
                ];
            }
        } else {
            logDatabaseError($conn, 'Loading recent automatic payments for dashboard');
        }
    } catch (Throwable $exception) {
        logException($exception, 'Loading recent automatic payments for dashboard');
    }

    try {
        $recentManualResult = $conn->query("SELECT v.id, v.sold_price, v.sold_at, p.name AS package_name
            FROM vouchers v
            LEFT JOIN packages p ON p.id = v.package_id
            WHERE v.source = 'manual' AND v.sold_at IS NOT NULL
            ORDER BY v.sold_at DESC, v.id DESC
            LIMIT 6");
        if ($recentManualResult) {
            while ($sale = $recentManualResult->fetch_assoc()) {
                $recentActivity[] = [
                    'kind' => 'Cash sale',
                    'name' => trim((string)($sale['package_name'] ?? '')) !== '' ? (string)$sale['package_name'] : 'Wi-Fi voucher',
                    'detail' => 'Recorded by admin',
                    'status' => 'SOLD',
                    'amount' => (float)($sale['sold_price'] ?? 0),
                    'at' => (string)($sale['sold_at'] ?? ''),
                ];
            }
        } else {
            logDatabaseError($conn, 'Loading recent cash sales for dashboard');
        }
    } catch (Throwable $exception) {
        logException($exception, 'Loading recent cash sales for dashboard');
    }

    try {
        $recentAdminActiveResult = $conn->query("SELECT v.id, v.status, v.activated_at, p.name AS package_name, COALESCE(v.sold_price, p.price, 0) AS package_price
            FROM vouchers v
            LEFT JOIN packages p ON p.id = v.package_id
            WHERE v.source = 'manual' AND v.sold_at IS NULL
              AND v.activated_at IS NOT NULL
            ORDER BY v.activated_at DESC, v.id DESC
            LIMIT 6");
        if ($recentAdminActiveResult) {
            while ($sale = $recentAdminActiveResult->fetch_assoc()) {
                $recentActivity[] = [
                    'kind' => 'Admin voucher sale',
                    'name' => trim((string)($sale['package_name'] ?? '')) !== '' ? (string)$sale['package_name'] : 'Wi-Fi voucher',
                    'detail' => 'Sales record kept after expiry',
                    'status' => strtoupper((string)($sale['status'] ?? 'ACTIVE')),
                    'amount' => (float)($sale['package_price'] ?? 0),
                    'at' => (string)($sale['activated_at'] ?? ''),
                ];
            }
        } else {
            logDatabaseError($conn, 'Loading recently activated admin vouchers for dashboard');
        }
    } catch (Throwable $exception) {
        logException($exception, 'Loading recently activated admin vouchers for dashboard');
    }
    usort($recentActivity, static fn(array $left, array $right): int => strcmp($right['at'], $left['at']));
    $recentActivity = array_slice($recentActivity, 0, 7);

    $popularPackages = [];
    try {
        $packageResult = $conn->query("SELECT p.id, p.name, p.price, p.duration_minutes, p.speed_limit,
                COUNT(v.id) AS voucher_count
            FROM packages p
            LEFT JOIN vouchers v ON v.package_id = p.id AND v.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY p.id, p.name, p.price, p.duration_minutes, p.speed_limit
            ORDER BY voucher_count DESC, p.name ASC
            LIMIT 5");
        if ($packageResult) {
            while ($package = $packageResult->fetch_assoc()) {
                $popularPackages[] = $package;
            }
        } else {
            logDatabaseError($conn, 'Loading package overview for dashboard');
        }
    } catch (Throwable $exception) {
        logException($exception, 'Loading package overview for dashboard');
    }

    $voucherBreakdown = ['unused' => 0, 'active' => $stats['active_vouchers'], 'expired' => $stats['expired_vouchers']];
    try {
        $voucherBreakdownResult = $conn->query("SELECT
                SUM(status = 'unused') AS unused,
                SUM(status = 'active') AS active,
                SUM(status = 'expired') AS expired
            FROM vouchers");
        if ($voucherBreakdownResult) {
            $voucherBreakdownRow = $voucherBreakdownResult->fetch_assoc() ?: [];
            $voucherBreakdown['unused'] = (int)($voucherBreakdownRow['unused'] ?? 0);
            $voucherBreakdown['active'] = (int)($voucherBreakdownRow['active'] ?? 0);
            $voucherBreakdown['expired'] = (int)($voucherBreakdownRow['expired'] ?? 0);
        } else {
            logDatabaseError($conn, 'Loading voucher status breakdown for dashboard');
        }
    } catch (Throwable $exception) {
        logException($exception, 'Loading voucher status breakdown for dashboard');
    }

    ?>
    <style>
        .dashboard-page{--dashboard-accent:#e87537;max-width:1500px;margin:0 auto;padding:10px;color:#0f172a}
        .dashboard-page a{text-decoration:none}
        .dashboard-heading{display:flex;align-items:flex-end;justify-content:space-between;gap:18px;margin:0 0 18px}
        .dashboard-heading-copy .eyebrow{margin-bottom:5px;color:#64748b;font-size:10px;font-weight:750;letter-spacing:.09em;text-transform:uppercase}
        .dashboard-heading h2{margin:0;color:#111827;font-size:24px;line-height:1.2;font-weight:750}
        .dashboard-heading p{margin:6px 0 0;color:#64748b;font-size:12px}
        .dashboard-heading-actions{display:flex;gap:8px}
        .dashboard-action{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:39px;padding:0 13px;border:1px solid #e7e3df;border-radius:12px;background:#fff;color:#334155;font-size:11px;font-weight:750}
        .dashboard-action:hover{background:#fff8f3;color:#111827}.dashboard-action.is-primary{border-color:#e87537;background:#e87537;color:#fff}.dashboard-action.is-primary:hover{border-color:#ce5b25;background:#ce5b25}
        .dashboard-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;margin-bottom:14px}
        .dashboard-kpi,.dashboard-card{min-width:0;border:1px solid #e5eaf0;border-radius:13px;background:#fff;box-shadow:0 4px 15px rgba(15,23,42,.035)}
        .dashboard-wallet-kpi{border-color:#bbf7d0;background:linear-gradient(110deg,#ecfdf5,#fff 78%)}
        .dashboard-wallet-kpi .dashboard-kpi-icon{background:#d1fae5;color:#047857}
        .dashboard-wallet-kpi .dashboard-kpi-value{overflow:hidden;font-size:18px;text-overflow:ellipsis}
        .dashboard-wallet-kpi .dashboard-kpi-value small{color:#64748b;font-size:10px}
        .dashboard-wallet-kpi .dashboard-kpi-help{min-height:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

        .dashboard-kpi{padding:15px 16px}
        .dashboard-kpi-top{display:flex;align-items:center;justify-content:space-between;gap:8px;color:#64748b;font-size:10px;font-weight:700}
        .dashboard-kpi-icon{width:34px;height:34px;display:grid;place-items:center;border-radius:10px;background:#fff1e8;color:#d9692e;font-size:14px}
        .dashboard-kpi-icon.is-green{background:#ecfdf5;color:#059669}.dashboard-kpi-icon.is-amber{background:#fffbeb;color:#d97706}.dashboard-kpi-icon.is-violet{background:#f5f3ff;color:#7c3aed}
        .dashboard-kpi-value{display:block;margin-top:11px;color:#111827;font-size:22px;line-height:1.2;font-weight:800;white-space:nowrap}
        .dashboard-kpi-value.is-money{font-size:19px}.dashboard-kpi-help{display:block;margin-top:5px;color:#94a3b8;font-size:9px}
        .dashboard-analytics-grid{display:grid;grid-template-columns:minmax(0,1.8fr) minmax(245px,.8fr);gap:13px;margin-bottom:13px}
        .dashboard-card{overflow:hidden}
        .dashboard-card-heading{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 16px;border-bottom:1px solid #edf0f4}
        .dashboard-card-heading h3{margin:0;color:#111827;font-size:12px;font-weight:750}.dashboard-card-heading p{margin:4px 0 0;color:#94a3b8;font-size:9px;line-height:1.4}
        .dashboard-card-tag{display:inline-flex;align-items:center;gap:5px;padding:5px 8px;border-radius:20px;background:#f1f5f9;color:#64748b;font-size:8px;font-weight:750;white-space:nowrap}
        .dashboard-chart-wrap{padding:9px 15px 13px}.dashboard-chart{display:block;width:100%;height:174px;overflow:visible}
        .dashboard-chart-labels{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:2px;margin-top:1px;color:#94a3b8;text-align:center;font-size:8px}
        .dashboard-legend{display:flex;gap:14px;margin:7px 0 0;color:#64748b;font-size:9px}.dashboard-legend span{display:flex;align-items:center;gap:6px}.dashboard-legend i{width:7px;height:7px;border-radius:50%;background:#e87537}.dashboard-legend i.is-cash{background:#14b8a6}
        .dashboard-today-list{display:grid;gap:0;padding:3px 15px 10px}.dashboard-today-row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 0;border-bottom:1px solid #f1f5f9}.dashboard-today-row:last-child{border-bottom:0}
        .dashboard-today-label{display:flex;align-items:center;gap:8px;color:#64748b;font-size:10px}.dashboard-today-label i{width:25px;height:25px;display:grid;place-items:center;border-radius:8px;background:#fff1e8;color:#d9692e;font-size:10px}.dashboard-today-label i.is-cash{background:#ecfdf5;color:#059669}.dashboard-today-label i.is-pending{background:#fffbeb;color:#d97706}
        .dashboard-today-value{text-align:right}.dashboard-today-value strong{display:block;color:#172033;font-size:11px}.dashboard-today-value small{display:block;margin-top:3px;color:#94a3b8;font-size:8px}
        .dashboard-content-grid{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(300px,.9fr);gap:13px;margin-bottom:13px}
        .dashboard-table-wrap{width:100%;overflow-x:auto}.dashboard-table{width:100%;min-width:560px;border-collapse:collapse}.dashboard-table th{padding:9px 12px;border-bottom:1px solid #edf0f4;background:#f8fafc;color:#94a3b8;text-align:left;font-size:8px;font-weight:750;letter-spacing:.04em;text-transform:uppercase;white-space:nowrap}.dashboard-table td{padding:10px 12px;border-bottom:1px solid #f1f5f9;color:#475569;font-size:9px;vertical-align:middle}.dashboard-table tbody tr:last-child td{border-bottom:0}.dashboard-table td strong{display:block;color:#172033;font-size:9px}.dashboard-table td small{display:block;margin-top:3px;color:#94a3b8;font-size:8px}.dashboard-table td.amount{text-align:right;color:#111827;font-weight:750;white-space:nowrap}
        .dashboard-state{display:inline-flex;align-items:center;padding:4px 7px;border-radius:20px;background:#f1f5f9;color:#64748b;font-size:8px;font-weight:750;white-space:nowrap}.dashboard-state.is-success{background:#ecfdf5;color:#15803d}.dashboard-state.is-pending{background:#fffbeb;color:#b45309}.dashboard-state.is-expired{background:#f1f5f9;color:#64748b}.dashboard-state.is-failed{background:#fef2f2;color:#b91c1c}
        .dashboard-empty{padding:24px 16px;color:#94a3b8;text-align:center;font-size:10px}.dashboard-empty i{display:block;margin-bottom:7px;color:#cbd5e1;font-size:19px}
        .dashboard-package-list{display:grid;padding:2px 15px}.dashboard-package-row{display:grid;grid-template-columns:32px minmax(0,1fr) auto;align-items:center;gap:9px;padding:11px 0;border-bottom:1px solid #f1f5f9}.dashboard-package-row:last-child{border-bottom:0}
        .dashboard-package-icon{width:30px;height:30px;display:grid;place-items:center;border-radius:9px;background:#fff1e8;color:#d9692e;font-size:11px}.dashboard-package-main{min-width:0}.dashboard-package-main strong{display:block;overflow:hidden;color:#172033;font-size:9px;text-overflow:ellipsis;white-space:nowrap}.dashboard-package-main small{display:block;margin-top:3px;color:#94a3b8;font-size:8px}.dashboard-package-count{color:#334155;text-align:right;font-size:9px;font-weight:750}.dashboard-package-count small{display:block;margin-top:3px;color:#94a3b8;font-size:8px;font-weight:500}
        .dashboard-bottom-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px;margin-bottom:14px}.dashboard-status-list{display:grid;padding:4px 15px 10px}.dashboard-status-row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 0;border-bottom:1px solid #f1f5f9}.dashboard-status-row:last-child{border-bottom:0}.dashboard-status-row span{color:#64748b;font-size:9px}.dashboard-status-row strong{color:#172033;font-size:10px}.dashboard-status-link{color:#cf642f!important;font-size:9px!important;font-weight:750;text-decoration:none}.dashboard-status-link:hover{text-decoration:underline}
        .dashboard-shortcuts{display:flex;flex-wrap:wrap;gap:7px;padding:12px 15px 15px}.dashboard-shortcut{display:inline-flex;align-items:center;gap:6px;min-height:30px;padding:0 9px;border:1px solid #e2e8f0;border-radius:8px;background:#fff;color:#475569;font-size:8px;font-weight:700}.dashboard-shortcut:hover{border-color:#f0c8af;background:#fff8f3;color:#a34f26}
        @media(max-width:1180px){.dashboard-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}.dashboard-analytics-grid{grid-template-columns:minmax(0,1.4fr) minmax(230px,.8fr)}.dashboard-bottom-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
        @media(max-width:850px){.dashboard-analytics-grid,.dashboard-content-grid{grid-template-columns:1fr}.dashboard-content-grid{gap:12px}.dashboard-heading{align-items:flex-start;flex-direction:column}.dashboard-heading-actions{width:100%;flex-wrap:wrap}.dashboard-heading-actions .dashboard-action{flex:1}}
        @media(max-width:560px){.dashboard-kpis,.dashboard-bottom-grid{grid-template-columns:1fr 1fr;gap:8px}.dashboard-kpi{padding:12px}.dashboard-kpi-value{font-size:18px}.dashboard-kpi-value.is-money{font-size:16px}.dashboard-kpi-help{line-height:1.4}.dashboard-bottom-grid .dashboard-card:last-child{grid-column:auto}.dashboard-heading h2{font-size:21px}.dashboard-heading-actions{flex-direction:column}.dashboard-chart-wrap{padding:8px}.dashboard-chart{height:150px}.dashboard-card-heading{align-items:flex-start}.dashboard-card-tag{font-size:7px}}
        @media(max-width:390px){.dashboard-kpis,.dashboard-bottom-grid{grid-template-columns:1fr}.dashboard-kpi{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center}.dashboard-kpi-top{grid-column:1/2}.dashboard-kpi-icon{grid-column:2;grid-row:1/3}.dashboard-kpi-value,.dashboard-kpi-help{grid-column:1}.dashboard-kpi-value{margin-top:5px}}
    </style>

    <div class="dashboard-page">
        <section class="dashboard-heading">
            <div class="dashboard-heading-copy">
                <div class="eyebrow">Wi‑Fi voucher control center</div>
                <h2>Welcome, <?= e(currentAdminName()) ?></h2>
                <p>An overview of sales, vouchers, and your Wi-Fi services.</p>
            </div>
            <div class="dashboard-heading-actions">
                                <a class="dashboard-action is-primary" href="<?= e(appUrl('admin/dashboard.php?page=vouchers&action=create')) ?>"><i class="fa-solid fa-ticket"></i> Create voucher</a>
                <a class="dashboard-action" href="<?= e(appUrl('admin/dashboard.php?page=payments&action=manual_sales')) ?>"><i class="fa-solid fa-cash-register"></i> Cash sales</a>
            </div>
        </section>

        <section class="dashboard-kpis" aria-label="Today's overview">
            <article class="dashboard-kpi"><div class="dashboard-kpi-top"><span>Total counted sales</span><i class="dashboard-kpi-icon is-green fa-solid fa-sack-dollar"></i></div><strong class="dashboard-kpi-value is-money"><?= e(formatMoney($salesAllTime['total_amount'])) ?></strong><small class="dashboard-kpi-help"><?= number_format($salesAllTime['total_count']) ?> sales · <?= e(formatMoney($salesToday)) ?> today</small></article>
            <article class="dashboard-kpi"><div class="dashboard-kpi-top"><span>Online sales · all time</span><i class="dashboard-kpi-icon fa-solid fa-mobile-screen-button"></i></div><strong class="dashboard-kpi-value"><?= number_format($salesAllTime['automatic_count']) ?></strong><small class="dashboard-kpi-help"><?= e(formatMoney($salesAllTime['automatic_amount'])) ?> total</small></article>
            <article class="dashboard-kpi"><div class="dashboard-kpi-top"><span>Cash sales · all time</span><i class="dashboard-kpi-icon is-violet fa-solid fa-money-bill-wave"></i></div><strong class="dashboard-kpi-value"><?= number_format($salesAllTime['manual_count']) ?></strong><small class="dashboard-kpi-help"><?= e(formatMoney($salesAllTime['manual_amount'])) ?> total</small></article>
            <article class="dashboard-kpi"><div class="dashboard-kpi-top"><span>Admin-activated vouchers</span><i class="dashboard-kpi-icon is-amber fa-solid fa-ticket"></i></div><strong class="dashboard-kpi-value"><?= number_format($salesAllTime['admin_active_count']) ?></strong><small class="dashboard-kpi-help"><?= e(formatMoney($salesAllTime['admin_active_amount'])) ?> · records remain after expiry</small></article>
            <article class="dashboard-kpi"><div class="dashboard-kpi-top"><span>Vouchers active</span><i class="dashboard-kpi-icon is-amber fa-solid fa-wifi"></i></div><strong class="dashboard-kpi-value"><?= number_format($stats['active_vouchers']) ?></strong><small class="dashboard-kpi-help">Currently in use</small></article>
            <?php if (is_array($dashboardWalletChannel)): ?>
                <?php $dashboardWalletProviderLabel = (string)($dashboardWalletChannel['provider_label'] ?? 'Payment provider'); ?>
                <article class="dashboard-kpi dashboard-wallet-kpi" id="dashboard-wallet-card" data-wallet-balance-widget data-endpoint="<?= e(appUrl('admin/modules/wallet/balance.php')) ?>" data-form-id="dashboard-wallet-refresh-form" data-channel-id="<?= (int)$dashboardWalletChannel['id'] ?>" data-checked-at="<?= (int)$dashboardWalletCheckedAt ?>" data-has-balance="<?= $dashboardWalletBalance !== null ? '1' : '0' ?>">
                    <div class="dashboard-kpi-top"><span><?= e($dashboardWalletProviderLabel) ?> balance</span><i class="dashboard-kpi-icon fa-solid fa-building-columns"></i></div>
                    <?php if ($dashboardWalletBalance !== null): ?>
                        <strong class="dashboard-kpi-value is-money js-wallet-balance-value"><?= number_format($dashboardWalletBalance['balance'], 2) ?> <small><?= e($dashboardWalletBalance['currency']) ?></small></strong>
                        <small class="dashboard-kpi-help js-wallet-balance-status" role="status" aria-live="polite"><?= $dashboardWalletCheckedAt > 0 ? 'Last updated ' . e(date('M j, g:i A', $dashboardWalletCheckedAt)) : 'Loading the latest balance…' ?></small>
                    <?php else: ?>
                        <strong class="dashboard-kpi-value is-money js-wallet-balance-value">Loading…</strong>
                        <small class="dashboard-kpi-help js-wallet-balance-status" role="status" aria-live="polite">Loading balance automatically.</small>
                    <?php endif; ?>
                    <form id="dashboard-wallet-refresh-form" hidden><?= csrfField() ?></form>
                </article>
            <?php endif; ?>
        </section>
        <?php if (is_array($dashboardWalletChannel)): ?>
            <script src="<?= e(appUrl('admin/modules/wallet/balance-widget.js?v=1')) ?>" defer></script>
        <?php endif; ?>

        <section class="dashboard-analytics-grid">
            <article class="dashboard-card">
                <header class="dashboard-card-heading"><div><h3>Sales trend</h3><p>Online payments, recorded cash sales, and administrator-activated vouchers · 7 days</p></div><span class="dashboard-card-tag"><i class="fa-solid fa-calendar-week"></i> 7 days</span></header>
                <div class="dashboard-chart-wrap">
                    <svg class="dashboard-chart" viewBox="0 0 1000 190" preserveAspectRatio="none" role="img" aria-label="Seven-day revenue trend">
                        <defs><linearGradient id="dashboardRevenueFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#e87537" stop-opacity=".22"/><stop offset="100%" stop-color="#e87537" stop-opacity=".01"/></linearGradient></defs>
                        <line x1="0" y1="44" x2="1000" y2="44" stroke="#eef2f7"/><line x1="0" y1="88" x2="1000" y2="88" stroke="#eef2f7"/><line x1="0" y1="132" x2="1000" y2="132" stroke="#eef2f7"/><line x1="0" y1="176" x2="1000" y2="176" stroke="#e5eaf0"/>
                        <path d="<?= e($chartAreaPath) ?>" fill="url(#dashboardRevenueFill)"/><polyline points="<?= e($chartPoints) ?>" fill="none" stroke="#e87537" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>
                        <?php foreach (array_values($salesByDay) as $pointIndex => $salesDay): ?><?php $pointX = $chartPointCount > 1 ? (int)round($pointIndex * 1000 / ($chartPointCount - 1)) : 500; $pointY = 172 - (int)round(($salesDay['total'] / max(1, $maxDailyRevenue)) * 132); ?><circle cx="<?= $pointX ?>" cy="<?= $pointY ?>" r="5" fill="#fff" stroke="#e87537" stroke-width="3" vector-effect="non-scaling-stroke"><title><?= e($salesDay['label'] . ': ' . formatMoney($salesDay['total'])) ?></title></circle><?php endforeach; ?>
                    </svg>
                    <div class="dashboard-chart-labels"><?php foreach ($salesByDay as $salesDay): ?><span><?= e($salesDay['label']) ?></span><?php endforeach; ?></div>
                    <div class="dashboard-legend"><span><i></i> Revenue received (online and cash)</span></div>
                </div>
            </article>

            <article class="dashboard-card">
                <header class="dashboard-card-heading"><div><h3>Today's sales</h3><p>Breakdown by sales channel</p></div><span class="dashboard-card-tag"><i class="fa-regular fa-clock"></i> Today</span></header>
                <div class="dashboard-today-list">
                    <div class="dashboard-today-row"><div class="dashboard-today-label"><i class="fa-solid fa-mobile-screen-button"></i><span>Online payments</span></div><div class="dashboard-today-value"><strong><?= e(formatMoney($automaticSalesToday)) ?></strong><small><?= number_format($automaticCountToday) ?> successful payments</small></div></div>
                    <div class="dashboard-today-row"><div class="dashboard-today-label"><i class="is-cash fa-solid fa-cash-register"></i><span>Cash sales</span></div><div class="dashboard-today-value"><strong><?= e(formatMoney($manualSalesToday)) ?></strong><small><?= number_format($manualCountToday) ?> recorded sales</small></div></div>
                    <div class="dashboard-today-row"><div class="dashboard-today-label"><i class="is-pending fa-solid fa-ticket"></i><span>Administrator-activated voucher sales</span></div><div class="dashboard-today-value"><strong><?= e(formatMoney($adminActiveSalesToday)) ?></strong><small><?= number_format($adminActiveCountToday) ?> activated today</small></div></div>
                    <div class="dashboard-today-row"><div class="dashboard-today-label"><i class="is-pending fa-solid fa-hourglass-half"></i><span>Pending payments</span></div><div class="dashboard-today-value"><strong><?= number_format($stats['pending']) ?></strong><small>Total pending payments</small></div></div>
                </div>
            </article>
        </section>

        <section class="dashboard-content-grid">
            <article class="dashboard-card">
                <header class="dashboard-card-heading"><div><h3>Recent transactions</h3><p>Online payments and recorded cash sales</p></div><a class="dashboard-status-link" href="<?= e(appUrl('admin/dashboard.php?page=payments')) ?>">View all <i class="fa-solid fa-arrow-right"></i></a></header>
                <?php if ($recentActivity): ?>
                    <div class="dashboard-table-wrap"><table class="dashboard-table"><thead><tr><th>Type</th><th>Package</th><th>Status</th><th>Time</th><th class="amount">Amount</th></tr></thead><tbody>
                        <?php foreach ($recentActivity as $activity): ?>
                            <?php $statusClass = in_array($activity['status'], ['SUCCESS', 'SOLD', 'ACTIVE'], true) ? 'is-success' : (in_array($activity['status'], ['PENDING', 'PROCESSING'], true) ? 'is-pending' : ($activity['status'] === 'EXPIRED' ? 'is-expired' : 'is-failed')); $activityTimestamp = strtotime($activity['at']); ?>
                            <tr><td><strong><?= e($activity['kind']) ?></strong><small><?= e($activity['detail']) ?></small></td><td><?= e($activity['name']) ?></td><td><span class="dashboard-state <?= $statusClass ?>"><?= e($activity['status'] === 'SOLD' ? 'Sold' : ucfirst(strtolower($activity['status']))) ?></span></td><td><?= $activityTimestamp ? e(date('d M, H:i', $activityTimestamp)) : '—' ?></td><td class="amount"><?= e(formatMoney($activity['amount'])) ?></td></tr>
                        <?php endforeach; ?>
                    </tbody></table></div>
                <?php else: ?><div class="dashboard-empty"><i class="fa-solid fa-receipt"></i>No transactions or recorded sales yet.</div><?php endif; ?>
            </article>

            <article class="dashboard-card">
                <header class="dashboard-card-heading"><div><h3>Packages and vouchers</h3><p>Vouchers generated in the last 30 days</p></div><a class="dashboard-status-link" href="<?= e(appUrl('admin/dashboard.php?page=packages')) ?>">Packages <i class="fa-solid fa-arrow-right"></i></a></header>
                <?php if ($popularPackages): ?>
                    <div class="dashboard-package-list">
                        <?php foreach ($popularPackages as $package): ?>
                            <?php $durationMinutes = (int)($package['duration_minutes'] ?? 0); $durationLabel = $durationMinutes >= 1440 ? number_format($durationMinutes / 1440, 1) . ' days' : ($durationMinutes >= 60 ? number_format($durationMinutes / 60, 1) . ' hours' : number_format($durationMinutes) . ' minutes'); ?>
                            <div class="dashboard-package-row"><span class="dashboard-package-icon"><i class="fa-solid fa-box"></i></span><div class="dashboard-package-main"><strong><?= e((string)$package['name']) ?></strong><small><?= e($durationLabel) ?> · <?= e((string)($package['speed_limit'] ?: 'Speed not set')) ?></small></div><div class="dashboard-package-count"><?= number_format((int)$package['voucher_count']) ?><small>vouchers</small></div></div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?><div class="dashboard-empty"><i class="fa-solid fa-box-open"></i>There are no packages to display yet.</div><?php endif; ?>
            </article>
        </section>

        <section class="dashboard-bottom-grid">
            <article class="dashboard-card">
                <header class="dashboard-card-heading"><div><h3>Voucher status</h3><p>Breakdown of existing vouchers</p></div><a class="dashboard-status-link" href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>">Vouchers</a></header>
                <div class="dashboard-status-list"><div class="dashboard-status-row"><span><i class="fa-solid fa-ticket"></i> Unused</span><strong><?= number_format($voucherBreakdown['unused']) ?></strong></div><div class="dashboard-status-row"><span><i class="fa-solid fa-wifi"></i> Active</span><strong><?= number_format($voucherBreakdown['active']) ?></strong></div><div class="dashboard-status-row"><span><i class="fa-solid fa-clock-rotate-left"></i> Expired</span><strong><?= number_format($voucherBreakdown['expired']) ?></strong></div></div>
            </article>
            <article class="dashboard-card">
                <header class="dashboard-card-heading"><div><h3>Payment status</h3><p>Total transactions received</p></div><a class="dashboard-status-link" href="<?= e(appUrl('admin/dashboard.php?page=payments')) ?>">Payments</a></header>
                <div class="dashboard-status-list"><div class="dashboard-status-row"><span><i class="fa-solid fa-circle-check"></i> Successful</span><strong><?= number_format($stats['successful']) ?></strong></div><div class="dashboard-status-row"><span><i class="fa-solid fa-hourglass-half"></i> Pending</span><strong><?= number_format($stats['pending']) ?></strong></div><div class="dashboard-status-row"><span><i class="fa-solid fa-circle-xmark"></i> Failed</span><strong><?= number_format($stats['failed']) ?></strong></div></div>
            </article>
        </section>
    </div>
    <?php

} else {

    /*
    |--------------------------------------------------------------------------
    | MODULE
    |--------------------------------------------------------------------------
    */

    $moduleDirectory = __DIR__ . '/modules/' . $page;
    $moduleIndex = $moduleDirectory . '/index.php';

    if (is_file($moduleIndex)) {

        require $moduleIndex;

    } else {

        ?>

        <div class="module-page">

            <div class="module-placeholder">

                <div class="module-placeholder-icon">
                    <i class="fa-solid fa-puzzle-piece"></i>
                </div>

                <h2>
                    <?= e($pageTitle) ?>
                </h2>

                <p>This section is not available in this installation.</p>

            </div>

        </div>

        <?php
    }
}


/*
|--------------------------------------------------------------------------
| Shared Footer
|--------------------------------------------------------------------------
*/

require __DIR__ . '/includes/admin_footer.php';
