<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/admin_auth.php';
require_once __DIR__ . '/functions.php';

requireAdminRole(['admin', 'super_admin', 'superadmin']);
requireAdminPostWithCsrf();

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, private');

$respond = static function (array $payload, int $status = 200): void {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
};

$channelId = filter_var($_POST['channel_id'] ?? null, FILTER_VALIDATE_INT) ?: 0;
$forceRefresh = ($_POST['force'] ?? '') === '1';
if ($channelId < 1) {
    $respond(['success' => false, 'message' => 'Choose a valid payment account.'], 400);
}

$cacheKey = 'admin_wallet_balance_' . $channelId;
$cached = $_SESSION[$cacheKey] ?? null;
if (!$forceRefresh && is_array($cached)
    && is_numeric($cached['balance'] ?? null)
    && is_string($cached['currency'] ?? null)
    && (int)($cached['checked_at'] ?? 0) > 0
    && time() - (int)$cached['checked_at'] < 300) {
    $respond([
        'success' => true,
        'balance' => (float)$cached['balance'],
        'currency' => strtoupper((string)$cached['currency']),
        'checked_at' => (int)$cached['checked_at'],
        'cached' => true,
    ]);
}

try {
    global $conn;
    if (!($conn instanceof mysqli)) {
        throw new RuntimeException('The database connection is not available.');
    }
    $config = adminWalletLoadPayoutConfig($conn, $channelId);
    $balance = adminWalletGetBalance($config);
    $entry = [
        'balance' => (float)$balance['balance'],
        'currency' => strtoupper((string)$balance['currency']),
        'provider_key' => (string)$config['provider_key'],
        'checked_at' => time(),
    ];
    $_SESSION[$cacheKey] = $entry;
    $respond([
        'success' => true,
        'balance' => $entry['balance'],
        'currency' => $entry['currency'],
        'checked_at' => $entry['checked_at'],
        'cached' => false,
    ]);
} catch (Throwable $exception) {
    if (function_exists('appLog')) {
        appLog('Automatic admin wallet balance refresh failed', [
            'channel_id' => $channelId,
            'error' => $exception->getMessage(),
        ]);
    }
    $respond(['success' => false, 'message' => $exception->getMessage()], 502);
}
