<?php
declare(strict_types=1);

ini_set('session.use_strict_mode', '1');
session_set_cookie_params([
    'httponly' => true,
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'samesite' => 'Strict',
]);
session_start();

require_once dirname(__DIR__) . '/config/app.php';
require_once dirname(__DIR__) . '/config/security.php';
require_once dirname(__DIR__) . '/includes/payment_provider_catalog.php';
require_once dirname(__DIR__) . '/includes/payment_provider_adapters.php';

/*
 * Local live ClickPesa USSD-PUSH test page.
 * A voucher is issued only after ClickPesa status lookup confirms the exact
 * order reference, amount and TZS currency as successful.
 */

const CLICKPESA_API_BASE = 'https://api.clickpesa.com/third-parties';
const TEST_MAX_AMOUNT_TZS = 5000;

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function readEnvFile(string $path): array
{
    if (!is_file($path) || !is_readable($path)) {
        throw new RuntimeException('The .env file was not found or cannot be read from the project root.');
    }

    $values = [];
    foreach (file($path, FILE_IGNORE_NEW_LINES) ?: [] as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) {
            continue;
        }
        [$key, $value] = explode('=', $line, 2);
        $key = trim($key);
        $value = trim($value);
        if ($value !== '' && strlen($value) >= 2) {
            $first = $value[0];
            $last = $value[strlen($value) - 1];
            if (($first === '"' && $last === '"') || ($first === "'" && $last === "'")) {
                $value = substr($value, 1, -1);
            }
        }
        $values[$key] = $value;
    }
    return $values;
}

function cpRequest(string $path, string $method, ?array $payload = null, array $extraHeaders = [], string $apiBase = CLICKPESA_API_BASE): array
{
    if (!function_exists('curl_init')) {
        throw new RuntimeException('PHP cURL is not enabled on the server. Enable cURL in your PHP hosting configuration.');
    }

    $headers = array_merge(['Accept: application/json'], $extraHeaders);
    $options = [
        CURLOPT_URL => rtrim($apiBase, '/') . $path,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 25,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
    ];

    if ($payload !== null) {
        $json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $options[CURLOPT_POSTFIELDS] = $json;
        $options[CURLOPT_HTTPHEADER][] = 'Content-Type: application/json';
    }

    $curl = curl_init();
    curl_setopt_array($curl, $options);
    $raw = curl_exec($curl);
    $curlError = curl_error($curl);
    $httpCode = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);

    if ($raw === false) {
        throw new RuntimeException('Unable to connect to ClickPesa: ' . ($curlError ?: 'network error.'));
    }

    $decoded = json_decode((string) $raw, true);
    if (!is_array($decoded)) {
        throw new RuntimeException('ClickPesa returned an unrecognized response (HTTP ' . $httpCode . ').');
    }
    if ($httpCode < 200 || $httpCode >= 300) {
        $message = (string) ($decoded['message'] ?? $decoded['error'] ?? 'The request was rejected.');
        throw new RuntimeException('ClickPesa (HTTP ' . $httpCode . '): ' . $message);
    }
    return $decoded;
}

function canonicalizePayload(mixed $value): mixed
{
    if (!is_array($value)) {
        return $value;
    }
    if (array_is_list($value)) {
        return array_map('canonicalizePayload', $value);
    }
    ksort($value, SORT_STRING);
    foreach ($value as $key => $item) {
        $value[$key] = canonicalizePayload($item);
    }
    return $value;
}

function addPayloadChecksum(array $payload, string $checksumKey): array
{
    if ($checksumKey !== '') {
        $canonical = canonicalizePayload($payload);
        $serialized = json_encode($canonical, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $payload['checksum'] = hash_hmac('sha256', $serialized, $checksumKey);
    }
    return $payload;
}

function getClickPesaToken(array $config): string
{
    $tokenKey = 'cp_test_token_' . substr(hash('sha256', (string)$config['client_id'] . "\0" . (string)$config['api_key']), 0, 16);
    $expiresKey = $tokenKey . '_expires';
    $cached = $_SESSION[$tokenKey] ?? null;
    $expires = (int) ($_SESSION[$expiresKey] ?? 0);
    if (is_string($cached) && $cached !== '' && $expires > time() + 45) {
        return $cached;
    }

    $response = cpRequest('/generate-token', 'POST', null, [
        'client-id: ' . $config['client_id'],
        'api-key: ' . $config['api_key'],
    ], (string)($config['api_base_url'] ?? CLICKPESA_API_BASE));
    $token = trim((string) ($response['token'] ?? ''));
    if ($token === '') {
        throw new RuntimeException('ClickPesa did not return an API token. Review the saved credentials in Admin > Payment Channels.');
    }
    if (!str_starts_with($token, 'Bearer ')) {
        $token = 'Bearer ' . $token;
    }
    $_SESSION[$tokenKey] = $token;
    $_SESSION[$expiresKey] = time() + 3500;
    return $token;
}

function normalizeTanzaniaPhone(string $input): ?string
{
    $digits = preg_replace('/\D+/', '', $input) ?? '';
    if (str_starts_with($digits, '00')) {
        $digits = substr($digits, 2);
    } elseif (str_starts_with($digits, '0')) {
        $digits = '255' . substr($digits, 1);
    }
    return preg_match('/^255[67][0-9]{8}$/', $digits) ? $digits : null;
}

function connectDatabase(array $env): PDO
{
    $host = trim((string) ($env['DB_HOST'] ?? 'localhost'));
    $port = trim((string) ($env['DB_PORT'] ?? '3306'));
    $database = trim((string) ($env['DB_NAME'] ?? ''));
    $username = (string) ($env['DB_USER'] ?? '');
    $password = (string) ($env['DB_PASS'] ?? '');
    if ($database === '') {
        throw new RuntimeException('DB_NAME is not set in .env.');
    }
    $dsn = 'mysql:host=' . $host . ';port=' . $port . ';dbname=' . $database . ';charset=utf8mb4';
    return new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}

function loadClickPesaTestChannel(PDO $pdo, ?int $channelId = null, bool $requireEnabled = true): array
{
    $columns = 'id, name, type, channel_type, status, configured, api_base_url, client_id, api_key_enc, checksum_secret';
    if ($channelId !== null && $channelId > 0) {
        $stmt = $pdo->prepare("SELECT {$columns} FROM payment_channels WHERE id = :id LIMIT 1");
        $stmt->execute(['id' => $channelId]);
        $rows = $stmt->fetchAll();
    } else {
        $rows = $pdo->query("SELECT {$columns} FROM payment_channels ORDER BY id ASC")->fetchAll();
    }

    foreach ($rows as $row) {
        if (wifiPaymentProviderKeyFromChannel($row) !== 'clickpesa') {
            continue;
        }
        if ($requireEnabled && (strtolower((string)$row['status']) !== 'enabled' || (int)$row['configured'] !== 1)) {
            continue;
        }

        $clientId = trim((string)($row['client_id'] ?? ''));
        $encryptedApiKey = trim((string)($row['api_key_enc'] ?? ''));
        $encryptedChecksum = trim((string)($row['checksum_secret'] ?? ''));
        $apiBase = rtrim(trim((string)($row['api_base_url'] ?? '')) ?: CLICKPESA_API_BASE, '/');
        $apiBaseParts = parse_url($apiBase);
        if ($clientId === '' || $encryptedApiKey === '') {
            continue;
        }
        if (!is_array($apiBaseParts) || strtolower((string)($apiBaseParts['scheme'] ?? '')) !== 'https'
            || empty($apiBaseParts['host']) || isset($apiBaseParts['user']) || isset($apiBaseParts['pass'])
            || isset($apiBaseParts['query']) || isset($apiBaseParts['fragment'])
            || !wifiPaymentProviderHostAllowed('clickpesa', (string)$apiBaseParts['host'])) {
            throw new RuntimeException('The saved ClickPesa API Base URL must use HTTPS on an official ClickPesa domain.');
        }

        try {
            $apiKey = trim((string)decryptData($encryptedApiKey));
            $checksumKey = $encryptedChecksum !== '' ? trim((string)decryptData($encryptedChecksum)) : '';
        } catch (Throwable) {
            throw new RuntimeException('ClickPesa credentials could not be opened. Check APP_ENCRYPTION_KEY in .env.');
        }
        if ($apiKey === '') {
            continue;
        }

        return [
            'channel_id' => (int)$row['id'],
            'channel_name' => trim((string)$row['name']) ?: 'ClickPesa',
            'api_base_url' => $apiBase,
            'client_id' => $clientId,
            'api_key' => $apiKey,
            'checksum_key' => $checksumKey,
        ];
    }

    throw new RuntimeException('No enabled, verified ClickPesa channel with saved credentials was found. Configure it in Admin > Payment Channels.');
}

function loadActivePackages(PDO $pdo): array
{
    $columns = $pdo->query('SHOW COLUMNS FROM `packages`')->fetchAll();
    if ($columns === []) {
        throw new RuntimeException('The packages table has no readable fields.');
    }
    $actual = [];
    foreach ($columns as $column) {
        $actual[strtolower((string) $column['Field'])] = (string) $column['Field'];
    }
    $find = static function (array $aliases) use ($actual): ?string {
        foreach ($aliases as $alias) {
            if (isset($actual[strtolower($alias)])) {
                return $actual[strtolower($alias)];
            }
        }
        return null;
    };
    $primaryRows = $pdo->query("SHOW KEYS FROM `packages` WHERE Key_name = 'PRIMARY'")->fetchAll();
    $idColumn = isset($primaryRows[0]['Column_name'])
        ? (string) $primaryRows[0]['Column_name']
        : $find(['id', 'package_id']);
    $nameColumn = $find(['name', 'package_name']);
    $priceColumn = $find(['price']);
    $statusColumn = $find(['status']);
    if ($idColumn === null || $nameColumn === null || $priceColumn === null || $statusColumn === null) {
        throw new RuntimeException('The packages table needs ID, name, price, and status columns to select active packages.');
    }

    $durationColumn = $find(['duration_minutes']);
    $speedColumn = $find(['speed_limit']);
    $rows = $pdo->query('SELECT * FROM `packages`')->fetchAll();
    $packages = [];
    foreach ($rows as $row) {
        $status = strtolower(trim((string) ($row[$statusColumn] ?? '')));
        if (!in_array($status, ['active', 'enabled', '1'], true)) {
            continue;
        }
        $price = (float) ($row[$priceColumn] ?? 0);
        $name = trim((string) ($row[$nameColumn] ?? ''));
        if ($name === '' || $price <= 0) {
            continue;
        }
        $packages[] = [
            'id' => (string) ($row[$idColumn] ?? ''),
            'name' => $name,
            'price' => (int) round($price),
            'duration_minutes' => $durationColumn !== null ? (int) ($row[$durationColumn] ?? 0) : 0,
            'speed_limit' => $speedColumn !== null ? (string) ($row[$speedColumn] ?? '') : '',
        ];
    }
    return $packages;
}

function durationLabel(int $minutes): string
{
    if ($minutes <= 0) return '';
    if ($minutes % 1440 === 0) return (int) ($minutes / 1440) . ' days';
    if ($minutes % 60 === 0) return (int) ($minutes / 60) . ' hours';
    return $minutes . ' minutes';
}

function methodMatchesNetwork(string $methodName, string $networkId): bool
{
    $method = strtoupper($methodName);
    return match ($networkId) {
        'mixx_yas' => str_contains($method, 'YAS') || str_contains($method, 'TIGO') || str_contains($method, 'MIXX'),
        'airtel' => str_contains($method, 'AIRTEL'),
        'halopesa' => str_contains($method, 'HALO'),
        default => false,
    };
}

function newOrderReference(): string
{
    // 19 alphanumeric characters; ClickPesa allows up to 20.
    return 'W' . strtoupper(date('ymdHis')) . strtoupper(bin2hex(random_bytes(3)));
}

function ensurePendingPayment(PDO $pdo, array $preview): void
{
    $channelId = (int)($preview['channel_id'] ?? 0);
    if ($channelId < 1) {
        throw new RuntimeException('The saved ClickPesa channel is missing. Reload the test page before sending a request.');
    }

    $lookup = $pdo->prepare('SELECT id FROM payments WHERE order_reference = :reference LIMIT 1');
    $lookup->execute(['reference' => (string) $preview['reference']]);
    $existing = $lookup->fetch();
    if (is_array($existing)) {
        throw new RuntimeException('This order reference already exists in the database. Check its status and start a new preview instead of sending it again.');
    }

    $insert = $pdo->prepare("INSERT INTO payments (phone, package_id, amount, order_reference, payment_method, payment_channel_id, status)
        VALUES (:phone, :package_id, :amount, :reference, 'ClickPesa', :channel_id, 'PENDING')");
    $insert->execute([
        'phone' => (string) $preview['phone'],
        'package_id' => (int) $preview['package_id'],
        'amount' => number_format((int) $preview['amount'], 2, '.', ''),
        'reference' => (string) $preview['reference'],
        'channel_id' => $channelId,
    ]);
}

function amountInCents(mixed $amount): ?int
{
    $text = trim((string) $amount);
    if (!preg_match('/^\d+(?:\.\d{1,2})?$/', $text)) {
        return null;
    }
    [$whole, $fraction] = array_pad(explode('.', $text, 2), 2, '');
    return ((int) $whole * 100) + (int) str_pad($fraction, 2, '0');
}

function clickPesaMethodLabel(array $providerPayment): string
{
    $channel = trim((string) ($providerPayment['channel'] ?? ''));
    $label = $channel !== '' ? 'ClickPesa - ' . $channel : 'ClickPesa';
    return substr($label, 0, 50);
}

function voucherColumnNames(PDO $pdo): array
{
    $columns = $pdo->query('SHOW COLUMNS FROM `vouchers`')->fetchAll();
    $names = [];
    foreach ($columns as $column) {
        $names[strtolower((string) $column['Field'])] = (string) $column['Field'];
    }
    foreach (['id', 'code', 'package_id', 'status', 'source'] as $required) {
        if (!isset($names[$required])) {
            throw new RuntimeException('The vouchers table is missing a required column: ' . $required . '.');
        }
    }
    return $names;
}

function makeUniqueAutoVoucherCode(PDO $pdo): string
{
    $check = $pdo->prepare('SELECT id FROM vouchers WHERE code = :code LIMIT 1');
    $alphabet = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
    for ($attempt = 0; $attempt < 12; $attempt++) {
        $code = 'WIFI';
        for ($i = 0; $i < 8; $i++) {
            $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        }
        $check->execute(['code' => $code]);
        if (!$check->fetchColumn()) {
            return $code;
        }
    }
    throw new RuntimeException('Unable to generate a new voucher code.');
}

function issueVoucherForVerifiedPayment(PDO $pdo, array $preview, array $providerPayment): array
{
    $providerStatus = strtoupper(trim((string) ($providerPayment['status'] ?? '')));
    if (!in_array($providerStatus, ['SUCCESS', 'SETTLED'], true)) {
        throw new RuntimeException('ClickPesa has not confirmed the payment. No voucher was created.');
    }
    $returnedReference = trim((string) ($providerPayment['orderReference'] ?? ''));
    if ($returnedReference === '' || !hash_equals((string) $preview['reference'], $returnedReference)) {
        throw new RuntimeException('The confirmed payment reference does not match this request. No voucher was created.');
    }
    $collectedCents = amountInCents($providerPayment['collectedAmount'] ?? null);
    $expectedCents = amountInCents($preview['amount'] ?? null);
    $currency = strtoupper(trim((string) ($providerPayment['collectedCurrency'] ?? '')));
    if ($collectedCents === null || $expectedCents === null || $collectedCents !== $expectedCents || $currency !== 'TZS') {
        throw new RuntimeException('The amount or currency confirmed by ClickPesa does not match the package. No voucher was created.');
    }

    $columns = voucherColumnNames($pdo);
    $transactionReference = trim((string) ($providerPayment['paymentReference'] ?? $providerPayment['id'] ?? ''));
    if ($transactionReference === '') {
        $transactionReference = (string) $preview['reference'];
    }
    $transactionReference = substr($transactionReference, 0, 100);
    $voucher = null;

    try {
        $pdo->beginTransaction();
        $lookup = $pdo->prepare('SELECT id, phone, package_id, amount, status, voucher_id FROM payments WHERE order_reference = :reference LIMIT 1 FOR UPDATE');
        $lookup->execute(['reference' => (string) $preview['reference']]);
        $paymentRow = $lookup->fetch();
        if (!is_array($paymentRow)) {
            throw new RuntimeException('The payment record does not exist in the database.');
        }
        if ((string) $paymentRow['phone'] !== (string) $preview['phone']
            || (int) $paymentRow['package_id'] !== (int) $preview['package_id']
            || amountInCents($paymentRow['amount']) !== $expectedCents) {
            throw new RuntimeException('The payment details in the database do not match the confirmed request.');
        }

        $existingVoucherId = (int) ($paymentRow['voucher_id'] ?? 0);
        if ($existingVoucherId > 0) {
            $findVoucher = $pdo->prepare('SELECT id, code FROM vouchers WHERE id = :id LIMIT 1');
            $findVoucher->execute(['id' => $existingVoucherId]);
            $voucher = $findVoucher->fetch();
            if (!is_array($voucher)) {
                throw new RuntimeException('The payment has a voucher_id, but its voucher record cannot be found.');
            }
        } else {
            $voucherCode = makeUniqueAutoVoucherCode($pdo);
            $voucherData = [
                'code' => $voucherCode,
                'package_id' => (int) $preview['package_id'],
                'status' => 'unused',
                'source' => 'auto',
            ];
            if (isset($columns['sold_at'])) {
                $voucherData['sold_at'] = date('Y-m-d H:i:s');
            }
            if (isset($columns['sold_price'])) {
                $voucherData['sold_price'] = number_format((int) $preview['amount'], 2, '.', '');
            }
            $fieldNames = array_keys($voucherData);
            $quotedNames = array_map(static fn(string $name): string => '`' . $columns[$name] . '`', $fieldNames);
            $placeholders = array_map(static fn(string $name): string => ':' . $name, $fieldNames);
            $insertVoucher = $pdo->prepare('INSERT INTO `vouchers` (' . implode(', ', $quotedNames) . ') VALUES (' . implode(', ', $placeholders) . ')');
            $insertVoucher->execute($voucherData);
            $voucher = ['id' => (int) $pdo->lastInsertId(), 'code' => $voucherCode];
        }

        $update = $pdo->prepare("UPDATE payments
            SET status = 'SUCCESS', transaction_reference = :transaction_reference,
                payment_method = :payment_method, voucher_id = :voucher_id,
                paid_at = COALESCE(paid_at, NOW())
            WHERE id = :id");
        $update->execute([
            'transaction_reference' => $transactionReference,
            'payment_method' => clickPesaMethodLabel($providerPayment),
            'voucher_id' => (int) $voucher['id'],
            'id' => (int) $paymentRow['id'],
        ]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }

    return ['id' => (int) $voucher['id'], 'code' => (string) $voucher['code']];
}

function updatePendingPaymentStatus(PDO $pdo, string $reference, string $providerStatus): void
{
    $providerStatus = strtoupper(trim($providerStatus));
    $allowed = ['PENDING', 'PROCESSING', 'FAILED'];
    if (!in_array($providerStatus, $allowed, true)) {
        return;
    }
    $update = $pdo->prepare('UPDATE payments SET status = :status WHERE order_reference = :reference AND voucher_id IS NULL AND status <> \'SUCCESS\'');
    $update->execute(['status' => $providerStatus, 'reference' => $reference]);
}

$appRoot = dirname(__DIR__);
$pageError = '';
$packageError = '';
$pageNotice = '';
$config = ['client_id' => '', 'api_key' => '', 'checksum_key' => ''];
$env = [];
$packages = [];
$pdo = null;
$networkOptions = [
    'mixx_yas' => 'Mixx by Yas',
    'airtel' => 'Airtel Money',
    'halopesa' => 'HaloPesa',
];
$preview = $_SESSION['cp_test_preview'] ?? null;
$payment = $_SESSION['cp_test_payment'] ?? null;
$autoPollCount = (int) ($_SESSION['cp_test_auto_polls'] ?? 0);
if (is_array($preview) && !isset($preview['package_id'], $preview['network_id'])) {
    unset($_SESSION['cp_test_preview'], $_SESSION['cp_test_payment']);
    $preview = null;
    $payment = null;
}

$remoteAddress = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
if (!in_array($remoteAddress, ['127.0.0.1', '::1'], true)) {
    http_response_code(404);
    exit('Not found');
}

try {
    $env = readEnvFile($appRoot . DIRECTORY_SEPARATOR . '.env');
    foreach ($env as $key => $value) {
        $_ENV[$key] = $value;
    }
    $timezone = trim((string) ($env['APP_TIMEZONE'] ?? ''));
    if ($timezone !== '') {
        try {
            date_default_timezone_set($timezone);
        } catch (Throwable) {
            throw new RuntimeException('APP_TIMEZONE in .env is invalid.');
        }
    }
    $pdo = connectDatabase($env);
} catch (Throwable $e) {
    $pageError = $e->getMessage();
}

if ($pdo instanceof PDO) {
    try {
        $packages = loadActivePackages($pdo);
        if ($packages === []) {
            $packageError = 'No active packages were found in the packages table.';
        }
    } catch (Throwable $e) {
        $packageError = 'Unable to read packages from the database: ' . $e->getMessage();
    }

    if ($pageError === '') {
        $storedChannelId = is_array($preview) ? (int)($preview['channel_id'] ?? 0) : 0;
        $existingPaymentInFlight = is_array($preview) && !empty($preview['initiate_attempted']);
        try {
            $config = loadClickPesaTestChannel(
                $pdo,
                $storedChannelId > 0 ? $storedChannelId : null,
                !$existingPaymentInFlight
            );
        } catch (Throwable $e) {
            $pageError = $e->getMessage();
        }
    }
}

if (!isset($_SESSION['cp_test_csrf'])) {
    $_SESSION['cp_test_csrf'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = (string) ($_POST['csrf_token'] ?? '');
    if (!hash_equals((string) $_SESSION['cp_test_csrf'], $csrf)) {
        $pageError = 'The form has expired. Refresh the page and try again.';
    } elseif ($pageError === '' && $packageError === '') {
        $action = (string) ($_POST['action'] ?? '');
        try {
            if (in_array($action, ['preview', 'send'], true)) {
                $oldPreview = $_SESSION['cp_test_preview'] ?? null;
                $oldPayment = $_SESSION['cp_test_payment'] ?? null;
                $oldStatus = is_array($oldPayment) && is_array($oldPayment['response'] ?? null)
                    ? strtoupper((string) ($oldPayment['response']['status'] ?? ''))
                    : '';
                $oldVoucher = is_array($oldPayment) && is_array($oldPayment['voucher'] ?? null)
                    ? $oldPayment['voucher']
                    : null;
                $oldNeedsResolution = is_array($oldPreview)
                    && !empty($oldPreview['initiate_attempted'])
                    && !in_array($oldStatus, ['FAILED', 'CANCELLED', 'CANCELED'], true)
                    && !(is_array($oldVoucher) && !empty($oldVoucher['code']));
                if ($oldNeedsResolution) {
                    throw new RuntimeException('The previous request is still unresolved. Check its status first; do not submit another request to avoid duplicate charges.');
                }
                $phone = normalizeTanzaniaPhone((string) ($_POST['phone'] ?? ''));
                $networkId = (string) ($_POST['network'] ?? '');
                $packageId = (string) ($_POST['package_id'] ?? '');
                if ($phone === null) {
                    throw new RuntimeException('Enter a valid Tanzanian phone number, such as 0712345678.');
                }
                if (!isset($networkOptions[$networkId])) {
                    throw new RuntimeException('Select a network from the list.');
                }
                $chosenPackage = null;
                foreach ($packages as $candidate) {
                    if ($candidate['id'] === $packageId) {
                        $chosenPackage = $candidate;
                        break;
                    }
                }
                if (!is_array($chosenPackage)) {
                    throw new RuntimeException('Select an active package from the list.');
                }
                $amount = (int) $chosenPackage['price'];
                if ($amount < 100 || $amount > TEST_MAX_AMOUNT_TZS) {
                    throw new RuntimeException('The package price is outside the test range (100–' . number_format(TEST_MAX_AMOUNT_TZS) . ' TZS).');
                }

                $reference = newOrderReference();
                $token = getClickPesaToken($config);
                $payload = [
                    'amount' => (string) $amount,
                    'currency' => 'TZS',
                    'orderReference' => $reference,
                    'phoneNumber' => $phone,
                    'fetchSenderDetails' => true,
                ];
                $payload = addPayloadChecksum($payload, $config['checksum_key']);
                $response = cpRequest('/payments/preview-ussd-push-request', 'POST', $payload, [
                    'Authorization: ' . $token,
                ], (string)$config['api_base_url']);
                $safePreviewResponse = [
                    'activeMethods' => is_array($response['activeMethods'] ?? null) ? $response['activeMethods'] : [],
                ];
                $detectedProvider = (string) ($response['sender']['accountProvider'] ?? '');
                if ($detectedProvider !== '') {
                    $safePreviewResponse['sender'] = ['accountProvider' => $detectedProvider];
                }

                $preview = [
                    'channel_id' => (int)$config['channel_id'],
                    'channel_name' => (string)$config['channel_name'],
                    'phone' => $phone,
                    'amount' => $amount,
                    'network_id' => $networkId,
                    'network_name' => $networkOptions[$networkId],
                    'package_id' => $chosenPackage['id'],
                    'package_name' => $chosenPackage['name'],
                    'duration_minutes' => $chosenPackage['duration_minutes'],
                    'speed_limit' => $chosenPackage['speed_limit'],
                    'reference' => $reference,
                    'response' => $safePreviewResponse,
                    'created_at' => time(),
                    'initiate_attempted' => false,
                ];
                $_SESSION['cp_test_preview'] = $preview;
                unset($_SESSION['cp_test_payment']);
                $_SESSION['cp_test_auto_polls'] = 0;
                $autoPollCount = 0;
                $payment = null;
                if ($action === 'send') {
                    $available = $response['activeMethods'] ?? [];
                    $matches = is_array($available) ? array_values(array_filter($available, static function ($method): bool {
                        return is_array($method)
                            && strtoupper((string) ($method['status'] ?? '')) === 'AVAILABLE';
                    })) : [];
                    $providerMatches = $detectedProvider !== ''
                        ? methodMatchesNetwork($detectedProvider, $networkId)
                        : count(array_filter($matches, static fn($method): bool => methodMatchesNetwork((string) ($method['name'] ?? ''), $networkId))) > 0;
                    if ($matches === [] || !$providerMatches) {
                        throw new RuntimeException('The selected network does not match the phone number, or ClickPesa has not made that method available. Check the SIM and number before submitting the request.');
                    }
                    // A deliberate form click sends a live request after preview confirms the selected network.
                    $preview['initiate_attempted'] = true;
                    $_SESSION['cp_test_preview'] = $preview;
                    $_SESSION['cp_test_auto_polls'] = 0;
                    $autoPollCount = 0;
                    if (!$pdo instanceof PDO) {
                        throw new RuntimeException('The database is not connected; no payment request was sent.');
                    }
                    ensurePendingPayment($pdo, $preview);
                    $initPayload = [
                        'amount' => (string) $amount,
                        'currency' => 'TZS',
                        'orderReference' => $reference,
                        'phoneNumber' => $phone,
                    ];
                    $initPayload = addPayloadChecksum($initPayload, $config['checksum_key']);
                    $initResponse = cpRequest('/payments/initiate-ussd-push-request', 'POST', $initPayload, [
                        'Authorization: ' . $token,
                    ], (string)$config['api_base_url']);
                    $payment = ['response' => $initResponse, 'checked_at' => time()];
                    $_SESSION['cp_test_payment'] = $payment;
                    $pageNotice = 'A live USSD request was sent and the payment was saved as pending. After confirming your PIN, click “Verify payment and get voucher.”';
                } else {
                    $pageNotice = 'The number, package, and payment method have been checked. No payment request has been sent yet.';
                }
            } elseif ($action === 'initiate') {
                $preview = $_SESSION['cp_test_preview'] ?? null;
                if (!is_array($preview) || time() - (int) ($preview['created_at'] ?? 0) > 900) {
                    throw new RuntimeException('Check the number and amount again; the previous request has expired.');
                }
                if (!empty($preview['initiate_attempted'])) {
                    throw new RuntimeException('The USSD request has already been sent or attempted. Check its status before submitting another request.');
                }
                $previousMethods = $preview['response']['activeMethods'] ?? [];
                $previousAvailable = is_array($previousMethods) ? array_values(array_filter($previousMethods, static function ($method): bool {
                    return is_array($method) && strtoupper((string) ($method['status'] ?? '')) === 'AVAILABLE';
                })) : [];
                $previousProvider = (string) ($preview['response']['sender']['accountProvider'] ?? '');
                $networkAvailable = $previousAvailable !== [] && ($previousProvider !== ''
                    ? methodMatchesNetwork($previousProvider, (string) ($preview['network_id'] ?? ''))
                    : count(array_filter($previousAvailable, static fn($method): bool => methodMatchesNetwork((string) ($method['name'] ?? ''), (string) ($preview['network_id'] ?? '')))) > 0);
                if (!$networkAvailable) {
                    throw new RuntimeException('ClickPesa did not provide the selected network method for this request.');
                }

                // Mark before calling the live API to prevent accidental double-submission.
                $preview['initiate_attempted'] = true;
                $_SESSION['cp_test_preview'] = $preview;
                $_SESSION['cp_test_auto_polls'] = 0;
                $autoPollCount = 0;
                if (!$pdo instanceof PDO) {
                    throw new RuntimeException('The database is not connected; no payment request was sent.');
                }
                ensurePendingPayment($pdo, $preview);

                $token = getClickPesaToken($config);
                $payload = [
                    'amount' => (string) $preview['amount'],
                    'currency' => 'TZS',
                    'orderReference' => (string) $preview['reference'],
                    'phoneNumber' => (string) $preview['phone'],
                ];
                $payload = addPayloadChecksum($payload, $config['checksum_key']);
                $response = cpRequest('/payments/initiate-ussd-push-request', 'POST', $payload, [
                    'Authorization: ' . $token,
                ], (string)$config['api_base_url']);
                $payment = ['response' => $response, 'checked_at' => time()];
                $_SESSION['cp_test_payment'] = $payment;
                $pageNotice = 'The request was sent and the payment was saved as pending. After confirming your PIN, click “Verify payment and get voucher.”';
            } elseif ($action === 'status') {
                $preview = $_SESSION['cp_test_preview'] ?? null;
                $payment = $_SESSION['cp_test_payment'] ?? null;
                if (!is_array($preview) || empty($preview['initiate_attempted'])) {
                    throw new RuntimeException('There is no payment request to check.');
                }
                $token = getClickPesaToken($config);
                $reference = rawurlencode((string) $preview['reference']);
                $response = cpRequest('/payments/' . $reference, 'GET', null, [
                    'Authorization: ' . $token,
                ], (string)$config['api_base_url']);
                if (isset($response[0]) && is_array($response[0])) {
                    $response = $response[0];
                }
                $payment = ['response' => $response, 'checked_at' => time()];
                $_SESSION['cp_test_payment'] = $payment;
                if (!$pdo instanceof PDO) {
                    throw new RuntimeException('The database is not connected; the payment status was received but could not be saved.');
                }
                $providerStatus = strtoupper(trim((string) ($response['status'] ?? '')));
                if (in_array($providerStatus, ['SUCCESS', 'SETTLED'], true)) {
                    $issuedVoucher = issueVoucherForVerifiedPayment($pdo, $preview, $response);
                    $payment['voucher'] = $issuedVoucher;
                    $_SESSION['cp_test_auto_polls'] = 0;
                    $autoPollCount = 0;
                    $_SESSION['cp_test_payment'] = $payment;
                    $pageNotice = 'ClickPesa confirmed the payment. A voucher was created and linked to the payment record.';
                } else {
                    updatePendingPaymentStatus($pdo, (string) $preview['reference'], $providerStatus);
                    if (in_array($providerStatus, ['PENDING', 'PROCESSING'], true)) {
                        $autoPollCount = min(24, (int) ($_SESSION['cp_test_auto_polls'] ?? 0) + 1);
                        $_SESSION['cp_test_auto_polls'] = $autoPollCount;
                    } else {
                        $_SESSION['cp_test_auto_polls'] = 0;
                        $autoPollCount = 0;
                    }
                    $pageNotice = 'The payment status was checked with ClickPesa. A voucher is issued only after SUCCESS is confirmed.';
                }
            } else {
                throw new RuntimeException('The request was not recognized.');
            }
        } catch (Throwable $e) {
            $pageError = $e->getMessage();
            $preview = $_SESSION['cp_test_preview'] ?? null;
            $payment = $_SESSION['cp_test_payment'] ?? null;
        }
    }
}

$activeMethods = [];
$matchingMethods = [];
if (is_array($preview) && is_array($preview['response'] ?? null)) {
    $methods = $preview['response']['activeMethods'] ?? [];
    $activeMethods = is_array($methods) ? array_values(array_filter($methods, static function ($method): bool {
        return is_array($method) && strtoupper((string) ($method['status'] ?? '')) === 'AVAILABLE';
    })) : [];
    $detectedProvider = (string) ($preview['response']['sender']['accountProvider'] ?? '');
    if ($detectedProvider !== '') {
        $matchingMethods = methodMatchesNetwork($detectedProvider, (string) ($preview['network_id'] ?? '')) ? $activeMethods : [];
    } else {
        $matchingMethods = array_values(array_filter($activeMethods, static function ($method) use ($preview): bool {
            return methodMatchesNetwork((string) ($method['name'] ?? ''), (string) ($preview['network_id'] ?? ''));
        }));
    }
}
$paymentData = is_array($payment) && is_array($payment['response'] ?? null) ? $payment['response'] : null;
$issuedVoucher = is_array($payment) && is_array($payment['voucher'] ?? null) ? $payment['voucher'] : null;
$paymentStatus = strtoupper((string) ($paymentData['status'] ?? ''));
$statusLabels = [
    'PROCESSING' => 'Request awaiting confirmation on your phone',
    'PENDING' => 'Payment pending',
    'SUCCESS' => 'Payment confirmed by ClickPesa',
    'SETTLED' => 'Payment completed',
    'FAILED' => 'Payment failed',
];
$shouldAutoPoll = is_array($preview)
    && !empty($preview['initiate_attempted'])
    && in_array($paymentStatus, ['PROCESSING', 'PENDING', 'SUCCESS', 'SETTLED'], true)
    && !(is_array($issuedVoucher) && !empty($issuedVoucher['code']))
    && $autoPollCount < 24;
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#0d1b35">
    <title>ClickPesa Test | Wi-Fi</title>
    <style>
        :root{color-scheme:light;--navy:#0d1b35;--ink:#17233b;--muted:#72809a;--line:#e8edf4;--teal:#0bb7a5;--bg:#f3f6fb;--white:#fff}
        *{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(ellipse at 12% 5%,#dff8f5 0,transparent 34%),radial-gradient(ellipse at 90% 90%,#e3edff 0,transparent 35%),var(--bg);font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;color:var(--ink)}
        .shell{width:min(100% - 32px,980px);margin:0 auto;padding:34px 0 50px}.brand{display:flex;align-items:center;gap:12px;margin-bottom:25px}.brand-icon{width:46px;height:46px;border-radius:15px;background:var(--navy);color:#fff;display:grid;place-items:center;font-size:22px}.brand strong{font-size:16px}.brand small{display:block;color:var(--muted);margin-top:3px}.live{display:flex;gap:12px;padding:15px 17px;background:#fff7e7;border:1px solid #efd8a6;border-radius:15px;color:#745411;margin-bottom:21px;font-size:13px;line-height:1.55}.live b{display:block;margin-bottom:3px}.layout{display:grid;grid-template-columns:minmax(0,1fr) 290px;gap:21px;align-items:start}.card{background:#fff;border:1px solid var(--line);border-radius:20px;box-shadow:0 14px 36px #18335a0a}.main{padding:27px}.side{padding:22px;position:sticky;top:18px}.eyebrow{font-size:10px;text-transform:uppercase;letter-spacing:.13em;font-weight:850;color:#098d81}h1{font-size:27px;letter-spacing:-.04em;margin:8px 0}.intro{color:var(--muted);font-size:14px;line-height:1.6;margin:0 0 22px}.label{display:block;font-weight:750;font-size:13px;margin:16px 0 8px}.control{height:49px;width:100%;border:1px solid #dce4ef;border-radius:12px;padding:0 13px;font:inherit;color:var(--ink);outline:none}.control:focus{border-color:#35b9aa;box-shadow:0 0 0 4px #0bb7a51c}.hint{font-size:11px;color:var(--muted);margin:7px 0 0}.amounts{display:flex;flex-wrap:wrap;gap:9px}.amount{position:relative}.amount input{position:absolute;opacity:0}.amount label{display:block;padding:10px 13px;border:1px solid #dce4ef;border-radius:11px;font-weight:750;font-size:13px;cursor:pointer}.amount input:checked+label{border-color:var(--teal);background:#effbf9;color:#087d72;box-shadow:0 0 0 3px #0bb7a512}.btn{width:100%;height:50px;margin-top:20px;border:0;border-radius:12px;background:linear-gradient(135deg,#10bba9,#079b8e);color:white;font:inherit;font-weight:850;cursor:pointer}.btn:hover{filter:brightness(.97)}.btn.secondary{background:#10294b;box-shadow:none}.btn:disabled{opacity:.5;cursor:not-allowed}.notice,.error{padding:12px 14px;border-radius:12px;font-size:13px;margin:0 0 14px;line-height:1.5}.notice{background:#edfaf5;border:1px solid #cdeee0;color:#166044}.error{background:#fff0f1;border:1px solid #ffd0d5;color:#a32836}.methods{display:grid;gap:8px;margin-top:12px}.method{display:flex;justify-content:space-between;gap:10px;padding:11px 12px;border:1px solid var(--line);border-radius:11px;font-size:12px}.method span{color:var(--muted)}.confirm{border-top:1px solid var(--line);margin-top:18px;padding-top:16px}.confirm-title{font-size:14px;font-weight:850}.confirm-copy{font-size:12px;line-height:1.55;color:var(--muted);margin:7px 0 0}.result{margin-top:18px;padding:16px;border-radius:14px;background:#f7f9fc;border:1px solid var(--line)}.result h2{font-size:14px;margin:0 0 9px}.result p{font-size:12px;color:var(--muted);line-height:1.6;margin:7px 0}.status{font-weight:800;color:#127154}.status.bad{color:#ac2e3b}.side h2{font-size:15px;margin:0 0 13px}.row{display:flex;justify-content:space-between;gap:12px;padding:10px 0;border-bottom:1px solid var(--line);font-size:12px}.row span{color:var(--muted)}.total{padding-top:14px;font-size:14px;font-weight:850}.fine{margin-top:16px;padding:12px;background:#f5f7fa;border-radius:11px;color:var(--muted);font-size:11px;line-height:1.55}.footer{text-align:center;color:var(--muted);font-size:11px;margin-top:20px}@media(max-width:740px){.layout{grid-template-columns:1fr}.side{position:static;grid-row:1}.main{padding:22px}}@media(max-width:480px){.shell{width:min(100% - 22px,980px);padding-top:22px}.main,.side{padding:18px}h1{font-size:24px}}
    </style>
</head>
<body>
<main class="shell">
    <header class="brand"><span class="brand-icon" aria-hidden="true">⌁</span><div><strong>Customer Wi-Fi</strong><small>ClickPesa Payment Test</small></div></header>
    <section class="live"><span aria-hidden="true">⚠</span><div><b>Payments are live</b>Select a package and verify the number. Confirming your PIN on the phone will charge the package amount. ClickPesa has no sandbox mode.</div></section>
    <div class="layout">
        <section class="card main">
            <span class="eyebrow">USSD Push · ClickPesa</span>
            <h1>Test Phone Payments</h1>
            <p class="intro">Select a package and network, enter your number, and review the request. After reviewing it, you can choose whether to send a live USSD push.</p>
            <?php if ($pageError !== ''): ?><div class="error" role="alert"><?= h($pageError) ?></div><?php endif; ?>
            <?php if ($packageError !== ''): ?><div class="error" role="alert"><?= h($packageError) ?></div><?php endif; ?>
            <?php if ($pageNotice !== ''): ?><div class="notice" role="status"><?= h($pageNotice) ?></div><?php endif; ?>
            <form method="post" action="">
                <input type="hidden" name="csrf_token" value="<?= h((string) $_SESSION['cp_test_csrf']) ?>">
                <label class="label" for="package">Package</label>
                <select class="control" id="package" name="package_id">
                    <option value="">-- Select an active package --</option>
                    <?php foreach ($packages as $package): ?>
                        <?php
                            $packageDuration = durationLabel((int) $package['duration_minutes']);
                            $packageDetails = array_filter([$packageDuration, $package['speed_limit'] !== '' ? $package['speed_limit'] : '']);
                            $packageOption = $package['name'] . ($packageDetails !== [] ? ' · ' . implode(' · ', $packageDetails) : '') . ' · ' . number_format((int) $package['price']) . ' TZS';
                        ?>
                        <option value="<?= h($package['id']) ?>" <?= (string) ($preview['package_id'] ?? '') === $package['id'] ? 'selected' : '' ?> <?= (int) $package['price'] > TEST_MAX_AMOUNT_TZS ? 'disabled' : '' ?>><?= h($packageOption) ?><?= (int) $package['price'] > TEST_MAX_AMOUNT_TZS ? ' (above the test limit)' : '' ?></option>
                    <?php endforeach; ?>
                </select>
                <label class="label" for="network">Mobile network</label>
                <select class="control" id="network" name="network" required>
                    <option value="">-- Select the network used by this number --</option>
                    <?php foreach ($networkOptions as $networkId => $networkName): ?>
                        <option value="<?= h($networkId) ?>" <?= (string) ($preview['network_id'] ?? '') === $networkId ? 'selected' : '' ?>><?= h($networkName) ?></option>
                    <?php endforeach; ?>
                </select>
                <label class="label" for="phone">Phone number</label>
                <input class="control" id="phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="0712 345 678" value="<?= h((string) ($preview['phone'] ?? '')) ?>" required>
                <p class="hint">Enter a Tanzanian number, such as 0712345678. Make sure the selected network matches this number's SIM.</p>
                <button class="btn" type="submit" name="action" value="send" onclick="return confirm('Send a live USSD request? Confirming your PIN on the phone will charge the package amount.');">Send USSD Request Now</button>
                <button class="btn secondary" type="submit" name="action" value="preview">Review Without Sending</button>
            </form>

            <?php if (is_array($preview)): ?>
                <section class="result" aria-live="polite">
                    <h2>Review Results</h2>
                    <p>Package: <strong><?= h((string) $preview['package_name']) ?></strong><?= (int) ($preview['duration_minutes'] ?? 0) > 0 ? ' · ' . h(durationLabel((int) $preview['duration_minutes'])) : '' ?> · <strong><?= number_format((int) $preview['amount']) ?> TZS</strong><br>Selected network: <strong><?= h((string) $preview['network_name']) ?></strong><br>Number: <strong><?= h((string) $preview['phone']) ?></strong></p>
                    <p>Reference: <strong><?= h((string) $preview['reference']) ?></strong></p>
                    <?php if ($matchingMethods !== []): ?>
                        <div class="methods"><strong style="font-size:12px">Available methods for <?= h((string) $preview['network_name']) ?><?php if (!empty($preview['response']['sender']['accountProvider'])): ?> · ClickPesa identified it as <?= h((string) $preview['response']['sender']['accountProvider']) ?><?php endif; ?></strong>
                            <?php foreach ($matchingMethods as $method): if (!is_array($method)) continue; ?>
                                <div class="method"><strong><?= h((string) ($method['name'] ?? 'Mobile Money')) ?></strong><span><?= h((string) ($method['status'] ?? '')) ?><?= isset($method['fee']) ? ' · Fee ' . h((string) $method['fee']) . ' TZS' : '' ?></span></div>
                            <?php endforeach; ?>
                        </div>
                    <?php elseif ($activeMethods !== []): ?><p>ClickPesa did not provide a <?= h((string) $preview['network_name']) ?> method for this request. Check the number and selected network.</p>
                    <?php else: ?><p>ClickPesa did not provide an available method. Check that the Client ID, API Key, and payment methods are enabled in ClickPesa.</p><?php endif; ?>
                    <?php if (empty($preview['initiate_attempted']) && $matchingMethods !== []): ?>
                        <div class="confirm"><div class="confirm-title">The next step sends a live request</div><p class="confirm-copy">After you continue, this phone will receive a USSD request. Check that the number and amount are correct; your phone PIN will confirm the payment.</p>
                            <form method="post" action="" onsubmit="return confirm('Send a live payment request for <?= number_format((int) $preview['amount']) ?> TZS to number <?= h((string) $preview['phone']) ?>? Confirming your PIN on the phone will charge your account.');">
                                <input type="hidden" name="csrf_token" value="<?= h((string) $_SESSION['cp_test_csrf']) ?>"><input type="hidden" name="action" value="initiate">
                                <button class="btn secondary" type="submit">Send USSD Request Now</button>
                            </form>
                        </div>
                    <?php elseif (!empty($preview['initiate_attempted']) && !is_array($payment)): ?>
                        <div class="confirm"><div class="confirm-title">Request Attempted</div><p class="confirm-copy">Do not submit the same request again. Check whether ClickPesa received it before trying another payment.</p><form method="post" action=""><input type="hidden" name="csrf_token" value="<?= h((string) $_SESSION['cp_test_csrf']) ?>"><input type="hidden" name="action" value="status"><button class="btn" type="submit">Check This Request's Status</button></form></div>
                    <?php endif; ?>
                </section>
            <?php endif; ?>

            <?php if (is_array($paymentData)): ?>
                <?php $statusClass = in_array($paymentStatus, ['FAILED', 'CANCELLED', 'CANCELED'], true) ? 'bad' : 'status'; ?>
                <section class="result" aria-live="polite">
                    <h2>Transaction Status</h2>
                    <p class="<?= $statusClass ?>"><?= h($statusLabels[$paymentStatus] ?? ($paymentStatus !== '' ? $paymentStatus : 'Response received')) ?></p>
                    <?php if (!empty($paymentData['message'])): ?><p><?= h((string) $paymentData['message']) ?></p><?php endif; ?>
                    <p>Reference: <strong><?= h((string) ($preview['reference'] ?? '')) ?></strong>
                    <?php if (isset($paymentData['collectedAmount'])): ?> · Amount received: <strong><?= h((string) $paymentData['collectedAmount']) ?> <?= h((string) ($paymentData['collectedCurrency'] ?? 'TZS')) ?></strong><?php endif; ?></p>
                    <?php if (is_array($issuedVoucher) && !empty($issuedVoucher['code'])): ?>
                        <p class="status">Your voucher has been created: <strong style="font-size:20px;letter-spacing:.12em;color:#087d72"><?= h((string) $issuedVoucher['code']) ?></strong></p>
                        <p>Save this code. The payment and voucher are linked in the system.</p>
                    <?php elseif (in_array($paymentStatus, ['SUCCESS', 'SETTLED'], true)): ?>
                        <p>ClickPesa reports that the payment succeeded. Verify the status below so the system can confirm the amount and create a voucher.</p>
                    <?php endif; ?>
                    <form id="payment-status-form" method="post" action=""><input type="hidden" name="csrf_token" value="<?= h((string) $_SESSION['cp_test_csrf']) ?>"><input type="hidden" name="action" value="status"><button class="btn" type="submit"><?= is_array($issuedVoucher) ? 'Check Payment Status Again' : 'Verify Payment and Get Voucher' ?></button></form>
                    <?php if ($shouldAutoPoll): ?><p>This page is checking the payment automatically (<?= $autoPollCount + 1 ?>/24). You can wait or click the button above.</p><?php elseif ($autoPollCount >= 24 && !$issuedVoucher): ?><p>Automatic checks have stopped. Click the button above to check the status again.</p><?php endif; ?>
                </section>
            <?php endif; ?>
        </section>
        <aside class="card side"><h2>Summary</h2><div class="row"><span>Packages</span><strong>Active from database</strong></div><div class="row"><span>Mtoa huduma</span><strong>ClickPesa</strong></div><div class="row"><span>Request type</span><strong>USSD Push</strong></div><div class="row"><span>Status</span><strong>Live API</strong></div><div class="row total"><span>Test limit</span><strong><?= number_format(TEST_MAX_AMOUNT_TZS) ?> TZS</strong></div><div class="fine">The initial review does not charge you. After sending a request, confirm your PIN on the phone. This page then checks ClickPesa and issues one voucher only after payment is confirmed.</div></aside>
    </div>
    <p class="footer">This page is restricted to localhost, saves payments in the payments table, and issues a voucher after ClickPesa confirms the payment.</p>
</main>
<script>
<?php if ($shouldAutoPoll): ?>
window.setTimeout(function () {
    var statusForm = document.getElementById('payment-status-form');
    if (statusForm) statusForm.requestSubmit();
}, 5000);
<?php endif; ?>
document.querySelectorAll('input[name="amount"][type="radio"]').forEach(function (radio) {
    radio.addEventListener('change', function () {
        var custom = document.getElementById('custom-amount');
        if (custom) custom.value = '';
    });
});
var customAmount = document.getElementById('custom-amount');
if (customAmount) customAmount.addEventListener('input', function () {
    document.querySelectorAll('input[name="amount"][type="radio"]').forEach(function (radio) { radio.checked = false; });
});
</script>
</body>
</html>
