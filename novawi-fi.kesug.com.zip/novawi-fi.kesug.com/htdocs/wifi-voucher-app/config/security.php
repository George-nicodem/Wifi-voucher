<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| SECURITY CONFIGURATION
|--------------------------------------------------------------------------
| Central security helpers for the WiFi Voucher application.
|
| IMPORTANT:
| - Never hard-code API secrets in PHP files.
| - Encryption key must come from environment configuration.
| - Never display decrypted credentials to customers/admin pages.
|--------------------------------------------------------------------------
*/

if (!defined('APP_SECURITY_LOADED')) {
    define('APP_SECURITY_LOADED', true);
}

/*
|--------------------------------------------------------------------------
| Load database/config environment
|--------------------------------------------------------------------------
*/

$envFile = dirname(__DIR__) . '/.env';

if (is_file($envFile) && is_readable($envFile)) {

    $lines = file(
        $envFile,
        FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES
    );

    foreach ($lines as $line) {

        $line = trim($line);

        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }

        if (!str_contains($line, '=')) {
            continue;
        }

        [$key, $value] = explode('=', $line, 2);

        $key = trim($key);
        $value = trim($value);

        if (
            strlen($value) >= 2 &&
            (
                ($value[0] === '"' && $value[strlen($value) - 1] === '"') ||
                ($value[0] === "'" && $value[strlen($value) - 1] === "'")
            )
        ) {
            $value = substr($value, 1, -1);
        }

        if ($key !== '') {
            $_ENV[$key] = $value;
        }
    }
}

/*
|--------------------------------------------------------------------------
| Encryption Key
|--------------------------------------------------------------------------
|
| Generate a strong random key ONCE.
|
| Example:
|   bin2hex(random_bytes(32))
|
| Store it in .env as:
|
| APP_ENCRYPTION_KEY=64_character_hex_key
|
|--------------------------------------------------------------------------
*/

function getEncryptionKey(): string
{
    static $key = null;

    if ($key !== null) {
        return $key;
    }

    $keyValue = $_ENV['APP_ENCRYPTION_KEY'] ?? '';

    if ($keyValue === '') {
        error_log('APP_ENCRYPTION_KEY is missing.');

        throw new RuntimeException(
            'Application encryption key is not configured.'
        );
    }

    /*
     * We expect a 64-character hexadecimal string
     * representing 32 random bytes.
     */

    if (
        strlen($keyValue) !== 64 ||
        !ctype_xdigit($keyValue)
    ) {
        error_log('APP_ENCRYPTION_KEY has invalid format.');

        throw new RuntimeException(
            'Application encryption key has invalid format.'
        );
    }

    $key = hex2bin($keyValue);

    if ($key === false || strlen($key) !== 32) {
        error_log('Failed to initialize encryption key.');

        throw new RuntimeException(
            'Failed to initialize application security.'
        );
    }

    return $key;
}

/*
|--------------------------------------------------------------------------
| Encrypt Sensitive Data
|--------------------------------------------------------------------------
*/

function encryptData(string $plainText): string
{
    if ($plainText === '') {
        return '';
    }

    $key = getEncryptionKey();

    $iv = random_bytes(12);

    $tag = '';

    $cipherText = openssl_encrypt(
        $plainText,
        'aes-256-gcm',
        $key,
        OPENSSL_RAW_DATA,
        $iv,
        $tag,
        '',
        16
    );

    if ($cipherText === false) {
        throw new RuntimeException(
            'Encryption failed.'
        );
    }

    /*
     * Store:
     * IV + authentication tag + ciphertext
     *
     * Base64 makes it safe for database storage.
     */

    return base64_encode(
        $iv . $tag . $cipherText
    );
}

/*
|--------------------------------------------------------------------------
| Decrypt Sensitive Data
|--------------------------------------------------------------------------
*/

function decryptData(string $encryptedText): string
{
    if ($encryptedText === '') {
        return '';
    }

    $key = getEncryptionKey();

    $decoded = base64_decode(
        $encryptedText,
        true
    );

    if ($decoded === false) {
        throw new RuntimeException(
            'Invalid encrypted data.'
        );
    }

    /*
     * AES-256-GCM:
     *
     * IV  = 12 bytes
     * TAG = 16 bytes
     */

    if (strlen($decoded) < 28) {
        throw new RuntimeException(
            'Invalid encrypted data length.'
        );
    }

    $iv = substr($decoded, 0, 12);

    $tag = substr($decoded, 12, 16);

    $cipherText = substr($decoded, 28);

    $plainText = openssl_decrypt(
        $cipherText,
        'aes-256-gcm',
        $key,
        OPENSSL_RAW_DATA,
        $iv,
        $tag,
        ''
    );

    if ($plainText === false) {
        throw new RuntimeException(
            'Decryption failed.'
        );
    }

    return $plainText;
}

/*
|--------------------------------------------------------------------------
| Safe Secret Comparison
|--------------------------------------------------------------------------
*/

function secureCompare(
    string $known,
    string $provided
): bool {
    return hash_equals(
        $known,
        $provided
    );
}

/*
|--------------------------------------------------------------------------
| Generate Cryptographically Secure Token
|--------------------------------------------------------------------------
*/

function generateSecureToken(int $bytes = 32): string
{
    if ($bytes < 16) {
        $bytes = 16;
    }

    return bin2hex(
        random_bytes($bytes)
    );
}

/*
|--------------------------------------------------------------------------
| Generate Secure Voucher Code
|--------------------------------------------------------------------------
*/

function generateVoucherCode(
    int $length = 7
): string {
    // Voucher codes use a fixed 3-letter, 4-digit format.
    $letters = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    $digits = '0123456789';
    $code = '';

    for ($i = 0; $i < 3; $i++) {
        $code .= $letters[random_int(0, strlen($letters) - 1)];
    }

    for ($i = 0; $i < 4; $i++) {
        $code .= $digits[random_int(0, strlen($digits) - 1)];
    }

    return $code;
}