<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| DATABASE CONFIGURATION
|--------------------------------------------------------------------------
| Central database connection for the entire application.
| Do NOT create another database connection in individual files.
|--------------------------------------------------------------------------
*/

date_default_timezone_set('Africa/Dar_es_Salaam');

/*
|--------------------------------------------------------------------------
| Load .env
|--------------------------------------------------------------------------
*/

$envFile = dirname(__DIR__) . '/.env';

if (is_file($envFile) && is_readable($envFile)) {

    $lines = file(
        $envFile,
        FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES
    );

    foreach ($lines as $line) {

        $line = trim($line);

        // Ignore comments
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }

        // Ignore invalid lines
        if (!str_contains($line, '=')) {
            continue;
        }

        [$key, $value] = explode('=', $line, 2);

        $key = trim($key);
        $value = trim($value);

        // Remove optional quotes
        if (
            strlen($value) >= 2 &&
            (
                ($value[0] === '"' && $value[strlen($value) - 1] === '"') ||
                ($value[0] === "'" && $value[strlen($value) - 1] === "'")
            )
        ) {
            $value = substr($value, 1, -1);
        }

        if ($key !== '') {
            $_ENV[$key] = $value;
        }
    }
}

/*
|--------------------------------------------------------------------------
| Database Credentials
|--------------------------------------------------------------------------
*/

$dbHost = $_ENV['DB_HOST'] ?? 'localhost';
$dbUser = $_ENV['DB_USER'] ?? 'root';
$dbPass = $_ENV['DB_PASS'] ?? '';
$dbName = $_ENV['DB_NAME'] ?? 'wifi_voucher';
$dbPort = (int)($_ENV['DB_PORT'] ?? 3306);

/*
|--------------------------------------------------------------------------
| Create Connection
|--------------------------------------------------------------------------
*/

mysqli_report(MYSQLI_REPORT_OFF);

$conn = mysqli_init();

if (!$conn instanceof mysqli) {
    http_response_code(500);
    exit('A system error occurred. Please try again later.');
}

// Do not leave local pages waiting for the PHP execution timeout if MySQL is down.
$conn->options(MYSQLI_OPT_CONNECT_TIMEOUT, 5);
$conn->options(MYSQLI_OPT_READ_TIMEOUT, 5);
$connected = @$conn->real_connect(
    $dbHost,
    $dbUser,
    $dbPass,
    $dbName,
    $dbPort
);

/*
|--------------------------------------------------------------------------
| Connection Error
|--------------------------------------------------------------------------
*/

if (!$connected || $conn->connect_errno) {

    error_log(
        'Database connection failed: ' .
        $conn->connect_error
    );

    http_response_code(500);

    exit('A system error occurred. Please try again later.');
}

/*
|--------------------------------------------------------------------------
| Character Set
|--------------------------------------------------------------------------
*/

if (!$conn->set_charset('utf8mb4')) {

    error_log(
        'Failed to set database charset: ' .
        $conn->error
    );

    http_response_code(500);

    exit('A system error occurred. Please try again later.');
}

/*
|--------------------------------------------------------------------------
| Tanzania Timezone
|--------------------------------------------------------------------------
*/

$conn->query("SET time_zone = '+03:00'");
