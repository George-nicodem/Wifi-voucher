<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| APPLICATION CONFIGURATION
|--------------------------------------------------------------------------
| Central configuration for the WiFi Voucher application.
|--------------------------------------------------------------------------
*/

if (!defined('APP_CONFIG_LOADED')) {
    define('APP_CONFIG_LOADED', true);
}

/*
|--------------------------------------------------------------------------
| Load .env
|--------------------------------------------------------------------------
*/

$envFile = dirname(__DIR__) . '/.env';

if (is_file($envFile) && is_readable($envFile)) {

    $lines = file(
        $envFile,
        FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES
    );

    foreach ($lines as $line) {

        $line = trim($line);

        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }

        if (!str_contains($line, '=')) {
            continue;
        }

        [$key, $value] = explode('=', $line, 2);

        $key = trim($key);
        $value = trim($value);

        if (
            strlen($value) >= 2 &&
            (
                ($value[0] === '"' && $value[strlen($value) - 1] === '"') ||
                ($value[0] === "'" && $value[strlen($value) - 1] === "'")
            )
        ) {
            $value = substr($value, 1, -1);
        }

        if ($key !== '') {
            $_ENV[$key] = $value;
        }
    }
}

/*
|--------------------------------------------------------------------------
| Application Name
|--------------------------------------------------------------------------
*/

define(
    'APP_NAME',
    $_ENV['APP_NAME'] ?? 'WiFi Voucher'
);

/*
|--------------------------------------------------------------------------
| Environment
|--------------------------------------------------------------------------
*/

define(
    'APP_ENV',
    $_ENV['APP_ENV'] ?? 'production'
);

/*
|--------------------------------------------------------------------------
| Timezone
|--------------------------------------------------------------------------
*/

define(
    'APP_TIMEZONE',
    $_ENV['APP_TIMEZONE'] ?? 'Africa/Dar_es_Salaam'
);

date_default_timezone_set(APP_TIMEZONE);

/*
|--------------------------------------------------------------------------
| Base URL
|--------------------------------------------------------------------------
|
| For local development (for example, XAMPP):
| http://localhost/Wifi-Voucher/wifi-Voucher-App
|
| Change this later when deployed online.
|--------------------------------------------------------------------------
*/

define(
    'APP_URL',
    $_ENV['APP_URL'] ??
    'http://localhost/Wifi-Voucher/wifi-Voucher-App'
);

/*
|--------------------------------------------------------------------------
| Debug Mode
|--------------------------------------------------------------------------
*/

define(
    'APP_DEBUG',
    APP_ENV === 'development'
);

/*
|--------------------------------------------------------------------------
| Currency
|--------------------------------------------------------------------------
*/

define(
    'APP_CURRENCY',
    $_ENV['APP_CURRENCY'] ?? 'TZS'
);

/*
|--------------------------------------------------------------------------
| Voucher Settings
|--------------------------------------------------------------------------
*/

define(
    'VOUCHER_CODE_LENGTH',
    7
);

/*
|--------------------------------------------------------------------------
| Session Settings
|--------------------------------------------------------------------------
*/

define(
    'SESSION_NAME',
    $_ENV['SESSION_NAME'] ?? 'WIFI_VOUCHER_SESSION'
);

/*
|--------------------------------------------------------------------------
| Security Settings
|--------------------------------------------------------------------------
*/

define(
    'CSRF_TOKEN_NAME',
    'csrf_token'
);

/*
|--------------------------------------------------------------------------
| Payment Settings
|--------------------------------------------------------------------------
*/

define(
    'PAYMENT_TIMEOUT_MINUTES',
    15
);

/*
|--------------------------------------------------------------------------
| Logging
|--------------------------------------------------------------------------
*/

define(
    'LOG_DIRECTORY',
    dirname(__DIR__) . '/logs'
);

/*
|--------------------------------------------------------------------------
| Create log directory if needed
|--------------------------------------------------------------------------
*/

if (!is_dir(LOG_DIRECTORY)) {
    @mkdir(
        LOG_DIRECTORY,
        0750,
        true
    );
}

/*
|--------------------------------------------------------------------------
| Helper: Application URL
|--------------------------------------------------------------------------
*/

function appUrl(string $path = ''): string
{
    $path = ltrim($path, '/');
    $queryOffset = strpos($path, '?');
    $route = $queryOffset === false ? $path : substr($path, 0, $queryOffset);
    $query = $queryOffset === false ? '' : substr($path, $queryOffset);

    // Keep payment callback URLs stable; providers may have these registered.
    if (!preg_match('~^webhooks(?:/|$)~i', $route)) {
        $route = preg_replace('~\.php$~i', '', $route) ?? $route;
    }

    return rtrim(APP_URL, '/') .
        '/' .
        $route .
        $query;
}

/*
|--------------------------------------------------------------------------
| Helper: Log Application Error
|--------------------------------------------------------------------------
*/

function appLog(
    string $message,
    array $context = []
): void {

    $logMessage = '[' .
        date('Y-m-d H:i:s') .
        '] ' .
        $message;

    if (!empty($context)) {

        $logMessage .= ' ' .
            json_encode(
                $context,
                JSON_UNESCAPED_SLASHES |
                JSON_UNESCAPED_UNICODE
            );
    }

    $logMessage .= PHP_EOL;

    error_log(
        $logMessage,
        3,
        LOG_DIRECTORY . '/app.log'
    );
}
