<?php
declare(strict_types=1);

/* Serve only known local network image files, using their real image MIME type. */
$allowedFiles = [
    'airtel-money.svg',
    'halopesa.svg',
    'download (1).png',
    'download.jpeg',
    'mpesa.svg',
    'mpesa.png',
    'M-pesa.svg',
    'halotel.svg',
    'halotel.png',
    'mixx-by-yas.svg',
    'mixx-by-yas.png',
    'ttcl.svg',
    'ttcl.png',
    'TTCL.svg',
];
$requested = $_GET['file'] ?? '';
if (!is_string($requested)) {
    http_response_code(400);
    exit;
}
$isCustom = preg_match('~^custom/network-[1-9][0-9]*-[a-f0-9]{16}\.(?:png|jpg|webp)$~D', $requested) === 1;
if ($isCustom) {
    $file = basename($requested);
    $path = __DIR__ . DIRECTORY_SEPARATOR . 'custom' . DIRECTORY_SEPARATOR . $file;
} else {
    $file = basename($requested);
    if (!in_array($file, $allowedFiles, true) || $requested !== $file) {
        http_response_code(404);
        exit;
    }
    $path = __DIR__ . DIRECTORY_SEPARATOR . $file;
}
if (!is_file($path) || !is_readable($path)) {
    http_response_code(404);
    exit;
}
$contents = file_get_contents($path);
if (!is_string($contents) || $contents === '' || strlen($contents) > 2_000_000) {
    http_response_code(404);
    exit;
}

$mime = null;
if (str_starts_with($contents, "\x89PNG\r\n\x1a\n")) {
    $mime = 'image/png';
} elseif (str_starts_with($contents, "\xff\xd8\xff")) {
    $mime = 'image/jpeg';
} elseif (str_starts_with($contents, 'GIF87a') || str_starts_with($contents, 'GIF89a')) {
    $mime = 'image/gif';
} elseif (strlen($contents) >= 12 && substr($contents, 0, 4) === 'RIFF' && substr($contents, 8, 4) === 'WEBP') {
    $mime = 'image/webp';
} elseif (preg_match('/^\s*(?:<\?xml[^>]*>\s*)?<svg\b/i', $contents) === 1) {
    $mime = 'image/svg+xml';
}

if ($mime === null) {
    http_response_code(415);
    exit;
}
if ($isCustom) {
    $expectedMime = match (strtolower(pathinfo($file, PATHINFO_EXTENSION))) {
        'png' => 'image/png',
        'jpg' => 'image/jpeg',
        'webp' => 'image/webp',
        default => '',
    };
    if ($mime !== $expectedMime) {
        http_response_code(415);
        exit;
    }
}

header('Content-Type: ' . $mime);
header('Content-Length: ' . strlen($contents));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: public, max-age=300');
echo $contents;
