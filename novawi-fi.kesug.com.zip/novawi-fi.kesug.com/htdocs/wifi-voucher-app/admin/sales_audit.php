<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/admin_auth.php';
requireAdminLogin();
if (!adminHasRole(['admin', 'super_admin', 'superadmin'])) {
    http_response_code(403);
    exit('Administrator access required.');
}
header('Cache-Control: no-store, private');
header('X-Robots-Tag: noindex, nofollow');

$auditRows = [];
$auditError = false;
$read = static function (string $label, string $sql) use ($conn, &$auditRows, &$auditError): array {
    try {
        $result = $conn->query($sql);
        if (!$result) throw new RuntimeException('Audit query failed.');
        $row = $result->fetch_assoc() ?: [];
        $result->free();
        $auditRows[$label] = $row;
        return $row;
    } catch (Throwable $exception) {
        $auditError = true;
        logException($exception, 'Read-only sales audit: ' . $label);
        return [];
    }
};

$clock = $read('Database clock', 'SELECT NOW() AS database_time, @@session.time_zone AS database_timezone');
$sales = $read('Recorded sales', "SELECT
    (SELECT COUNT(*) FROM payments WHERE UPPER(COALESCE(status,'')) = 'SUCCESS') AS automatic_count,
    (SELECT COALESCE(SUM(amount),0) FROM payments WHERE UPPER(COALESCE(status,'')) = 'SUCCESS') AS automatic_amount,
    (SELECT COUNT(*) FROM vouchers WHERE source='manual' AND sold_at IS NOT NULL) AS cash_count,
    (SELECT COALESCE(SUM(sold_price),0) FROM vouchers WHERE source='manual' AND sold_at IS NOT NULL) AS cash_amount,
    (SELECT COUNT(*) FROM vouchers WHERE source='manual' AND sold_at IS NULL AND activated_at IS NOT NULL) AS admin_count,
    (SELECT COALESCE(SUM(COALESCE(v.sold_price,p.price,0)),0) FROM vouchers v LEFT JOIN packages p ON p.id=v.package_id
        WHERE v.source='manual' AND v.sold_at IS NULL AND v.activated_at IS NOT NULL) AS admin_amount");
$pending = $read('Payment states', "SELECT COUNT(*) AS total,
    COALESCE(SUM(UPPER(COALESCE(status,''))='PENDING'),0) AS pending,
    COALESCE(SUM(UPPER(COALESCE(status,''))='PROCESSING'),0) AS processing,
    COALESCE(SUM(UPPER(COALESCE(status,''))='SUCCESS'),0) AS successful,
    COALESCE(SUM(UPPER(COALESCE(status,'')) IN ('FAILED','CANCELLED','CANCELED','EXPIRED')),0) AS failed,
    COALESCE(SUM(UPPER(COALESCE(status,'')) NOT IN ('PENDING','PROCESSING','SUCCESS','FAILED','CANCELLED','CANCELED','EXPIRED')),0) AS other
    FROM payments");
$checks = [
    'Duplicate payment order references' => "SELECT COUNT(*) AS affected FROM (SELECT order_reference FROM payments GROUP BY order_reference HAVING COUNT(*)>1) duplicates",
    'One voucher linked to multiple successful payments' => "SELECT COUNT(*) AS affected FROM (SELECT voucher_id FROM payments WHERE UPPER(COALESCE(status,''))='SUCCESS' AND voucher_id IS NOT NULL GROUP BY voucher_id HAVING COUNT(*)>1) duplicates",
    'Successful payments missing a voucher' => "SELECT COUNT(*) AS affected FROM payments p LEFT JOIN vouchers v ON v.id=p.voucher_id WHERE UPPER(COALESCE(p.status,''))='SUCCESS' AND v.id IS NULL",
    'Manual vouchers also counted as successful online payments' => "SELECT COUNT(*) AS affected FROM vouchers v WHERE v.source='manual' AND (v.sold_at IS NOT NULL OR v.activated_at IS NOT NULL) AND EXISTS (SELECT 1 FROM payments p WHERE p.voucher_id=v.id AND UPPER(COALESCE(p.status,''))='SUCCESS')",
    'Sold or activated manual vouchers missing their saved sale price' => "SELECT COUNT(*) AS affected FROM vouchers WHERE source='manual' AND (sold_at IS NOT NULL OR activated_at IS NOT NULL) AND sold_price IS NULL",
    'Successful payment and voucher prices differ' => "SELECT COUNT(*) AS affected FROM payments p JOIN vouchers v ON v.id=p.voucher_id WHERE UPPER(COALESCE(p.status,''))='SUCCESS' AND v.sold_price IS NOT NULL AND p.amount<>v.sold_price",
    'Negative successful payment or manual sale values' => "SELECT (SELECT COUNT(*) FROM payments WHERE UPPER(COALESCE(status,''))='SUCCESS' AND amount<0) + (SELECT COUNT(*) FROM vouchers WHERE source='manual' AND (sold_at IS NOT NULL OR activated_at IS NOT NULL) AND sold_price<0) AS affected",
    'Manual sale records retained after expiry' => "SELECT COUNT(*) AS affected FROM vouchers WHERE source='manual' AND status='expired' AND (sold_at IS NOT NULL OR activated_at IS NOT NULL)",
];
foreach ($checks as $label => $sql) $read($label, $sql);
$amount = static fn(string $key): string => number_format((float)($sales[$key] ?? 0), 2) . ' TZS';
$totalCount = (int)($sales['automatic_count'] ?? 0) + (int)($sales['cash_count'] ?? 0) + (int)($sales['admin_count'] ?? 0);
$totalAmount = (float)($sales['automatic_amount'] ?? 0) + (float)($sales['cash_amount'] ?? 0) + (float)($sales['admin_amount'] ?? 0);
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sales verification</title>
<style>body{margin:0;padding:24px;background:#f3f6fb;color:#193047;font:15px/1.5 system-ui,sans-serif}main{max-width:1000px;margin:auto}a{color:#176b79}h1{margin-bottom:4px}.card{margin:18px 0;background:white;border:1px solid #dce4ee;border-radius:16px;padding:20px}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}.value{font-size:23px;font-weight:750}.muted{color:#596f83}table{width:100%;border-collapse:collapse}td,th{padding:12px;text-align:left;border-bottom:1px solid #e5ecf4}.warn{color:#9c3d21;font-weight:700}.ok{color:#19704b;font-weight:700}@media(max-width:600px){body{padding:12px}.grid{grid-template-columns:1fr}td,th{padding:10px 5px}}</style>
</head><body><main>
<a href="<?= e(appUrl('admin/dashboard.php')) ?>">Back to dashboard</a>
<h1>Sales verification</h1><p class="muted">Read-only checks of saved records. No payments, vouchers, or balances are changed.</p>
<?php if ($auditError): ?><p class="warn">One or more checks failed. The audit is incomplete; inspect the server log.</p><?php endif; ?>
<div class="card"><div class="muted">All-time recorded sales</div><div class="value"><?= number_format($totalAmount, 2) ?> TZS</div><div><?= $totalCount ?> sales</div></div>
<div class="grid">
<?php foreach ([['Online payments','automatic_count','automatic_amount'],['Cash sales','cash_count','cash_amount'],['Admin-activated vouchers','admin_count','admin_amount']] as [$label,$countKey,$amountKey]): ?>
<div class="card"><div><?= e($label) ?></div><div class="value"><?= e($amount($amountKey)) ?></div><div class="muted"><?= (int)($sales[$countKey] ?? 0) ?> sales</div></div>
<?php endforeach; ?>
</div>
<div class="card"><h2>Payment states</h2><p>Pending: <?= (int)($pending['pending'] ?? 0) ?> · Processing: <?= (int)($pending['processing'] ?? 0) ?> · Successful: <?= (int)($pending['successful'] ?? 0) ?> · Failed: <?= (int)($pending['failed'] ?? 0) ?> · Other: <?= (int)($pending['other'] ?? 0) ?></p></div>
<div class="card"><h2>Record checks</h2><table><thead><tr><th>Check</th><th>Records</th></tr></thead><tbody>
<?php foreach ($checks as $label => $sql): $isHistory = $label === 'Manual sale records retained after expiry'; $count = $auditRows[$label]['affected'] ?? null; ?>
<tr><td><?= e($label) ?></td><td class="<?= $count === null || (!$isHistory && (int)$count > 0) ? 'warn' : 'ok' ?>"><?= $count === null ? 'Check failed' : (int)$count ?></td></tr>
<?php endforeach; ?>
</tbody></table></div>
<p class="muted">Database time: <?= e((string)($clock['database_time'] ?? 'Unavailable')) ?>. PHP time: <?= e(date('Y-m-d H:i:s')) ?> (<?= e(date_default_timezone_get()) ?>). These totals verify stored sales; the payment provider confirms its account balance separately.</p>
</main></body></html>
