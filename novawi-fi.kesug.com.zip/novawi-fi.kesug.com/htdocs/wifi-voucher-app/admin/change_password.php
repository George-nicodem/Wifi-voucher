<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/admin_auth.php';

startAdminSession();

$error = '';
$username = '';
$success = isset($_GET['changed']) && $_GET['changed'] === '1';
$isSignedIn = isAdminLoggedIn();

if ($isSignedIn) {
    $currentId = currentAdminId();
    if ($currentId !== null) {
        $currentStmt = $conn->prepare('SELECT username FROM admin_users WHERE id = ? LIMIT 1');
        if ($currentStmt) {
            $currentStmt->bind_param('i', $currentId);
            if ($currentStmt->execute()) {
                $currentAccount = $currentStmt->get_result()->fetch_assoc() ?: null;
                $username = (string)($currentAccount['username'] ?? '');
            }
            $currentStmt->close();
        }
    }
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    requireCsrfToken();
    $username = trim(postString('username', ''));
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $currentPassword = is_string($currentPassword) ? $currentPassword : '';
    $newPassword = is_string($newPassword) ? $newPassword : '';
    $confirmPassword = is_string($confirmPassword) ? $confirmPassword : '';

    $now = time();
    $attempts = $_SESSION['admin_password_change_attempts'] ?? [];
    if (!is_array($attempts)) $attempts = [];
    $attempts = array_values(array_filter($attempts, static fn($at): bool => is_int($at) && $at >= $now - 900));

    if (count($attempts) >= 6) {
        $_SESSION['admin_password_change_attempts'] = $attempts;
        $error = 'Too many attempts. Wait 15 minutes, then try again.';
    } else {
        $attempts[] = $now;
        $_SESSION['admin_password_change_attempts'] = $attempts;

        $length = function_exists('mb_strlen') ? mb_strlen($newPassword) : strlen($newPassword);
        if (!preg_match('/^[A-Za-z0-9._@-]{3,50}$/D', $username)) {
            $error = 'Enter a valid administrator username.';
        } elseif ($currentPassword === '' || strlen($currentPassword) > 1024) {
            $error = 'Enter your current password.';
        } elseif ($length < 6 || strlen($newPassword) > 1024 || !preg_match('/[a-z]/', $newPassword) || !preg_match('/[A-Z]/', $newPassword) || !preg_match('/[0-9]/', $newPassword) || !preg_match('/[^A-Za-z0-9]/', $newPassword)) {
            $error = 'Use at least 6 characters, including uppercase and lowercase letters, a number, and a symbol.';
        } elseif (!hash_equals($newPassword, $confirmPassword)) {
            $error = 'The new password and confirmation do not match.';
        } else {
            $lookup = $conn->prepare('SELECT id, password_hash, status FROM admin_users WHERE username = ? LIMIT 1');
            if (!$lookup) {
                logDatabaseError($conn, 'Preparing administrator password change lookup');
                $error = 'Could not verify the account right now. Please try again.';
            } else {
                $lookup->bind_param('s', $username);
                if (!$lookup->execute()) {
                    logDatabaseError($conn, 'Looking up administrator password change');
                    $error = 'Could not verify the account right now. Please try again.';
                    $account = null;
                } else {
                    $account = $lookup->get_result()->fetch_assoc() ?: null;
                }
                $lookup->close();

                if (!$error && (!$account
                    || strtolower((string)($account['status'] ?? '')) !== 'active'
                    || !password_verify($currentPassword, (string)($account['password_hash'] ?? '')))) {
                    $error = 'The username or current password is incorrect.';
                }

                if (!$error && password_verify($newPassword, (string)$account['password_hash'])) {
                    $error = 'The new password must be different from the current password.';
                }

                if (!$error) {
                    $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
                    if (!is_string($newHash) || $newHash === '') {
                        $error = 'The new password could not be securely saved.';
                    } else {
                        $accountId = (int)$account['id'];
                        $oldHash = (string)$account['password_hash'];
                        $update = $conn->prepare('UPDATE admin_users SET password_hash = ? WHERE id = ? AND password_hash = ?');
                        if (!$update) {
                            logDatabaseError($conn, 'Preparing administrator password update');
                            $error = 'Could not save the new password.';
                        } else {
                            $update->bind_param('sis', $newHash, $accountId, $oldHash);
                            if (!$update->execute() || $update->affected_rows !== 1) {
                                logDatabaseError($conn, 'Updating administrator password');
                                $error = 'The password was not changed. Refresh the page and try again.';
                            } else {
                                logAdminSecurityEvent('ADMIN_PASSWORD_CHANGED', 'Administrator changed their password.');
                                $_SESSION['admin_password_change_attempts'] = [];
                                session_regenerate_id(true);
                                header('Location: ' . appUrl('admin/change_password.php?changed=1'), true, 303);
                                exit;
                            }
                            $update->close();
                        }
                    }
                }
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Change password | <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="<?= e(appUrl('admin/assets/auth-theme.css?v=5')) ?>">
</head>
<body class="password-change-page">
<main class="password-change-shell">
    <section class="password-change-card">
        <div class="auth-brand"><span class="auth-brand-mark"><i class="fa-solid fa-wifi" aria-hidden="true"></i></span><span><strong>WiFi Voucher</strong><small>Account security</small></span></div>
        <header class="password-change-heading"><h1>Change password</h1><p>Confirm your current password, then use a new password with at least 6 characters, uppercase and lowercase letters, a number, and a symbol.</p></header>
        <?php if ($success): ?><div class="message success" role="status">Your password has been changed. Use the new password the next time you sign in.</div><?php endif; ?>
        <?php if ($error !== ''): ?><div class="error" role="alert"><?= e($error) ?></div><?php endif; ?>
        <form method="post" autocomplete="off">
            <?= csrfField() ?>
            <div class="form-group"><label for="username">Administrator username</label><input id="username" name="username" maxlength="50" autocomplete="username" required value="<?= e($username) ?>"></div>
            <div class="form-group"><label for="current_password">Current password</label><input id="current_password" name="current_password" type="password" maxlength="1024" autocomplete="current-password" required></div>
            <div class="form-group"><label for="new_password">New password</label><input id="new_password" name="new_password" type="password" minlength="6" pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{6,}" title="Use at least 6 characters with uppercase and lowercase letters, a number, and a symbol" maxlength="1024" autocomplete="new-password" required><small>At least 6 characters, including uppercase and lowercase letters, a number, and a symbol.</small></div>
            <div class="form-group"><label for="confirm_password">Confirm new password</label><input id="confirm_password" name="confirm_password" type="password" minlength="6" maxlength="1024" autocomplete="new-password" required></div>
            <label class="password-visibility" for="showChangePasswords"><input id="showChangePasswords" type="checkbox" aria-controls="current_password new_password confirm_password"><span>Show passwords</span></label>
            <button type="submit"><i class="fa-solid fa-key" aria-hidden="true"></i> Save new password</button>
        </form>
        <p class="password-change-note">Forgot your current password? <a href="<?= e(appUrl('admin/forgot_password.php')) ?>">Reset it with a one-time code sent to your administrator email.</a></p>
        <a class="password-change-back" href="<?= e(appUrl($isSignedIn ? 'admin/dashboard.php' : 'admin/login.php')) ?>"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i> <?= $isSignedIn ? 'Return to dashboard' : 'Return to sign in' ?></a>
    </section>
</main>
<script>
(() => {
    const toggle = document.getElementById('showChangePasswords');
    const fields = [
        document.getElementById('current_password'),
        document.getElementById('new_password'),
        document.getElementById('confirm_password')
    ];
    if (!toggle) return;
    toggle.addEventListener('change', () => {
        fields.forEach((field) => {
            if (field) field.type = toggle.checked ? 'text' : 'password';
        });
    });
})();
</script>
    <script src="<?= e(appUrl('admin/assets/admin-password.js?v=1')) ?>" defer></script></body>""
</html>
