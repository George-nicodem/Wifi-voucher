<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/admin_email_auth.php';
startAdminSession();

if (isAdminLoggedIn()) {
    header('Location: ' . appUrl('admin/dashboard.php'), true, 302);
    exit;
}

if (isset($_GET['restart'])) {
    unset($_SESSION['admin_password_reset_email']);
}

$error = '';
$notice = '';
$email = (string)($_SESSION['admin_password_reset_email'] ?? '');
$schemaReady = adminEmailAuthSchemaReady();
$resetToken = trim((string) ($_GET['token'] ?? $_POST['email_code'] ?? ''));
$resetAdminId = (int) ($_GET['admin_id'] ?? $_POST['reset_admin_id'] ?? 0);
$hasResetLink = $resetToken !== '' || $resetAdminId > 0;
if ($resetAdminId > 0 && preg_match('/^[a-f0-9]{64}$/D', $resetToken)) {
    $tokenLookup = $conn->prepare("SELECT email FROM admin_users WHERE id = ? AND status = 'active' LIMIT 1");
    if ($tokenLookup) {
        $tokenLookup->bind_param('i', $resetAdminId);
        if ($tokenLookup->execute()) {
            $tokenResult = $tokenLookup->get_result();
            $tokenAdmin = $tokenResult ? $tokenResult->fetch_assoc() : null;
            $tokenEmail = adminAccountEmail((string) ($tokenAdmin['email'] ?? ''));
            if (filter_var($tokenEmail, FILTER_VALIDATE_EMAIL) !== false) {
                $email = $tokenEmail;
                $_SESSION['admin_password_reset_email'] = $email;
            }
        }
        $tokenLookup->close();}}

$showCodeForm = $hasResetLink && $resetAdminId > 0 && preg_match('/^[a-f0-9]{64}$/D', $resetToken) === 1;
if ($hasResetLink && !$showCodeForm) {
    $error = 'This password reset link is invalid or has expired. Request a new one.';
}
if (isPost()) {

    requireCsrfToken();
    $action = postString('form_action', 'request_reset');

    if (!$schemaReady) {
        $error = 'Administrator email sign-in is not set up. Run admin/database/admin_accounts.sql first.';
    } elseif ($action === 'request_reset') {
        $email = adminAccountEmail(postString('email'));
        if (filter_var($email, FILTER_VALIDATE_EMAIL) === false || strlen($email) > 190) {
            $error = 'Enter a valid administrator email address.';
        } else {
            $_SESSION['admin_password_reset_email'] = $email;
            $showCodeForm = false;

            $lookup = $conn->prepare("SELECT id, username, email, full_name FROM admin_users WHERE email = ? AND status = 'active' LIMIT 1");
            if (!$lookup) {
                logDatabaseError($conn, 'Preparing administrator password reset lookup');
                $error = 'Unable to start the password reset process right now. Please try again later.';
            } else {
                $lookup->bind_param('s', $email);
                if (!$lookup->execute()) {
                    logDatabaseError($conn, 'Looking up administrator password reset account');
                    $error = 'Unable to start the password reset process right now. Please try again later.';
                } else {
                    $result = $lookup->get_result();
                    $admin = $result ? $result->fetch_assoc() : null;
                    if ($admin) {
                        $issue = adminIssueEmailCode($admin, 'password_reset');
                        if (!empty($issue['sent']) || !empty($issue['cooldown'])) {
                            $notice = 'If that email belongs to an active administrator, check your inbox for a reset link. If you do not receive one, wait a minute before requesting another.';
                        } else {
                            $error = (string)$issue['message'];
                        }
                    } else {
                        $notice = 'If that email belongs to an active administrator, a password reset link will be sent.';
                    }
                }
                $lookup->close();
            }
        }
    } elseif ($action === 'reset_password') {
        $email = adminAccountEmail((string)($_SESSION['admin_password_reset_email'] ?? ''));
        $code = postString('email_code');
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['password_confirm'] ?? '';
        $newPassword = is_string($newPassword) ? $newPassword : '';
        $confirmPassword = is_string($confirmPassword) ? $confirmPassword : '';
        $passwordLength = function_exists('mb_strlen') ? mb_strlen($newPassword) : strlen($newPassword);

        if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            unset($_SESSION['admin_password_reset_email']);
            $showCodeForm = false;
            $error = 'Start again with the administrator email.';
        } elseif ($passwordLength < 6 || strlen($newPassword) > 1024 || !preg_match('/[a-z]/', $newPassword) || !preg_match('/[A-Z]/', $newPassword) || !preg_match('/[0-9]/', $newPassword) || !preg_match('/[^A-Za-z0-9]/', $newPassword)) {
            $error = 'Use at least 6 characters, including uppercase and lowercase letters, a number, and a symbol.';
        } elseif (!hash_equals($newPassword, $confirmPassword)) {
            $error = 'The new password and confirmation do not match.';
        } else {
            $lookup = $conn->prepare("SELECT id FROM admin_users WHERE email = ? AND status = 'active' LIMIT 1");
            $adminId = 0;
            if (!$lookup) {
                logDatabaseError($conn, 'Preparing administrator password reset verification');
                $error = 'Could not verify the account right now. Please try again.';
            } else {
                $lookup->bind_param('s', $email);
                if (!$lookup->execute()) {
                    logDatabaseError($conn, 'Looking up administrator for password reset');
                    $error = 'Could not verify the account right now. Please try again.';
                } else {
                    $result = $lookup->get_result();
                    $adminRow = $result ? $result->fetch_assoc() : null;
                    $adminId = (int)($adminRow['id'] ?? 0);
                }
                $lookup->close();
            }

            if ($error === '' && $adminId <= 0) {
                $error = 'This reset link is invalid or has expired. Request a new one.';
            }
            if ($error === '') {
                $verification = adminVerifyEmailCode($adminId, $code);
                if (empty($verification['ok'])) {
                    $error = (string)$verification['message'];
                } else {
                    $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
                    if (!is_string($newHash) || $newHash === '') {
                        $error = 'The new password could not be securely saved.';
                    } else {
                        $update = $conn->prepare("UPDATE admin_users SET password_hash = ? WHERE id = ? AND status = 'active'");
                        if (!$update) {
                            logDatabaseError($conn, 'Preparing administrator password reset update');
                            $error = 'The password could not be changed. Please try again.';
                        } else {
                            $update->bind_param('si', $newHash, $adminId);
                            if (!$update->execute() || $update->affected_rows !== 1) {
                                logDatabaseError($conn, 'Updating administrator password through email reset');
                                $error = 'The password could not be changed. Please try again.';
                            }
                            $update->close();
                        }
                    }

                    if ($error === '') {
                        unset($_SESSION['admin_password_reset_email']);
                        header('Location: ' . appUrl('admin/login.php?password_reset=1'), true, 303);
                        exit;
                    }
                }
            }
        }
    } else {
        $error = 'Unrecognized password reset request.';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Reset administrator password | <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="<?= e(appUrl('admin/assets/auth-theme.css?v=5')) ?>">
</head>
<body class="auth-page">
<main class="login-container">
    <section class="login-card">
        <div class="auth-brand"><span class="auth-brand-mark"><i class="fa-solid fa-wifi" aria-hidden="true"></i></span><span><strong>WiFi Voucher</strong><small>Administrator recovery</small></span></div>
        <header class="login-title"><h1><?= $showCodeForm ? 'Set a new password' : 'Forgot your password?' ?></h1><p><?= $showCodeForm ? 'Use the one-time reset link sent to the administrator email.' : 'We will send a one-time password reset link to the administrator email.' ?></p></header>
        <?php if ($notice !== ''): ?><div class="message success" role="status"><?= e($notice) ?></div><?php endif; ?>
        <?php if (!$schemaReady): ?><div class="error" role="alert">Administrator email sign-in is not set up. Run <code>admin/database/admin_accounts.sql</code> first.</div><?php endif; ?>
        <?php if ($error !== ''): ?><div class="error" role="alert"><?= e($error) ?></div><?php endif; ?>
        <?php if ($showCodeForm): ?>
            <form method="post" action="<?= e(appUrl('admin/forgot_password.php')) ?>" autocomplete="on">
                <?= csrfField() ?><input type="hidden" name="form_action" value="reset_password">
                <input type="hidden" name="email_code" value="<?= e($resetToken) ?>"><input type="hidden" name="reset_admin_id" value="<?= $resetAdminId ?>"><p class="password-change-note">This one-time reset link expires after 5 minutes and can only be used once.</p>
                <div class="form-group"><label for="new_password">New password</label><input id="new_password" name="new_password" type="password" minlength="6" pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{6,}" title="Use at least 6 characters with uppercase and lowercase letters, a number, and a symbol" maxlength="1024" autocomplete="new-password" required><small>At least 6 characters, including uppercase and lowercase letters, a number, and a symbol.</small></div>
                <div class="form-group"><label for="password_confirm">Confirm new password</label><input id="password_confirm" name="password_confirm" type="password" minlength="6" maxlength="1024" autocomplete="new-password" required></div>
                <label class="password-visibility" for="showResetPasswords"><input id="showResetPasswords" type="checkbox" aria-controls="new_password password_confirm"><span>Show passwords</span></label>
                <button type="submit" <?= !$schemaReady ? 'disabled' : '' ?>><i class="fa-solid fa-key" aria-hidden="true"></i> Set a new password</button>
            </form>
            <div class="auth-links"><a href="<?= e(appUrl('admin/forgot_password.php?restart=1')) ?>">Use a different email</a><a href="<?= e(appUrl('admin/login.php')) ?>">Return to administrator sign-in</a></div>
        <?php else: ?>
            <form method="post" action="<?= e(appUrl('admin/forgot_password.php')) ?>" autocomplete="on">
                <?= csrfField() ?><input type="hidden" name="form_action" value="request_reset">
                <div class="form-group"><label for="email">Existing administrator email</label><input id="email" name="email" type="email" maxlength="190" autocomplete="email" value="<?= e($email) ?>" required></div>
                <button type="submit" <?= !$schemaReady ? 'disabled' : '' ?>><i class="fa-solid fa-envelope" aria-hidden="true"></i> Send password reset link</button>
            </form>
            <div class="auth-links"><a href="<?= e(appUrl('admin/login.php')) ?>">Return to administrator sign-in</a></div>
        <?php endif; ?>
        <footer class="footer"><?= e(APP_NAME) ?> · Admin Panel</footer>
    </section>
</main>
<script>
(() => {
    const toggle = document.getElementById('showResetPasswords');
    const fields = [document.getElementById('new_password'), document.getElementById('password_confirm')];
    if (!toggle) return;
    toggle.addEventListener('change', () => {
        fields.forEach((field) => {
            if (field) field.type = toggle.checked ? 'text' : 'password';
        });
    });
})();
</script>
    <script src="<?= e(appUrl('admin/assets/admin-password.js?v=1')) ?>" defer></script></body>""
</html>
