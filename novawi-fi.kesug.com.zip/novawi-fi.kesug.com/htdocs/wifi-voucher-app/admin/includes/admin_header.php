<?php
declare(strict_types=1);

if (!isset($pageTitle) || !is_string($pageTitle) || $pageTitle === '') {
    $pageTitle = 'Dashboard';
}

$adminName = currentAdminName();
$adminRole = currentAdminRole();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0, viewport-fit=cover"
    >

    <meta
        name="robots"
        content="noindex, nofollow"
    >

    <title>
        <?= e($pageTitle) ?> - <?= e(APP_NAME) ?>
    </title>

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >
    <link rel="stylesheet" href="<?= e(appUrl('admin/assets/admin-theme.css?v=5')) ?>">

</head>

<body>

<div class="admin-layout">

    <?php require __DIR__ . '/admin_sidebar.php'; ?>

    <main class="admin-main">

        <header class="admin-topbar">

            <div class="topbar-left">

                <button
                    type="button"
                    class="mobile-menu-btn"
                    id="mobileMenuBtn"
                    aria-label="Open menu"
                    aria-controls="adminSidebar"
                    aria-expanded="false"
                >
                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true" focusable="false">
                        <path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" />
                    </svg>
                    <span>Menu</span>
                </button>

                <?php if (($page ?? 'dashboard') !== 'dashboard'): ?>
                <a class="admin-back-link" href="<?= e(appUrl('admin/dashboard.php')) ?>" aria-label="Back to dashboard"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i><span>Dashboard</span></a>
                <?php endif; ?>
                <div class="admin-context"><span><?= e($pageTitle) ?></span></div>

            </div>

            <div class="topbar-right">

                <div class="admin-profile">

                    <div class="admin-avatar">
                        <i class="fa-solid fa-user"></i>
                    </div>

                    <div class="admin-info">

                        <div class="admin-name">
                            <?= e($adminName) ?>
                        </div>

                        <div class="admin-role">
                            <?= e($adminRole) ?>
                        </div>

                    </div>

                </div>

                <a class="admin-password-link" href="<?= e(appUrl('admin/change_password.php')) ?>" title="Change password" aria-label="Change password">
                    <i class="fa-solid fa-key" aria-hidden="true"></i>
                    <span>Change password</span>
                </a>

            </div>

        </header>

        <section class="admin-content">
