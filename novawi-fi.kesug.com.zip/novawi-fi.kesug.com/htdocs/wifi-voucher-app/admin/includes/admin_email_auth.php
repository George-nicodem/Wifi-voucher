<?php
declare(strict_types=1);

require_once __DIR__ . '/admin_auth.php';
require_once __DIR__ . '/../../includes/customer_mail.php';

function adminEmailAuthSchemaReady(): bool
{
    global $conn;

    $admins = $conn->query('SELECT id, username, email, password_hash, full_name, role, status FROM admin_users LIMIT 0');
    $codes = $conn->query('SELECT admin_id, code_hash, expires_at, attempt_count, consumed_at, created_at FROM admin_login_codes LIMIT 0');
    $requests = $conn->query('SELECT id, email, full_name, password_hash, status, created_at FROM admin_account_requests LIMIT 0');
    return $admins !== false && $codes !== false && $requests !== false;
}

function adminAccountEmail(string $email): string
{
    return strtolower(trim($email));
}

/** Create the first active administrator only when the system has no administrator accounts yet. */
function adminBootstrapFirstAccount(string $email, string $fullName, string $passwordHash): string
{
    global $conn;

    $lockName = 'wifi_voucher_first_admin_setup';
    $lock = $conn->prepare('SELECT GET_LOCK(?, 5)');
    if (!$lock) {
        logDatabaseError($conn, 'Preparing first administrator setup lock');
        return 'error';
    }
    $lock->bind_param('s', $lockName);
    $lockAcquired = false;
    if ($lock->execute()) {
        $lockResult = $lock->get_result();
        $lockRow = $lockResult ? $lockResult->fetch_row() : null;
        $lockAcquired = is_array($lockRow) && (int)($lockRow[0] ?? 0) === 1;
    }
    $lock->close();
    if (!$lockAcquired) {
        return 'error';
    }

    try {
        if (!$conn->begin_transaction()) {
            throw new RuntimeException('Could not start first administrator setup transaction.');
        }

        $existingAdmins = $conn->query('SELECT id FROM admin_users ORDER BY id ASC LIMIT 1');
        if (!$existingAdmins) {
            throw new RuntimeException('Could not check for existing administrator accounts.');
        }
        if ($existingAdmins->num_rows > 0) {
            if (!$conn->commit()) {
                throw new RuntimeException('Could not finish administrator setup check.');
            }
            return 'exists';
        }

        $usernameLookup = $conn->prepare('SELECT id FROM admin_users WHERE username = ? LIMIT 1');
        if (!$usernameLookup) {
            throw new RuntimeException('Could not prepare first administrator username lookup.');
        }
        $username = '';
        for ($attempt = 0; $attempt < 8; $attempt++) {
            $candidate = 'a' . bin2hex(random_bytes(8));
            $usernameLookup->bind_param('s', $candidate);
            if (!$usernameLookup->execute()) {
                $usernameLookup->close();
                throw new RuntimeException('Could not check first administrator username.');
            }
            $result = $usernameLookup->get_result();
            if (!$result || $result->num_rows === 0) {
                $username = $candidate;
                break;
            }
        }
        $usernameLookup->close();
        if ($username === '') {
            throw new RuntimeException('Could not allocate a unique first administrator username.');
        }

        $role = 'admin';
        $status = 'active';
        $insert = $conn->prepare('INSERT INTO admin_users (username, email, password_hash, full_name, role, status) VALUES (?, ?, ?, ?, ?, ?)');
        if (!$insert) {
            throw new RuntimeException('Could not prepare first administrator creation.');
        }
        $insert->bind_param('ssssss', $username, $email, $passwordHash, $fullName, $role, $status);
        if (!$insert->execute()) {
            $insert->close();
            throw new RuntimeException('Could not create first administrator.');
        }
        $insert->close();

        $clearOldRequest = $conn->prepare("UPDATE admin_account_requests
            SET password_hash = '', status = 'approved', reviewed_at = CURRENT_TIMESTAMP, reviewed_by_admin_id = NULL
            WHERE email = ?");
        if (!$clearOldRequest) {
            throw new RuntimeException('Could not prepare first administrator request cleanup.');
        }
        $clearOldRequest->bind_param('s', $email);
        if (!$clearOldRequest->execute()) {
            $clearOldRequest->close();
            throw new RuntimeException('Could not clear the previous first administrator request.');
        }
        $clearOldRequest->close();

        if (!$conn->commit()) {
            throw new RuntimeException('Could not save first administrator.');
        }
        return 'created';
    } catch (Throwable $exception) {
        $conn->rollback();
        error_log('[WiFi Voucher] First administrator setup failed: ' . $exception->getMessage());
        return 'error';
    } finally {
        $release = $conn->prepare('SELECT RELEASE_LOCK(?)');
        if ($release) {
            $release->bind_param('s', $lockName);
            $release->execute();
            $release->close();
        }
    }
}

/** Send a short-lived, single-use administrator sign-in code. */
function adminIssueEmailCode(array $admin, string $purpose = 'login'): array
{
    global $conn;

    $adminId = (int)($admin['id'] ?? 0);
    $email = adminAccountEmail((string)($admin['email'] ?? ''));
    $name = trim((string)($admin['full_name'] ?? '')) ?: (string)($admin['username'] ?? 'Administrator');
    if ($adminId <= 0 || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
        return ['sent' => false, 'cooldown' => false, 'message' => 'This account does not have a valid email address. Contact the system administrator.'];
    }

    $previous = $conn->prepare('SELECT created_at, expires_at, attempt_count, consumed_at FROM admin_login_codes WHERE admin_id = ? LIMIT 1');
    if ($previous) {
        $previous->bind_param('i', $adminId);
        if ($previous->execute()) {
            $result = $previous->get_result();
            $row = $result ? $result->fetch_assoc() : null;
            $createdAt = $row ? strtotime((string)$row['created_at']) : false;
            $expiresAt = $row ? strtotime((string)$row['expires_at']) : false;
            $usable = $row
                && empty($row['consumed_at'])
                && (int)$row['attempt_count'] < 5
                && $expiresAt !== false
                && $expiresAt > time();
            if ($usable && $createdAt !== false && time() - $createdAt < 60) {
                $previous->close();
                return ['sent' => false, 'cooldown' => true, 'message' => ($purpose === 'password_reset' ? 'A verification email was sent recently. If it contains a reset link, use it; otherwise wait one minute and request another link.' : 'A code was sent recently. Enter the code sent to your email.')];
            }
        }
        $previous->close();
    }

    $code = (string)($purpose === 'password_reset' ? bin2hex(random_bytes(32)) : random_int(100000, 999999));
    $codeHash = password_hash($code, PASSWORD_DEFAULT);
    if (!is_string($codeHash) || $codeHash === '') {
        return ['sent' => false, 'cooldown' => false, 'message' => 'Could not generate a sign-in code. Please try again.'];
    }

    $save = $conn->prepare("INSERT INTO admin_login_codes (admin_id, code_hash, expires_at, attempt_count, consumed_at, created_at)
        VALUES (?, ?, DATE_ADD(CURRENT_TIMESTAMP, INTERVAL 5 MINUTE), 0, NULL, CURRENT_TIMESTAMP)
        ON DUPLICATE KEY UPDATE code_hash = VALUES(code_hash), expires_at = VALUES(expires_at), attempt_count = 0, consumed_at = NULL, created_at = CURRENT_TIMESTAMP");
    if (!$save) {
        appLog('Could not prepare administrator login code storage', ['error' => $conn->error]);
        return ['sent' => false, 'cooldown' => false, 'message' => 'Could not generate the email code. Please try again.'];
    }
    $save->bind_param('is', $adminId, $codeHash);
    if (!$save->execute()) {
        appLog('Could not store administrator login code', ['error' => $save->error]);
        $save->close();
        return ['sent' => false, 'cooldown' => false, 'message' => 'Could not generate the email code. Please try again.'];
    }
    $save->close();

    $isPasswordReset = $purpose === 'password_reset';
    $resetUrl = $isPasswordReset
        ? appUrl('admin/forgot_password.php') . '?admin_id=' . rawurlencode((string)$adminId) . '&token=' . rawurlencode($code)
        : '';
    $actionLabel = $isPasswordReset ? 'reset the password for the Admin Panel of ' : 'sign in to the Admin Panel of ';
    $subject = $isPasswordReset ? APP_NAME . ' admin password reset link' : APP_NAME . ' admin login code';
    $body = "Hello {$name},\n\n" . ($isPasswordReset
        ? "Use this one-time password reset link:\n{$resetUrl}\n\nIt expires in 5 minutes. If you did not request it, you can ignore this email.\n"
        : "Your code to {$actionLabel}" . APP_NAME . " is: {$code}\n\nThis code can be used once and expires in 5 minutes. If you did not request it, you can ignore this email.\n");

    if (!wifiSendEmail($email, $subject, $body)) {
        $delete = $conn->prepare('DELETE FROM admin_login_codes WHERE admin_id = ?');
        if ($delete) {
            $delete->bind_param('i', $adminId);
            $delete->execute();
            $delete->close();
        }
        return ['sent' => false, 'cooldown' => false, 'message' => 'Unable to send the verification email. Check the email settings and try again.'];
    }

    return ['sent' => true, 'cooldown' => false, 'message' => ($isPasswordReset ? 'We sent a password reset link to your email.' : 'We sent a sign-in code to your email.')];
}

/** Validate and consume an administrator email code once, counting up to five tries. */
function adminVerifyEmailCode(int $adminId, string $code): array
{
    global $conn;

    if ($adminId <= 0 || (!preg_match('/^\d{6}$/D', $code) && !preg_match('/^[a-f0-9]{64}$/D', $code))) {
        return ['ok' => false, 'message' => 'Enter the 6-digit code from your email, or use the one-time password reset link.'];
    }

    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare('SELECT code_hash, expires_at, attempt_count, consumed_at, created_at FROM admin_login_codes WHERE admin_id = ? FOR UPDATE');
        if (!$stmt) {
            throw new RuntimeException('Could not prepare administrator code lookup.');
        }
        $stmt->bind_param('i', $adminId);
        if (!$stmt->execute()) {
            $stmt->close();
            throw new RuntimeException('Could not execute administrator code lookup.');
        }
        $result = $stmt->get_result();
        $record = $result ? $result->fetch_assoc() : null;
        $stmt->close();

        $expiresAt = $record ? strtotime((string)$record['expires_at']) : false;
        $createdAt = $record ? strtotime((string)$record['created_at']) : false;
        $available = $record
            && empty($record['consumed_at'])
            && (int)$record['attempt_count'] < 5
            && $createdAt !== false
            && $createdAt > time() - 300
            && $expiresAt !== false
            && $expiresAt > time();
        $matches = $available && password_verify($code, (string)$record['code_hash']);

        if (!$matches) {
            if ($record && empty($record['consumed_at']) && (int)$record['attempt_count'] < 5) {
                $attempts = (int)$record['attempt_count'] + 1;
                $consume = $attempts >= 5 ? ', consumed_at = CURRENT_TIMESTAMP' : '';
                $update = $conn->prepare('UPDATE admin_login_codes SET attempt_count = ?' . $consume . ' WHERE admin_id = ?');
                if ($update) {
                    $update->bind_param('ii', $attempts, $adminId);
                    $update->execute();
                    $update->close();
                }
            }
            $conn->commit();
            return ['ok' => false, 'message' => 'The code or reset link is incorrect, expired, or already used. Request a new one and try again.'];
        }

        $consume = $conn->prepare('UPDATE admin_login_codes SET consumed_at = CURRENT_TIMESTAMP WHERE admin_id = ? AND consumed_at IS NULL');
        if (!$consume) {
            throw new RuntimeException('Could not prepare administrator code consumption.');
        }
        $consume->bind_param('i', $adminId);
        if (!$consume->execute() || $consume->affected_rows !== 1) {
            $consume->close();
            throw new RuntimeException('Could not consume administrator email code.');
        }
        $consume->close();
        $conn->commit();
        return ['ok' => true, 'message' => 'Email verified.'];
    } catch (Throwable $exception) {
        $conn->rollback();
        appLog('Administrator email code verification failed', ['error' => $exception->getMessage()]);
        return ['ok' => false, 'message' => 'Could not verify the code right now. Please try again.'];
    }
}

function adminClearPendingEmailLogin(): void
{
    unset($_SESSION['admin_login_pending_id'], $_SESSION['admin_login_pending_email']);
}
