<?php
declare(strict_types=1);

$currentPage = getString('page', 'dashboard');

$adminRole = currentAdminRole();

function adminNavActive(string $page, string $currentPage): string
{
    if ($page === 'settings' && in_array($currentPage, ['settings', 'trial_settings', 'backup'], true)) {
        return 'active';
    }

    return $page === $currentPage ? 'active' : '';
}

function adminNavUrl(string $page): string
{
    return appUrl('admin/dashboard.php?page=' . rawurlencode($page));
}
?>

<aside class="admin-sidebar" id="adminSidebar" aria-label="Main administration menu">

    <div class="sidebar-header">

        <div class="sidebar-logo">
            <div class="logo-icon">
                <i class="fa-solid fa-wifi"></i>
            </div>

            <div class="logo-text">
                <strong>WiFi Voucher</strong>
                <span>Admin Panel</span>
            </div>
        </div>

        <button
            type="button"
            class="sidebar-close"
            id="sidebarClose"
            aria-label="Close menu"
            aria-controls="adminSidebar"
        >
            <i class="fa-solid fa-xmark"></i>
        </button>

    </div>

<nav class="sidebar-nav" aria-label="System pages">

        <div class="nav-section-title">
            MAIN
        </div>


        <a
            href="<?= e(adminNavUrl('dashboard')) ?>"
            class="nav-item <?= e(adminNavActive('dashboard', $currentPage)) ?>"
        >
            <i class="fa-solid fa-gauge-high"></i>
            <span>Dashboard</span>
        </a>


        <div class="nav-section-title">
            SALES &amp; SERVICES
        </div>

        <a
            href="<?= e(adminNavUrl('vouchers')) ?>"
            class="nav-item <?= e(adminNavActive('vouchers', $currentPage)) ?>"
        >
            <i class="fa-solid fa-ticket"></i>
            <span>Vouchers</span>
        </a>

        <a
            href="<?= e(adminNavUrl('packages')) ?>"
            class="nav-item <?= e(adminNavActive('packages', $currentPage)) ?>"
        >
            <i class="fa-solid fa-box"></i>
            <span>Packages</span>
        </a>

        <a
            href="<?= e(adminNavUrl('payments')) ?>"
            class="nav-item <?= e(adminNavActive('payments', $currentPage)) ?>"
        >
            <i class="fa-solid fa-money-bill-transfer"></i>
            <span>Payments &amp; Sales</span>
        </a>

        <a
            href="<?= e(adminNavUrl('wallet')) ?>"
            class="nav-item <?= e(adminNavActive('wallet', $currentPage)) ?>"
        >
            <i class="fa-solid fa-wallet"></i>
            <span>Admin Wallet</span>
        </a>


        <details class="nav-group" <?= in_array($currentPage, ['payment_methods', 'payment_channels', 'payment_routing'], true) ? 'open' : '' ?>>
            <summary class="nav-group-toggle">
                <span>PAYMENT CONFIGURATION</span>
                <i class="fa-solid fa-chevron-down" aria-hidden="true"></i>
            </summary>
            <div class="nav-group-links">
                <a
                    href="<?= e(adminNavUrl('payment_methods')) ?>"
                    class="nav-item <?= e(adminNavActive('payment_methods', $currentPage)) ?>"
                >
                    <i class="fa-solid fa-credit-card"></i>
                    <span>Payment Methods</span>
                </a>

                <a
                    href="<?= e(adminNavUrl('payment_channels')) ?>"
                    class="nav-item <?= e(adminNavActive('payment_channels', $currentPage)) ?>"
                >
                    <i class="fa-solid fa-tower-broadcast"></i>
                    <span>Payment Channels</span>
                </a>

                <a
                    href="<?= e(adminNavUrl('payment_routing')) ?>"
                    class="nav-item <?= e(adminNavActive('payment_routing', $currentPage)) ?>"
                >
                    <i class="fa-solid fa-route"></i>
                    <span>Payment Routing</span>
                </a>
            </div>
        </details>

        <details class="nav-group" <?= in_array($currentPage, ['sites', 'router'], true) ? 'open' : '' ?>>
            <summary class="nav-group-toggle">
                <span>NETWORK</span>
                <i class="fa-solid fa-chevron-down" aria-hidden="true"></i>
            </summary>
            <div class="nav-group-links">
                <a
                    href="<?= e(adminNavUrl('sites')) ?>"
                    class="nav-item <?= e(adminNavActive('sites', $currentPage)) ?>"
                >
                    <i class="fa-solid fa-location-dot"></i>
                    <span>Sites</span>
                </a>

                <a
                    href="<?= e(adminNavUrl('router')) ?>"
                    class="nav-item <?= e(adminNavActive('router', $currentPage)) ?>"
                >
                    <i class="fa-solid fa-network-wired"></i>
                    <span>Routers &amp; Wi-Fi</span>
                </a>
            </div>
        </details>

        <div class="nav-section-title">
            CUSTOMER EXPERIENCE
        </div>

        <a
            href="<?= e(adminNavUrl('customer_portal')) ?>"
            class="nav-item <?= e(adminNavActive('customer_portal', $currentPage)) ?>"
            aria-label="Customer Portal theme and preview settings"
        >
            <i class="fa-solid fa-palette"></i>
            <span>Customer Portal &amp; Theme</span>
        </a>


        <div class="nav-section-title">
            REPORTS
        </div>

        <a
            href="<?= e(adminNavUrl('reports')) ?>"
            class="nav-item <?= e(adminNavActive('reports', $currentPage)) ?>"
        >
            <i class="fa-solid fa-chart-column"></i>
            <span>Reports</span>
        </a>


        <div class="nav-section-title">
            SYSTEM
        </div>

        <?php if (!function_exists('currentAdminIsMaster') || currentAdminIsMaster()): ?>
            <a
                href="<?= e(adminNavUrl('users')) ?>"
                class="nav-item <?= e(adminNavActive('users', $currentPage)) ?>"
            >
                <i class="fa-solid fa-users"></i>
                <span>Admin Users</span>
            </a>
        <?php endif; ?>

        <a
            href="<?= e(adminNavUrl('security')) ?>"
            class="nav-item <?= e(adminNavActive('security', $currentPage)) ?>"
        >
            <i class="fa-solid fa-shield-halved"></i>
            <span>Security &amp; Audit</span>
        </a>


        <div class="nav-section-title">
            SETTINGS
        </div>

        <a
            href="<?= e(adminNavUrl('settings')) ?>"
            class="nav-item <?= e(adminNavActive('settings', $currentPage)) ?>"
        >
            <i class="fa-solid fa-gear"></i>
            <span>Settings</span>
        </a>

    </nav>


    <div class="sidebar-footer">
        <a
            href="<?= e(appUrl('admin/logout.php')) ?>"
            class="logout-link"
        >
            <i class="fa-solid fa-right-from-bracket"></i>
            <span>Logout</span>
        </a>

    </div>

</aside>


<div
    class="page-overlay"
    id="pageOverlay"
></div>





<script>

(function () {
    function initAdminMobileNavigation() {
        const sidebar = document.getElementById('adminSidebar');
        const menuButton = document.getElementById('mobileMenuBtn');
        const closeButton = document.getElementById('sidebarClose');
        const overlay = document.getElementById('pageOverlay');
        const mobileQuery = window.matchMedia('(max-width: 1100px), (any-pointer: coarse), (max-device-width: 1100px)');

        if (!sidebar || !menuButton) {
            return;
        }

        let focusBeforeOpen = null;

        function syncClosedState() {
            const isMobile = mobileQuery.matches;
            sidebar.setAttribute('aria-hidden', isMobile ? 'true' : 'false');
            menuButton.setAttribute('aria-expanded', 'false');
        }

        function openSidebar() {
            if (!mobileQuery.matches) {
                return;
            }

            focusBeforeOpen = document.activeElement;
            sidebar.classList.add('open');
            sidebar.setAttribute('aria-hidden', 'false');
            overlay?.classList.add('show');
            document.documentElement.classList.add('mobile-nav-open');
            document.body.classList.add('mobile-nav-open');
            menuButton.setAttribute('aria-expanded', 'true');
            closeButton?.focus({ preventScroll: true });
        }

        function closeSidebar(restoreFocus = false) {
            sidebar.classList.remove('open');
            overlay?.classList.remove('show');
            document.documentElement.classList.remove('mobile-nav-open');
            document.body.classList.remove('mobile-nav-open');
            syncClosedState();

            if (restoreFocus && mobileQuery.matches && focusBeforeOpen instanceof HTMLElement) {
                focusBeforeOpen.focus({ preventScroll: true });
            }
        }

        menuButton.addEventListener('click', openSidebar);
        closeButton?.addEventListener('click', () => closeSidebar(true));
        overlay?.addEventListener('click', () => closeSidebar(true));

        sidebar.querySelectorAll('.sidebar-nav a, .logout-link').forEach((link) => {
            link.addEventListener('click', () => closeSidebar(false));
        });

        document.addEventListener('keydown', (event) => {
            if (!sidebar.classList.contains('open')) {
                return;
            }

            if (event.key === 'Escape') {
                event.preventDefault();
                closeSidebar(true);
                return;
            }

            if (event.key !== 'Tab') {
                return;
            }

            const focusable = Array.from(sidebar.querySelectorAll(
                'button:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])'
            )).filter((element) => element.offsetParent !== null);

            if (focusable.length === 0) {
                event.preventDefault();
                return;
            }

            const first = focusable[0];
            const last = focusable[focusable.length - 1];

            if (event.shiftKey && document.activeElement === first) {
                event.preventDefault();
                last.focus();
            } else if (!event.shiftKey && document.activeElement === last) {
                event.preventDefault();
                first.focus();
            }
        });

        const handleViewportChange = () => closeSidebar(false);
        if (typeof mobileQuery.addEventListener === 'function') {
            mobileQuery.addEventListener('change', handleViewportChange);
        } else if (typeof mobileQuery.addListener === 'function') {
            mobileQuery.addListener(handleViewportChange);
        }

        syncClosedState();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAdminMobileNavigation, { once: true });
    } else {
        initAdminMobileNavigation();
    }
})();

</script>
