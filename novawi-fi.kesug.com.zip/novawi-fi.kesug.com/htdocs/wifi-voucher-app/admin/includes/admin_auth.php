<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| ADMIN AUTHENTICATION
|--------------------------------------------------------------------------
| Handles:
| - Secure admin sessions
| - Admin login state
| - Session timeout
| - Logout
| - CSRF protection
| - Admin roles
| - Security logging
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/../../config/app.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/security.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/csrf.php';


/*
|--------------------------------------------------------------------------
| START ADMIN SESSION
|--------------------------------------------------------------------------
*/

function startAdminSession(): void
{
    startSecureSession();
}


/*
|--------------------------------------------------------------------------
| CHECK LOGIN STATUS
|--------------------------------------------------------------------------
*/

function isAdminLoggedIn(): bool
{
    startAdminSession();

    return isset($_SESSION['admin_id'])
        && is_numeric($_SESSION['admin_id'])
        && (int)$_SESSION['admin_id'] > 0
        && !empty($_SESSION['admin_authenticated']);
}


/*
|--------------------------------------------------------------------------
| REQUIRE ADMIN LOGIN
|--------------------------------------------------------------------------
*/

/**
 * Revalidate an existing login once per request. A disabled or deleted account
 * must lose access even when its old session cookie is still valid.
 */
function adminSessionAccountIsActive(): bool
{
    static $validatedAccounts = [];
    $adminId = (int)($_SESSION['admin_id'] ?? 0);
    if ($adminId < 1 || empty($_SESSION['admin_authenticated'])) {
        return false;
    }

    $validationKey = session_id() . ':' . $adminId;
    if (isset($validatedAccounts[$validationKey])) {
        return true;
    }

    global $conn;
    if (!($conn instanceof mysqli)) {
        throw new RuntimeException('Administrator database connection is unavailable.');
    }
    $statement = $conn->prepare('SELECT role, status FROM admin_users WHERE id = ? LIMIT 1');
    if (!$statement) {
        throw new RuntimeException('Could not prepare administrator account validation.');
    }

    try {
        if (!$statement->bind_param('i', $adminId) || !$statement->execute()) {
            throw new RuntimeException('Could not validate the administrator account.');
        }
        $result = $statement->get_result();
        if (!($result instanceof mysqli_result)) {
            throw new RuntimeException('Could not read the administrator account.');
        }
        try {
            $account = $result->fetch_assoc();
        } finally {
            $result->free();
        }
    } finally {
        $statement->close();
    }

    if (!is_array($account)
        || (string)($account['status'] ?? '') !== 'active'
        || trim((string)($account['role'] ?? '')) === '') {
        return false;
    }

    $_SESSION['admin_role'] = (string)$account['role'];
    $validatedAccounts[$validationKey] = true;
    return true;
}


function requireAdminLogin(): void
{
    if (!isAdminLoggedIn()) {
        header('Location: ' . appUrl('admin/login.php'), true, 302);
        exit;
    }

    try {
        $accountIsActive = adminSessionAccountIsActive();
    } catch (Throwable $exception) {
        appLog('Could not verify the current administrator account', ['error' => $exception->getMessage()]);
        http_response_code(503);
        header('Retry-After: 5');
        exit('Administrator access could not be verified. Please try again.');
    }

    if (!$accountIsActive) {
        logoutAdmin();
        header('Location: ' . appUrl('admin/login.php'), true, 302);
        exit;
    }

    checkAdminSessionTimeout();

    $page = adminRequestedPageKey();
    if ($page !== null) {
        requireAdminPageAccess($page);
    }
}


/*
|--------------------------------------------------------------------------
| CURRENT ADMIN ID
|--------------------------------------------------------------------------
*/

function currentAdminId(): ?int
{
    if (!isAdminLoggedIn()) {
        return null;
    }

    return (int)$_SESSION['admin_id'];
}


/*
|--------------------------------------------------------------------------
| MASTER ADMIN CHECK
|--------------------------------------------------------------------------
| The first administrator account is the permanent owner account. Keeping
| this tied to the existing lowest admin ID avoids requiring a database
| migration on installations that already have admin accounts.
|--------------------------------------------------------------------------
*/

function currentAdminIsMaster(): bool
{
    $adminId = currentAdminId();
    if ($adminId === null) {
        return false;
    }

    global $conn;
    if (!($conn instanceof mysqli)) {
        return false;
    }

    try {
        $result = $conn->query('SELECT id FROM admin_users ORDER BY id ASC LIMIT 1');
        if (!($result instanceof mysqli_result)) {
            return false;
        }

        $row = $result->fetch_assoc() ?: null;
        $result->free();
        return $row !== null && (int)$row['id'] === $adminId;
    } catch (Throwable $exception) {
        appLog('Could not verify the Master Admin account', ['error' => $exception->getMessage()]);
        return false;
    }
}


function requireMasterAdmin(): void
{
    requireAdminLogin();

    if (!currentAdminIsMaster()) {
        logAdminSecurityEvent('MASTER_ADMIN_ACCESS_DENIED', 'A non-master administrator tried to manage administrator accounts.');
        http_response_code(403);
        exit('Only the Master Admin can manage administrator accounts.');
    }
}


/*
|--------------------------------------------------------------------------
| ADMIN ACCESS FOUNDATION
|--------------------------------------------------------------------------
| Existing administrators remain unrestricted until an access row is
| deliberately configured. The optional tables are created by
| admin/database/admin_access_foundation.sql; no payment or access screen is
| enabled by this foundation alone.
|--------------------------------------------------------------------------
*/

function adminRequestedPageKey(): ?string
{
    $scriptPath = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));

    if (preg_match('~/admin/dashboard\.php$~i', $scriptPath) === 1) {
        $page = $_GET['page'] ?? 'dashboard';
        if (!is_string($page) || preg_match('/^[a-z0-9_]{1,50}$/i', $page) !== 1) {
            return 'dashboard';
        }
        return strtolower($page);
    }

    if (preg_match('~/admin/(?:backup_action|backup_download)\.php$~i', $scriptPath) === 1) {
        return 'backup';
    }

    $moduleMarker = '/admin/modules/';
    $modulePosition = stripos($scriptPath, $moduleMarker);
    if ($modulePosition !== false) {
        $modulePath = substr($scriptPath, $modulePosition + strlen($moduleMarker));
        $moduleName = strtolower((string)(explode('/', $modulePath, 2)[0] ?? ''));
        return preg_match('/^[a-z0-9_]{1,50}$/', $moduleName) === 1 ? $moduleName : null;
    }

    return null;
}

function adminCanAccessPage(string $page): bool
{
    $adminId = currentAdminId();
    if ($adminId === null) {
        return false;
    }

    if ($page === 'users') {
        return currentAdminIsMaster();
    }

    if (currentAdminIsMaster()) {
        return true;
    }

    // Keep the future subscription/limited-access foundation dormant until
    // the owner explicitly enables it in the private application environment.
    // This avoids a failed optional-table query on every admin page today.
    $accessControlEnabled = strtolower(trim((string)($_ENV['ADMIN_ACCESS_CONTROL_ENABLED'] ?? 'false')));
    if (!in_array($accessControlEnabled, ['1', 'true', 'yes', 'on'], true)) {
        return true;
    }

    global $conn;
    if (!($conn instanceof mysqli)) {
        return false;
    }

    $access = $conn->prepare('SELECT access_profile, subscription_status, subscription_expires_at FROM admin_account_access WHERE admin_id = ? LIMIT 1');
    if (!$access) {
        // Once enabled, a missing access table must not silently disable checks.
        return false;
    }

    $access->bind_param('i', $adminId);
    if (!$access->execute()) {
        $access->close();
        return false;
    }
    $accessRow = $access->get_result()?->fetch_assoc() ?: null;
    $access->close();

    // No access row keeps the account on its current, unrestricted behavior.
    if ($accessRow === null) {
        return true;
    }

    $subscriptionStatus = strtolower((string)$accessRow['subscription_status']);
    if ($subscriptionStatus !== 'not_required') {
        $expiresAt = strtotime((string)($accessRow['subscription_expires_at'] ?? ''));
        if ($subscriptionStatus !== 'active' || $expiresAt === false || $expiresAt <= time()) {
            return false;
        }
    }

    $accessProfile = strtolower((string)$accessRow['access_profile']);
    if ($accessProfile === 'full') {
        return true;
    }
    if ($accessProfile !== 'limited') {
        return false;
    }

    $permission = $conn->prepare('SELECT allowed FROM admin_account_permissions WHERE admin_id = ? AND permission_key = ? LIMIT 1');
    if (!$permission) {
        return false;
    }
    $permission->bind_param('is', $adminId, $page);
    if (!$permission->execute()) {
        $permission->close();
        return false;
    }
    $permissionRow = $permission->get_result()?->fetch_assoc() ?: null;
    $permission->close();

    return $permissionRow !== null && (int)$permissionRow['allowed'] === 1;
}

function requireAdminPageAccess(string $page): void
{
    if (adminCanAccessPage($page)) {
        return;
    }

    logAdminSecurityEvent('ADMIN_PAGE_ACCESS_DENIED', 'Admin account was blocked from the ' . $page . ' section.');
    http_response_code(403);
    exit('Your administrator account does not currently have access to this section.');
}


/*
|--------------------------------------------------------------------------
| CURRENT ADMIN NAME
|--------------------------------------------------------------------------
*/

function currentAdminName(): string
{
    startAdminSession();

    if (
        isset($_SESSION['admin_name'])
        && is_string($_SESSION['admin_name'])
        && $_SESSION['admin_name'] !== ''
    ) {
        return $_SESSION['admin_name'];
    }

    return 'Administrator';
}


/*
|--------------------------------------------------------------------------
| CURRENT ADMIN ROLE
|--------------------------------------------------------------------------
*/

function currentAdminRole(): string
{
    startAdminSession();

    if (
        isset($_SESSION['admin_role'])
        && is_string($_SESSION['admin_role'])
        && $_SESSION['admin_role'] !== ''
    ) {
        return $_SESSION['admin_role'];
    }

    return 'admin';
}


/*
|--------------------------------------------------------------------------
| LOGIN ADMIN
|--------------------------------------------------------------------------
*/

function loginAdmin(
    int $adminId,
    string $adminName,
    string $adminRole = 'admin'
): void {

    startAdminSession();

    /*
    | Prevent session fixation.
    */
    session_regenerate_id(true);

    $_SESSION['admin_id'] = $adminId;

    $_SESSION['admin_name'] = $adminName;

    $_SESSION['admin_role'] = $adminRole;

    $_SESSION['admin_login_time'] = time();

    $_SESSION['admin_last_activity'] = time();

    $_SESSION['admin_authenticated'] = true;
}


/*
|--------------------------------------------------------------------------
| SESSION TIMEOUT
|--------------------------------------------------------------------------
| Default: 30 minutes
|--------------------------------------------------------------------------
*/

function adminSecurityPolicy(): array
{
    static $policy = null;
    if (is_array($policy)) return $policy;

    $policy = [
        'session_timeout_minutes' => 30,
        'max_login_attempts' => 5,
        'lockout_minutes' => 15,
        'configured' => false,
        'login_protection_enabled' => false,
    ];
    global $conn;
    if (!$conn instanceof mysqli) return $policy;

    $result = $conn->query('SELECT session_timeout_minutes, max_login_attempts, lockout_minutes FROM admin_security_policy WHERE id = 1 LIMIT 1');
    if ($result instanceof mysqli_result) {
        $row = $result->fetch_assoc() ?: [];
        $result->free();
        if ($row !== []) {
            $policy['session_timeout_minutes'] = max(5, min(480, (int)$row['session_timeout_minutes']));
            $policy['max_login_attempts'] = max(3, min(20, (int)$row['max_login_attempts']));
            $policy['lockout_minutes'] = max(1, min(1440, (int)$row['lockout_minutes']));
            $policy['configured'] = true;
            $throttleCheck = $conn->query('SELECT identity_hash FROM admin_login_throttle LIMIT 0');
            $policy['login_protection_enabled'] = $throttleCheck !== false;
            if ($throttleCheck instanceof mysqli_result) $throttleCheck->free();
        }
    }
    return $policy;
}

function adminLoginThrottleHash(string $username, string $ipAddress): string
{
    $identity = strtolower(trim($username)) . "\0" . trim($ipAddress);
    $secret = (string)($_ENV['APP_ENCRYPTION_KEY'] ?? '');
    return strlen($secret) >= 32
        ? hash_hmac('sha256', $identity, $secret)
        : hash('sha256', 'wifi-voucher-admin-login:' . $identity);
}

function adminLoginThrottleStatus(string $username, string $ipAddress): array
{
    $policy = adminSecurityPolicy();
    if (!$policy['login_protection_enabled']) return ['locked' => false, 'minutes_left' => 0];
    global $conn;
    $identityHash = adminLoginThrottleHash($username, $ipAddress);
    $stmt = $conn->prepare('SELECT locked_until FROM admin_login_throttle WHERE identity_hash = ? LIMIT 1');
    if (!$stmt) return ['locked' => false, 'minutes_left' => 0];
    $stmt->bind_param('s', $identityHash);
    if (!$stmt->execute()) {
        $stmt->close();
        return ['locked' => false, 'minutes_left' => 0];
    }
    $row = $stmt->get_result()->fetch_assoc() ?: [];
    $stmt->close();
    $lockedUntil = trim((string)($row['locked_until'] ?? ''));
    $lockTimestamp = $lockedUntil !== '' ? strtotime($lockedUntil) : false;
    if ($lockTimestamp === false || $lockTimestamp <= time()) return ['locked' => false, 'minutes_left' => 0];
    return ['locked' => true, 'minutes_left' => max(1, (int)ceil(($lockTimestamp - time()) / 60))];
}

function recordFailedAdminLogin(string $username, string $ipAddress): void
{
    $policy = adminSecurityPolicy();
    if (!$policy['login_protection_enabled']) return;
    global $conn;
    $conn->query('DELETE FROM admin_login_throttle WHERE updated_at < DATE_SUB(NOW(), INTERVAL 30 DAY)');
    $identityHash = adminLoginThrottleHash($username, $ipAddress);
    $stmt = $conn->prepare("INSERT INTO admin_login_throttle (identity_hash, failed_attempts, window_started_at, locked_until)
        VALUES (?, 1, NOW(), NULL)
        ON DUPLICATE KEY UPDATE
            failed_attempts = IF(window_started_at < DATE_SUB(NOW(), INTERVAL 15 MINUTE), 1, failed_attempts + 1),
            locked_until = IF(window_started_at < DATE_SUB(NOW(), INTERVAL 15 MINUTE), NULL, locked_until),
            window_started_at = IF(window_started_at < DATE_SUB(NOW(), INTERVAL 15 MINUTE), NOW(), window_started_at)");
    if (!$stmt) return;
    $stmt->bind_param('s', $identityHash);
    if ($stmt->execute()) {
        $stmt->close();
        $countQuery = $conn->prepare('SELECT failed_attempts FROM admin_login_throttle WHERE identity_hash = ? LIMIT 1');
        if (!$countQuery) return;
        $countQuery->bind_param('s', $identityHash);
        if (!$countQuery->execute()) {
            $countQuery->close();
            return;
        }
        $row = $countQuery->get_result()->fetch_assoc() ?: [];
        $countQuery->close();
        if ((int)($row['failed_attempts'] ?? 0) >= (int)$policy['max_login_attempts']) {
            $lockedUntil = date('Y-m-d H:i:s', time() + ((int)$policy['lockout_minutes'] * 60));
            $lock = $conn->prepare('UPDATE admin_login_throttle SET locked_until = ? WHERE identity_hash = ?');
            if ($lock) {
                $lock->bind_param('ss', $lockedUntil, $identityHash);
                $lock->execute();
                $lock->close();
            }
        }
        return;
    }
    $stmt->close();
}

function clearAdminLoginThrottle(string $username, string $ipAddress): void
{
    $policy = adminSecurityPolicy();
    if (!$policy['login_protection_enabled']) return;
    global $conn;
    $identityHash = adminLoginThrottleHash($username, $ipAddress);
    $stmt = $conn->prepare('DELETE FROM admin_login_throttle WHERE identity_hash = ?');
    if (!$stmt) return;
    $stmt->bind_param('s', $identityHash);
    $stmt->execute();
    $stmt->close();
}

function checkAdminSessionTimeout(
    ?int $timeout = null
): void {

    if (!isAdminLoggedIn()) {
        return;
    }

    startAdminSession();

    $timeout ??= (int)adminSecurityPolicy()['session_timeout_minutes'] * 60;

    $lastActivity =
        $_SESSION['admin_last_activity'] ?? null;

    if (!is_numeric($lastActivity)) {

        logoutAdmin();

        header('Location: ' . appUrl('admin/login.php?timeout=1'), true, 302);

        exit;
    }

    if (
        (time() - (int)$lastActivity)
        > $timeout
    ) {

        logoutAdmin();

        header('Location: ' . appUrl('admin/login.php?timeout=1'), true, 302);

        exit;
    }

    /*
    | Refresh activity timestamp.
    */
    $_SESSION['admin_last_activity'] = time();
}


/*
|--------------------------------------------------------------------------
| LOGOUT ADMIN
|--------------------------------------------------------------------------
*/

function logoutAdmin(): void
{
    startAdminSession();

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {

        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            [
                'expires'  => time() - 42000,
                'path'     => $params['path'] ?? '/',
                'domain'   => $params['domain'] ?? '',
                'secure'   => (bool)($params['secure'] ?? false),
                'httponly' => (bool)($params['httponly'] ?? true),
                'samesite' => $params['samesite'] ?? 'Lax'
            ]
        );
    }

    session_destroy();
}


/*
|--------------------------------------------------------------------------
| REQUIRE POST REQUEST
|--------------------------------------------------------------------------
*/

function requireAdminPost(): void
{
    if (
        ($_SERVER['REQUEST_METHOD'] ?? '')
        !== 'POST'
    ) {

        http_response_code(405);

        header('Allow: POST');

        exit('Method not allowed.');
    }
}


/*
|--------------------------------------------------------------------------
| REQUIRE POST + CSRF
|--------------------------------------------------------------------------
*/

function requireAdminPostWithCsrf(): void
{
    requireAdminLogin();

    requireAdminPost();

    requireCsrfToken();
}


/*
|--------------------------------------------------------------------------
| REQUIRE CSRF
|--------------------------------------------------------------------------
*/

function requireAdminCsrf(): void
{
    requireAdminLogin();

    requireCsrfToken();
}


/*
|--------------------------------------------------------------------------
| ADMIN SECURITY LOG
|--------------------------------------------------------------------------
*/

function logAdminSecurityEvent(
    string $action,
    string $details = ''
): void {

    global $conn;

    if (
        !isset($conn)
        || !($conn instanceof mysqli)
    ) {
        return;
    }

    $adminId = currentAdminId();

    $ip = clientIp();

    $stmt = $conn->prepare("
        INSERT INTO security_logs
        (
            user_id,
            action,
            details,
            ip_address
        )
        VALUES (?, ?, ?, ?)
    ");

    if (!$stmt) {

        appLog(
            'Failed to prepare admin security log',
            [
                'action' => $action,
                'error' => $conn->error
            ]
        );

        return;
    }

    $stmt->bind_param(
        'isss',
        $adminId,
        $action,
        $details,
        $ip
    );

    if (!$stmt->execute()) {

        appLog(
            'Failed to write admin security log',
            [
                'action' => $action,
                'error' => $stmt->error
            ]
        );
    }

    $stmt->close();
}


/*
|--------------------------------------------------------------------------
| CHECK ADMIN ROLE
|--------------------------------------------------------------------------
*/

function adminHasRole(
    string|array $roles
): bool {

    if (!isAdminLoggedIn()) {
        return false;
    }

    $currentRole =
        strtolower(currentAdminRole());

    if (is_string($roles)) {
        $roles = [$roles];
    }

    foreach ($roles as $role) {

        if (
            $currentRole
            === strtolower((string)$role)
        ) {
            return true;
        }
    }

    return false;
}


/*
|--------------------------------------------------------------------------
| REQUIRE ADMIN ROLE
|--------------------------------------------------------------------------
*/

function requireAdminRole(
    string|array $roles
): void {

    requireAdminLogin();

    if (!adminHasRole($roles)) {

        logAdminSecurityEvent(
            'ADMIN_UNAUTHORIZED',
            'Unauthorized admin role access attempt.'
        );

        http_response_code(403);

        exit('Access denied.');
    }
}
