<?php
declare(strict_types=1);
?>

        </section>

    </main>

</div>

<script>
(function () {

    // Prevent accidental form resubmission when navigating back.
    if (window.history.replaceState) {
        window.history.replaceState(
            null,
            document.title,
            window.location.href
        );
    }

})();
</script>

</body>
</html>