<?php
declare(strict_types=1);

/*
 * Legacy login URL. Keep one canonical admin login implementation.
 */
require_once __DIR__ . '/../../includes/functions.php';

header('Location: ' . appUrl('admin/login.php'), true, 302);
exit;
