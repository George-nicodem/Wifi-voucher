<?php
declare(strict_types=1);

require_once __DIR__ . '/../../config/app.php';

function startSecureSession(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    $secure = (
        isset($_SERVER['HTTPS']) &&
        $_SERVER['HTTPS'] !== 'off'
    );

    session_name(SESSION_NAME);

    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);

    session_start();
}

function csrfToken(): string
{
    startSecureSession();

    if (
        empty($_SESSION[CSRF_TOKEN_NAME]) ||
        !is_string($_SESSION[CSRF_TOKEN_NAME])
    ) {
        $_SESSION[CSRF_TOKEN_NAME] =
            bin2hex(random_bytes(32));
    }

    return $_SESSION[CSRF_TOKEN_NAME];
}

function csrfField(): string
{
    return '<input type="hidden" name="' .
        htmlspecialchars(
            CSRF_TOKEN_NAME,
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        ) .
        '" value="' .
        htmlspecialchars(
            csrfToken(),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        ) .
        '">';
}

function verifyCsrfToken(?string $token): bool
{
    startSecureSession();

    if (
        !$token ||
        !isset($_SESSION[CSRF_TOKEN_NAME])
    ) {
        return false;
    }

    if (
        !is_string($_SESSION[CSRF_TOKEN_NAME])
    ) {
        return false;
    }

    return hash_equals(
        $_SESSION[CSRF_TOKEN_NAME],
        $token
    );
}

function requireCsrfToken(): void
{
    $token = $_POST[CSRF_TOKEN_NAME] ?? null;

    if (
        !is_string($token) ||
        !verifyCsrfToken($token)
    ) {
        http_response_code(403);

        exit(
            'Invalid security token. Please refresh the page and try again.'
        );
    }
}
