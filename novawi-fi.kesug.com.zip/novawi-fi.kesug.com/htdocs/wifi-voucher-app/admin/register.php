<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/admin_email_auth.php';
startAdminSession();

if (isAdminLoggedIn()) {
    header('Location: ' . appUrl('admin/dashboard.php'), true, 302);
    exit;
}

$errors = [];
$email = '';
$fullName = '';
$notice = isset($_GET['created']) ? 'Your request has been submitted. The account will be activated after an administrator approves it. An existing administrator can reset a password using an email code.' : '';
$schemaReady = adminEmailAuthSchemaReady();

if (isPost()) {
    requireCsrfToken();

    $email = adminAccountEmail(postString('email'));
    $fullName = trim(postString('full_name'));
    $password = $_POST['password'] ?? '';
    $passwordConfirm = $_POST['password_confirm'] ?? '';
    $password = is_string($password) ? $password : '';
    $passwordConfirm = is_string($passwordConfirm) ? $passwordConfirm : '';
    $passwordLength = function_exists('mb_strlen') ? mb_strlen($password) : strlen($password);
    $nameLength = function_exists('mb_strlen') ? mb_strlen($fullName) : strlen($fullName);
    if (!$schemaReady) {
        $errors[] = 'Administrator registration is not configured. Run admin/database/admin_accounts.sql and make sure admin_users contains an email address.';
    } else {
        if ($fullName === '' || $nameLength > 100) {
            $errors[] = 'Enter a full name with no more than 100 characters.';
        }
        if (strlen($email) > 190 || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            $errors[] = 'Enter a valid email address.';
        }
        if ($passwordLength < 6 || strlen($password) > 1024 || !preg_match('/[a-z]/', $password) || !preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password) || !preg_match('/[^A-Za-z0-9]/', $password)) {
            $errors[] = 'Use at least 6 characters, including uppercase and lowercase letters, a number, and a symbol.';
        }
        if (!hash_equals($password, $passwordConfirm)) {
            $errors[] = 'The passwords do not match.';
        }
    }

    if (!$errors) {
        $exists = $conn->prepare('SELECT id FROM admin_users WHERE email = ? OR username = ? LIMIT 1');
        if (!$exists) {
            logDatabaseError($conn, 'Preparing admin registration duplicate check');
            $errors[] = 'The email address could not be checked right now.';
        } else {
            $exists->bind_param('ss', $email, $email);
            if (!$exists->execute()) {
                logDatabaseError($conn, 'Checking admin registration email');
                $errors[] = 'The email address could not be checked right now.';
            } else {
                $result = $exists->get_result();
                if ($result && $result->num_rows > 0) {
                    $errors[] = 'An administrator account already uses this email address.';
                }
            }
            $exists->close();
        }
    }

    if (!$errors) {
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        if (!is_string($passwordHash) || $passwordHash === '') {
            $errors[] = 'The password could not be securely hashed.';
        } else {
            $bootstrap = adminBootstrapFirstAccount($email, $fullName, $passwordHash);
            if ($bootstrap === 'created') {
                header('Location: ' . appUrl('admin/login.php?first_admin=1'), true, 303);
                exit;
            }
            if ($bootstrap === 'error') {
                $errors[] = 'The first administrator account could not be created. Try again or check the database permissions.';
            }
        }

        if (!$errors && is_string($passwordHash) && $passwordHash !== '') {
            $requestLookup = $conn->prepare('SELECT id, status FROM admin_account_requests WHERE email = ? LIMIT 1');
            $existingRequest = null;
            if (!$requestLookup) {
                logDatabaseError($conn, 'Preparing admin request lookup');
                $errors[] = 'The account request could not be submitted right now.';
            } else {
                $requestLookup->bind_param('s', $email);
                if (!$requestLookup->execute()) {
                    logDatabaseError($conn, 'Looking up admin account request');
                    $errors[] = 'The account request could not be submitted right now.';
                } else {
                    $requestResult = $requestLookup->get_result();
                    $existingRequest = $requestResult ? ($requestResult->fetch_assoc() ?: null) : null;
                }
                $requestLookup->close();
            }

            if (!$errors && $existingRequest && (string)$existingRequest['status'] === 'pending') {
                $errors[] = 'Your administrator request is already awaiting approval.';
            } elseif (!$errors) {
                if ($existingRequest) {
                    $requestId = (int)$existingRequest['id'];
                    $saveRequest = $conn->prepare("UPDATE admin_account_requests
                        SET full_name = ?, password_hash = ?, status = 'pending', created_at = CURRENT_TIMESTAMP,
                            reviewed_at = NULL, reviewed_by_admin_id = NULL
                        WHERE id = ?");
                    if (!$saveRequest) {
                        logDatabaseError($conn, 'Preparing admin request renewal');
                        $errors[] = 'The account request could not be submitted right now.';
                    } else {
                        $saveRequest->bind_param('ssi', $fullName, $passwordHash, $requestId);
                    }
                } else {
                    $saveRequest = $conn->prepare("INSERT INTO admin_account_requests (email, full_name, password_hash, status)
                        VALUES (?, ?, ?, 'pending')");
                    if (!$saveRequest) {
                        logDatabaseError($conn, 'Preparing pending admin request');
                        $errors[] = 'The account request could not be submitted right now.';
                    } else {
                        $saveRequest->bind_param('sss', $email, $fullName, $passwordHash);
                    }
                }

                if (!$errors && isset($saveRequest)) {
                    if (!$saveRequest->execute()) {
                        logDatabaseError($conn, 'Saving admin account request');
                        $errors[] = $saveRequest->errno === 1062
                            ? 'An administrator request already exists for this email address.'
                            : 'The account request could not be submitted right now.';
                    }
                    $saveRequest->close();
                }

                if (!$errors) {
                    header('Location: ' . appUrl('admin/register.php?created=1'), true, 303);
                    exit;
                }
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Request an administrator account | <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="<?= e(appUrl('admin/assets/auth-theme.css?v=5')) ?>">
</head>
<body class="auth-page">
<main class="login-container">
    <section class="login-card">
        <div class="auth-brand"><span class="auth-brand-mark"><i class="fa-solid fa-wifi" aria-hidden="true"></i></span><span><strong>WiFi Voucher</strong><small>Administrator account request</small></span></div>
        <header class="login-title"><h1>Request an account</h1><p>New administrator requests stay pending until an active administrator approves them. Only the very first account on an empty system is activated during setup.</p></header>
        <?php if ($notice !== ''): ?><div class="message success" role="status"><?= e($notice) ?> <a href="<?= e(appUrl('admin/forgot_password.php')) ?>">Reset administrator password</a></div><?php endif; ?>
        <?php if (!$schemaReady): ?><div class="error" role="alert">Administrator accounts are not configured. Run <code>admin/database/admin_accounts.sql</code> and make sure <code>admin_users</code> has an email address.</div><?php endif; ?>
        <?php foreach (array_unique($errors) as $error): ?><div class="error" role="alert"><?= e($error) ?></div><?php endforeach; ?>
        <?php if (!isset($_GET['created'])): ?>
            <form method="post" action="<?= e(appUrl('admin/register.php')) ?>" autocomplete="on">
                <?= csrfField() ?>
                <div class="form-group"><label for="full_name">Full name</label><input id="full_name" name="full_name" type="text" maxlength="100" autocomplete="name" value="<?= e($fullName) ?>" required></div>
                <div class="form-group"><label for="email">Administrator email</label><input id="email" name="email" type="email" maxlength="190" autocomplete="email" value="<?= e($email) ?>" required></div>
                <div class="form-group"><label for="password">Password</label><input id="password" name="password" type="password" minlength="6" pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{6,}" title="Use at least 6 characters with uppercase and lowercase letters, a number, and a symbol" maxlength="1024" autocomplete="new-password" required><small>At least 6 characters, including uppercase and lowercase letters, a number, and a symbol.</small></div>
                <div class="form-group"><label for="password_confirm">Confirm password</label><input id="password_confirm" name="password_confirm" type="password" minlength="6"   maxlength="1024" autocomplete="new-password" required></div>
                <button type="submit" <?= !$schemaReady ? 'disabled' : '' ?>><i class="fa-solid fa-user-plus" aria-hidden="true"></i> Continue registration</button>
            </form>
        <?php endif; ?>
        <div class="auth-links"><a href="<?= e(appUrl('admin/login.php')) ?>"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i> Return to administrator sign-in</a></div>
        <p class="password-change-note"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i> Every administrator sign-in is verified with a code sent to your email.</p>
    </section>
</main>
    <script src="<?= e(appUrl('admin/assets/admin-password.js?v=1')) ?>" defer></script></body>""
</html>
