-- Settings for the customer portal.
-- Select the application's database in phpMyAdmin before running this file.
-- Existing portal settings and customer data are not deleted or overwritten.
-- The idempotent ALTER syntax below is for MariaDB; it does not query
-- information_schema, which may be unavailable to restricted local accounts.

CREATE TABLE IF NOT EXISTS portal_settings (
    id TINYINT UNSIGNED NOT NULL,
    brand_name VARCHAR(100) NOT NULL DEFAULT 'WiFi Voucher',
    welcome_message VARCHAR(200) NOT NULL DEFAULT 'Lipa kwa simu yako na upokee voucher baada ya malipo kuthibitishwa.',
    call_phone VARCHAR(20) NOT NULL DEFAULT '',
    whatsapp_phone VARCHAR(20) NOT NULL DEFAULT '',
    maintenance_enabled TINYINT(1) NOT NULL DEFAULT 0,
    maintenance_message VARCHAR(250) NOT NULL DEFAULT 'Manunuzi mapya yamesitishwa kwa muda kwa ajili ya matengenezo. Tafadhali jaribu tena baadaye.',
    customer_payments_enabled TINYINT(1) NOT NULL DEFAULT 1,
    logo_path VARCHAR(255) NOT NULL DEFAULT '',
    theme_key VARCHAR(20) NOT NULL DEFAULT 'ocean',
    theme_accent_color CHAR(7) NOT NULL DEFAULT '#08aebe',
    theme_background_color CHAR(7) NOT NULL DEFAULT '#f3f7fb',
    theme_surface_color CHAR(7) NOT NULL DEFAULT '#ffffff',
    theme_text_color CHAR(7) NOT NULL DEFAULT '#14283d',
    theme_border_color CHAR(7) NOT NULL DEFAULT '#e1e9f1',
    theme_button_color CHAR(7) NOT NULL DEFAULT '#e87537',
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add fields to an older portal_settings table only when they are missing.
ALTER TABLE portal_settings
    ADD COLUMN IF NOT EXISTS brand_name VARCHAR(100) NOT NULL DEFAULT 'WiFi Voucher',
    ADD COLUMN IF NOT EXISTS welcome_message VARCHAR(200) NOT NULL DEFAULT 'Lipa kwa simu yako na upokee voucher baada ya malipo kuthibitishwa.',
    ADD COLUMN IF NOT EXISTS call_phone VARCHAR(20) NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS whatsapp_phone VARCHAR(20) NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS maintenance_enabled TINYINT(1) NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS maintenance_message VARCHAR(250) NOT NULL DEFAULT 'Manunuzi mapya yamesitishwa kwa muda kwa ajili ya matengenezo. Tafadhali jaribu tena baadaye.',
    ADD COLUMN IF NOT EXISTS customer_payments_enabled TINYINT(1) NOT NULL DEFAULT 1,
    ADD COLUMN IF NOT EXISTS logo_path VARCHAR(255) NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS theme_key VARCHAR(20) NOT NULL DEFAULT 'ocean',
    ADD COLUMN IF NOT EXISTS theme_accent_color CHAR(7) NOT NULL DEFAULT '#08aebe',
    ADD COLUMN IF NOT EXISTS theme_background_color CHAR(7) NOT NULL DEFAULT '#f3f7fb',
    ADD COLUMN IF NOT EXISTS theme_surface_color CHAR(7) NOT NULL DEFAULT '#ffffff',
    ADD COLUMN IF NOT EXISTS theme_text_color CHAR(7) NOT NULL DEFAULT '#14283d',
    ADD COLUMN IF NOT EXISTS theme_border_color CHAR(7) NOT NULL DEFAULT '#e1e9f1',
    ADD COLUMN IF NOT EXISTS theme_button_color CHAR(7) NOT NULL DEFAULT '#e87537';

INSERT IGNORE INTO portal_settings
    (id, brand_name, welcome_message, call_phone, whatsapp_phone, maintenance_enabled, maintenance_message, customer_payments_enabled, logo_path, theme_key,
     theme_accent_color, theme_background_color, theme_surface_color, theme_text_color, theme_border_color, theme_button_color)
VALUES
    (1, 'WiFi Voucher', 'Lipa kwa simu yako na upokee voucher baada ya malipo kuthibitishwa.', '', '', 0,
     'Manunuzi mapya yamesitishwa kwa muda kwa ajili ya matengenezo. Tafadhali jaribu tena baadaye.', 1, '', 'ocean',
     '#08aebe', '#f3f7fb', '#ffffff', '#14283d', '#e1e9f1', '#e87537');
