-- Enable or disable mobile-money checkout while keeping voucher activation available.
-- Select the application's database in phpMyAdmin before running this file.
-- Existing installations keep payments enabled by default.

ALTER TABLE portal_settings
    ADD COLUMN IF NOT EXISTS customer_payments_enabled TINYINT(1) NOT NULL DEFAULT 1;
