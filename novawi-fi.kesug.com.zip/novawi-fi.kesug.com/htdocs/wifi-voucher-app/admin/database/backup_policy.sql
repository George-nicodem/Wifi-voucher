-- Settings for scheduled database backups.
-- Select the application's database in phpMyAdmin before running this file.
-- Manual backups continue to work when no server scheduler is configured.

CREATE TABLE IF NOT EXISTS backup_policy (
    id TINYINT UNSIGNED NOT NULL,
    enabled TINYINT(1) NOT NULL DEFAULT 0,
    frequency ENUM('daily', 'weekly') NOT NULL DEFAULT 'daily',
    run_time TIME NOT NULL DEFAULT '02:00:00',
    run_day TINYINT UNSIGNED NOT NULL DEFAULT 1,
    retention_count TINYINT UNSIGNED NOT NULL DEFAULT 7,
    last_run_at DATETIME NULL DEFAULT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO backup_policy (id, enabled, frequency, run_time, run_day, retention_count)
VALUES (1, 0, 'daily', '02:00:00', 1, 7);
