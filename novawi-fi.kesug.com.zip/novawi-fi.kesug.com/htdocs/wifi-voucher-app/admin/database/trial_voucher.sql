-- Wi-Fi trial records are separate from paid/manual vouchers.
CREATE TABLE IF NOT EXISTS trial_settings (
    id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    duration_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 5,
    cooldown_days SMALLINT UNSIGNED NOT NULL DEFAULT 7,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_trial_settings_singleton CHECK (id = 1),
    CONSTRAINT chk_trial_duration CHECK (duration_minutes BETWEEN 1 AND 60),
    CONSTRAINT chk_trial_cooldown CHECK (cooldown_days BETWEEN 1 AND 365)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO trial_settings (id, enabled, duration_minutes, cooldown_days)
VALUES (1, 1, 5, 7);

CREATE TABLE IF NOT EXISTS trial_vouchers (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    code_hash CHAR(64) NOT NULL,
    code_encrypted TEXT NOT NULL,
    device_token_hash CHAR(64) NOT NULL,
    mac_hash CHAR(64) NULL,
    issued_at DATETIME NOT NULL,
    expires_at DATETIME NOT NULL,
    cooldown_until DATETIME NOT NULL,
    status ENUM('pending_router', 'provisioned', 'active', 'expired', 'failed', 'revoked') NOT NULL DEFAULT 'pending_router',
    router_provisioned_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_trial_code_hash (code_hash),
    KEY idx_trial_token_cooldown (device_token_hash, cooldown_until),
    KEY idx_trial_mac_cooldown (mac_hash, cooldown_until),
    KEY idx_trial_status_expiry (status, expires_at),
    KEY idx_trial_issued_at (issued_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
