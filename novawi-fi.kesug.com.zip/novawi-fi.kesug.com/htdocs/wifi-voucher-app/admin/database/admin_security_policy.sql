-- Admin session and login-protection settings.
-- Select the application's database in phpMyAdmin before running this file.
-- Existing admin accounts and audit records are not changed.

CREATE TABLE IF NOT EXISTS admin_security_policy (
    id TINYINT UNSIGNED NOT NULL,
    session_timeout_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 30,
    max_login_attempts TINYINT UNSIGNED NOT NULL DEFAULT 5,
    lockout_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 15,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS admin_login_throttle (
    identity_hash CHAR(64) NOT NULL,
    failed_attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    window_started_at DATETIME NOT NULL,
    locked_until DATETIME NULL DEFAULT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (identity_hash),
    KEY idx_admin_login_throttle_updated_at (updated_at),
    KEY idx_admin_login_throttle_locked_until (locked_until)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO admin_security_policy (id, session_timeout_minutes, max_login_attempts, lockout_minutes)
VALUES (1, 30, 5, 15);
