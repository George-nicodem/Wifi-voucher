<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/admin_auth.php';
requireAdminLogin();
requireAdminPost();
requireCsrfToken();

function backupActionRedirect(string $type, string $message): never
{
    $_SESSION['backup_flash'] = ['type' => $type, 'message' => $message];
    header('Location: ' . appUrl('admin/dashboard.php?page=backup'));
    exit;
}

function backupActionWrite($handle, string $contents): void
{
    $length = strlen($contents);
    $offset = 0;
    while ($offset < $length) {
        $written = fwrite($handle, substr($contents, $offset));
        if ($written === false || $written === 0) {
            throw new RuntimeException('Could not write the safety backup completely.');
        }
        $offset += $written;
    }
}

function createPreRestoreBackup(mysqli $conn, string $backupDirectory, string $dbName): string
{
    if (!is_dir($backupDirectory) && !mkdir($backupDirectory, 0750, true) && !is_dir($backupDirectory)) {
        throw new RuntimeException('Backup folder is not writable.');
    }

    $safeDbName = preg_replace('/[^A-Za-z0-9_-]/', '_', $dbName) ?: 'database';
    $fileName = $safeDbName . '_backup_' . date('Y-m-d_H-i-s')
        . '_before_restore_' . bin2hex(random_bytes(4)) . '.sql';
    $filePath = $backupDirectory . DIRECTORY_SEPARATOR . $fileName;
    $handle = fopen($filePath, 'xb');
    if ($handle === false) {
        throw new RuntimeException('Could not create the safety backup before restore.');
    }

    try {
        backupActionWrite($handle,
            "-- WiFi Voucher Database Backup\n"
            . '-- Database: ' . $dbName . "\n"
            . '-- Created: ' . date('Y-m-d H:i:s') . "\n"
            . "-- Timezone: Africa/Dar_es_Salaam\n"
            . "-- --------------------------------------------------------\n\n"
            . "SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n"
            . "SET FOREIGN_KEY_CHECKS = 0;\n"
            . "SET AUTOCOMMIT = 0;\n"
            . "START TRANSACTION;\n\n"
        );

        $tablesResult = $conn->query('SHOW TABLES');
        if (!$tablesResult) {
            throw new RuntimeException('Could not list database tables for the safety backup.');
        }

        while ($tableRow = $tablesResult->fetch_row()) {
            $tableName = (string)($tableRow[0] ?? '');
            if ($tableName === '') {
                continue;
            }

            $escapedTable = '`' . str_replace('`', '``', $tableName) . '`';
            backupActionWrite($handle,
                "\n-- --------------------------------------------------------\n"
                . '-- Table: ' . $tableName . "\n"
                . "-- --------------------------------------------------------\n\n"
                . 'DROP TABLE IF EXISTS ' . $escapedTable . ";\n\n"
            );

            $createResult = $conn->query('SHOW CREATE TABLE ' . $escapedTable);
            if (!$createResult) {
                throw new RuntimeException('Could not read a table definition for the safety backup.');
            }
            $createRow = $createResult->fetch_assoc() ?: [];
            $createSql = (string)($createRow['Create Table'] ?? '');
            $createResult->free();
            if ($createSql === '') {
                throw new RuntimeException('A table definition was empty in the safety backup.');
            }
            backupActionWrite($handle, $createSql . ";\n\n");

            $dataResult = $conn->query('SELECT * FROM ' . $escapedTable, MYSQLI_USE_RESULT);
            if (!$dataResult) {
                throw new RuntimeException('Could not read table data for the safety backup.');
            }
            $fieldCount = $dataResult->field_count;
            while ($dataRow = $dataResult->fetch_row()) {
                $values = [];
                for ($i = 0; $i < $fieldCount; $i++) {
                    $value = $dataRow[$i] ?? null;
                    $values[] = $value === null
                        ? 'NULL'
                        : "'" . $conn->real_escape_string((string)$value) . "'";
                }
                backupActionWrite($handle,
                    'INSERT INTO ' . $escapedTable . ' VALUES (' . implode(', ', $values) . ");\n"
                );
            }
            $dataResult->free();
            backupActionWrite($handle, "\n");
        }
        $tablesResult->free();
        backupActionWrite($handle,
            "\nSET FOREIGN_KEY_CHECKS = 1;\nCOMMIT;\nSET AUTOCOMMIT = 1;\n"
        );
        if (!fclose($handle)) {
            $handle = null;
            throw new RuntimeException('Could not finalize the safety backup file.');
        }
        $handle = null;

        $size = filesize($filePath);
        if ($size === false || $size < 1) {
            throw new RuntimeException('The safety backup file is empty.');
        }
        logAdminSecurityEvent('DATABASE_BACKUP_CREATED', 'Pre-restore safety snapshot: ' . $fileName);
        return $fileName;
    } catch (Throwable $exception) {
        if (is_resource($handle)) {
            fclose($handle);
        }
        if (is_file($filePath)) {
            @unlink($filePath);
        }
        throw $exception;
    }
}

$action = $_POST['action'] ?? '';
$fileName = $_POST['backup_file'] ?? '';
$confirmation = $_POST['confirmation'] ?? '';
$pattern = '/^[A-Za-z0-9_-]+_backup_[0-9]{4}-[0-9]{2}-[0-9]{2}_[0-9]{2}-[0-9]{2}-[0-9]{2}(?:_before_restore_[a-f0-9]{8})?\.sql$/D';

if (!in_array($action, ['restore', 'delete'], true)
    || !is_string($fileName)
    || !preg_match($pattern, $fileName)
    || !is_string($confirmation)
) {
    backupActionRedirect('error', 'Request was not recognized. Refresh the page and try again.');
}

$backupDirectory = dirname(__DIR__)
    . DIRECTORY_SEPARATOR . 'storage'
    . DIRECTORY_SEPARATOR . 'backups';
$directoryRealPath = realpath($backupDirectory);
$fileRealPath = realpath($backupDirectory . DIRECTORY_SEPARATOR . $fileName);
if ($directoryRealPath === false || $fileRealPath === false
    || dirname($fileRealPath) !== $directoryRealPath
    || !is_file($fileRealPath)
) {
    backupActionRedirect('error', 'That backup does not exist or cannot be opened.');
}

if ($action === 'delete') {
    if (!hash_equals('DELETE', $confirmation)) {
        backupActionRedirect('error', 'The deletion confirmation was incorrect.');
    }
    $sqlFiles = glob($backupDirectory . DIRECTORY_SEPARATOR . '*.sql') ?: [];
    if (count($sqlFiles) <= 1) {
        backupActionRedirect('error', 'You cannot delete the last remaining backup. Create another one first.');
    }
    if (!unlink($fileRealPath)) {
        backupActionRedirect('error', 'The backup could not be deleted. Make sure the folder allows files to be deleted.');
    }
    logAdminSecurityEvent('DATABASE_BACKUP_DELETED', 'Administrator deleted database backup: ' . $fileName);
    backupActionRedirect('success', 'The backup was deleted. Database data was not changed.');
}

if (!hash_equals('RESTORE', $confirmation)) {
    backupActionRedirect('error', 'The restore confirmation was incorrect.');
}

if (!$conn instanceof mysqli) {
    backupActionRedirect('error', 'The database connection is unavailable.');
}
$currentDbResult = $conn->query('SELECT DATABASE() AS db_name');
$currentDbRow = $currentDbResult ? ($currentDbResult->fetch_assoc() ?: []) : [];
$currentDbName = (string)($currentDbRow['db_name'] ?? '');
if ($currentDbResult) {
    $currentDbResult->free();
}
if ($currentDbName === '') {
    backupActionRedirect('error', 'The name of the active database could not be found.');
}

$headerHandle = fopen($fileRealPath, 'rb');
$header = $headerHandle !== false ? fread($headerHandle, 2048) : false;
if ($headerHandle !== false) {
    fclose($headerHandle);
}
if (!is_string($header)
    || !preg_match('/\A-- WiFi Voucher (?:Database Backup|scheduled database backup)\r?\n-- Database: ([^\r\n]+)/', $header, $matches)
    || !hash_equals($currentDbName, trim($matches[1]))
) {
    backupActionRedirect('error', 'This backup was not created by this system or belongs to a different database.');
}

$safetyFile = '';
try {
    $safetyFile = createPreRestoreBackup($conn, $backupDirectory, $currentDbName);
    logAdminSecurityEvent('DATABASE_RESTORE_STARTED', 'Administrator restoring database from: ' . $fileName);

    $sql = file_get_contents($fileRealPath);
    if (!is_string($sql) || trim($sql) === '') {
        throw new RuntimeException('Backup file is empty or unreadable.');
    }
    if (!$conn->multi_query($sql)) {
        throw new RuntimeException($conn->error ?: 'Database rejected the backup file.');
    }
    do {
        $result = $conn->store_result();
        if ($result instanceof mysqli_result) {
            $result->free();
        }
        if (!$conn->more_results()) {
            break;
        }
        if (!$conn->next_result()) {
            throw new RuntimeException($conn->error ?: 'Database restore stopped before completion.');
        }
    } while (true);

    logAdminSecurityEvent('DATABASE_RESTORE_COMPLETED', 'Database restored from: ' . $fileName);
    backupActionRedirect('success', 'The database was restored from ' . $fileName . '. Pre-restore snapshot: ' . $safetyFile);
} catch (Throwable $exception) {
    logException($exception, 'Database restore');
    $message = 'Restore did not complete. The database may have been partially changed. Safety snapshot: '
        . ($safetyFile !== '' ? $safetyFile : 'could not be created')
        . '. Use that snapshot to restore or contact an administrator.';
    backupActionRedirect('error', $message);
}
