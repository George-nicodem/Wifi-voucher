<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/config/database.php';

function wifiScheduledBackupWrite($handle, string $data): void
{
    $length = strlen($data);
    $offset = 0;
    while ($offset < $length) {
        $written = fwrite($handle, substr($data, $offset));
        if ($written === false || $written === 0) {
            throw new RuntimeException('Could not write the scheduled backup file.');
        }
        $offset += $written;
    }
}

function wifiScheduledBackupExport(mysqli $db, string $backupDirectory, string $dbName, string $safeDbName): string
{
    if (!is_dir($backupDirectory) && !mkdir($backupDirectory, 0750, true) && !is_dir($backupDirectory)) {
        throw new RuntimeException('Backup directory could not be created.');
    }

    $fileName = $safeDbName . '_scheduled_backup_' . date('Y-m-d_H-i-s') . '.sql';
    $filePath = $backupDirectory . DIRECTORY_SEPARATOR . $fileName;
    $handle = fopen($filePath, 'xb');
    if ($handle === false) {
        throw new RuntimeException('Scheduled backup file could not be created.');
    }

    try {
        wifiScheduledBackupWrite($handle,
            "-- WiFi Voucher scheduled database backup\n"
            . '-- Database: ' . $dbName . "\n"
            . '-- Created: ' . date('Y-m-d H:i:s') . "\n"
            . "SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n"
            . "SET FOREIGN_KEY_CHECKS = 0;\n"
            . "SET AUTOCOMMIT = 0;\nSTART TRANSACTION;\n\n"
        );

        $tablesResult = $db->query('SHOW TABLES');
        if (!$tablesResult instanceof mysqli_result) {
            throw new RuntimeException('Database tables could not be listed.');
        }

        while ($tableRow = $tablesResult->fetch_row()) {
            $tableName = (string)($tableRow[0] ?? '');
            if ($tableName === '') continue;
            $escapedTable = '`' . str_replace('`', '``', $tableName) . '`';
            wifiScheduledBackupWrite($handle,
                "\n-- --------------------------------------------------------\n"
                . '-- Table: ' . $tableName . "\n"
                . "-- --------------------------------------------------------\n\n"
                . 'DROP TABLE IF EXISTS ' . $escapedTable . ";\n\n"
            );

            $createResult = $db->query('SHOW CREATE TABLE ' . $escapedTable);
            if (!$createResult instanceof mysqli_result) {
                throw new RuntimeException('A database table definition could not be read.');
            }
            $createRow = $createResult->fetch_assoc() ?: [];
            $createSql = (string)($createRow['Create Table'] ?? '');
            $createResult->free();
            if ($createSql === '') {
                throw new RuntimeException('A database table definition was empty.');
            }
            wifiScheduledBackupWrite($handle, $createSql . ";\n\n");

            $dataResult = $db->query('SELECT * FROM ' . $escapedTable, MYSQLI_USE_RESULT);
            if (!$dataResult instanceof mysqli_result) {
                throw new RuntimeException('Database table data could not be read.');
            }
            $fieldCount = $dataResult->field_count;
            while ($dataRow = $dataResult->fetch_row()) {
                $values = [];
                for ($i = 0; $i < $fieldCount; $i++) {
                    $value = $dataRow[$i] ?? null;
                    $values[] = $value === null ? 'NULL' : "'" . $db->real_escape_string((string)$value) . "'";
                }
                wifiScheduledBackupWrite($handle,
                    'INSERT INTO ' . $escapedTable . ' VALUES (' . implode(', ', $values) . ");\n"
                );
            }
            $dataResult->free();
            wifiScheduledBackupWrite($handle, "\n");
        }
        $tablesResult->free();
        wifiScheduledBackupWrite($handle, "\nSET FOREIGN_KEY_CHECKS = 1;\nCOMMIT;\nSET AUTOCOMMIT = 1;\n");
        if (!fclose($handle)) {
            $handle = null;
            throw new RuntimeException('Scheduled backup file could not be finalized.');
        }
        $handle = null;

        $size = filesize($filePath);
        if ($size === false || $size < 1) {
            throw new RuntimeException('Scheduled backup file is empty.');
        }
        return $fileName;
    } catch (Throwable $exception) {
        if (is_resource($handle)) fclose($handle);
        if (is_file($filePath)) @unlink($filePath);
        throw $exception;
    }
}

$lockAcquired = false;
try {
    $policyResult = $conn->query('SELECT enabled, frequency, run_time, run_day, retention_count, last_run_at FROM backup_policy WHERE id = 1 LIMIT 1');
    $policy = $policyResult instanceof mysqli_result ? ($policyResult->fetch_assoc() ?: null) : null;
    if ($policyResult instanceof mysqli_result) $policyResult->free();
    if (!is_array($policy) || (int)$policy['enabled'] !== 1) {
        echo "Scheduled backup is disabled.\n";
        exit(0);
    }

    $lockResult = $conn->query("SELECT GET_LOCK('wifi_voucher_scheduled_backup', 0) AS acquired");
    $lockRow = $lockResult instanceof mysqli_result ? ($lockResult->fetch_assoc() ?: []) : [];
    if ($lockResult instanceof mysqli_result) $lockResult->free();
    if ((int)($lockRow['acquired'] ?? 0) !== 1) {
        echo "Another scheduled backup is already running.\n";
        exit(0);
    }
    $lockAcquired = true;

    $now = new DateTimeImmutable('now');
    $frequency = (string)$policy['frequency'];
    $runDay = max(1, min(7, (int)$policy['run_day']));
    $runTime = substr((string)$policy['run_time'], 0, 8);
    $lastRun = trim((string)($policy['last_run_at'] ?? ''));
    $alreadyRanToday = $lastRun !== '' && substr($lastRun, 0, 10) === $now->format('Y-m-d');
    $due = $now->format('H:i:s') >= $runTime && !$alreadyRanToday;
    if ($frequency === 'weekly' && (int)$now->format('N') !== $runDay) $due = false;
    if (!in_array($frequency, ['daily', 'weekly'], true)) $due = false;
    if (!$due) {
        echo "Scheduled backup is not due.\n";
        exit(0);
    }

    $dbNameResult = $conn->query('SELECT DATABASE() AS db_name');
    $dbNameRow = $dbNameResult instanceof mysqli_result ? ($dbNameResult->fetch_assoc() ?: []) : [];
    if ($dbNameResult instanceof mysqli_result) $dbNameResult->free();
    $dbName = trim((string)($dbNameRow['db_name'] ?? ''));
    if ($dbName === '') throw new RuntimeException('The active database name could not be determined.');

    $backupDirectory = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'backups';
    $safeDbName = preg_replace('/[^A-Za-z0-9_-]/', '_', $dbName) ?: 'database';
    $fileName = wifiScheduledBackupExport($conn, $backupDirectory, $dbName, $safeDbName);

    $mark = $conn->prepare('UPDATE backup_policy SET last_run_at = NOW() WHERE id = 1');
    if (!$mark || !$mark->execute()) {
        if ($mark) $mark->close();
        throw new RuntimeException('The scheduled backup was created but its run time could not be recorded.');
    }
    $mark->close();

    $retentionCount = max(1, min(30, (int)$policy['retention_count']));
    $scheduledFiles = glob($backupDirectory . DIRECTORY_SEPARATOR . $safeDbName . '_scheduled_backup_*.sql') ?: [];
    usort($scheduledFiles, static fn(string $a, string $b): int => (filemtime($b) ?: 0) <=> (filemtime($a) ?: 0));
    foreach (array_slice($scheduledFiles, $retentionCount) as $oldFile) {
        if (is_file($oldFile)) @unlink($oldFile);
    }

    echo 'Scheduled backup created: ' . $fileName . "\n";
} catch (Throwable $exception) {
    error_log('Wi-Fi Voucher scheduled backup: ' . $exception->getMessage());
    fwrite(STDERR, "Scheduled backup failed. Check the PHP error log.\n");
    exitCode(1);
} finally {
    if ($lockAcquired) $conn->query("SELECT RELEASE_LOCK('wifi_voucher_scheduled_backup')");
}

function exitCode(int $code): never
{
    exit($code);
}
