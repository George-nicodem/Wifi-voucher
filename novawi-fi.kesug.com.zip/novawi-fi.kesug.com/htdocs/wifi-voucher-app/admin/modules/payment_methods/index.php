<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';

requireAdminLogin();

global $conn;

// Load the stylesheet before action routing so create/edit views inherit it too.
$cssUrl = appUrl('admin/modules/payment_methods/payment-methods.css?v=2');
echo '<link rel="stylesheet" href="' . e($cssUrl) . '">';

$action = getString('action', '');
if ($action === 'create') {
    require __DIR__ . '/create.php';
    return;
}
if ($action === 'edit') {
    require __DIR__ . '/edit.php';
    return;
}
if ($action === 'toggle') {
    require __DIR__ . '/toggle.php';
    return;
}

$search = trim(getString('search', ''));
$search = function_exists('mb_substr') ? mb_substr($search, 0, 120) : substr($search, 0, 120);
$searchLike = '%' . $search . '%';
$status = strtolower(trim(getString('status', '')));
if (!in_array($status, ['', 'enabled', 'disabled', 'needs_review'], true)) {
    $status = '';
}

$currentPage = max(1, getInt('methods_page', 1) ?? 1);
$perPage = 20;
$pageError = '';
$methodStats = ['total' => 0, 'enabled' => 0, 'disabled' => 0, 'review' => 0, 'supported' => 0];

$statsResult = $conn->query("
    SELECT
        COUNT(*) AS total,
        SUM(status = 'enabled') AS enabled,
        SUM(status = 'disabled') AS disabled,
        SUM(status IS NULL OR status NOT IN ('enabled', 'disabled')) AS review
    FROM payment_methods
");
if ($statsResult) {
    $statsRow = $statsResult->fetch_assoc() ?: [];
    foreach (['total', 'enabled', 'disabled', 'review'] as $key) {
        $methodStats[$key] = (int)($statsRow[$key] ?? 0);
    }
} else {
    logDatabaseError($conn, 'Loading payment method totals');
}

$supportedResult = $conn->query("
    SELECT COUNT(DISTINCT pm.id) AS total
    FROM payment_methods pm
    INNER JOIN channel_payment_methods cpm
        ON cpm.payment_method_id = pm.id AND cpm.status = 'enabled'
    INNER JOIN payment_channels pc
        ON pc.id = cpm.channel_id AND pc.status = 'enabled' AND COALESCE(pc.configured, 0) = 1
");
if ($supportedResult) {
    $methodStats['supported'] = (int)(($supportedResult->fetch_assoc()['total'] ?? 0));
} else {
    logDatabaseError($conn, 'Loading payment network channel support totals');
}

$whereSql = "
    (? = '' OR (? = 'needs_review' AND COALESCE(pm.status, '') NOT IN ('enabled', 'disabled')) OR pm.status = ?)
    AND
    (
        ? = ''
        OR pm.name LIKE ?
        OR pm.display_name LIKE ?
        OR COALESCE(pm.provider_code, '') LIKE ?
        OR COALESCE(pm.payment_type, '') LIKE ?
    )
";

$countStmt = $conn->prepare("SELECT COUNT(*) AS total FROM payment_methods pm WHERE $whereSql");
$totalMethods = 0;
if (!$countStmt) {
    logDatabaseError($conn, 'Preparing payment method count');
    $pageError = 'Payment methods could not be loaded right now.';
} else {
    $countStmt->bind_param('ssssssss', $status, $status, $status, $search, $searchLike, $searchLike, $searchLike, $searchLike);
    if (!$countStmt->execute()) {
        logDatabaseError($conn, 'Loading payment method count');
        $pageError = 'Payment methods could not be loaded right now.';
    } else {
        $countResult = $countStmt->get_result();
        $countRow = $countResult ? $countResult->fetch_assoc() : null;
        $totalMethods = (int)($countRow['total'] ?? 0);
    }
    $countStmt->close();
}

$totalPages = max(1, (int)ceil($totalMethods / $perPage));
$currentPage = min($currentPage, $totalPages);
$offset = ($currentPage - 1) * $perPage;
$methods = [];

if ($pageError === '') {
    $listStmt = $conn->prepare("
        SELECT
            pm.id,
            pm.name,
            pm.display_name,
            pm.provider_code,
            pm.payment_type,
            pm.icon,
            pm.status,
            pm.display_order,
            pm.created_at,
            COUNT(DISTINCT cpm.channel_id) AS mapped_channel_count,
            COUNT(DISTINCT CASE
                WHEN cpm.status = 'enabled'
                    AND pc.status = 'enabled'
                    AND COALESCE(pc.configured, 0) = 1
                THEN pc.id
            END) AS compatible_channel_count,
            GROUP_CONCAT(DISTINCT CASE
                WHEN cpm.status = 'enabled'
                    AND pc.status = 'enabled'
                    AND COALESCE(pc.configured, 0) = 1
                THEN pc.name
            END ORDER BY pc.name SEPARATOR ', ') AS compatible_channels
        FROM payment_methods pm
        LEFT JOIN channel_payment_methods cpm ON cpm.payment_method_id = pm.id
        LEFT JOIN payment_channels pc ON pc.id = cpm.channel_id
        WHERE $whereSql
        GROUP BY pm.id, pm.name, pm.display_name, pm.provider_code, pm.payment_type, pm.icon, pm.status, pm.display_order, pm.created_at
        ORDER BY COALESCE(pm.display_order, 0) ASC, pm.display_name ASC, pm.id ASC
        LIMIT ? OFFSET ?
    ");

    if (!$listStmt) {
        logDatabaseError($conn, 'Preparing payment method list');
        $pageError = 'Payment methods could not be loaded right now.';
    } else {
        $listStmt->bind_param(
            'ssssssssii',
            $status,
            $status,
            $status,
            $search,
            $searchLike,
            $searchLike,
            $searchLike,
            $searchLike,
            $perPage,
            $offset
        );
        if (!$listStmt->execute()) {
            logDatabaseError($conn, 'Loading payment method list');
            $pageError = 'Payment methods could not be loaded right now.';
        } else {
            $listResult = $listStmt->get_result();
            if ($listResult) {
                while ($row = $listResult->fetch_assoc()) {
                    $methods[] = $row;
                }
            }
        }
        $listStmt->close();
    }
}

$basePageUrl = 'admin/dashboard.php?page=payment_methods&search=' . urlencode($search)
    . '&status=' . urlencode($status) . '&methods_page=';
?>

<div class="payment-methods-page">
    <header class="payment-methods-header">
        <div class="payment-methods-heading">
            <div class="payment-methods-heading-icon"><i class="fa-solid fa-mobile-screen-button"></i></div>
            <div>
                <div class="payment-methods-eyebrow">Payments / Customer options</div>
                <h1>Payment Methods</h1>
                <p>Manage the mobile networks customers choose when paying for a voucher.</p>
            </div>
        </div>
        <div class="payment-methods-header-actions">
            <a class="payment-methods-primary" href="<?= e(appUrl('admin/dashboard.php?page=payment_methods&action=create')) ?>"><i class="fa-solid fa-plus"></i> Add Network</a>
        </div>
    </header>

    <div class="payment-methods-note"><i class="fa-solid fa-circle-info"></i><span><strong>Networks are customer choices; aggregators stay behind the scenes.</strong> A customer selecting M-Pesa should be routed only through an enabled, configured channel that supports M-Pesa. Channel compatibility is shown below; primary and backup routes are chosen separately in Payment Routing.</span></div>

    <section class="payment-methods-stats" aria-label="Payment method totals">
        <article><span>Customer networks</span><strong><?= number_format($methodStats['total']) ?></strong></article>
        <article><span>Enabled choices</span><strong><?= number_format($methodStats['enabled']) ?></strong></article>
        <article><span>Disabled</span><strong><?= number_format($methodStats['disabled']) ?></strong></article>
        <article><span>With compatible channel*</span><strong><?= number_format($methodStats['supported']) ?></strong></article>
    </section>

    <p class="payment-methods-footnote">*Counts configured and enabled channel mappings on this page. Final customer availability also depends on a primary/backup route being set.</p>

    <?php if ($pageError !== ''): ?>
        <div class="payment-methods-alert" role="alert"><i class="fa-solid fa-circle-exclamation"></i> <?= e($pageError) ?></div>
    <?php endif; ?>

    <form class="payment-methods-filters" method="get" action="<?= e(appUrl('admin/dashboard.php')) ?>">
        <input type="hidden" name="page" value="payment_methods">
        <label class="payment-methods-search"><i class="fa-solid fa-magnifying-glass"></i><input type="search" name="search" value="<?= e($search) ?>" maxlength="120" placeholder="Search network, code or type"></label>
        <select name="status" aria-label="Filter by status">
            <option value="" <?= $status === '' ? 'selected' : '' ?>>All statuses</option>
            <option value="enabled" <?= $status === 'enabled' ? 'selected' : '' ?>>Enabled</option>
            <option value="disabled" <?= $status === 'disabled' ? 'selected' : '' ?>>Disabled</option>
            <option value="needs_review" <?= $status === 'needs_review' ? 'selected' : '' ?>>Needs status</option>
        </select>
        <button type="submit"><i class="fa-solid fa-filter"></i> Filter</button>
        <?php if ($search !== '' || $status !== ''): ?><a href="<?= e(appUrl('admin/dashboard.php?page=payment_methods')) ?>">Clear</a><?php endif; ?>
    </form>

    <section class="payment-methods-table-card">
        <div class="payment-methods-table-heading"><div><h2>Customer payment networks</h2><p><?= number_format($totalMethods) ?> record<?= $totalMethods === 1 ? '' : 's' ?><?= $search !== '' || $status !== '' ? ' match your filters' : '' ?></p></div><span class="payment-methods-count"><i class="fa-solid fa-route"></i> Aggregator support</span></div>
        <?php if ($pageError === ''): ?>
            <?php if ($methods): ?>
                <div class="payment-methods-table-wrap">
                    <table class="payment-methods-table">
                        <thead><tr><th>Customer network</th><th>Network key / code</th><th>Type</th><th>Compatible aggregators</th><th>Order</th><th>Customer choice</th><th>Actions</th></tr></thead>
                        <tbody>
                            <?php foreach ($methods as $method): ?>
                                <?php
                                    $methodStatus = $method['status'] !== null ? (string)$method['status'] : null;
                                    $compatibleCount = (int)$method['compatible_channel_count'];
                                    $compatibleNames = trim((string)($method['compatible_channels'] ?? ''));
                                ?>
                                <tr>
                                    <td><strong><?= e((string)$method['display_name']) ?></strong><small>Internal key: <?= e((string)$method['name']) ?></small></td>
                                    <td><?= e((string)($method['provider_code'] ?: '—')) ?></td>
                                    <td><?= e(paymentMethodTypeLabel($method['payment_type'] !== null ? (string)$method['payment_type'] : null)) ?></td>
                                    <td>
                                        <?php if ($compatibleCount > 0): ?>
                                            <span class="payment-methods-support-ready"><i class="fa-solid fa-circle-check"></i> <?= number_format($compatibleCount) ?> channel<?= $compatibleCount === 1 ? '' : 's' ?></span>
                                            <small class="payment-methods-channel-names"><?= e($compatibleNames) ?></small>
                                        <?php elseif ((int)$method['mapped_channel_count'] > 0): ?>
                                            <span class="payment-methods-support-pending"><i class="fa-solid fa-clock"></i> Mapping needs setup</span>
                                        <?php else: ?>
                                            <span class="payment-methods-support-none"><i class="fa-solid fa-link-slash"></i> No compatible channel yet</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= number_format((int)($method['display_order'] ?? 0)) ?></td>
                                    <td><span class="method-status <?= e(paymentMethodStatusClass($methodStatus)) ?>"><?= e(paymentMethodStatusLabel($methodStatus)) ?></span></td>
                                    <td>
                                        <div class="payment-methods-row-actions">
                                            <a href="<?= e(appUrl('admin/dashboard.php?page=payment_methods&action=edit&id=' . (int)$method['id'])) ?>" class="payment-methods-icon-action" title="Edit network" aria-label="Edit <?= e((string)$method['display_name']) ?>"><i class="fa-solid fa-pen"></i></a>
                                            <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=payment_methods&action=toggle')) ?>" onsubmit="return confirm('Change the status of this customer payment option?');">
                                                <?= csrfField() ?>
                                                <input type="hidden" name="id" value="<?= (int)$method['id'] ?>">
                                                <input type="hidden" name="status" value="<?= $methodStatus === 'enabled' ? 'disabled' : 'enabled' ?>">
                                                <button class="payment-methods-icon-action <?= $methodStatus === 'enabled' ? 'is-disable' : 'is-enable' ?>" type="submit" title="<?= $methodStatus === 'enabled' ? 'Disable' : 'Enable' ?> network" aria-label="<?= $methodStatus === 'enabled' ? 'Disable' : 'Enable' ?> <?= e((string)$method['display_name']) ?>"><i class="fa-solid <?= $methodStatus === 'enabled' ? 'fa-toggle-on' : 'fa-toggle-off' ?>"></i></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($totalPages > 1): ?>
                    <nav class="payment-methods-pagination" aria-label="Payment method pages">
                        <span>Page <?= number_format($currentPage) ?> of <?= number_format($totalPages) ?></span>
                        <div>
                            <?php if ($currentPage > 1): ?><a href="<?= e(appUrl($basePageUrl . ($currentPage - 1))) ?>" aria-label="Previous page"><i class="fa-solid fa-chevron-left"></i></a><?php endif; ?>
                            <?php if ($currentPage < $totalPages): ?><a href="<?= e(appUrl($basePageUrl . ($currentPage + 1))) ?>" aria-label="Next page"><i class="fa-solid fa-chevron-right"></i></a><?php endif; ?>
                        </div>
                    </nav>
                <?php endif; ?>
            <?php else: ?>
                <div class="payment-methods-empty"><span><i class="fa-solid fa-mobile-screen-button"></i></span><h3><?= $search !== '' || $status !== '' ? 'No matching networks' : 'No payment networks yet' ?></h3><p><?= $search !== '' || $status !== '' ? 'Change the filters and try again.' : 'Add customer-facing networks such as M-Pesa, Airtel Money, Mixx by Yas or Halotel.' ?></p></div>
            <?php endif; ?>
        <?php endif; ?>
    </section>
</div>
