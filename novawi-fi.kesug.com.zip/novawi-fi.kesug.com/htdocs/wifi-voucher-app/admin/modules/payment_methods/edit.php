<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';

requireAdminLogin();

global $conn;

$methodId = isPost() ? (postInt('id', 0) ?? 0) : (getInt('id', 0) ?? 0);
$method = null;
$errors = [];
$success = '';
$loadFailed = false;

if ($methodId <= 0) {
    $errors[] = 'The selected payment method is invalid.';
} else {
    $loadStmt = $conn->prepare('SELECT id, name, display_name, provider_code, payment_type, icon, status, display_order FROM payment_methods WHERE id = ? LIMIT 1');
    if (!$loadStmt) {
        logDatabaseError($conn, 'Preparing payment method lookup');
        $errors[] = 'The payment method could not be loaded right now.';
        $loadFailed = true;
    } else {
        $loadStmt->bind_param('i', $methodId);
        if (!$loadStmt->execute()) {
            logDatabaseError($conn, 'Loading payment method');
            $errors[] = 'The payment method could not be loaded right now.';
            $loadFailed = true;
        } else {
            $result = $loadStmt->get_result();
            $method = $result ? $result->fetch_assoc() : null;
            if (!$method) {
                $errors[] = 'This payment method was not found.';
            }
        }
        $loadStmt->close();
    }
}

$values = $method ? [
    'name' => (string)$method['name'],
    'display_name' => (string)$method['display_name'],
    'provider_code' => (string)($method['provider_code'] ?? ''),
    'payment_type' => (string)($method['payment_type'] ?? ''),
    'icon' => (string)($method['icon'] ?? ''),
    'status' => in_array((string)($method['status'] ?? ''), ['enabled', 'disabled'], true) ? (string)$method['status'] : 'disabled',
    'display_order' => (int)($method['display_order'] ?? 0),
] : [
    'name' => '',
    'display_name' => '',
    'provider_code' => '',
    'payment_type' => '',
    'icon' => '',
    'status' => 'disabled',
    'display_order' => 0,
];

if (isPost() && $method && !$loadFailed) {
    requireAdminPost();
    requireCsrfToken();

    $values = [
        'name' => postString('name'),
        'display_name' => postString('display_name'),
        'provider_code' => postString('provider_code'),
        'payment_type' => postString('payment_type'),
        'icon' => postString('icon'),
        'status' => postString('status', 'disabled'),
        'display_order' => postInt('display_order', 0) ?? 0,
    ];

    $validation = validatePaymentMethodData($values);
    $errors = $validation['errors'];
    $data = $validation['data'];

    if (!$errors) {
        $nameExists = paymentMethodNameExists($conn, $data['name'], $methodId);
        if ($nameExists === null) {
            $errors[] = 'Could not check for an existing method name. Please try again.';
        } elseif ($nameExists) {
            $errors[] = 'That network key is already in use. Choose a different key.';
        }
    }

    if (!$errors) {
        $stmt = $conn->prepare("
            UPDATE payment_methods
            SET name = ?, display_name = ?, provider_code = ?, payment_type = ?, icon = ?, status = ?, display_order = ?, updated_at = NOW()
            WHERE id = ?
            LIMIT 1
        ");

        if (!$stmt) {
            logDatabaseError($conn, 'Preparing payment method update');
            $errors[] = 'The payment method could not be saved right now.';
        } else {
            $name = $data['name'];
            $displayName = $data['display_name'];
            $providerCode = $data['provider_code'];
            $paymentType = $data['payment_type'];
            $icon = $data['icon'];
            $status = $data['status'];
            $displayOrder = $data['display_order'];
            $stmt->bind_param('ssssssii', $name, $displayName, $providerCode, $paymentType, $icon, $status, $displayOrder, $methodId);

            if (!$stmt->execute()) {
                logDatabaseError($conn, 'Saving payment method changes');
                $errors[] = 'The payment method could not be saved right now.';
            } else {
                logAdminSecurityEvent('PAYMENT_METHOD_UPDATED', 'Updated payment method ID #' . $methodId . ' (' . $displayName . ').');
                $success = 'Payment method updated.';
                $method = array_merge($method ?: [], $data);
            }
            $stmt->close();
        }
    }
}
?>

<div class="payment-methods-page">
    <header class="payment-methods-page-heading">
        <div><div class="payment-methods-eyebrow">Payment Methods</div><h1>Edit customer network</h1><p>Update the customer-facing network choice or its availability flag.</p></div>
        <a class="payment-methods-secondary" href="<?= e(appUrl('admin/dashboard.php?page=payment_methods')) ?>"><i class="fa-solid fa-arrow-left"></i> Back to methods</a>
    </header>

    <?php if ($success !== ''): ?><div class="payment-methods-success" role="status"><i class="fa-solid fa-circle-check"></i> <?= e($success) ?></div><?php endif; ?>
    <?php foreach ($errors as $error): ?><div class="payment-methods-alert" role="alert"><i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?></div><?php endforeach; ?>

    <?php if ($method): ?>
        <section class="payment-methods-form-card">
            <div class="payment-methods-form-heading"><span><i class="fa-solid fa-pen"></i></span><div><h2><?= e((string)($values['display_name'] ?: $method['display_name'])) ?></h2><p>Internal network key: <?= e((string)$method['name']) ?></p></div></div>
            <form class="payment-methods-form" method="post" action="<?= e(appUrl('admin/dashboard.php?page=payment_methods&action=edit&id=' . $methodId)) ?>">
                <?= csrfField() ?>
                <input type="hidden" name="id" value="<?= $methodId ?>">
                <div class="payment-methods-form-grid">
                    <div class="payment-methods-field"><label for="method-name">Internal network key <b>*</b></label><input id="method-name" name="name" value="<?= e((string)$values['name']) ?>" maxlength="100" required pattern="[a-z0-9][a-z0-9_-]*" autocomplete="off"><small>Stable lowercase identifier, for example <code>mpesa</code> or <code>mixx_by_yas</code>.</small></div>
                    <div class="payment-methods-field"><label for="display-name">Customer label <b>*</b></label><input id="display-name" name="display_name" value="<?= e((string)$values['display_name']) ?>" maxlength="100" required></div>
                    <div class="payment-methods-field"><label for="provider-code">Network code</label><input id="provider-code" name="provider_code" value="<?= e((string)$values['provider_code']) ?>" maxlength="100"><small>Optional shared code. Each aggregator's own code is kept on its channel mapping.</small></div>
                    <div class="payment-methods-field"><label for="payment-type">Payment type</label><input id="payment-type" name="payment_type" value="<?= e((string)$values['payment_type']) ?>" maxlength="50" pattern="[a-zA-Z0-9_-]*" placeholder="For example, mobile_money"></div>
                    <div class="payment-methods-field"><label for="method-icon">Network icon class or path</label><input id="method-icon" name="icon" value="<?= e((string)$values['icon']) ?>" maxlength="255"><small>Optional customer-facing icon value.</small></div>
                    <div class="payment-methods-field"><label for="display-order">Display order</label><input id="display-order" name="display_order" type="number" min="0" max="99999" step="1" value="<?= e((string)$values['display_order']) ?>"></div>
                    <div class="payment-methods-field"><label for="method-status">Customer choice</label><select id="method-status" name="status"><?php foreach (paymentMethodStatuses() as $statusKey => $statusLabel): ?><option value="<?= e($statusKey) ?>" <?= $values['status'] === $statusKey ? 'selected' : '' ?>><?= e($statusLabel) ?></option><?php endforeach; ?></select><small>Enabled alone does not make checkout offer this network. It also needs a compatible configured channel and a route.</small></div>
                </div>
                <div class="payment-methods-form-actions"><a class="payment-methods-secondary" href="<?= e(appUrl('admin/dashboard.php?page=payment_methods')) ?>">Cancel</a><button class="payment-methods-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save changes</button></div>
            </form>
        </section>
    <?php endif; ?>
</div>
