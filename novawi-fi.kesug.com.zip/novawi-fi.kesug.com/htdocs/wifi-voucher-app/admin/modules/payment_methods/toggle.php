<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';

requireAdminLogin();

global $conn;

$error = '';
$success = '';

if (!isPost()) {
    $error = 'Method status can only be changed using the admin form.';
} else {
    requireAdminPost();
    requireCsrfToken();

    $methodId = postInt('id', 0) ?? 0;
    $newStatus = strtolower(trim(postString('status', '')));

    if ($methodId <= 0 || !in_array($newStatus, ['enabled', 'disabled'], true)) {
        $error = 'The requested status change is invalid.';
    } else {
        $stmt = $conn->prepare('UPDATE payment_methods SET status = ?, updated_at = NOW() WHERE id = ? LIMIT 1');
        if (!$stmt) {
            logDatabaseError($conn, 'Preparing payment method status change');
            $error = 'The payment method status could not be changed right now.';
        } else {
            $stmt->bind_param('si', $newStatus, $methodId);
            if (!$stmt->execute()) {
                logDatabaseError($conn, 'Changing payment method status');
                $error = 'The payment method status could not be changed right now.';
            } elseif ($stmt->affected_rows !== 1) {
                $error = 'The payment method was not found or already has that status.';
            } else {
                logAdminSecurityEvent(
                    'PAYMENT_METHOD_STATUS_CHANGED',
                    'Changed payment method ID #' . $methodId . ' status to ' . $newStatus . '.'
                );
                $success = 'Payment method is now ' . $newStatus . '.';
            }
            $stmt->close();
        }
    }
}
?>

<div class="payment-methods-page">
    <header class="payment-methods-page-heading">
        <div><div class="payment-methods-eyebrow">Payment Methods</div><h1>Update method status</h1><p>Enable or disable a payment method.</p></div>
        <a class="payment-methods-secondary" href="<?= e(appUrl('admin/dashboard.php?page=payment_methods')) ?>"><i class="fa-solid fa-arrow-left"></i> Back to methods</a>
    </header>
    <?php if ($success !== ''): ?><div class="payment-methods-success" role="status"><i class="fa-solid fa-circle-check"></i> <?= e($success) ?></div><?php endif; ?>
    <?php if ($error !== ''): ?><div class="payment-methods-alert" role="alert"><i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?></div><?php endif; ?>
    <a class="payment-methods-primary" href="<?= e(appUrl('admin/dashboard.php?page=payment_methods')) ?>">Return to methods</a>
</div>
