<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../config/app.php';
require_once __DIR__ . '/../../../config/security.php';
require_once __DIR__ . '/../../../includes/functions.php';

function paymentMethodStatuses(): array
{
    return [
        'enabled' => 'Enabled',
        'disabled' => 'Disabled',
    ];
}

function paymentMethodStatusLabel(?string $status): string
{
    $status = strtolower(trim((string)$status));
    return paymentMethodStatuses()[$status] ?? 'Needs status';
}

function paymentMethodStatusClass(?string $status): string
{
    return match (strtolower(trim((string)$status))) {
        'enabled' => 'method-status-enabled',
        'disabled' => 'method-status-disabled',
        default => 'method-status-review',
    };
}

function paymentMethodTypeLabel(?string $type): string
{
    $type = trim((string)$type);
    if ($type === '') {
        return 'Not set';
    }

    return ucwords(str_replace(['_', '-'], ' ', $type));
}

function paymentMethodLength(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
}

function validatePaymentMethodData(array $input): array
{
    $name = strtolower(trim((string)($input['name'] ?? '')));
    $displayName = trim((string)($input['display_name'] ?? ''));
    $providerCode = strtoupper(trim((string)($input['provider_code'] ?? '')));
    $paymentType = strtolower(trim((string)($input['payment_type'] ?? '')));
    $icon = trim((string)($input['icon'] ?? ''));
    $status = strtolower(trim((string)($input['status'] ?? 'disabled')));
    $displayOrder = $input['display_order'] ?? 0;
    $errors = [];

    if ($name === '' || paymentMethodLength($name) > 100 || !preg_match('/^[a-z0-9][a-z0-9_-]*$/D', $name)) {
        $errors[] = 'Enter a network key using lowercase letters, numbers, hyphens or underscores (up to 100 characters).';
    }
    if ($displayName === '' || paymentMethodLength($displayName) > 100) {
        $errors[] = 'Customer label is required and must be 100 characters or fewer.';
    }
    if (paymentMethodLength($providerCode) > 100) {
        $errors[] = 'Network code must be 100 characters or fewer.';
    }
    if ($paymentType !== '' && (paymentMethodLength($paymentType) > 50 || !preg_match('/^[a-z0-9_-]+$/D', $paymentType))) {
        $errors[] = 'Payment type may use lowercase letters, numbers, hyphens and underscores (up to 50 characters).';
    }
    if (paymentMethodLength($icon) > 255) {
        $errors[] = 'Icon value must be 255 characters or fewer.';
    }
    if (!array_key_exists($status, paymentMethodStatuses())) {
        $errors[] = 'Choose a valid method status.';
    }
    if (!is_int($displayOrder) || $displayOrder < 0 || $displayOrder > 99999) {
        $errors[] = 'Display order must be a whole number from 0 to 99,999.';
    }

    return [
        'errors' => $errors,
        'data' => [
            'name' => $name,
            'display_name' => $displayName,
            'provider_code' => $providerCode !== '' ? $providerCode : null,
            'payment_type' => $paymentType !== '' ? $paymentType : null,
            'icon' => $icon !== '' ? $icon : null,
            'status' => $status,
            'display_order' => $displayOrder,
        ],
    ];
}

function paymentMethodNameExists(mysqli $conn, string $name, int $excludeId = 0): ?bool
{
    $stmt = $conn->prepare('SELECT id FROM payment_methods WHERE name = ? AND id <> ? LIMIT 1');
    if (!$stmt) {
        return null;
    }

    $stmt->bind_param('si', $name, $excludeId);
    if (!$stmt->execute()) {
        $stmt->close();
        return null;
    }

    $result = $stmt->get_result();
    $exists = $result ? $result->num_rows > 0 : false;
    $stmt->close();
    return $exists;
}
