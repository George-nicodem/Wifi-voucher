<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';

requireAdminLogin();

global $conn;

$errors = [];
$success = '';
$createdId = 0;
$values = [
    'name' => '',
    'display_name' => '',
    'provider_code' => '',
    'payment_type' => '',
    'icon' => '',
    'status' => 'disabled',
    'display_order' => 0,
];

if (isPost()) {
    requireAdminPost();
    requireCsrfToken();

    $values = [
        'name' => postString('name'),
        'display_name' => postString('display_name'),
        'provider_code' => postString('provider_code'),
        'payment_type' => postString('payment_type'),
        'icon' => postString('icon'),
        'status' => postString('status', 'disabled'),
        'display_order' => postInt('display_order', 0) ?? 0,
    ];

    $validation = validatePaymentMethodData($values);
    $errors = $validation['errors'];
    $data = $validation['data'];

    if (!$errors) {
        $nameExists = paymentMethodNameExists($conn, $data['name']);
        if ($nameExists === null) {
            $errors[] = 'Could not check for an existing method name. Please try again.';
        } elseif ($nameExists) {
            $errors[] = 'That network key is already in use. Choose a different key.';
        }
    }

    if (!$errors) {
        $stmt = $conn->prepare("
            INSERT INTO payment_methods
                (name, display_name, provider_code, payment_type, icon, status, display_order)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        if (!$stmt) {
            logDatabaseError($conn, 'Preparing payment method insert');
            $errors[] = 'The payment method could not be saved right now.';
        } else {
            $name = $data['name'];
            $displayName = $data['display_name'];
            $providerCode = $data['provider_code'];
            $paymentType = $data['payment_type'];
            $icon = $data['icon'];
            $status = $data['status'];
            $displayOrder = $data['display_order'];
            $stmt->bind_param('ssssssi', $name, $displayName, $providerCode, $paymentType, $icon, $status, $displayOrder);

            if (!$stmt->execute()) {
                logDatabaseError($conn, 'Saving payment method');
                $errors[] = 'The payment method could not be saved right now.';
            } else {
                $createdId = (int)$stmt->insert_id;
                logAdminSecurityEvent('PAYMENT_METHOD_CREATED', 'Created payment method ID #' . $createdId . ' (' . $displayName . ').');
                $success = 'Payment method added.';
                $values = [
                    'name' => '',
                    'display_name' => '',
                    'provider_code' => '',
                    'payment_type' => '',
                    'icon' => '',
                    'status' => 'disabled',
                    'display_order' => 0,
                ];
            }
            $stmt->close();
        }
    }
}
?>

<div class="payment-methods-page">
    <header class="payment-methods-page-heading">
        <div><div class="payment-methods-eyebrow">Payment Methods</div><h1>Add customer network</h1><p>Add a payment network that a customer can choose during checkout.</p></div>
        <a class="payment-methods-secondary" href="<?= e(appUrl('admin/dashboard.php?page=payment_methods')) ?>"><i class="fa-solid fa-arrow-left"></i> Back to methods</a>
    </header>

    <?php if ($success !== ''): ?>
        <div class="payment-methods-success" role="status"><i class="fa-solid fa-circle-check"></i> <?= e($success) ?><?php if ($createdId > 0): ?> <a href="<?= e(appUrl('admin/dashboard.php?page=payment_methods&action=edit&id=' . $createdId)) ?>">Edit this method</a><?php endif; ?></div>
    <?php endif; ?>
    <?php foreach ($errors as $error): ?>
        <div class="payment-methods-alert" role="alert"><i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?></div>
    <?php endforeach; ?>

    <section class="payment-methods-form-card">
        <div class="payment-methods-form-heading"><span><i class="fa-solid fa-mobile-screen-button"></i></span><div><h2>Network details</h2><p>This is the network choice shown to customers. Aggregator APIs are configured separately.</p></div></div>
        <form class="payment-methods-form" method="post" action="<?= e(appUrl('admin/dashboard.php?page=payment_methods&action=create')) ?>">
            <?= csrfField() ?>
            <div class="payment-methods-form-grid">
                <div class="payment-methods-field"><label for="method-name">Internal network key <b>*</b></label><input id="method-name" name="name" value="<?= e((string)$values['name']) ?>" maxlength="100" required pattern="[a-z0-9][a-z0-9_-]*" autocomplete="off"><small>Stable lowercase key, for example <code>mpesa</code> or <code>mixx_by_yas</code>.</small></div>
                <div class="payment-methods-field"><label for="display-name">Customer label <b>*</b></label><input id="display-name" name="display_name" value="<?= e((string)$values['display_name']) ?>" maxlength="100" required placeholder="For example, M-Pesa or Mixx by Yas"></div>
                <div class="payment-methods-field"><label for="provider-code">Network code</label><input id="provider-code" name="provider_code" value="<?= e((string)$values['provider_code']) ?>" maxlength="100" placeholder="For example, MPESA"><small>Optional shared code. Each aggregator's own code is kept on its channel mapping.</small></div>
                <div class="payment-methods-field"><label for="payment-type">Payment type</label><input id="payment-type" name="payment_type" value="<?= e((string)$values['payment_type']) ?>" maxlength="50" pattern="[a-zA-Z0-9_-]*" placeholder="For example, mobile_money"><small>Usually <code>mobile_money</code> for a phone network.</small></div>
                <div class="payment-methods-field"><label for="method-icon">Network icon class or path</label><input id="method-icon" name="icon" value="<?= e((string)$values['icon']) ?>" maxlength="255" placeholder="Optional"><small>Optional customer-facing icon value.</small></div>
                <div class="payment-methods-field"><label for="display-order">Display order</label><input id="display-order" name="display_order" type="number" min="0" max="99999" step="1" value="<?= e((string)$values['display_order']) ?>"><small>Lower numbers appear first.</small></div>
                <div class="payment-methods-field"><label for="method-status">Customer choice</label><select id="method-status" name="status"><?php foreach (paymentMethodStatuses() as $statusKey => $statusLabel): ?><option value="<?= e($statusKey) ?>" <?= $values['status'] === $statusKey ? 'selected' : '' ?>><?= e($statusLabel) ?></option><?php endforeach; ?></select><small>Enabled alone does not make checkout offer this network. It also needs a compatible configured channel and a route.</small></div>
            </div>
            <div class="payment-methods-form-actions"><a class="payment-methods-secondary" href="<?= e(appUrl('admin/dashboard.php?page=payment_methods')) ?>">Cancel</a><button class="payment-methods-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save method</button></div>
        </form>
    </section>
</div>
