<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';
requireAdminRole(['admin', 'super_admin', 'superadmin']);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');

if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'GET') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Use GET to load the bank list.']);
    exit;
}

try {
    global $conn;
    $channelId = filter_var($_GET['channel_id'] ?? null, FILTER_VALIDATE_INT) ?: 0;
    if ($channelId < 1) throw new RuntimeException('Select a payout account.');

    $config = adminWalletLoadPayoutConfig($conn, $channelId);
    $banks = adminWalletBanksForProvider($config);
    $items = [];
    foreach ($banks as $code => $name) {
        $items[] = ['code' => (string)$code, 'name' => (string)$name];
    }
    echo json_encode(['ok' => true, 'provider' => (string)$config['provider_key'], 'banks' => $items], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $exception) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => $exception->getMessage()], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
