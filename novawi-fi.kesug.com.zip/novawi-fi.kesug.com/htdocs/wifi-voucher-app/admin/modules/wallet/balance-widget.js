(() => {
    const refreshInterval = 5 * 60 * 1000;

    document.querySelectorAll('[data-wallet-balance-widget]').forEach(card => {
        const form = document.getElementById(card.dataset.formId || '');
        const value = card.querySelector('.js-wallet-balance-value');
        const status = card.querySelector('.js-wallet-balance-status');
        const channel = form?.querySelector('[name="channel_id"]') || null;
        const button = form?.querySelector('button[type="submit"]') || null;
        if (!form || !value || !status || !card.dataset.endpoint) return;

        let checkedAt = Number(card.dataset.checkedAt || 0);
        let hasBalance = card.dataset.hasBalance === '1';
        let loading = false;

        const isFresh = () => checkedAt > 0 && (Date.now() / 1000 - checkedAt) < refreshInterval / 1000;

        async function refreshBalance(force = false) {
            if (loading || (!force && document.hidden)) return;
            loading = true;

            const body = new FormData(form);
            body.set('channel_id', channel ? channel.value : card.dataset.channelId || '0');
            body.set('force', force ? '1' : '0');
            if (channel) channel.disabled = true;
            if (button) button.disabled = true;
            status.textContent = hasBalance ? 'Updating balance…' : 'Loading the latest balance…';

            try {
                const response = await fetch(card.dataset.endpoint, {
                    method: 'POST',
                    body,
                    credentials: 'same-origin',
                    headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
                });
                let result;
                try {
                    result = await response.json();
                } catch {
                    throw new Error('The balance response could not be read. Refresh the page and sign in again if needed.');
                }
                if (!response.ok || !result.success) {
                    throw new Error(result.message || 'Unable to retrieve the account balance.');
                }

                const amount = new Intl.NumberFormat(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                }).format(Number(result.balance));
                const currency = document.createElement('small');
                currency.textContent = String(result.currency);
                value.replaceChildren(document.createTextNode(`${amount} `), currency);
                checkedAt = Number(result.checked_at || Math.floor(Date.now() / 1000));
                hasBalance = true;
                card.dataset.checkedAt = String(checkedAt);
                card.dataset.hasBalance = '1';
                status.textContent = `${result.cached ? 'Last updated' : 'Updated'} ${new Date(checkedAt * 1000).toLocaleString()}`;
            } catch (error) {
                if (!hasBalance) value.textContent = 'Unavailable';
                status.textContent = `${error.message || 'Unable to retrieve the account balance.'}${hasBalance ? ' · Showing the last successful balance.' : ''}`;
            } finally {
                loading = false;
                if (channel) channel.disabled = false;
                if (button) button.disabled = false;
            }
        }

        form.addEventListener('submit', event => {
            event.preventDefault();
            refreshBalance(true);
        });
        if (channel) {
            channel.addEventListener('change', () => {
                hasBalance = false;
                checkedAt = 0;
                card.dataset.hasBalance = '0';
                card.dataset.checkedAt = '0';
                value.textContent = 'Loading…';
                refreshBalance(false);
            });
        }

        if (!isFresh()) refreshBalance(false);
        window.setInterval(() => {
            if (!isFresh()) refreshBalance(false);
        }, refreshInterval);
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden && !isFresh()) refreshBalance(false);
        });
    });
})();
