<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/admin_auth.php';
require_once __DIR__ . '/functions.php';

requireAdminRole(['admin', 'super_admin', 'superadmin']);
requireAdminPostWithCsrf();

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, private');

$respond = static function (array $payload, int $status = 200): void {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
};

$channelId = filter_var($_POST['channel_id'] ?? null, FILTER_VALIDATE_INT) ?: 0;
$forceRefresh = ($_POST['force'] ?? '') === '1';
if ($channelId < 1) {
    $respond(['success' => false, 'message' => 'Choose a valid payment account.'], 400);
}

$cacheKey = 'admin_wallet_balance_' . $channelId;
$cached = $_SESSION[$cacheKey] ?? null;
if (!$forceRefresh && is_array($cached)
    && is_numeric($cached['balance'] ?? null)
    && is_string($cached['currency'] ?? null)
    && (int)($cached['checked_at'] ?? 0) > 0
    && time() - (int)$cached['checked_at'] < 300) {
    $respond([
        'success' => true,
        'balance' => (float)$cached['balance'],
        'currency' => strtoupper((string)$cached['currency']),
        'checked_at' => (int)$cached['checked_at'],
        'cached' => true,
    ]);
}

$balanceSessionId = session_id();
$balanceAdminId = (int)($_SESSION['admin_id'] ?? 0);
$balanceLoginTime = (int)($_SESSION['admin_login_time'] ?? 0);

/**
 * Cache only in the original, still authenticated session. A logout or a new
 * login during the provider request must never be replaced by an old snapshot.
 */
function adminWalletCacheFreshBalance(
    string $originalSessionId,
    int $originalAdminId,
    int $originalLoginTime,
    string $cacheKey,
    array $entry
): void {
    if ($originalSessionId === '' || $originalAdminId < 1
        || session_status() !== PHP_SESSION_NONE || headers_sent()) {
        return;
    }

    session_id($originalSessionId);
    // Do not renew a cookie that a concurrent logout has already expired.
    if (!@session_start(['use_cookies' => false, 'use_strict_mode' => true, 'cache_limiter' => ''])) {
        return;
    }
    try {
        if (hash_equals($originalSessionId, session_id())
            && (int)($_SESSION['admin_id'] ?? 0) === $originalAdminId
            && !empty($_SESSION['admin_authenticated'])
            && (int)($_SESSION['admin_login_time'] ?? 0) === $originalLoginTime) {
            $_SESSION[$cacheKey] = $entry;
        }
    } finally {
        session_write_close();
    }
}

try {
    global $conn;
    if (!($conn instanceof mysqli)) {
        throw new RuntimeException('The database connection is not available.');
    }
    $config = adminWalletLoadBalanceConfig($conn, $channelId);
    // Provider calls can take several seconds. Let the dashboard and logout
    // use this session while the balance request is waiting for the provider.
    if (session_status() === PHP_SESSION_ACTIVE && !session_write_close()) {
        throw new RuntimeException('Could not release the session for a balance check. Try again.');
    }
    $balance = adminWalletGetBalance($config);
    $entry = [
        'balance' => (float)$balance['balance'],
        'currency' => strtoupper((string)$balance['currency']),
        'provider_key' => (string)$config['provider_key'],
        'checked_at' => time(),
    ];
    adminWalletCacheFreshBalance($balanceSessionId, $balanceAdminId, $balanceLoginTime, $cacheKey, $entry);
    $respond([
        'success' => true,
        'balance' => $entry['balance'],
        'currency' => $entry['currency'],
        'checked_at' => $entry['checked_at'],
        'cached' => false,
    ]);
} catch (Throwable $exception) {
    if (function_exists('appLog')) {
        appLog('Automatic admin wallet balance refresh failed', [
            'channel_id' => $channelId,
            'error' => $exception->getMessage(),
        ]);
    }
    $respond(['success' => false, 'message' => $exception->getMessage()], 502);
}
