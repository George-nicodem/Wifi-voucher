-- Add bank-recipient fields to an existing Admin Wallet history table.
-- Run this in the same database used by the application after the table exists.
-- Safe to import again: each field is added only when it is missing.

SET @wallet_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admin_wallet_withdrawals' AND COLUMN_NAME = 'destination_type');
SET @wallet_column_sql = IF(@wallet_column_exists = 0, 'ALTER TABLE `admin_wallet_withdrawals` ADD COLUMN `destination_type` VARCHAR(20) NOT NULL DEFAULT ''mobile_money'' AFTER `order_reference`', 'SELECT 1');
PREPARE wallet_column_stmt FROM @wallet_column_sql;
EXECUTE wallet_column_stmt;
DEALLOCATE PREPARE wallet_column_stmt;

SET @wallet_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admin_wallet_withdrawals' AND COLUMN_NAME = 'destination_bank');
SET @wallet_column_sql = IF(@wallet_column_exists = 0, 'ALTER TABLE `admin_wallet_withdrawals` ADD COLUMN `destination_bank` VARCHAR(40) NULL AFTER `destination_type`', 'SELECT 1');
PREPARE wallet_column_stmt FROM @wallet_column_sql;
EXECUTE wallet_column_stmt;
DEALLOCATE PREPARE wallet_column_stmt;

SET @wallet_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admin_wallet_withdrawals' AND COLUMN_NAME = 'recipient_account');
SET @wallet_column_sql = IF(@wallet_column_exists = 0, 'ALTER TABLE `admin_wallet_withdrawals` ADD COLUMN `recipient_account` VARCHAR(64) NULL AFTER `destination_bank`', 'SELECT 1');
PREPARE wallet_column_stmt FROM @wallet_column_sql;
EXECUTE wallet_column_stmt;
DEALLOCATE PREPARE wallet_column_stmt;

SET @wallet_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admin_wallet_withdrawals' AND COLUMN_NAME = 'recipient_name');
SET @wallet_column_sql = IF(@wallet_column_exists = 0, 'ALTER TABLE `admin_wallet_withdrawals` ADD COLUMN `recipient_name` VARCHAR(120) NULL AFTER `recipient_account`', 'SELECT 1');
PREPARE wallet_column_stmt FROM @wallet_column_sql;
EXECUTE wallet_column_stmt;
DEALLOCATE PREPARE wallet_column_stmt;
