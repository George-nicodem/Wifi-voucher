<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../includes/clickpesa_checkout.php';
require_once __DIR__ . '/../../../includes/payment_provider_adapters.php';

function adminWalletTableReady(mysqli $db): bool
{
    $result = $db->query("SHOW TABLES LIKE 'admin_wallet_withdrawals'");
    if (!$result || $result->num_rows < 1) return false;
    $columnsResult = $db->query('SHOW COLUMNS FROM admin_wallet_withdrawals');
    if (!$columnsResult) return false;
    $columns = [];
    while ($column = $columnsResult->fetch_assoc()) $columns[(string)$column['Field']] = true;
    return count(array_diff([
        'id', 'provider_key', 'payment_channel_id', 'channel_name', 'order_reference',
        'destination_type', 'destination_bank', 'recipient_account', 'recipient_name',
        'phone_number', 'payout_amount', 'fee_amount', 'debit_amount', 'currency',
        'status', 'provider_payout_id', 'requested_by', 'requested_at', 'updated_at',
    ], array_keys($columns))) === 0;
}

function adminWalletSecurityTableReady(mysqli $db): bool
{
    $result = $db->query("SHOW TABLES LIKE 'admin_wallet_security'");
    if (!$result || $result->num_rows < 1) return false;
    $columnsResult = $db->query('SHOW COLUMNS FROM admin_wallet_security');
    if (!$columnsResult) return false;
    $columns = [];
    while ($column = $columnsResult->fetch_assoc()) $columns[(string)$column['Field']] = true;
    return count(array_diff([
        'admin_id', 'withdrawal_password_hash', 'failed_attempts', 'locked_until', 'updated_at',
    ], array_keys($columns))) === 0;
}

function adminWalletWithdrawalPasswordSet(mysqli $db, int $adminId): bool
{
    if ($adminId < 1 || !adminWalletSecurityTableReady($db)) return false;
    $stmt = $db->prepare('SELECT withdrawal_password_hash FROM admin_wallet_security WHERE admin_id = ? LIMIT 1');
    if (!$stmt) return false;
    $stmt->bind_param('i', $adminId);
    if (!$stmt->execute()) {
        $stmt->close();
        return false;
    }
    $row = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    return is_array($row) && (string)($row['withdrawal_password_hash'] ?? '') !== '';
}

function adminWalletVerifyCurrentAdminPassword(mysqli $db, int $adminId, string $password): bool
{
    if ($adminId < 1 || $password === '') return false;
    $stmt = $db->prepare("SELECT password_hash FROM admin_users WHERE id = ? AND status = 'active' LIMIT 1");
    if (!$stmt) return false;
    $stmt->bind_param('i', $adminId);
    if (!$stmt->execute()) {
        $stmt->close();
        return false;
    }
    $row = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    return is_array($row)
        && (string)($row['password_hash'] ?? '') !== ''
        && password_verify($password, (string)$row['password_hash']);
}

function adminWalletSaveWithdrawalPassword(mysqli $db, int $adminId, string $password): void
{
    if ($adminId < 1 || !adminWalletSecurityTableReady($db)) {
        throw new RuntimeException('Withdrawal PIN storage is not ready. Run admin/modules/wallet/install.sql first.');
    }
    $hash = password_hash($password, PASSWORD_DEFAULT);
    if (!is_string($hash) || $hash === '') throw new RuntimeException('Could not secure the withdrawal PIN. Try again.');
    $stmt = $db->prepare("INSERT INTO admin_wallet_security (admin_id, withdrawal_password_hash, failed_attempts, locked_until, updated_at)
        VALUES (?, ?, 0, NULL, CURRENT_TIMESTAMP)
        ON DUPLICATE KEY UPDATE withdrawal_password_hash = VALUES(withdrawal_password_hash), failed_attempts = 0, locked_until = NULL, updated_at = CURRENT_TIMESTAMP");
    if (!$stmt) throw new RuntimeException('Could not save the withdrawal PIN.');
    $stmt->bind_param('is', $adminId, $hash);
    $ok = $stmt->execute();
    $stmt->close();
    if (!$ok) throw new RuntimeException('Could not save the withdrawal PIN.');
}

function adminWalletVerifyWithdrawalPassword(mysqli $db, int $adminId, string $password): void
{
    if ($adminId < 1 || !adminWalletSecurityTableReady($db)) {
        throw new RuntimeException('Withdrawal PIN protection is not set up. Run admin/modules/wallet/install.sql first.');
    }
    $stmt = $db->prepare('SELECT withdrawal_password_hash, failed_attempts,
        TIMESTAMPDIFF(SECOND, CURRENT_TIMESTAMP, locked_until) AS lock_seconds
        FROM admin_wallet_security WHERE admin_id = ? LIMIT 1');
    if (!$stmt) throw new RuntimeException('Could not verify the withdrawal PIN.');
    $stmt->bind_param('i', $adminId);
    if (!$stmt->execute()) {
        $stmt->close();
        throw new RuntimeException('Could not verify the withdrawal PIN.');
    }
    $row = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    if (!$row || (string)($row['withdrawal_password_hash'] ?? '') === '') {
        throw new RuntimeException('Set your withdrawal PIN before sending a payout.');
    }
    $lockSeconds = (int)($row['lock_seconds'] ?? 0);
    if ($lockSeconds > 0) {
        $minutes = max(1, (int)ceil($lockSeconds / 60));
        throw new RuntimeException('Wallet PIN is temporarily locked after failed attempts. Try again in ' . $minutes . ' minute(s).');
    }
    if (!preg_match('/^\d{4}$/D', $password)
        || !password_verify($password, (string)$row['withdrawal_password_hash'])) {
        if (function_exists('logAdminSecurityEvent')) {
            logAdminSecurityEvent('ADMIN_WALLET_PIN_FAILED', 'A withdrawal PIN check failed.');
        }
        $update = $db->prepare("UPDATE admin_wallet_security
            SET failed_attempts = failed_attempts + 1,
                locked_until = CASE WHEN failed_attempts + 1 >= 5 THEN DATE_ADD(CURRENT_TIMESTAMP, INTERVAL 15 MINUTE) ELSE NULL END,
                updated_at = CURRENT_TIMESTAMP
            WHERE admin_id = ?");
        if ($update) {
            $update->bind_param('i', $adminId);
            $update->execute();
            $update->close();
        }
        throw new RuntimeException('The PIN is incorrect. Five failed attempts lock balance checks and withdrawals for 15 minutes.');
    }
    $reset = $db->prepare('UPDATE admin_wallet_security SET failed_attempts = 0, locked_until = NULL, updated_at = CURRENT_TIMESTAMP WHERE admin_id = ?');
    if ($reset) {
        $reset->bind_param('i', $adminId);
        $reset->execute();
        $reset->close();
    }
}

function adminWalletSelcomSettingsTableReady(mysqli $db): bool
{
    $result = $db->query("SHOW TABLES LIKE 'admin_wallet_selcom_settings'");
    if (!$result || $result->num_rows < 1) return false;
    $columnsResult = $db->query('SHOW COLUMNS FROM admin_wallet_selcom_settings');
    if (!$columnsResult) return false;
    $columns = [];
    while ($column = $columnsResult->fetch_assoc()) $columns[(string)$column['Field']] = true;
    return count(array_diff([
        'payment_channel_id', 'provider_key', 'vendor_enc', 'pin_enc', 'sender_account_enc',
        'sender_name_enc', 'sender_msisdn_enc', 'purpose_enc', 'created_at', 'updated_at',
    ], array_keys($columns))) === 0;
}

function adminWalletSelcomChannels(mysqli $db): array
{
    $rows = [];
    $result = $db->query("SELECT id, name, type, channel_type, environment, status, configured
        FROM payment_channels ORDER BY name ASC, id ASC");
    if (!$result) return $rows;
    while ($row = $result->fetch_assoc()) {
        if (wifiPaymentProviderKeyFromChannel($row) !== 'selcom') continue;
        $rows[] = $row;
    }
    return $rows;
}

function adminWalletSaveSelcomQwiksendSettings(mysqli $db, int $channelId, array $input): void
{
    if (!adminWalletSelcomSettingsTableReady($db)) {
        throw new RuntimeException('Run admin/modules/wallet/upgrade_selcom_qwiksend.sql before saving Selcom Qwiksend settings.');
    }
    if ($channelId < 1) throw new RuntimeException('Select a Selcom payment channel.');

    $channel = null;
    foreach (adminWalletSelcomChannels($db) as $candidate) {
        if ((int)$candidate['id'] === $channelId) {
            $channel = $candidate;
            break;
        }
    }
    if (!$channel) throw new RuntimeException('The selected channel is not a Selcom account.');

    $vendor = trim((string)($input['vendor'] ?? ''));
    $pin = trim((string)($input['pin'] ?? ''));
    $senderAccount = trim((string)($input['sender_account'] ?? ''));
    $senderName = trim((string)($input['sender_name'] ?? ''));
    $senderPhoneInput = trim((string)($input['sender_msisdn'] ?? ''));
    $senderPhone = $senderPhoneInput === '' ? '' : (adminWalletNormalizeTzPhone($senderPhoneInput) ?? '');
    $purpose = trim((string)($input['purpose'] ?? ''));
    if ($senderPhoneInput !== '' && $senderPhone === '') throw new RuntimeException('Enter a valid Tanzania phone number for the sender.');
    if (strlen($vendor) > 100 || strlen($pin) > 100 || strlen($senderAccount) > 120
        || strlen($senderName) > 120 || strlen($senderPhone) > 20 || strlen($purpose) > 250) {
        throw new RuntimeException('One or more Selcom Qwiksend values exceed the allowed length.');
    }

    $select = $db->prepare('SELECT vendor_enc, pin_enc, sender_account_enc, sender_name_enc, sender_msisdn_enc, purpose_enc
        FROM admin_wallet_selcom_settings WHERE payment_channel_id = ? LIMIT 1');
    if (!$select) throw new RuntimeException('Could not load the saved Selcom settings.');
    $select->bind_param('i', $channelId);
    if (!$select->execute()) {
        $select->close();
        throw new RuntimeException('Could not load the saved Selcom settings.');
    }
    $existing = $select->get_result()->fetch_assoc() ?: [];
    $select->close();

    $values = [
        'vendor_enc' => $vendor,
        'pin_enc' => $pin,
        'sender_account_enc' => $senderAccount,
        'sender_name_enc' => $senderName,
        'sender_msisdn_enc' => $senderPhone,
        'purpose_enc' => $purpose,
    ];
    foreach ($values as $column => $plainText) {
        $values[$column] = $plainText === '' && (string)($existing[$column] ?? '') !== ''
            ? (string)$existing[$column]
            : encryptData($plainText);
    }
    foreach (['vendor_enc', 'pin_enc', 'sender_account_enc', 'sender_name_enc', 'sender_msisdn_enc', 'purpose_enc'] as $required) {
        if (($values[$required] ?? '') === '') throw new RuntimeException('Fill all Selcom Qwiksend fields the first time you save this account.');
    }

    if ($existing) {
        $stmt = $db->prepare('UPDATE admin_wallet_selcom_settings SET provider_key = \'selcom\', vendor_enc = ?, pin_enc = ?,
            sender_account_enc = ?, sender_name_enc = ?, sender_msisdn_enc = ?, purpose_enc = ?, updated_at = CURRENT_TIMESTAMP
            WHERE payment_channel_id = ?');
        if (!$stmt) throw new RuntimeException('Could not prepare the Selcom settings update.');
        $stmt->bind_param('ssssssi', $values['vendor_enc'], $values['pin_enc'], $values['sender_account_enc'],
            $values['sender_name_enc'], $values['sender_msisdn_enc'], $values['purpose_enc'], $channelId);
    } else {
        $stmt = $db->prepare('INSERT INTO admin_wallet_selcom_settings
            (payment_channel_id, provider_key, vendor_enc, pin_enc, sender_account_enc, sender_name_enc, sender_msisdn_enc, purpose_enc)
            VALUES (?, \'selcom\', ?, ?, ?, ?, ?, ?)');
        if (!$stmt) throw new RuntimeException('Could not prepare the Selcom settings save.');
        $stmt->bind_param('issssss', $channelId, $values['vendor_enc'], $values['pin_enc'], $values['sender_account_enc'],
            $values['sender_name_enc'], $values['sender_msisdn_enc'], $values['purpose_enc']);
    }
    $ok = $stmt->execute();
    $stmt->close();
    if (!$ok) throw new RuntimeException('Could not save the Selcom Qwiksend settings.');
}

function adminWalletSelcomSettingsSaved(mysqli $db, int $channelId): bool
{
    if ($channelId < 1 || !adminWalletSelcomSettingsTableReady($db)) return false;
    $stmt = $db->prepare('SELECT 1 FROM admin_wallet_selcom_settings WHERE payment_channel_id = ? LIMIT 1');
    if (!$stmt) return false;
    $stmt->bind_param('i', $channelId);
    $ok = $stmt->execute();
    $saved = $ok && $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $saved;
}

function adminWalletProviderCatalog(): array
{
    return [
        'clickpesa' => [
            'label' => 'ClickPesa',
            'direct_payout' => true,
            'balance_api' => true,
            'destination' => 'Mobile money na benki',
            'note' => 'Balance and mobile-money or bank payouts are available through the API. Banks are loaded from ClickPesa.',
        ],
        'snippe' => [
            'label' => 'Snippe',
            'direct_payout' => true,
            'balance_api' => true,
            'destination' => 'Mobile money na benki',
            'note' => 'Balance, fees, mobile-money payouts and bank payouts are available through the API.',
        ],
        'pesapal' => [
            'label' => 'Pesapal',
            'direct_payout' => false,
            'balance_api' => false,
            'destination' => 'Bank via Pesapal dashboard',
            'note' => 'Withdrawals are made through the Pesapal merchant dashboard.',
        ],
        'zenopay' => [
            'label' => 'ZenoPay',
            'direct_payout' => false,
            'balance_api' => false,
            'destination' => 'Haijaunganishwa',
            'note' => 'The payout API is not connected to Admin Wallet yet.',
        ],
        'selcom' => [
            'label' => 'Selcom',
            'direct_payout' => false,
            'balance_api' => false,
            'destination' => 'Haijaunganishwa',
            'note' => 'Qwiksend setup can be stored securely; direct payout awaits Selcom access and confirmed fees.',
        ],
        'azampay' => [
            'label' => 'AzamPay',
            'direct_payout' => false,
            'balance_api' => false,
            'destination' => 'Haijaunganishwa',
            'note' => 'The payout API is not connected to Admin Wallet yet.',
        ],
    ];
}

function adminWalletProviderInfo(string $providerKey): array
{
    return adminWalletProviderCatalog()[$providerKey] ?? [
        'label' => 'Other aggregator',
        'direct_payout' => false,
        'balance_api' => false,
        'destination' => 'Not connected',
        'note' => 'This provider does not have a payout adapter in Admin Wallet yet.',
    ];
}

function adminWalletProviderInventory(mysqli $db): array
{
    $rows = [];
    $result = $db->query("SELECT id, name, type, channel_type, environment, status, configured
        FROM payment_channels ORDER BY name ASC, id ASC");
    if (!$result) return $rows;
    while ($row = $result->fetch_assoc()) {
        $key = wifiPaymentProviderKeyFromChannel($row);
        if ($key === '') continue;
        $info = adminWalletProviderInfo($key);
        $row['provider_key'] = $key;
        $row['provider_label'] = (string)$info['label'];
        $row['wallet_payout_supported'] = (bool)$info['direct_payout'];
        $row['wallet_balance_supported'] = (bool)$info['balance_api'];
        $row['wallet_note'] = (string)$info['note'];
        $rows[] = $row;
    }
    return $rows;
}

function adminWalletConfiguredChannels(mysqli $db): array
{
    $rows = [];
    foreach (adminWalletProviderInventory($db) as $row) {
        if (!($row['wallet_payout_supported'] ?? false)
            || strtolower(trim((string)($row['status'] ?? ''))) !== 'enabled'
            || (int)($row['configured'] ?? 0) !== 1
            || !in_array(strtolower(trim((string)($row['environment'] ?? ''))), ['live', 'production'], true)) {
            continue;
        }
        $rows[] = $row;
    }
    return $rows;
}

/**
 * Return live, verified accounts with an implemented balance API. Dashboard
 * balance cards use this capability separately from payout support so a
 * future balance-only provider can be added without changing dashboard markup.
 */
function adminWalletConfiguredBalanceChannels(mysqli $db): array
{
    $rows = [];
    foreach (adminWalletProviderInventory($db) as $row) {
        if (!($row['wallet_balance_supported'] ?? false)
            || strtolower(trim((string)($row['status'] ?? ''))) !== 'enabled'
            || (int)($row['configured'] ?? 0) !== 1
            || !in_array(strtolower(trim((string)($row['environment'] ?? ''))), ['live', 'production'], true)) {
            continue;
        }
        $rows[] = $row;
    }
    return $rows;
}

function adminWalletLoadBalanceConfig(mysqli $db, int $channelId, bool $requireEnabled = true): array
{
    // Balance access only needs a known provider and its approved API host; it
    // must not depend on that provider also implementing customer checkout.
    $config = wifiPaymentLoadChannelConfig($db, $channelId, $requireEnabled, false);
    $providerKey = (string)($config['provider_key'] ?? '');
    $providerInfo = adminWalletProviderInfo($providerKey);
    if (!($providerInfo['balance_api'] ?? false)) {
        throw new RuntimeException($providerInfo['label'] . ' does not have a balance API adapter in Admin Wallet yet.');
    }
    if (!in_array(strtolower(trim((string)($config['environment'] ?? ''))), ['live', 'production'], true)) {
        throw new RuntimeException('Balance checks are available only on a live payment channel.');
    }
    $parts = parse_url((string)$config['api_base_url']);
    $host = strtolower((string)($parts['host'] ?? ''));
    $path = rtrim((string)($parts['path'] ?? ''), '/');
    if ($providerKey === 'clickpesa') {
        if (($config['client_id'] ?? '') === '' || ($config['api_key'] ?? '') === '' || ($config['checksum_key'] ?? '') === '') {
            throw new RuntimeException('ClickPesa requires a Client ID, API Key and Checksum Security Key in Payment Channels.');
        }
        if ($host !== 'api.clickpesa.com' || !in_array($path, ['', '/third-parties'], true)) {
            throw new RuntimeException('Set the ClickPesa API Base URL to https://api.clickpesa.com/third-parties.');
        }
        $config['api_base_url'] = 'https://api.clickpesa.com/third-parties';
    } elseif ($providerKey === 'snippe') {
        if (($config['api_key'] ?? '') === '') {
            throw new RuntimeException('Snippe requires an API key with collection:read scope.');
        }
        if ($host !== 'api.snippe.sh' || !in_array($path, ['', '/'], true)) {
            throw new RuntimeException('Set the Snippe API Base URL to https://api.snippe.sh.');
        }
        $config['api_base_url'] = 'https://api.snippe.sh';
    } else {
        throw new RuntimeException($providerInfo['label'] . ' has no balance request adapter configured yet.');
    }
    return $config;
}

function adminWalletLoadPayoutConfig(mysqli $db, int $channelId, bool $requireEnabled = true): array
{
    $config = wifiPaymentLoadChannelConfig($db, $channelId, $requireEnabled);
    $providerKey = (string)($config['provider_key'] ?? '');
    $providerInfo = adminWalletProviderInfo($providerKey);
    if (!($providerInfo['direct_payout'] ?? false)) {
        throw new RuntimeException($providerInfo['label'] . ' does not have a direct-payout adapter in Admin Wallet yet.');
    }
    if (!in_array(strtolower(trim((string)($config['environment'] ?? ''))), ['live', 'production'], true)) {
        throw new RuntimeException('Live payouts are available only on a live payment channel.');
    }
    $parts = parse_url((string)$config['api_base_url']);
    $host = strtolower((string)($parts['host'] ?? ''));
    $path = rtrim((string)($parts['path'] ?? ''), '/');
    if ($providerKey === 'clickpesa') {
        if (($config['client_id'] ?? '') === '' || ($config['api_key'] ?? '') === '' || ($config['checksum_key'] ?? '') === '') {
            throw new RuntimeException('ClickPesa requires a Client ID, API Key and Checksum Security Key in Payment Channels.');
        }
        if ($host !== 'api.clickpesa.com' || !in_array($path, ['', '/third-parties'], true)) {
            throw new RuntimeException('Set the ClickPesa API Base URL to https://api.clickpesa.com/third-parties.');
        }
        $config['api_base_url'] = 'https://api.clickpesa.com/third-parties';
    } elseif ($providerKey === 'snippe') {
        if (($config['api_key'] ?? '') === '') {
            throw new RuntimeException('Snippe requires an API key with collection:read, disbursement:read and disbursement:create scopes.');
        }
        if ($host !== 'api.snippe.sh') {
            throw new RuntimeException('Set the Snippe API Base URL to https://api.snippe.sh.');
        }
        $config['api_base_url'] = 'https://api.snippe.sh';
    } else {
        throw new RuntimeException('This provider’s payout adapter is not available yet.');
    }
    return $config;
}

function adminWalletAcquireChannelLock(mysqli $db, int $channelId, string $providerKey): bool
{
    $lockName = 'wifi_admin_wallet_' . preg_replace('/[^a-z0-9_]/i', '', $providerKey) . '_' . $channelId;
    $stmt = $db->prepare('SELECT GET_LOCK(?, 0) AS acquired');
    if (!$stmt) throw new RuntimeException('Unable to lock another withdrawal request for a short time.');
    $stmt->bind_param('s', $lockName);
    $ok = $stmt->execute();
    $row = $ok ? ($stmt->get_result()->fetch_assoc() ?: []) : [];
    $stmt->close();
    if (!$ok) throw new RuntimeException('Unable to lock another withdrawal request for a short time.');
    return (int)($row['acquired'] ?? 0) === 1;
}

function adminWalletReleaseChannelLock(mysqli $db, int $channelId, string $providerKey): void
{
    $lockName = 'wifi_admin_wallet_' . preg_replace('/[^a-z0-9_]/i', '', $providerKey) . '_' . $channelId;
    $stmt = $db->prepare('SELECT RELEASE_LOCK(?)');
    if (!$stmt) return;
    $stmt->bind_param('s', $lockName);
    $stmt->execute();
    $stmt->close();
}

function adminWalletApiRequest(array $config, string $path, string $method, ?array $payload = null, array $extraHeaders = []): array
{
    $attempt = 0;
    while (true) {
        try {
            if (($config['provider_key'] ?? '') === 'clickpesa') {
                $token = wifiCpToken($config);
                return wifiCpRequest($path, $method, $payload, array_merge(['Authorization: ' . $token], $extraHeaders), (string)$config['api_base_url']);
            }
            if (($config['provider_key'] ?? '') === 'snippe') {
                $result = wifiPaymentHttpJson(
                    rtrim((string)$config['api_base_url'], '/') . $path,
                    $method,
                    $payload,
                    array_merge(['Authorization: Bearer ' . (string)$config['api_key']], $extraHeaders)
                );
                return $result['json'];
            }
            throw new RuntimeException('This provider does not have a wallet API adapter.');
        } catch (RuntimeException $exception) {
            $isRetryableRead = strtoupper($method) === 'GET'
                && $attempt === 0
                && preg_match('/HTTP (?:502|503|504)\b/', $exception->getMessage());
            if (!$isRetryableRead) throw $exception;
            // Retry only idempotent reads. Never retry payout submissions.
            $attempt++;
            usleep(700000);
        }
    }
}

function adminWalletResponseData(array $response): array
{
    if (isset($response['data']) && is_array($response['data'])) {
        $data = $response['data'];
        if (array_is_list($data) && isset($data[0]) && is_array($data[0])) return $data[0];
        return $data;
    }
    if (array_is_list($response) && isset($response[0]) && is_array($response[0])) return $response[0];
    return $response;
}

function adminWalletGetBalance(array $config): array
{
    if (($config['provider_key'] ?? '') === 'clickpesa') {
        $response = adminWalletApiRequest($config, '/account/balance', 'GET');
        $rows = [];
        $collectRows = static function (array $node, int $depth = 0) use (&$collectRows, &$rows): void {
            if ($depth > 8) return;
            if (array_key_exists('currency', $node) && array_key_exists('balance', $node)) {
                $rows[] = $node;
                return;
            }
            foreach ($node as $value) {
                if (is_array($value)) $collectRows($value, $depth + 1);
            }
        };
        $collectRows($response);
        foreach ($rows as $row) {
            $currency = strtoupper(trim((string)($row['currency'] ?? '')));
            if ($currency === 'TZS' && is_numeric($row['balance'] ?? null)) {
                return ['currency' => $currency, 'balance' => (float)$row['balance']];
            }
        }

        $currencies = [];
        $collectCurrencies = static function (array $node, int $depth = 0) use (&$collectCurrencies, &$currencies): void {
            if ($depth > 8) return;
            if (isset($node['currency']) && is_scalar($node['currency'])) {
                $currency = strtoupper(trim((string)$node['currency']));
                if ($currency !== '') $currencies[] = $currency;
            }
            foreach ($node as $value) {
                if (is_array($value)) $collectCurrencies($value, $depth + 1);
            }
        };
        $collectCurrencies($response);
        if (function_exists('appLog')) {
            appLog('ClickPesa balance response did not include a TZS balance', [
                'top_level_keys' => array_slice(array_map('strval', array_keys($response)), 0, 20),
                'currency_values' => array_values(array_unique($currencies)),
            ]);
        }
        throw new RuntimeException('ClickPesa returned a successful response, but it did not contain a numeric TZS balance in a recognized format.');
    }
    if (($config['provider_key'] ?? '') === 'snippe') {
        $response = adminWalletApiRequest($config, '/v1/payments/balance', 'GET');
        $data = adminWalletResponseData($response);
        $currency = strtoupper((string)($data['available']['currency'] ?? $data['balance']['currency'] ?? ''));
        $balance = $data['available']['value'] ?? $data['balance']['value'] ?? null;
        if ($currency !== 'TZS' || !is_numeric($balance)) throw new RuntimeException('Snippe did not return a readable TZS balance.');
        return ['currency' => $currency, 'balance' => (float)$balance];
    }
    throw new RuntimeException('This provider does not have a connected balance lookup API.');
}

function adminWalletGetClickPesaStatement(array $config, string $currency, string $startDate, string $endDate): array
{
    if (($config['provider_key'] ?? '') !== 'clickpesa') {
        throw new RuntimeException('Account statements are currently available for ClickPesa only.');
    }

    $currency = strtoupper(trim($currency));
    if (!in_array($currency, ['TZS', 'USD'], true)) {
        throw new RuntimeException('Select TZS or USD for the ClickPesa statement.');
    }

    $query = ['currency' => $currency];
    if ($startDate !== '') $query['startDate'] = $startDate;
    if ($endDate !== '') $query['endDate'] = $endDate;

    $path = '/account/statement?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    $response = adminWalletApiRequest($config, $path, 'GET');
    $statement = adminWalletResponseData($response);
    $accountDetails = $statement['accountDetails'] ?? null;
    $transactions = $statement['transactions'] ?? null;

    if (!is_array($accountDetails) || !is_array($transactions)) {
        throw new RuntimeException('ClickPesa returned an unreadable account statement.');
    }

    return [
        'accountDetails' => $accountDetails,
        'transactions' => array_values(array_filter($transactions, 'is_array')),
    ];
}

function adminWalletNormalizeTzPhone(string $input): ?string
{
    return wifiCpNormalizePhone($input);
}

function adminWalletSnippeBanks(): array
{
    return [
        'ABSA' => 'ABSA Bank Tanzania', 'ACCESS' => 'AccessBank Tanzania', 'AKIBA' => 'Akiba Commercial Bank',
        'AMANA' => 'Amana Bank', 'AZANIA' => 'Azania Bank', 'BANCABC' => 'Bank ABC',
        'BARODA' => 'Bank of Baroda', 'BOA' => 'Bank of Africa', 'BOI' => 'Bank of India',
        'CANARA' => 'Canara Bank', 'CITI' => 'Citibank Tanzania', 'CRDB' => 'CRDB Bank',
        'DASHENG' => 'China Dasheng Bank', 'DCB' => 'Dar es Salaam Community Bank',
        'DTB' => 'Diamond Trust Bank', 'ECOBANK' => 'Ecobank Tanzania', 'EQUITY' => 'Equity Bank',
        'EXIM' => 'Exim Bank', 'FNB' => 'First National Bank', 'GT BANK' => 'Guaranty Trust Bank',
        'HABIB' => 'Habib African Bank', 'ICB' => 'International Commercial Bank', 'IMBANK' => 'I&M Bank',
        'KCB' => 'KCB Bank', 'KILIMANJARO' => 'Kilimanjaro Cooperative Bank', 'MAENDELEO' => 'Maendeleo Bank',
        'MKOMBOZI' => 'Mkombozi Commercial Bank', 'MWALIMU' => 'Mwalimu Commercial Bank',
        'MWANGA' => 'Mwanga Hakika Microfinance Bank', 'NBC' => 'NBC', 'NCBA' => 'NCBA Bank',
        'NMB' => 'NMB Bank', 'PBZ' => 'People’s Bank of Zanzibar', 'SCB' => 'Standard Chartered Bank',
        'SELCOMPESA' => 'Selcom Pesa Bank', 'STANBIC' => 'Stanbic Bank',
        'TCB' => 'Tanzania Commercial Bank', 'UBA' => 'United Bank for Africa',
        'UCHUMI' => 'Uchumi Commercial Bank', 'YETU' => 'Yetu Microfinance Bank',
    ];
}

function adminWalletClickPesaBanks(array $config): array
{
    if (($config['provider_key'] ?? '') !== 'clickpesa') {
        throw new RuntimeException('Select a ClickPesa account to load its supported banks.');
    }
    $response = adminWalletApiRequest($config, '/list/banks', 'GET');
    $rows = $response['data'] ?? $response['banks'] ?? $response;
    if (is_array($rows) && !array_is_list($rows)) {
        $rows = $rows['banks'] ?? $rows['data'] ?? [];
    }
    if (!is_array($rows) || !array_is_list($rows)) {
        throw new RuntimeException('ClickPesa returned an unreadable bank list.');
    }

    $banks = [];
    foreach ($rows as $row) {
        if (!is_array($row)) continue;
        $bic = strtoupper(trim((string)($row['bic'] ?? '')));
        $name = trim((string)($row['name'] ?? ''));
        if ($bic === '' || $name === '' || !preg_match('/^[A-Z0-9 ._-]{2,40}$/D', $bic)) continue;
        $banks[$bic] = $name;
    }
    if (!$banks) throw new RuntimeException('ClickPesa returned no usable banks. Check that bank payouts are enabled for this account.');
    asort($banks, SORT_NATURAL | SORT_FLAG_CASE);
    return $banks;
}

function adminWalletBanksForProvider(array $config): array
{
    return match ((string)($config['provider_key'] ?? '')) {
        'clickpesa' => adminWalletClickPesaBanks($config),
        'snippe' => adminWalletSnippeBanks(),
        default => [],
    };
}

function adminWalletMaskAccountNumber(string $account): string
{
    $account = trim($account);
    if ($account === '') return '—';
    $visible = substr($account, -4);
    return str_repeat('•', max(4, strlen($account) - strlen($visible))) . $visible;
}

function adminWalletCreatePayoutPayload(array $config, float $amount, string $phone, string $reference): array
{
    $payload = [
        'amount' => round($amount, 2),
        'phoneNumber' => $phone,
        'currency' => 'TZS',
        'orderReference' => $reference,
    ];
    return wifiCpSignPayload($payload, (string)$config['checksum_key']);
}

function adminWalletPreviewPayout(array $config, float $amount, array $destination, string $reference): array
{
    if (($config['provider_key'] ?? '') === 'clickpesa') {
        if (($destination['type'] ?? '') === 'bank') {
            $payload = wifiCpSignPayload([
                'amount' => round($amount, 2),
                'accountNumber' => (string)$destination['account'],
                'orderReference' => $reference,
                'bic' => (string)$destination['bank_code'],
                'accountCurrency' => 'TZS',
            ], (string)$config['checksum_key']);
            $response = adminWalletApiRequest($config, '/payouts/preview-bank-payout', 'POST', $payload);
            return adminWalletResponseData($response);
        }
        $payload = adminWalletCreatePayoutPayload($config, $amount, (string)$destination['phone'], $reference);
        $response = adminWalletApiRequest($config, '/payouts/preview-mobile-money-payout', 'POST', $payload);
        return adminWalletResponseData($response);
    }
    if (($config['provider_key'] ?? '') === 'snippe') {
        if ((int)$amount !== $amount) throw new RuntimeException('Snippe payouts require a whole-number amount in TZS.');
        $feeResponse = adminWalletApiRequest($config, '/v1/payouts/fee?amount=' . rawurlencode((string)(int)$amount), 'GET');
        $feeData = adminWalletResponseData($feeResponse);
        $balanceData = adminWalletGetBalance($config);
        $fee = $feeData['fee_amount'] ?? null;
        $debit = $feeData['total_amount'] ?? null;
        if (!is_numeric($fee) || !is_numeric($debit)) throw new RuntimeException('Snippe did not return the fee and total debit amount.');
        return ['fee' => (float)$fee, 'amount' => (float)$debit, 'balance' => (float)$balanceData['balance']];
    }
    throw new RuntimeException('Payout preview is not connected for this provider.');
}

function adminWalletCreatePayout(array $config, float $amount, array $destination, string $reference): array
{
    if (($config['provider_key'] ?? '') === 'clickpesa') {
        if (($destination['type'] ?? '') === 'bank') {
            $payload = wifiCpSignPayload([
                'amount' => round($amount, 2),
                'accountNumber' => (string)$destination['account'],
                'accountName' => (string)$destination['recipient_name'],
                'orderReference' => $reference,
                'bic' => (string)$destination['bank_code'],
                'accountCurrency' => 'TZS',
            ], (string)$config['checksum_key']);
            $response = adminWalletApiRequest($config, '/payouts/create-bank-payout', 'POST', $payload);
            return adminWalletResponseData($response);
        }
        $payload = adminWalletCreatePayoutPayload($config, $amount, (string)$destination['phone'], $reference);
        $response = adminWalletApiRequest($config, '/payouts/create-mobile-money-payout', 'POST', $payload);
        return adminWalletResponseData($response);
    }
    if (($config['provider_key'] ?? '') === 'snippe') {
        $idempotencyKey = substr(preg_replace('/[^A-Za-z0-9_-]/', '', $reference) ?? '', 0, 30);
        $response = adminWalletApiRequest($config, '/v1/payouts/send', 'POST', [
            'amount' => (int)$amount,
            'channel' => ($destination['type'] ?? '') === 'bank' ? 'bank' : 'mobile',
            'recipient_name' => (string)$destination['recipient_name'],
            'narration' => 'Admin wallet withdrawal ' . $reference,
            'metadata' => ['order_reference' => $reference],
        ] + (($destination['type'] ?? '') === 'bank'
            ? ['recipient_bank' => (string)$destination['bank_code'], 'recipient_account' => (string)$destination['account']]
            : ['recipient_phone' => (string)$destination['phone']]), ['Idempotency-Key: ' . $idempotencyKey]);
        return adminWalletResponseData($response);
    }
    throw new RuntimeException('Payouts are not connected for this provider.');
}

function adminWalletFetchPayoutStatus(array $config, string $reference): array
{
    $path = ($config['provider_key'] ?? '') === 'snippe'
        ? '/v1/payouts/' . rawurlencode($reference)
        : '/payouts/' . rawurlencode($reference);
    $response = adminWalletApiRequest($config, $path, 'GET');
    return adminWalletResponseData($response);
}

function adminWalletSaveRequestedPayout(mysqli $db, array $preview, int $adminId): void
{
    $stmt = $db->prepare("INSERT INTO admin_wallet_withdrawals
        (provider_key, payment_channel_id, channel_name, order_reference, destination_type,
         destination_bank, recipient_account, recipient_name, phone_number,
         payout_amount, fee_amount, debit_amount, currency, status, requested_by)
        VALUES (?, ?, ?, ?, ?, NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), ?, ?, ?, ?, 'TZS', 'PROCESSING', ?)");
    if (!$stmt) throw new RuntimeException('Unable to save the withdrawal request before sending it.');
    $providerKey = (string)$preview['provider_key'];
    $channelId = (int)$preview['channel_id'];
    $channelName = (string)$preview['channel_name'];
    $reference = (string)$preview['order_reference'];
    $destinationType = (string)$preview['destination_type'];
    $destinationBank = (string)($preview['destination_bank'] ?? '');
    $recipientAccount = (string)($preview['recipient_account'] ?? '');
    $recipientName = (string)($preview['recipient_name'] ?? '');
    $phone = (string)($preview['phone_number'] ?? '');
    $amount = (float)$preview['payout_amount'];
    $fee = (float)$preview['fee_amount'];
    $debit = (float)$preview['debit_amount'];
    $stmt->bind_param('sisssssssdddi', $providerKey, $channelId, $channelName, $reference,
        $destinationType, $destinationBank, $recipientAccount, $recipientName, $phone,
        $amount, $fee, $debit, $adminId);
    $ok = $stmt->execute();
    $stmt->close();
    if (!$ok) throw new RuntimeException('The withdrawal was not sent because its record could not be saved.');
}

function adminWalletUpdatePayout(mysqli $db, string $reference, array $providerResult, string $fallbackStatus = 'UNKNOWN'): void
{
    $status = strtoupper(trim((string)($providerResult['status'] ?? '')));
    $status = match ($status) {
        'COMPLETED', 'SUCCESSFUL' => 'SUCCESS',
        'REJECTED' => 'FAILED',
        default => $status,
    };
    if (!preg_match('/^[A-Z_]{1,24}$/D', $status)) $status = $fallbackStatus;
    $feeValue = $providerResult['fee'] ?? $providerResult['fee_amount'] ?? $providerResult['fees']['value'] ?? null;
    $fee = is_numeric($feeValue) ? (float)$feeValue : null;
    $debitValue = $providerResult['debit_amount'] ?? $providerResult['total_amount'] ?? $providerResult['total']['value'] ?? null;
    if (!is_numeric($debitValue) && is_numeric($providerResult['amount'] ?? null) && $fee !== null) {
        $debitValue = (float)$providerResult['amount'] + $fee;
    }
    $debit = is_numeric($debitValue) ? (float)$debitValue : null;
    $providerId = trim((string)($providerResult['reference'] ?? $providerResult['id'] ?? $providerResult['external_reference'] ?? ''));
    $stmt = $db->prepare("UPDATE admin_wallet_withdrawals SET status = ?,
        fee_amount = COALESCE(?, fee_amount), debit_amount = COALESCE(?, debit_amount),
        provider_payout_id = COALESCE(NULLIF(?, ''), provider_payout_id), updated_at = NOW()
        WHERE order_reference = ? LIMIT 1");
    if (!$stmt) throw new RuntimeException('The withdrawal status was received, but it could not be saved.');
    $stmt->bind_param('sddss', $status, $fee, $debit, $providerId, $reference);
    $ok = $stmt->execute();
    $stmt->close();
    if (!$ok) throw new RuntimeException('The withdrawal status could not be saved to the history.');
}

function adminWalletStatusLabel(string $status): string
{
    return match (strtoupper($status)) {
        'SUCCESS', 'COMPLETED', 'SUCCESSFUL' => 'Completed',
        'AUTHORIZED' => 'Authorized · pending',
        'PROCESSING' => 'Processing',
        'PENDING' => 'Pending',
        'REVERSED' => 'Reversed',
        'FAILED' => 'Failed',
        'UNKNOWN' => 'Check status',
        default => ucfirst(strtolower($status)),
    };
}

function adminWalletStatusClass(string $status): string
{
    return match (strtoupper($status)) {
        'SUCCESS', 'COMPLETED', 'SUCCESSFUL' => 'wallet-status-success',
        'FAILED', 'REVERSED' => 'wallet-status-failed',
        'AUTHORIZED', 'PROCESSING', 'PENDING', 'UNKNOWN' => 'wallet-status-pending',
        default => 'wallet-status-unknown',
    };
}
