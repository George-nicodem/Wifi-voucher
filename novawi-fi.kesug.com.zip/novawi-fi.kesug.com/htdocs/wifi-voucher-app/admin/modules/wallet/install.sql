-- Admin wallet payout history. This is separate from any existing withdrawals table.
-- Safe to run repeatedly; it does not alter or delete existing tables or records.
CREATE TABLE IF NOT EXISTS admin_wallet_withdrawals (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    provider_key VARCHAR(40) NOT NULL DEFAULT 'clickpesa',
    payment_channel_id INT(11) NOT NULL,
    channel_name VARCHAR(120) NOT NULL,
    order_reference VARCHAR(80) NOT NULL,
    destination_type VARCHAR(20) NOT NULL DEFAULT 'mobile_money',
    destination_bank VARCHAR(40) NULL,
    recipient_account VARCHAR(64) NULL,
    recipient_name VARCHAR(120) NULL,
    phone_number VARCHAR(20) NOT NULL,
    payout_amount DECIMAL(12,2) NOT NULL,
    fee_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    debit_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    currency CHAR(3) NOT NULL DEFAULT 'TZS',
    status VARCHAR(24) NOT NULL DEFAULT 'PROCESSING',
    provider_payout_id VARCHAR(100) NULL,
    requested_by INT(11) NULL,
    requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_admin_wallet_order_reference (order_reference),
    KEY idx_admin_wallet_requested_at (requested_at),
    KEY idx_admin_wallet_status (status),
    KEY idx_admin_wallet_channel (payment_channel_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Separate per-admin password gate for every live withdrawal.
-- Passwords are stored as PHP password_hash() output, never as plain text.
CREATE TABLE IF NOT EXISTS admin_wallet_security (
    admin_id INT(11) NOT NULL,
    withdrawal_password_hash VARCHAR(255) NOT NULL,
    failed_attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    locked_until DATETIME NULL DEFAULT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (admin_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
