-- Selcom Qwiksend setup fields for Admin Wallet.
-- Safe to run again. This creates a separate table and leaves existing records unchanged.
-- Run against the same database configured in the application's .env file.

CREATE TABLE IF NOT EXISTS admin_wallet_selcom_settings (
    payment_channel_id INT(11) NOT NULL,
    provider_key VARCHAR(40) NOT NULL DEFAULT 'selcom',
    vendor_enc MEDIUMTEXT NOT NULL,
    pin_enc MEDIUMTEXT NOT NULL,
    sender_account_enc MEDIUMTEXT NOT NULL,
    sender_name_enc MEDIUMTEXT NOT NULL,
    sender_msisdn_enc MEDIUMTEXT NOT NULL,
    purpose_enc MEDIUMTEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (payment_channel_id),
    KEY idx_admin_wallet_selcom_provider (provider_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
