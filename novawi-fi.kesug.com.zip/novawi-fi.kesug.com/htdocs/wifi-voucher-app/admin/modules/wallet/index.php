<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';
requireAdminRole(['admin', 'super_admin', 'superadmin']);

global $conn;
$cssUrl = appUrl('admin/modules/wallet/wallet.css?v=8');
echo '<link rel="stylesheet" href="' . e($cssUrl) . '">';

$channels = adminWalletConfiguredChannels($conn);
$errors = [];
$success = '';
$balance = null;
$balanceChannelId = 0;
$balanceProviderKey = '';
$balanceCheckedAt = 0;
$statement = null;
$statementChannelId = 0;
$statementCurrency = 'TZS';
$statementStartDate = date('Y-m-01');
$statementEndDate = date('Y-m-d');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    requireAdminPostWithCsrf();
    $action = trim((string)($_POST['wallet_action'] ?? ''));
    try {
        if ($action === 'refresh_balance') {
            $balanceChannelId = filter_var($_POST['channel_id'] ?? null, FILTER_VALIDATE_INT) ?: 0;
            if ($balanceChannelId < 1) throw new RuntimeException('Choose a payment account.');
            $config = adminWalletLoadPayoutConfig($conn, $balanceChannelId);
            $balanceProviderKey = (string)$config['provider_key'];
            $balance = adminWalletGetBalance($config);
            $balanceCheckedAt = time();
            $_SESSION['admin_wallet_balance_' . $balanceChannelId] = [
                'balance' => $balance['balance'],
                'currency' => $balance['currency'],
                'provider_key' => $balanceProviderKey,
                'checked_at' => $balanceCheckedAt,
            ];
        } elseif ($action === 'retrieve_statement') {
            $statementChannelId = filter_var($_POST['statement_channel_id'] ?? null, FILTER_VALIDATE_INT) ?: 0;
            $statementCurrency = strtoupper(trim((string)($_POST['statement_currency'] ?? 'TZS')));
            $statementStartDate = trim((string)($_POST['statement_start_date'] ?? ''));
            $statementEndDate = trim((string)($_POST['statement_end_date'] ?? ''));
            $startDate = DateTimeImmutable::createFromFormat('!Y-m-d', $statementStartDate);
            $endDate = DateTimeImmutable::createFromFormat('!Y-m-d', $statementEndDate);
            if (!$startDate || $startDate->format('Y-m-d') !== $statementStartDate
                || !$endDate || $endDate->format('Y-m-d') !== $statementEndDate) {
                throw new RuntimeException('Enter a valid start date and end date.');
            }
            if ($startDate > $endDate) throw new RuntimeException('The start date must be on or before the end date.');
            if (!in_array($statementCurrency, ['TZS', 'USD'], true)) throw new RuntimeException('Select TZS or USD for the statement.');
            $config = adminWalletLoadPayoutConfig($conn, $statementChannelId);
            if ((string)$config['provider_key'] !== 'clickpesa') throw new RuntimeException('Select a ClickPesa account to retrieve its statement.');
            $statement = adminWalletGetClickPesaStatement($config, $statementCurrency, $statementStartDate, $statementEndDate);
            logAdminSecurityEvent('ADMIN_WALLET_STATEMENT_RETRIEVED', 'Retrieved a ClickPesa account statement for channel ' . $statementChannelId . ' (' . $statementCurrency . ').');
            $success = 'ClickPesa account statement retrieved.';
        } else {
            throw new RuntimeException('This wallet page supports balance and account statement viewing only.');
        }
    } catch (Throwable $exception) {
        $errors[] = $exception->getMessage();
    }
}
$selectedChannelId = $balanceChannelId;
if ($selectedChannelId === 0 && $channels) $selectedChannelId = (int)$channels[0]['id'];
$selectedProviderKey = '';
foreach ($channels as $channel) {
    if ((int)$channel['id'] === $selectedChannelId) {
        $selectedProviderKey = (string)$channel['provider_key'];
        break;
    }
}
$selectedProviderLabel = (string)adminWalletProviderInfo($selectedProviderKey)['label'];
$balanceCache = $_SESSION['admin_wallet_balance_' . $selectedChannelId] ?? null;
if ($balance === null && is_array($balanceCache)
    && is_numeric($balanceCache['balance'] ?? null)
    && is_string($balanceCache['currency'] ?? null)) {
    $balance = [
        'balance' => (float)$balanceCache['balance'],
        'currency' => strtoupper((string)$balanceCache['currency']),
    ];
    $balanceProviderKey = (string)($balanceCache['provider_key'] ?? $selectedProviderKey);
    $balanceCheckedAt = (int)($balanceCache['checked_at'] ?? 0);
}
$clickpesaChannels = array_values(array_filter($channels, static fn(array $channel): bool => (string)($channel['provider_key'] ?? '') === 'clickpesa'));
if ($statementChannelId < 1 && $clickpesaChannels) $statementChannelId = (int)$clickpesaChannels[0]['id'];

?>

<main class="admin-wallet-page">
    <header class="wallet-header">
        <div class="wallet-title-wrap">
            <div class="wallet-title-icon"><i class="fa-solid fa-wallet"></i></div>
            <div><span class="wallet-eyebrow">BUSINESS OPERATIONS</span><h1>Admin Wallet</h1>
                <p>View live account balances and provider statements.</p></div>
        </div>
        <a class="wallet-back" href="<?= e(appUrl('admin/dashboard.php?page=dashboard')) ?>"><i class="fa-solid fa-arrow-left"></i> Dashboard</a>
    </header>

    <?php foreach ($errors as $error): ?><div class="wallet-alert wallet-alert-error" role="alert"><i class="fa-solid fa-circle-exclamation"></i><span><?= e($error) ?></span></div><?php endforeach; ?>
    <?php if ($success !== ''): ?><div class="wallet-alert wallet-alert-success" role="status"><i class="fa-solid fa-circle-check"></i><span><?= e($success) ?></span></div><?php endif; ?>

    <div class="wallet-note"><i class="fa-solid fa-circle-info"></i><p>Account balances and statements come directly from the connected payment provider. They are separate from voucher sales.</p></div>

    <?php if (!$channels): ?>
        <section class="wallet-setup-card"><span><i class="fa-solid fa-plug-circle-exclamation"></i></span><div><h2>No provider account is connected</h2><p>Connect a payment provider that supports account balance checks to view your wallet balance.</p><a href="<?= e(appUrl('admin/dashboard.php?page=payment_channels')) ?>">Open Payment Channels <i class="fa-solid fa-arrow-right"></i></a></div></section>
    <?php else: ?>
        <section class="wallet-balance-card" id="wallet-balance-card" data-wallet-balance-widget data-endpoint="<?= e(appUrl('admin/modules/wallet/balance.php')) ?>" data-form-id="wallet-refresh-form" data-checked-at="<?= (int)$balanceCheckedAt ?>" data-has-balance="<?= $balance !== null ? '1' : '0' ?>">
            <div class="wallet-balance-mark"><i class="fa-solid fa-building-columns"></i></div>
            <div class="wallet-balance-copy"><span><?= e($balanceProviderKey !== '' ? adminWalletProviderInfo($balanceProviderKey)['label'] : $selectedProviderLabel) ?> balance</span>
                <?php if ($balance !== null): ?><strong class="js-wallet-balance-value"><?= number_format($balance['balance'], 2) ?> <small><?= e($balance['currency']) ?></small></strong><p class="js-wallet-balance-status" role="status" aria-live="polite"><?= $balanceCheckedAt > 0 ? 'Last updated ' . e(date('M j, Y, g:i A', $balanceCheckedAt)) : 'Loading the latest balance…' ?></p>
                <?php else: ?><strong class="wallet-balance-placeholder js-wallet-balance-value">Loading…</strong><p class="js-wallet-balance-status" role="status" aria-live="polite">Loading the latest balance automatically.</p><?php endif; ?>
                <small class="wallet-balance-auto-note">Automatically refreshes every 5 minutes while this page is open.</small>
            </div>
            <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=wallet')) ?>" class="wallet-refresh-form" id="wallet-refresh-form">
                <?= csrfField() ?><input type="hidden" name="wallet_action" value="refresh_balance">
                <label for="wallet-balance-channel">Payment account</label>
                <select id="wallet-balance-channel" name="channel_id" required><?php foreach ($channels as $channel): ?><option value="<?= (int)$channel['id'] ?>" <?= $selectedChannelId === (int)$channel['id'] ? 'selected' : '' ?>><?= e((string)$channel['provider_label']) ?> · <?= e((string)$channel['name']) ?></option><?php endforeach; ?></select>
                <button class="wallet-button wallet-button-light" type="submit"><i class="fa-solid fa-rotate"></i> Check balance</button>
            </form>
        </section>

        <?php if ($clickpesaChannels): ?>
            <section class="wallet-statement-card">
                <header class="wallet-statement-heading"><span><i class="fa-solid fa-file-invoice-dollar"></i></span><div><h2>ClickPesa account statement</h2><p>Read-only transactions and account totals from ClickPesa.</p></div></header>
                <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=wallet')) ?>" class="wallet-statement-form" autocomplete="off">
                    <?= csrfField() ?><input type="hidden" name="wallet_action" value="retrieve_statement">
                    <div><label for="statement-channel">ClickPesa account</label><select id="statement-channel" name="statement_channel_id" required><?php foreach ($clickpesaChannels as $channel): ?><option value="<?= (int)$channel['id'] ?>" <?= $statementChannelId === (int)$channel['id'] ? 'selected' : '' ?>><?= e((string)$channel['name']) ?></option><?php endforeach; ?></select></div>
                    <div><label for="statement-currency">Currency</label><select id="statement-currency" name="statement_currency"><option value="TZS" <?= $statementCurrency === 'TZS' ? 'selected' : '' ?>>TZS</option><option value="USD" <?= $statementCurrency === 'USD' ? 'selected' : '' ?>>USD</option></select></div>
                    <div><label for="statement-start-date">Start date</label><input id="statement-start-date" name="statement_start_date" type="date" value="<?= e($statementStartDate) ?>" required></div>
                    <div><label for="statement-end-date">End date</label><input id="statement-end-date" name="statement_end_date" type="date" value="<?= e($statementEndDate) ?>" required></div>
                    <div class="wallet-statement-submit"><button class="wallet-button wallet-button-primary" type="submit"><i class="fa-solid fa-magnifying-glass-chart"></i> Retrieve statement</button></div>
                </form>

                <?php if ($statement !== null): ?>
                    <?php
                    $statementDetails = $statement['accountDetails'];
                    $statementRows = $statement['transactions'];
                    $detailsCurrency = strtoupper((string)($statementDetails['currency'] ?? $statementCurrency));
                    ?>
                    <div class="wallet-statement-summary">
                        <?php foreach ([
                            'Opening balance' => 'openingBalance',
                            'Closing balance' => 'closingBalance',
                            'Total credits' => 'totalCredits',
                            'Total debits' => 'totalDebits',
                        ] as $label => $key): ?>
                            <div><span><?= e($label) ?></span><strong><?= is_numeric($statementDetails[$key] ?? null) ? number_format((float)$statementDetails[$key], 2) . ' ' . e($detailsCurrency) : '—' ?></strong></div>
                        <?php endforeach; ?>
                    </div>
                    <div class="wallet-statement-table-wrap">
                        <?php if ($statementRows): ?>
                            <table class="wallet-statement-table"><thead><tr><th>Date</th><th>Type</th><th>Entry</th><th>Description</th><th>Reference</th><th>Amount</th><th>Balance</th></tr></thead><tbody>
                                <?php foreach ($statementRows as $transaction): ?>
                                    <?php
                                    $transactionCurrency = strtoupper((string)($transaction['currency'] ?? $detailsCurrency));
                                    $transactionAmount = $transaction['amount'] ?? null;
                                    $transactionBalance = $transaction['balance'] ?? null;
                                    ?>
                                    <tr><td><?= e((string)($transaction['date'] ?? '—')) ?></td><td><?= e((string)($transaction['type'] ?? '—')) ?></td><td><?= e((string)($transaction['entry'] ?? '—')) ?></td><td><?= e((string)($transaction['description'] ?? '—')) ?></td><td><?= e((string)($transaction['orderReference'] ?? $transaction['id'] ?? '—')) ?></td><td><?= is_numeric($transactionAmount) ? number_format((float)$transactionAmount, 2) . ' ' . e($transactionCurrency) : '—' ?></td><td><?= is_numeric($transactionBalance) ? number_format((float)$transactionBalance, 2) . ' ' . e($transactionCurrency) : '—' ?></td></tr>
                                <?php endforeach; ?>
                            </tbody></table>
                        <?php else: ?>
                            <div class="wallet-empty">No transactions were returned for this period.</div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </section>
        <?php endif; ?>
    <?php endif; ?>
</main>

<?php if ($channels): ?>
<script src="<?= e(appUrl('admin/modules/wallet/balance-widget.js?v=1')) ?>" defer></script>
<?php endif; ?>
