<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';

requireAdminLogin();

global $conn;

$paymentId = getInt('id', 0) ?? 0;
$payment = null;
$error = '';

if ($paymentId <= 0) {
    $error = 'The selected payment is invalid.';
} else {
    $stmt = $conn->prepare("
        SELECT
            pay.id,
            pay.phone,
            pay.package_id,
            pay.amount,
            pay.order_reference,
            pay.transaction_reference,
            pay.payment_method,
            pay.status,
            pay.voucher_id,
            pay.created_at,
            pay.paid_at,
            p.name AS package_name,
            v.code AS voucher_code
        FROM payments pay
        LEFT JOIN packages p ON p.id = pay.package_id
        LEFT JOIN vouchers v ON v.id = pay.voucher_id
        WHERE pay.id = ?
        LIMIT 1
    ");

    if (!$stmt) {
        logDatabaseError($conn, 'Preparing payment details');
        $error = 'Payment details could not be loaded right now.';
    } else {
        $stmt->bind_param('i', $paymentId);

        if (!$stmt->execute()) {
            logDatabaseError($conn, 'Loading payment details');
            $error = 'Payment details could not be loaded right now.';
        } else {
            $result = $stmt->get_result();
            $payment = $result ? $result->fetch_assoc() : null;
            if (!$payment) {
                $error = 'This payment record was not found.';
            }
        }

        $stmt->close();
    }
}

$status = $payment && $payment['status'] !== null ? (string)$payment['status'] : null;
?>

<div class="payments-page">
    <header class="payments-header payments-detail-header">
        <div class="payments-heading">
            <div class="payments-heading-icon"><i class="fa-solid fa-receipt"></i></div>
            <div>
                <div class="payments-eyebrow">Payments / Record details</div>
                <h1>Payment details</h1>
                <p>Review the saved payment and its linked records.</p>
            </div>
        </div>
        <a class="payments-back" href="<?= e(appUrl('admin/dashboard.php?page=payments')) ?>"><i class="fa-solid fa-arrow-left"></i> Back to Payments</a>
    </header>

    <?php if ($error !== ''): ?>
        <div class="payments-alert" role="alert"><i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?></div>
    <?php elseif ($payment): ?>
        <section class="payment-detail-card">
            <div class="payment-detail-top">
                <div>
                    <span class="payment-detail-label">Amount</span>
                    <strong class="payment-detail-amount"><?= e(formatMoney($payment['amount'])) ?></strong>
                </div>
                <span class="payment-status <?= e(paymentStatusClass($status)) ?>"><?= e(paymentStatusLabel($status)) ?></span>
            </div>

            <div class="payment-detail-grid">
                <div class="payment-detail-item"><span>Order reference</span><strong><?= e((string)$payment['order_reference']) ?></strong></div>
                <div class="payment-detail-item"><span>Transaction reference</span><strong><?= e((string)($payment['transaction_reference'] ?: '—')) ?></strong></div>
                <div class="payment-detail-item"><span>Customer phone</span><strong><?= e((string)$payment['phone']) ?></strong></div>
                <div class="payment-detail-item"><span>Payment method</span><strong><?= e((string)($payment['payment_method'] ?: '—')) ?></strong></div>
                <div class="payment-detail-item"><span>Package</span><strong><?= e((string)($payment['package_name'] ?? 'Package unavailable')) ?></strong></div>
                <div class="payment-detail-item"><span>Created</span><strong><?= e(paymentDateLabel((string)$payment['created_at'])) ?></strong></div>
                <div class="payment-detail-item"><span>Paid at</span><strong><?= e(paymentDateLabel($payment['paid_at'] !== null ? (string)$payment['paid_at'] : null)) ?></strong></div>
                <div class="payment-detail-item">
                    <span>Voucher</span>
                    <?php if ((int)($payment['voucher_id'] ?? 0) > 0 && !empty($payment['voucher_code'])): ?>
                        <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers&action=view&id=' . (int)$payment['voucher_id'])) ?>"><i class="fa-solid fa-ticket"></i> <?= e((string)$payment['voucher_code']) ?></a>
                    <?php elseif ((int)($payment['voucher_id'] ?? 0) > 0): ?>
                        <strong>Voucher record #<?= (int)$payment['voucher_id'] ?></strong>
                    <?php else: ?>
                        <strong>Not linked</strong>
                    <?php endif; ?>
                </div>
            </div>

            <div class="payment-detail-note"><i class="fa-solid fa-lock"></i><span>This is a read-only view of the payment record. No payment status or transaction data is changed here.</span></div>
        </section>
    <?php endif; ?>
</div>
