<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';

requireAdminLogin();

global $conn;

$error = '';
$success = '';
$voucher = null;
$lookupFailed = false;
$code = strtoupper(trim(isPost() ? postString('code', '') : getString('code', '')));
$soldPriceInput = isPost() ? trim(postString('sold_price', '')) : '';
$mode = isPost() ? postString('mode', 'lookup') : 'lookup';

$loadVoucher = static function (string $voucherCode) use ($conn, &$lookupFailed): ?array {
    $stmt = $conn->prepare("
        SELECT
            v.id,
            v.code,
            v.source,
            v.status,
            v.sold_at,
            v.sold_price,
            p.name AS package_name,
            p.price AS package_price
        FROM vouchers v
        LEFT JOIN packages p ON p.id = v.package_id
        WHERE v.code = ?
        LIMIT 1
    ");

    if (!$stmt) {
        $lookupFailed = true;
        return null;
    }

    $stmt->bind_param('s', $voucherCode);
    if (!$stmt->execute()) {
        $stmt->close();
        $lookupFailed = true;
        return null;
    }

    $result = $stmt->get_result();
    $row = $result ? $result->fetch_assoc() : null;
    $stmt->close();

    return $row ?: null;
};

if (isPost()) {
    requireAdminPost();
    requireCsrfToken();

    if ($code === '') {
        $error = 'Enter the voucher code first.';
    } else {
        $voucher = $loadVoucher($code);

        if ($lookupFailed) {
            $error = 'The voucher could not be checked right now.';
        } elseif (!$voucher) {
            $error = 'No voucher was found with that code.';
        } elseif ((string)$voucher['source'] !== 'manual') {
            $error = 'This voucher is from the automatic customer-payment flow. Record it in Automatic Payments instead.';
        } elseif ($mode === 'record') {
            if ((string)$voucher['status'] !== 'unused') {
                $error = 'Only an unused manual voucher can be recorded as a cash sale.';
            } elseif ($voucher['sold_at'] !== null) {
                $error = 'This voucher already has a manual sale recorded.';
            } elseif (!preg_match('/^\d{1,8}(?:\.\d{1,2})?$/D', $soldPriceInput)) {
                $error = 'Enter the cash amount received, from 0 to 99,999,999.99, with up to two decimal places.';
            } else {
                $voucherId = (int)$voucher['id'];
                $updateStmt = $conn->prepare("
                    UPDATE vouchers
                    SET sold_at = NOW(), sold_price = ?
                    WHERE id = ?
                      AND source = 'manual'
                      AND status = 'unused'
                      AND sold_at IS NULL
                ");

                if (!$updateStmt) {
                    logDatabaseError($conn, 'Preparing manual cash sale record');
                    $error = 'The sale could not be recorded right now.';
                } else {
                    $updateStmt->bind_param('si', $soldPriceInput, $voucherId);
                    if (!$updateStmt->execute()) {
                        logDatabaseError($conn, 'Recording manual cash sale');
                        $error = 'The sale could not be recorded right now.';
                    } elseif ($updateStmt->affected_rows !== 1) {
                        $error = 'The voucher changed or has already been sold. Check it again before retrying.';
                    } else {
                        logAdminSecurityEvent(
                            'MANUAL_VOUCHER_SALE_RECORDED',
                            'Recorded a cash sale for manual voucher ID #' . $voucherId . '.'
                        );
                        $success = 'Cash sale recorded. The voucher remains unused until it is activated.';
                    }
                    $updateStmt->close();
                }

                $lookupFailed = false;
                $voucher = $loadVoucher($code);
                if (!$voucher && $error === '') {
                    $error = 'The sale was recorded, but the latest voucher details could not be loaded.';
                }
            }
        }
    }
} elseif ($code !== '') {
    $voucher = $loadVoucher($code);
    if ($lookupFailed) {
        $error = 'The voucher could not be checked right now.';
    } elseif (!$voucher) {
        $error = 'No voucher was found with that code.';
    }
}

$canRecordSale = $voucher
    && (string)$voucher['source'] === 'manual'
    && (string)$voucher['status'] === 'unused'
    && $voucher['sold_at'] === null;

if ($soldPriceInput === '' && $voucher && $voucher['package_price'] !== null) {
    $soldPriceInput = number_format((float)$voucher['package_price'], 2, '.', '');
}
?>

<div class="payments-page">
    <header class="payments-header payments-detail-header">
        <div class="payments-heading">
            <div class="payments-heading-icon payments-manual-icon"><i class="fa-solid fa-cash-register"></i></div>
            <div>
                <div class="payments-eyebrow">Payments / Manual Sales</div>
                <h1>Record cash sale</h1>
                <p>Record a manual voucher only after cash has been received.</p>
            </div>
        </div>
        <a class="payments-back" href="<?= e(appUrl('admin/dashboard.php?page=payments&action=manual_sales')) ?>"><i class="fa-solid fa-arrow-left"></i> Back to Manual Sales</a>
    </header>

    <?php if ($error !== ''): ?>
        <div class="payments-alert" role="alert"><i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?></div>
    <?php endif; ?>
    <?php if ($success !== ''): ?>
        <div class="payments-success-alert" role="status"><i class="fa-solid fa-circle-check"></i> <?= e($success) ?></div>
    <?php endif; ?>

    <div class="payments-record-layout">
        <section class="payments-table-card payments-record-card">
            <div class="payments-table-heading">
                <div><h2>Find the manual voucher</h2><p>Enter its code to review it before recording the cash sale.</p></div>
                <span class="payments-readonly"><i class="fa-solid fa-shield-halved"></i> Admin only</span>
            </div>
            <form class="payments-record-form" method="post" action="<?= e(appUrl('admin/dashboard.php?page=payments&action=record_manual_sale')) ?>">
                <?= csrfField() ?>
                <input type="hidden" name="mode" value="lookup">
                <div class="payments-record-field">
                    <label for="manual-voucher-code">Voucher code</label>
                    <div class="payments-record-input-row">
                        <input id="manual-voucher-code" type="text" name="code" value="<?= e($code) ?>" maxlength="50" required autocomplete="off" placeholder="Enter voucher code">
                        <button class="payments-filter-button" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Find voucher</button>
                    </div>
                    <span>Only unused vouchers created manually by an admin can be recorded as cash sales.</span>
                </div>
            </form>
        </section>

        <aside class="payments-table-card payments-record-help">
            <h2><i class="fa-solid fa-circle-info"></i> Manual sale rules</h2>
            <ul>
                <li>Record the sale after receiving cash.</li>
                <li>The amount is the cash actually received and can differ from the package price.</li>
                <li>Recording the sale does not activate the voucher. It remains unused until activation.</li>
                <li>Automatic customer payments are tracked separately in Payments.</li>
            </ul>
        </aside>
    </div>

    <?php if ($voucher): ?>
        <section class="payments-table-card payments-record-review">
            <div class="payments-table-heading">
                <div><h2>Voucher review</h2><p>Confirm the voucher and amount before saving the manual sale.</p></div>
                <span class="payment-voucher-status <?= e(paymentVoucherStatusClass((string)$voucher['status'])) ?>"><?= e(paymentVoucherStatusLabel((string)$voucher['status'])) ?></span>
            </div>
            <div class="payments-record-details">
                <div><span>Voucher code</span><strong><?= e((string)$voucher['code']) ?></strong></div>
                <div><span>Package</span><strong><?= e((string)($voucher['package_name'] ?? 'Package unavailable')) ?></strong></div>
                <div><span>Package price</span><strong><?= $voucher['package_price'] !== null ? e(formatMoney($voucher['package_price'])) : '—' ?></strong></div>
                <div><span>Sale status</span><strong><?= $voucher['sold_at'] === null ? 'Not recorded as sold' : 'Already sold' ?></strong></div>
                <?php if ($voucher['sold_at'] !== null): ?>
                    <div><span>Sold at</span><strong><?= e(paymentDateLabel((string)$voucher['sold_at'])) ?></strong></div>
                    <div><span>Recorded sale amount</span><strong><?= $voucher['sold_price'] !== null ? e(formatMoney($voucher['sold_price'])) : '—' ?></strong></div>
                <?php endif; ?>
            </div>

            <?php if ($canRecordSale): ?>
                <form class="payments-record-sale-form" method="post" action="<?= e(appUrl('admin/dashboard.php?page=payments&action=record_manual_sale')) ?>" onsubmit="return confirm('Confirm that cash has been received and record this voucher as sold?');">
                    <?= csrfField() ?>
                    <input type="hidden" name="mode" value="record">
                    <input type="hidden" name="code" value="<?= e((string)$voucher['code']) ?>">
                    <div class="payments-record-field">
                        <label for="sold-price">Cash received (TZS)</label>
                        <input id="sold-price" type="number" name="sold_price" min="0" max="99999999.99" step="0.01" value="<?= e($soldPriceInput) ?>" required>
                        <span>Suggested amount is the package price. Change it to the cash actually received if needed.</span>
                    </div>
                    <button class="payments-filter-button payments-record-submit" type="submit"><i class="fa-solid fa-check"></i> Record cash received</button>
                </form>
            <?php elseif ((string)$voucher['source'] !== 'manual'): ?>
                <div class="payments-record-blocked">This voucher belongs to the automatic customer-payment flow. Do not record it as a manual cash sale.</div>
            <?php elseif ($voucher['sold_at'] !== null): ?>
                <div class="payments-record-blocked">A sale is already recorded for this voucher. It cannot be recorded twice.</div>
            <?php else: ?>
                <div class="payments-record-blocked">Only unused vouchers can be recorded as manual sales.</div>
            <?php endif; ?>
        </section>
    <?php endif; ?>
</div>
