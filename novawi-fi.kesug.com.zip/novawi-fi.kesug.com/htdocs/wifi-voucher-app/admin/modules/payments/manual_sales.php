<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';

requireAdminLogin();

global $conn;

$search = trim(getString('search', ''));
$search = function_exists('mb_substr') ? mb_substr($search, 0, 120) : substr($search, 0, 120);
$searchLike = '%' . $search . '%';
$pageNumber = max(1, getInt('manual_sales_page', 1) ?? 1);
$perPage = 20;
$pageError = '';
$manualSales = [];

$stats = ['count' => 0, 'amount' => 0.0];
$statsResult = $conn->query("
    SELECT COUNT(*) AS total, COALESCE(SUM(sold_price), 0) AS amount
    FROM vouchers
    WHERE source = 'manual' AND sold_at IS NOT NULL
");

if ($statsResult) {
    $statsRow = $statsResult->fetch_assoc() ?: [];
    $stats['count'] = (int)($statsRow['total'] ?? 0);
    $stats['amount'] = (float)($statsRow['amount'] ?? 0);
} else {
    logDatabaseError($conn, 'Loading manual sales totals');
}

$countStmt = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM vouchers v
    LEFT JOIN packages p ON p.id = v.package_id
    WHERE v.source = 'manual'
      AND v.sold_at IS NOT NULL
      AND (? = '' OR v.code LIKE ? OR COALESCE(p.name, '') LIKE ?)
");

$totalSales = 0;
if (!$countStmt) {
    logDatabaseError($conn, 'Preparing manual sales count');
    $pageError = 'Manual sales could not be loaded right now.';
} else {
    $countStmt->bind_param('sss', $search, $searchLike, $searchLike);
    if (!$countStmt->execute()) {
        logDatabaseError($conn, 'Loading manual sales count');
        $pageError = 'Manual sales could not be loaded right now.';
    } else {
        $countResult = $countStmt->get_result();
        $countRow = $countResult ? $countResult->fetch_assoc() : null;
        $totalSales = (int)($countRow['total'] ?? 0);
    }
    $countStmt->close();
}

$totalPages = max(1, (int)ceil($totalSales / $perPage));
$pageNumber = min($pageNumber, $totalPages);
$offset = ($pageNumber - 1) * $perPage;

if ($pageError === '') {
    $listStmt = $conn->prepare("
        SELECT
            v.id,
            v.code,
            v.status,
            v.sold_price,
            v.sold_at,
            p.name AS package_name
        FROM vouchers v
        LEFT JOIN packages p ON p.id = v.package_id
        WHERE v.source = 'manual'
          AND v.sold_at IS NOT NULL
          AND (? = '' OR v.code LIKE ? OR COALESCE(p.name, '') LIKE ?)
        ORDER BY v.sold_at DESC, v.id DESC
        LIMIT ? OFFSET ?
    ");

    if (!$listStmt) {
        logDatabaseError($conn, 'Preparing manual sales list');
        $pageError = 'Manual sales could not be loaded right now.';
    } else {
        $listStmt->bind_param('sssii', $search, $searchLike, $searchLike, $perPage, $offset);
        if (!$listStmt->execute()) {
            logDatabaseError($conn, 'Loading manual sales list');
            $pageError = 'Manual sales could not be loaded right now.';
        } else {
            $listResult = $listStmt->get_result();
            if ($listResult) {
                while ($row = $listResult->fetch_assoc()) {
                    $manualSales[] = $row;
                }
            }
        }
        $listStmt->close();
    }
}

$basePageUrl = 'admin/dashboard.php?page=payments&action=manual_sales&search=' . urlencode($search) . '&manual_sales_page=';
?>

<div class="payments-page">
    <header class="payments-header payments-detail-header">
        <div class="payments-heading">
            <div class="payments-heading-icon payments-manual-icon"><i class="fa-solid fa-cash-register"></i></div>
            <div>
                <div class="payments-eyebrow">Admin / Sales</div>
                <h1>Manual Sales</h1>
                <p>Cash or offline voucher sales recorded by an administrator.</p>
            </div>
        </div>
        <div class="payments-header-actions">
            <a class="payments-record-cta" href="<?= e(appUrl('admin/dashboard.php?page=payments&action=record_manual_sale')) ?>"><i class="fa-solid fa-plus"></i> Record cash sale</a>
            <a class="payments-back" href="<?= e(appUrl('admin/dashboard.php?page=payments')) ?>"><i class="fa-solid fa-arrow-left"></i> Automatic Payments</a>
        </div>
    </header>

    <section class="payments-manual-summary">
        <div><span class="payments-manual-summary-icon"><i class="fa-solid fa-cash-register"></i></span><div><span class="payments-stat-label">Recorded manual sales</span><strong><?= number_format($stats['count']) ?></strong></div></div>
        <div><span class="payments-stat-label">Recorded manual sales total</span><strong class="payments-manual-amount"><?= e(formatMoney($stats['amount'])) ?></strong></div>
    </section>

    <div class="payments-manual-note"><i class="fa-solid fa-circle-info"></i><span>Recorded cash sales remain here even after a voucher expires; its status will show as Expired. An administrator voucher without a cash record is counted when activated, and its record remains after expiry.</span></div>

    <?php if ($pageError !== ''): ?>
        <div class="payments-alert" role="alert"><i class="fa-solid fa-circle-exclamation"></i> <?= e($pageError) ?></div>
    <?php endif; ?>

    <form class="payments-filters" method="get" action="<?= e(appUrl('admin/dashboard.php')) ?>">
        <input type="hidden" name="page" value="payments">
        <input type="hidden" name="action" value="manual_sales">
        <label class="payments-search">
            <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
            <input type="search" name="search" value="<?= e($search) ?>" maxlength="120" placeholder="Search voucher code or package">
        </label>
        <button class="payments-filter-button" type="submit"><i class="fa-solid fa-filter"></i> Search</button>
        <?php if ($search !== ''): ?><a class="payments-reset" href="<?= e(appUrl('admin/dashboard.php?page=payments&action=manual_sales')) ?>">Clear</a><?php endif; ?>
    </form>

    <section class="payments-table-card">
        <div class="payments-table-heading">
            <div><h2>Manual sale records</h2><p><?= number_format($totalSales) ?> record<?= $totalSales === 1 ? '' : 's' ?><?= $search !== '' ? ' match your search' : '' ?></p></div>
            <span class="payments-readonly"><i class="fa-solid fa-lock"></i> Read only</span>
        </div>

        <?php if ($pageError === ''): ?>
            <?php if ($manualSales): ?>
                <div class="payments-table-wrap">
                    <table class="payments-table payments-manual-table">
                        <thead><tr><th>Voucher</th><th>Package</th><th>Sale price</th><th>Sold at</th><th>Voucher status</th><th></th></tr></thead>
                        <tbody>
                            <?php foreach ($manualSales as $sale): ?>
                                <tr>
                                    <td><strong class="payments-ref"><?= e((string)$sale['code']) ?></strong></td>
                                    <td><?= e((string)($sale['package_name'] ?? 'Package unavailable')) ?></td>
                                    <td class="payments-amount"><?= $sale['sold_price'] !== null ? e(formatMoney($sale['sold_price'])) : '—' ?></td>
                                    <td><?= e(paymentDateLabel((string)$sale['sold_at'])) ?></td>
                                    <td><span class="payment-voucher-status <?= e(paymentVoucherStatusClass((string)$sale['status'])) ?>"><?= e(paymentVoucherStatusLabel((string)$sale['status'])) ?></span></td>
                                    <td><a class="payments-view" href="<?= e(appUrl('admin/dashboard.php?page=vouchers&action=view&id=' . (int)$sale['id'])) ?>"><i class="fa-solid fa-arrow-up-right-from-square"></i><span>Voucher</span></a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($totalPages > 1): ?>
                    <nav class="payments-pagination" aria-label="Manual sales pages">
                        <span>Page <?= number_format($pageNumber) ?> of <?= number_format($totalPages) ?></span>
                        <div>
                            <?php if ($pageNumber > 1): ?><a href="<?= e(appUrl($basePageUrl . ($pageNumber - 1))) ?>" aria-label="Previous page"><i class="fa-solid fa-chevron-left"></i></a><?php endif; ?>
                            <?php if ($pageNumber < $totalPages): ?><a href="<?= e(appUrl($basePageUrl . ($pageNumber + 1))) ?>" aria-label="Next page"><i class="fa-solid fa-chevron-right"></i></a><?php endif; ?>
                        </div>
                    </nav>
                <?php endif; ?>
            <?php else: ?>
                <div class="payments-empty">
                    <span><i class="fa-solid fa-cash-register"></i></span>
                    <h3><?= $search !== '' ? 'No matching manual sales' : 'No manual sales recorded yet' ?></h3>
                    <p><?= $search !== '' ? 'Try a different voucher code or package name.' : 'Manual vouchers will appear here after a sale has been recorded.' ?></p>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </section>
</div>
