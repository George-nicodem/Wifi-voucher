<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';

requireAdminLogin();

global $conn;

$paymentsCssUrl = appUrl('admin/modules/payments/payments.css?v=1');
echo '<link rel="stylesheet" href="' . e($paymentsCssUrl) . '">';

$expireOldPayments = $conn->prepare("UPDATE payments SET status = 'EXPIRED' WHERE status IN ('PENDING', 'PROCESSING') AND voucher_id IS NULL AND created_at <= DATE_SUB(NOW(), INTERVAL 30 MINUTE)");
if ($expireOldPayments) {
    if (!$expireOldPayments->execute()) {
        logDatabaseError($conn, 'Expiring abandoned payment attempts');
    }
    $expireOldPayments->close();
}

$action = getString('action', '');

if ($action === 'view') {
    require __DIR__ . '/view.php';
    return;
}

if ($action === 'manual_sales') {
    require __DIR__ . '/manual_sales.php';
    return;
}

if ($action === 'record_manual_sale') {
    require __DIR__ . '/record_manual_sale.php';
    return;
}

$search = trim(getString('search', ''));
if (function_exists('mb_substr')) {
    $search = mb_substr($search, 0, 120);
} else {
    $search = substr($search, 0, 120);
}

$status = strtoupper(trim(getString('status', '')));
$validStatuses = array_keys(paymentStatuses());
if ($status !== '' && !in_array($status, $validStatuses, true)) {
    $status = '';
}

$paymentsPage = max(1, getInt('payments_page', 1) ?? 1);
$perPage = 20;
$pageError = '';

$stats = [
    'successful' => 0,
    'successful_amount' => 0.0,
    'pending' => 0,
    'processing' => 0,
    'failed' => 0,
];

$statsResult = $conn->query("
    SELECT
        SUM(UPPER(COALESCE(status, '')) = 'SUCCESS') AS successful,
        COALESCE(SUM(CASE WHEN UPPER(COALESCE(status, '')) = 'SUCCESS' THEN amount ELSE 0 END), 0) AS successful_amount,
        SUM(UPPER(COALESCE(status, '')) = 'PENDING') AS pending,
        SUM(UPPER(COALESCE(status, '')) = 'PROCESSING') AS processing,
        SUM(UPPER(COALESCE(status, '')) IN ('FAILED', 'CANCELLED', 'CANCELED', 'EXPIRED')) AS failed
    FROM payments
");

if ($statsResult) {
    $statsRow = $statsResult->fetch_assoc() ?: [];
    $stats['successful'] = (int)($statsRow['successful'] ?? 0);
    $stats['successful_amount'] = (float)($statsRow['successful_amount'] ?? 0);
    $stats['pending'] = (int)($statsRow['pending'] ?? 0);
    $stats['processing'] = (int)($statsRow['processing'] ?? 0);
    $stats['failed'] = (int)($statsRow['failed'] ?? 0);
} else {
    logDatabaseError($conn, 'Loading payment dashboard totals');
}

$manualSalesStats = ['count' => 0, 'amount' => 0.0];
$manualStatsResult = $conn->query("
    SELECT
        COUNT(*) AS total,
        COALESCE(SUM(sold_price), 0) AS amount
    FROM vouchers
    WHERE source = 'manual'
      AND sold_at IS NOT NULL
");

if ($manualStatsResult) {
    $manualStatsRow = $manualStatsResult->fetch_assoc() ?: [];
    $manualSalesStats['count'] = (int)($manualStatsRow['total'] ?? 0);
    $manualSalesStats['amount'] = (float)($manualStatsRow['amount'] ?? 0);
} else {
    logDatabaseError($conn, 'Loading manual sales totals');
}

$adminActivatedVoucherStats = ['count' => 0, 'amount' => 0.0];
$adminActivatedResult = $conn->query("SELECT COUNT(*) AS total, COALESCE(SUM(COALESCE(v.sold_price, p.price, 0)), 0) AS amount
    FROM vouchers v
    LEFT JOIN packages p ON p.id = v.package_id
    WHERE v.source = 'manual' AND v.sold_at IS NULL
      AND v.activated_at IS NOT NULL");
if ($adminActivatedResult) {
    $adminActivatedRow = $adminActivatedResult->fetch_assoc() ?: [];
    $adminActivatedVoucherStats['count'] = (int)($adminActivatedRow['total'] ?? 0);
    $adminActivatedVoucherStats['amount'] = (float)($adminActivatedRow['amount'] ?? 0);
} else {
    logDatabaseError($conn, 'Loading activated admin voucher sales totals');
}

$searchLike = '%' . $search . '%';
$filterSql = "
    (? = '' OR UPPER(COALESCE(pay.status, '')) = ?)
    AND
    (
        ? = ''
        OR pay.phone LIKE ?
        OR pay.order_reference LIKE ?
        OR COALESCE(pay.transaction_reference, '') LIKE ?
        OR COALESCE(p.name, '') LIKE ?
        OR COALESCE(v.code, '') LIKE ?
    )
";

$countSql = "
    SELECT COUNT(*) AS total
    FROM payments pay
    LEFT JOIN packages p ON p.id = pay.package_id
    LEFT JOIN vouchers v ON v.id = pay.voucher_id
    WHERE $filterSql
";

$totalPayments = 0;
$countStmt = $conn->prepare($countSql);

if (!$countStmt) {
    logDatabaseError($conn, 'Preparing payment list count');
    $pageError = 'Payments could not be loaded right now.';
} else {
    $countStmt->bind_param(
        'ssssssss',
        $status,
        $status,
        $search,
        $searchLike,
        $searchLike,
        $searchLike,
        $searchLike,
        $searchLike
    );

    if (!$countStmt->execute()) {
        logDatabaseError($conn, 'Loading payment list count');
        $pageError = 'Payments could not be loaded right now.';
    } else {
        $countResult = $countStmt->get_result();
        $countRow = $countResult ? $countResult->fetch_assoc() : null;
        $totalPayments = (int)($countRow['total'] ?? 0);
    }

    $countStmt->close();
}

$totalPages = max(1, (int)ceil($totalPayments / $perPage));
$paymentsPage = min($paymentsPage, $totalPages);
$offset = ($paymentsPage - 1) * $perPage;
$payments = [];

$listSql = "
    SELECT
        pay.id,
        pay.phone,
        pay.package_id,
        pay.amount,
        pay.order_reference,
        pay.transaction_reference,
        pay.payment_method,
        pay.status,
        pay.voucher_id,
        pay.created_at,
        pay.paid_at,
        p.name AS package_name,
        v.code AS voucher_code
    FROM payments pay
    LEFT JOIN packages p ON p.id = pay.package_id
    LEFT JOIN vouchers v ON v.id = pay.voucher_id
    WHERE $filterSql
    ORDER BY pay.created_at DESC, pay.id DESC
    LIMIT ? OFFSET ?
";

if ($pageError === '') {
    $listStmt = $conn->prepare($listSql);

    if (!$listStmt) {
        logDatabaseError($conn, 'Preparing payment list');
        $pageError = 'Payments could not be loaded right now.';
    } else {
        $listStmt->bind_param(
            'ssssssssii',
            $status,
            $status,
            $search,
            $searchLike,
            $searchLike,
            $searchLike,
            $searchLike,
            $searchLike,
            $perPage,
            $offset
        );

        if (!$listStmt->execute()) {
            logDatabaseError($conn, 'Loading payment list');
            $pageError = 'Payments could not be loaded right now.';
        } else {
            $listResult = $listStmt->get_result();
            if ($listResult) {
                while ($row = $listResult->fetch_assoc()) {
                    $payments[] = $row;
                }
            }
        }

        $listStmt->close();
    }
}

$basePageUrl = 'admin/dashboard.php?page=payments&search=' . urlencode($search)
    . '&status=' . urlencode($status) . '&payments_page=';
?>

<div class="payments-page">
    <header class="payments-header">
        <div class="payments-heading">
            <div class="payments-heading-icon"><i class="fa-solid fa-money-bill-transfer"></i></div>
            <div>
                <div class="payments-eyebrow">Admin / Transactions</div>
                <h1>Payments</h1>
                <p>Online payments, cash sales, and administrator-activated vouchers are shown as separate sales; records remain after expiry.</p>
            </div>
        </div>
        <a class="payments-back" href="<?= e(appUrl('admin/dashboard.php?page=payments&action=manual_sales')) ?>"><i class="fa-solid fa-cash-register"></i> Manual Sales</a>
    </header>

    <section class="payments-stats" aria-label="Payment totals">
        <article class="payments-stat"><span class="payments-stat-icon payments-stat-green"><i class="fa-solid fa-circle-check"></i></span><div><span class="payments-stat-label">Automatic sales</span><strong><?= number_format($stats['successful']) ?></strong><small class="payments-stat-amount"><?= e(formatMoney($stats['successful_amount'])) ?></small></div></article>
        <article class="payments-stat"><span class="payments-stat-icon payments-stat-blue"><i class="fa-solid fa-cash-register"></i></span><div><span class="payments-stat-label">Manual sales</span><strong><?= number_format($manualSalesStats['count']) ?></strong><small class="payments-stat-amount"><?= e(formatMoney($manualSalesStats['amount'])) ?></small></div></article>
        <article class="payments-stat"><span class="payments-stat-icon payments-stat-amber"><i class="fa-solid fa-clock"></i></span><div><span class="payments-stat-label">Pending</span><strong><?= number_format($stats['pending']) ?></strong></div></article>
        <article class="payments-stat"><span class="payments-stat-icon payments-stat-violet"><i class="fa-solid fa-arrows-rotate"></i></span><div><span class="payments-stat-label">Processing</span><strong><?= number_format($stats['processing']) ?></strong></div></article>
        <article class="payments-stat"><span class="payments-stat-icon payments-stat-red"><i class="fa-solid fa-circle-xmark"></i></span><div><span class="payments-stat-label">Failed / cancelled</span><strong><?= number_format($stats['failed']) ?></strong></div></article>
    </section>

    <section class="payments-manual-summary" aria-label="Admin voucher sales history">
        <div><span class="payments-manual-summary-icon"><i class="fa-solid fa-ticket"></i></span><div><span class="payments-stat-label">Administrator-activated vouchers (including expired)</span><strong><?= number_format($adminActivatedVoucherStats['count']) ?></strong></div></div>
        <div><span class="payments-stat-label">Package price at time of sale</span><strong class="payments-manual-amount"><?= e(formatMoney($adminActivatedVoucherStats['amount'])) ?></strong></div>
    </section>
    <div class="payments-manual-note"><i class="fa-solid fa-circle-info"></i><span>Cash sales are counted when recorded. An administrator voucher without a cash record is counted when activated, at the package price; its record remains after expiry.</span></div>

    <?php if ($pageError !== ''): ?>
        <div class="payments-alert" role="alert"><i class="fa-solid fa-circle-exclamation"></i> <?= e($pageError) ?></div>
    <?php endif; ?>

    <form class="payments-filters" method="get" action="<?= e(appUrl('admin/dashboard.php')) ?>">
        <input type="hidden" name="page" value="payments">
        <label class="payments-search">
            <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
            <input type="search" name="search" value="<?= e($search) ?>" maxlength="120" placeholder="Phone, order, transaction, package or voucher">
        </label>
        <select name="status" aria-label="Filter by payment status">
            <option value="">All statuses</option>
            <?php foreach (paymentStatuses() as $statusKey => $statusLabel): ?>
                <option value="<?= e($statusKey) ?>" <?= $status === $statusKey ? 'selected' : '' ?>><?= e($statusLabel) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="payments-filter-button" type="submit"><i class="fa-solid fa-filter"></i> Filter</button>
        <?php if ($search !== '' || $status !== ''): ?>
            <a class="payments-reset" href="<?= e(appUrl('admin/dashboard.php?page=payments')) ?>">Clear</a>
        <?php endif; ?>
    </form>

    <section class="payments-table-card">
        <div class="payments-table-heading">
            <div>
                <h2>Automatic customer payments</h2>
                <p><?= number_format($totalPayments) ?> record<?= $totalPayments === 1 ? '' : 's' ?><?= $search !== '' || $status !== '' ? ' match your filters' : '' ?></p>
            </div>
            <span class="payments-readonly"><i class="fa-solid fa-bolt"></i> Customer-paid</span>
        </div>

        <?php if ($pageError === ''): ?>
            <?php if ($payments): ?>
                <div class="payments-table-wrap">
                    <table class="payments-table">
                        <thead>
                            <tr>
                                <th>Payment</th>
                                <th>Customer</th>
                                <th>Package</th>
                                <th>Amount</th>
                                <th>Method</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($payments as $payment): ?>
                                <tr>
                                    <td>
                                        <strong class="payments-ref"><?= e((string)$payment['order_reference']) ?></strong>
                                        <small><?= e($payment['transaction_reference'] ?: 'No transaction reference') ?></small>
                                    </td>
                                    <td><?= e((string)$payment['phone']) ?></td>
                                    <td>
                                        <strong><?= e((string)($payment['package_name'] ?? 'Package unavailable')) ?></strong>
                                        <?php if (!empty($payment['voucher_code'])): ?><small>Voucher <?= e((string)$payment['voucher_code']) ?></small><?php endif; ?>
                                    </td>
                                    <td class="payments-amount"><?= e(formatMoney($payment['amount'])) ?></td>
                                    <td><?= e((string)($payment['payment_method'] ?: '—')) ?></td>
                                    <td><span class="payment-status <?= e(paymentStatusClass($payment['status'] !== null ? (string)$payment['status'] : null)) ?>"><?= e(paymentStatusLabel($payment['status'] !== null ? (string)$payment['status'] : null)) ?></span></td>
                                    <td><?= e(paymentDateLabel((string)$payment['created_at'])) ?></td>
                                    <td><a class="payments-view" href="<?= e(appUrl('admin/dashboard.php?page=payments&action=view&id=' . (int)$payment['id'])) ?>" aria-label="View payment details"><i class="fa-solid fa-arrow-up-right-from-square"></i><span>View</span></a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($totalPages > 1): ?>
                    <nav class="payments-pagination" aria-label="Payments pages">
                        <span>Page <?= number_format($paymentsPage) ?> of <?= number_format($totalPages) ?></span>
                        <div>
                            <?php if ($paymentsPage > 1): ?><a href="<?= e(appUrl($basePageUrl . ($paymentsPage - 1))) ?>" aria-label="Previous page"><i class="fa-solid fa-chevron-left"></i></a><?php endif; ?>
                            <?php if ($paymentsPage < $totalPages): ?><a href="<?= e(appUrl($basePageUrl . ($paymentsPage + 1))) ?>" aria-label="Next page"><i class="fa-solid fa-chevron-right"></i></a><?php endif; ?>
                        </div>
                    </nav>
                <?php endif; ?>
            <?php else: ?>
                <div class="payments-empty">
                    <span><i class="fa-solid fa-receipt"></i></span>
                    <h3><?= $search !== '' || $status !== '' ? 'No matching payments' : 'No payments recorded yet' ?></h3>
                    <p><?= $search !== '' || $status !== '' ? 'Try a different search or clear the filters.' : 'Payment records will appear here when they are saved by the payment flow.' ?></p>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </section>
</div>
