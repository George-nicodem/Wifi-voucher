<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../config/app.php';
require_once __DIR__ . '/../../../config/security.php';
require_once __DIR__ . '/../../../includes/functions.php';

function paymentStatuses(): array
{
    return [
        'PENDING' => 'Pending',
        'PROCESSING' => 'Processing',
        'SUCCESS' => 'Successful',
        'FAILED' => 'Failed',
        'CANCELLED' => 'Cancelled', 'EXPIRED' => 'Expired',
    ];
}

function paymentStatusLabel(?string $status): string
{
    $status = strtoupper(trim((string)$status));

    if ($status === '') {
        return 'Unknown';
    }

    return paymentStatuses()[$status] ?? ucfirst(strtolower($status));
}

function paymentStatusClass(?string $status): string
{
    return match (strtoupper(trim((string)$status))) {
        'SUCCESS' => 'payment-status-success',
        'PENDING' => 'payment-status-pending',
        'PROCESSING' => 'payment-status-processing',
        'FAILED', 'CANCELLED', 'CANCELED', 'EXPIRED' => 'payment-status-failed',
        default => 'payment-status-unknown',
    };
}

function paymentDateLabel(?string $date): string
{
    if ($date === null || trim($date) === '') {
        return '—';
    }

    $timestamp = strtotime($date);

    return $timestamp === false ? '—' : date('M j, Y · g:i A', $timestamp);
}

function paymentVoucherStatusLabel(string $status): string
{
    return match (strtolower(trim($status))) {
        'unused' => 'Unused',
        'active' => 'Active',
        'expired' => 'Expired',
        'disabled' => 'Disabled',
        default => ucfirst(strtolower($status)),
    };
}

function paymentVoucherStatusClass(string $status): string
{
    return match (strtolower(trim($status))) {
        'unused' => 'payment-voucher-status-unused',
        'active' => 'payment-voucher-status-active',
        'expired' => 'payment-voucher-status-expired',
        'disabled' => 'payment-voucher-status-disabled',
        default => 'payment-voucher-status-disabled',
    };
}
