<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/admin_auth.php';
requireAdminLogin();
global $conn;

function sitesEscape(mixed $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function sitesLength(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
}

function sitesPlatformLabel(string $platform): string
{
    return match (strtolower($platform)) {
        'mikrotik' => 'MikroTik',
        'omada' => 'TP-Link Omada',
        'tp_link' => 'TP-Link',
        default => ucfirst(str_replace('_', ' ', $platform)),
    };
}

function sitesMapLink(mixed $latitude, mixed $longitude): string
{
    if (!is_numeric($latitude) || !is_numeric($longitude)) return '';
    $lat = number_format((float)$latitude, 7, '.', '');
    $lng = number_format((float)$longitude, 7, '.', '');
    return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($lat . ',' . $lng);
}

$errors = [];
$success = '';
$schemaReady = false;
$sites = [];
$devices = [];

try {
    $siteTable = $conn->query("SHOW TABLES LIKE 'network_sites'");
    $deviceTable = $conn->query("SHOW TABLES LIKE 'network_devices'");
    $deviceSiteColumn = $deviceTable ? $conn->query("SHOW COLUMNS FROM network_devices LIKE 'site_id'") : false;
    $latitudeColumn = $siteTable && $siteTable->num_rows > 0 ? $conn->query("SHOW COLUMNS FROM network_sites LIKE 'latitude'") : false;
    $longitudeColumn = $siteTable && $siteTable->num_rows > 0 ? $conn->query("SHOW COLUMNS FROM network_sites LIKE 'longitude'") : false;
    $schemaReady = $siteTable && $siteTable->num_rows > 0
        && $deviceTable && $deviceTable->num_rows > 0
        && $deviceSiteColumn && $deviceSiteColumn->num_rows > 0
        && $latitudeColumn && $latitudeColumn->num_rows > 0
        && $longitudeColumn && $longitudeColumn->num_rows > 0;
} catch (Throwable $exception) {
    logException($exception, 'Checking Sites module schema');
}

if ($schemaReady && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    requireAdminPostWithCsrf();
    $action = postString('form_action', '');

    if ($action === 'create_site' || $action === 'update_site') {
        $siteId = postInt('site_id', 0) ?? 0;
        $name = trim(postString('name', ''));
        $detail = trim(postString('location_detail', ''));
        $status = trim(postString('status', 'active'));
        $latitudeRaw = trim(postString('latitude', ''));
        $longitudeRaw = trim(postString('longitude', ''));
        $coordinatesProvided = $latitudeRaw !== '' || $longitudeRaw !== '';
        $latitudeValue = '';
        $longitudeValue = '';

        if ($name === '' || sitesLength($name) > 100) {
            $errors[] = 'Enter a site name with no more than 100 characters.';
        }
        if ($action === 'update_site' && $siteId <= 0) {
            $errors[] = 'The selected site was not recognized.';
        }
        if (sitesLength($detail) > 255) {
            $errors[] = 'Location details must be no longer than 255 characters.';
        }
        if ($coordinatesProvided && (!is_numeric($latitudeRaw) || !is_numeric($longitudeRaw))) {
            $errors[] = 'Enter both latitude and longitude from Google Maps, or leave both blank.';
        } elseif ($coordinatesProvided) {
            $latitudeNumber = (float)$latitudeRaw;
            $longitudeNumber = (float)$longitudeRaw;
            if ($latitudeNumber < -90 || $latitudeNumber > 90 || $longitudeNumber < -180 || $longitudeNumber > 180) {
                $errors[] = 'The latitude or longitude is invalid. Make sure you copied the coordinates correctly from Google Maps.';
            } else {
                $latitudeValue = number_format($latitudeNumber, 7, '.', '');
                $longitudeValue = number_format($longitudeNumber, 7, '.', '');
            }
        }
        if ($action === 'update_site' && !in_array($status, ['active', 'inactive'], true)) {
            $errors[] = 'The site status was not recognized.';
        }

        if (!$errors && $action === 'create_site') {
            $stmt = $conn->prepare('INSERT INTO network_sites (name, location_detail, latitude, longitude) VALUES (?, NULLIF(?, \'\'), NULLIF(?, \'\'), NULLIF(?, \'\'))');
            if (!$stmt) {
                logDatabaseError($conn, 'Preparing new network site');
                $errors[] = 'The site could not be saved.';
            } else {
                $stmt->bind_param('ssss', $name, $detail, $latitudeValue, $longitudeValue);
                if ($stmt->execute()) {
                    $success = 'The new site has been saved.';
                    logAdminSecurityEvent('NETWORK_SITE_CREATED', 'Created a network site.');
                } else {
                    logDatabaseError($conn, 'Saving new network site');
                    $errors[] = 'The site could not be saved.';
                }
                $stmt->close();
            }
        } elseif (!$errors) {
            $stmt = $conn->prepare('UPDATE network_sites SET name = ?, location_detail = NULLIF(?, \'\'), latitude = NULLIF(?, \'\'), longitude = NULLIF(?, \'\'), status = ? WHERE id = ?');
            if (!$stmt) {
                logDatabaseError($conn, 'Preparing network site update');
                $errors[] = 'Site changes could not be saved.';
            } else {
                $stmt->bind_param('sssssi', $name, $detail, $latitudeValue, $longitudeValue, $status, $siteId);
                if ($stmt->execute() && $stmt->affected_rows >= 0) {
                    $success = 'Site details have been saved.';
                    logAdminSecurityEvent('NETWORK_SITE_UPDATED', 'Updated a network site.');
                } else {
                    logDatabaseError($conn, 'Updating network site');
                    $errors[] = 'Site changes could not be saved.';
                }
                $stmt->close();
            }
        }
    } elseif ($action === 'assign_device') {
        $deviceId = postInt('device_id', 0) ?? 0;
        $siteIdRaw = trim(postString('site_id', ''));
        $siteId = $siteIdRaw === '' ? 0 : (ctype_digit($siteIdRaw) ? (int)$siteIdRaw : -1);
        if ($deviceId <= 0 || $siteId < 0) {
            $errors[] = 'Select a valid device and site.';
        } else {
            $deviceCheck = $conn->prepare('SELECT id FROM network_devices WHERE id = ? LIMIT 1');
            if (!$deviceCheck) {
                $errors[] = 'Unable to verify the device.';
            } else {
                $deviceCheck->bind_param('i', $deviceId);
                $deviceCheck->execute();
                $foundDevice = $deviceCheck->get_result()?->fetch_assoc();
                $deviceCheck->close();
                if (!$foundDevice) $errors[] = 'The selected device is no longer in the list.';
            }
        }
        if (!$errors && $siteId > 0) {
            $siteCheck = $conn->prepare("SELECT id FROM network_sites WHERE id = ? AND status = 'active' LIMIT 1");
            if (!$siteCheck) {
                $errors[] = 'Unable to verify the site.';
            } else {
                $siteCheck->bind_param('i', $siteId);
                $siteCheck->execute();
                $foundSite = $siteCheck->get_result()?->fetch_assoc();
                $siteCheck->close();
                if (!$foundSite) {
                    $errors[] = 'Eneo hilo halipo au linactive.';
                }
            }
        }

        if (!$errors) {
            if ($siteId === 0) {
                $stmt = $conn->prepare('UPDATE network_devices SET site_id = NULL WHERE id = ?');
                if ($stmt) $stmt->bind_param('i', $deviceId);
            } else {
                $stmt = $conn->prepare('UPDATE network_devices SET site_id = ? WHERE id = ?');
                if ($stmt) $stmt->bind_param('ii', $siteId, $deviceId);
            }
            if (!$stmt) {
                logDatabaseError($conn, 'Preparing device site assignment');
                $errors[] = 'The device location could not be saved.';
            } else {
                if ($stmt->execute() && $stmt->affected_rows >= 0) {
                    $success = 'The device location has been saved.';
                    logAdminSecurityEvent('NETWORK_DEVICE_SITE_UPDATED', 'Updated the physical site assigned to a network device.');
                } else {
                    logDatabaseError($conn, 'Saving device site assignment');
                    $errors[] = 'The device location could not be saved.';
                }
                $stmt->close();
            }
        }
    } else {
        $errors[] = 'The request was not recognized.';
    }
}

if ($schemaReady) {
    try {
        $siteResult = $conn->query('SELECT s.id, s.name, s.location_detail, s.latitude, s.longitude, s.status, COUNT(d.id) AS device_count FROM network_sites s LEFT JOIN network_devices d ON d.site_id = s.id GROUP BY s.id, s.name, s.location_detail, s.latitude, s.longitude, s.status ORDER BY (s.status = \'active\') DESC, s.name ASC');
        if ($siteResult) while ($row = $siteResult->fetch_assoc()) $sites[] = $row;
        $deviceResult = $conn->query('SELECT d.id, d.platform, d.role, d.device_family, d.device_model, d.management_ip, d.status, d.site_id, s.name AS site_name, s.latitude AS site_latitude, s.longitude AS site_longitude FROM network_devices d LEFT JOIN network_sites s ON s.id = d.site_id ORDER BY (d.site_id IS NULL) DESC, s.name ASC, d.platform ASC, d.device_model ASC LIMIT 500');
        if ($deviceResult) while ($row = $deviceResult->fetch_assoc()) $devices[] = $row;
    } catch (Throwable $exception) {
        logException($exception, 'Loading Sites and network device locations');
        $errors[] = 'The sites and devices could not be loaded.';
    }
}

$assignedCount = count(array_filter($devices, static fn(array $device): bool => !empty($device['site_id'])));
$unassignedCount = count($devices) - $assignedCount;
?>
<style>
.sites-page{--sites-ink:#17233b;--sites-muted:#71809a;--sites-line:#e5ebf3;--sites-teal:#087f74;color:var(--sites-ink)}
.sites-head{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin:6px 0 20px}.sites-head h1{margin:0;font-size:26px;font-weight:850;letter-spacing:-.04em}.sites-head p{margin:7px 0 0;color:var(--sites-muted);font-size:13px;line-height:1.6}
.sites-stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-bottom:16px}.sites-stat,.sites-card{background:#fff;border:1px solid var(--sites-line);border-radius:15px;box-shadow:0 8px 25px #1c31500a}.sites-stat{padding:16px}.sites-stat span{display:block;color:var(--sites-muted);font-size:11px}.sites-stat strong{display:block;margin-top:5px;font-size:23px}.sites-layout{display:grid;grid-template-columns:minmax(260px,.8fr) minmax(0,1.7fr);gap:15px;align-items:start}.sites-card{padding:18px;margin-bottom:15px}.sites-card h2{margin:0 0 12px;font-size:16px}.sites-form{display:grid;gap:10px}.sites-field{display:grid;gap:5px}.sites-field label{font-size:11px;font-weight:800}.sites-field input,.sites-field select{width:100%;min-height:41px;padding:9px 11px;border:1px solid #d7e0eb;border-radius:9px;background:#fff;color:var(--sites-ink);font:inherit;font-size:12px}.sites-btn{display:inline-flex;justify-content:center;align-items:center;gap:8px;min-height:40px;padding:0 14px;border:0;border-radius:9px;background:var(--sites-teal);color:#fff;font:inherit;font-size:12px;font-weight:800;cursor:pointer}.sites-btn:hover{filter:brightness(1.06)}.sites-note,.sites-alert{padding:12px 14px;margin:0 0 13px;border-radius:11px;font-size:12px;line-height:1.55}.sites-note{border:1px solid #f0d89f;background:#fff8e9;color:#745311}.sites-alert{border:1px solid #a7f3d0;background:#ecfdf5;color:#065f46}.sites-alert.error{border-color:#fecdd3;background:#fff1f2;color:#9f1239}.sites-list{display:grid;gap:11px}.site-item{padding:13px;border:1px solid var(--sites-line);border-radius:12px;background:#fbfcfe}.site-item-head{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}.site-item h3{margin:0;font-size:14px}.site-item p{margin:4px 0 0;color:var(--sites-muted);font-size:11px}.site-count{padding:4px 8px;border-radius:99px;background:#e8f6f4;color:#087f74;font-size:10px;font-weight:850;white-space:nowrap}.site-edit{display:grid;grid-template-columns:1fr 1fr;gap:7px;align-items:end;margin-top:11px}.site-edit input,.site-edit select{min-width:0;min-height:36px;padding:7px 8px;border:1px solid #d7e0eb;border-radius:8px;background:#fff;font:inherit;font-size:11px}.site-edit .sites-btn{min-height:36px;padding:0 9px;font-size:10px}.sites-table-wrap{overflow:auto}.sites-table{width:100%;border-collapse:collapse;font-size:12px}.sites-table th,.sites-table td{padding:11px 9px;border-bottom:1px solid #edf1f5;text-align:left;vertical-align:middle}.sites-table th{color:#677792;font-size:10px;text-transform:uppercase;letter-spacing:.05em}.device-name{font-weight:800}.device-sub{display:block;margin-top:3px;color:var(--sites-muted);font-size:10px}.device-location-form{display:flex;align-items:center;gap:7px;min-width:220px}.device-location-form select{min-width:130px;min-height:35px;padding:6px 8px;border:1px solid #d7e0eb;border-radius:8px;background:#fff;font:inherit;font-size:11px}.device-location-form .sites-btn{min-height:35px;padding:0 9px;font-size:10px}.site-platform,.site-status{display:inline-flex;padding:4px 8px;border-radius:99px;background:#eef3f8;color:#34435a;font-size:10px;font-weight:800}.site-status.online{background:#e5f8ef;color:#0c7a4d}.site-status.offline{background:#fff0ed;color:#bb3d2b}.site-status.inactive{background:#f0f1f4;color:#606b7a}.sites-empty{padding:18px;border:1px dashed #ccd6e3;border-radius:11px;color:var(--sites-muted);font-size:12px;line-height:1.5;text-align:center}.sites-subtitle{margin:-5px 0 12px;color:var(--sites-muted);font-size:11px;line-height:1.55}
@media(max-width:980px){.sites-layout{grid-template-columns:1fr}.site-edit{grid-template-columns:1fr 1fr}.site-edit .sites-btn{width:100%}}@media(max-width:640px){.sites-stats{grid-template-columns:1fr 1fr;gap:8px}.sites-stats .sites-stat:last-child{grid-column:1/-1}.sites-head h1{font-size:22px}.sites-card{padding:14px}.site-edit{grid-template-columns:1fr}.sites-table{min-width:720px}}
.sites-coordinate-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}.sites-coordinate-grid .sites-field{min-width:0}.sites-coordinate-grid input{font-variant-numeric:tabular-nums}.sites-coordinates-help{margin:0;color:var(--sites-muted);font-size:10px;line-height:1.5}.sites-map-search{display:inline-flex;align-items:center;gap:7px;color:#087f74;font-size:11px;font-weight:800;text-decoration:none}.sites-map-search:hover,.site-map-link:hover{text-decoration:underline}.site-edit .sites-coordinate-grid,.site-edit .sites-map-search{grid-column:1/-1}.site-edit .sites-field label{font-size:10px}.site-map-link{display:inline-flex;align-items:center;gap:5px;margin-top:5px;color:#087f74;font-size:10px;font-weight:800;text-decoration:none}
@media(max-width:560px){.sites-coordinate-grid{grid-template-columns:1fr}.site-edit .sites-coordinate-grid{grid-template-columns:1fr 1fr}}
</style>

<div class="sites-page">
    <header class="sites-head"><div><h1><i class="fa-solid fa-location-dot" aria-hidden="true"></i> Sites</h1><p>Save coordinates for each site, then open the location directly in Google Maps.</p></div></header>

    <?php foreach ($errors as $error): ?><div class="sites-alert error" role="alert"><?= e($error) ?></div><?php endforeach; ?>
    <?php if ($success !== ''): ?><div class="sites-alert" role="status"><?= e($success) ?></div><?php endif; ?>

    <?php if (!$schemaReady): ?>
        <div class="sites-note"><strong>Sites and maps are not yet connected to the device table.</strong><br>First run <code>admin/modules/router/install.sql</code>, then run <code>admin/modules/sites/install.sql</code> on the selected system database. The migration adds location coordinates without deleting existing data.</div>
    <?php else: ?>
        <section class="sites-stats" aria-label="Sites Summary"><article class="sites-stat"><span>Registered sites</span><strong><?= number_format(count($sites)) ?></strong></article><article class="sites-stat"><span>Devices with a location</span><strong><?= number_format($assignedCount) ?></strong></article><article class="sites-stat"><span>Devices awaiting a location</span><strong><?= number_format($unassignedCount) ?></strong></article></section>

        <div class="sites-layout">
            <section>
                <article class="sites-card"><h2><i class="fa-solid fa-circle-plus" aria-hidden="true"></i> Add Site</h2><p class="sites-subtitle">Enter a name and Google Maps coordinates, then link this site to a device in the list.</p><form class="sites-form" id="newSiteForm" method="post" action="<?= e(appUrl('admin/dashboard.php?page=sites')) ?>"><?= csrfField() ?><input type="hidden" name="form_action" value="create_site"><div class="sites-field"><label for="new_site_name">Site name *</label><input id="new_site_name" name="name" maxlength="100" placeholder="Magomeni" required></div><div class="sites-field"><label for="new_site_detail">Location details (optional)</label><input id="new_site_detail" name="location_detail" maxlength="255" placeholder="Example: near the market"></div><div class="sites-coordinate-grid"><div class="sites-field"><label for="new_site_latitude">Latitude</label><input type="number" step="any" min="-90" max="90" id="new_site_latitude" name="latitude" placeholder="-6.8000000" inputmode="decimal"></div><div class="sites-field"><label for="new_site_longitude">Longitude</label><input type="number" step="any" min="-180" max="180" id="new_site_longitude" name="longitude" placeholder="39.2000000" inputmode="decimal"></div></div><a class="sites-map-search" data-maps-search target="_blank" rel="noopener noreferrer" href="https://www.google.com/maps/search/?api=1&amp;query=Tanzania"><i class="fa-brands fa-google" aria-hidden="true"></i> Find location in Google Maps</a><p class="sites-coordinates-help">In Google Maps, copy the coordinates from the router section and paste them here. Enter both or leave both blank.</p><button class="sites-btn" type="submit"><i class="fa-solid fa-plus" aria-hidden="true"></i> Save site</button></form></article>

                <article class="sites-card"><h2><i class="fa-solid fa-map-location-dot" aria-hidden="true"></i> Your Sites</h2><?php if ($sites === []): ?><div class="sites-empty">There are no sites yet. Add a site such as Magomeni or Ubungo.</div><?php else: ?><div class="sites-list"><?php foreach ($sites as $site): ?><div class="site-item"><div class="site-item-head"><div><h3><?= e((string)$site['name']) ?></h3><p><?= e((string)($site['location_detail'] ?: 'Details not set')) ?> · <?= e((string)$site['status']) ?></p><?php if (is_numeric($site['latitude'] ?? null) && is_numeric($site['longitude'] ?? null)): ?><a class="site-map-link" href="<?= e(sitesMapLink($site['latitude'], $site['longitude'])) ?>" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-google" aria-hidden="true"></i> <?= e(number_format((float)$site['latitude'], 7, '.', '') . ', ' . number_format((float)$site['longitude'], 7, '.', '')) ?> · Open Google Maps</a><?php endif; ?></div><span class="site-count"><?= number_format((int)$site['device_count']) ?> devices</span></div><form class="site-edit" id="siteEditForm-<?= (int)$site['id'] ?>" method="post" action="<?= e(appUrl('admin/dashboard.php?page=sites')) ?>"><?= csrfField() ?><input type="hidden" name="form_action" value="update_site"><input type="hidden" name="site_id" value="<?= (int)$site['id'] ?>"><input name="name" maxlength="100" value="<?= e((string)$site['name']) ?>" aria-label="Site name" required><input name="location_detail" maxlength="255" value="<?= e((string)($site['location_detail'] ?? '')) ?>" aria-label="Location details"><div class="sites-coordinate-grid"><div class="sites-field"><label>Latitude</label><input type="number" step="any" min="-90" max="90" name="latitude" value="<?= e((string)($site['latitude'] ?? '')) ?>" aria-label="Latitude"></div><div class="sites-field"><label>Longitude</label><input type="number" step="any" min="-180" max="180" name="longitude" value="<?= e((string)($site['longitude'] ?? '')) ?>" aria-label="Longitude"></div></div><a class="sites-map-search" data-maps-search target="_blank" rel="noopener noreferrer" href="https://www.google.com/maps/search/?api=1&amp;query=Tanzania"><i class="fa-brands fa-google" aria-hidden="true"></i> Find location in Google Maps</a><select name="status" aria-label="Site status"><option value="active" <?= $site['status'] === 'active' ? 'selected' : '' ?>>Active</option><option value="inactive" <?= $site['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option></select><button class="sites-btn" type="submit">Save</button></form></div><?php endforeach; ?></div><?php endif; ?></article>
            </section>

            <section class="sites-card"><h2><i class="fa-solid fa-router" aria-hidden="true"></i> Devices and Their Locations</h2><p class="sites-subtitle">Link a router/access point to its site; the link opens its coordinates in Google Maps.</p><?php if ($devices === []): ?><div class="sites-empty">No devices have been registered yet. Add a device from Routers &amp; Wi-Fi first.</div><?php else: ?><div class="sites-table-wrap"><table class="sites-table"><thead><tr><th>Device</th><th>Platform</th><th>Status</th><th>Location</th></tr></thead><tbody><?php foreach ($devices as $device): ?><?php $status = strtolower((string)$device['status']); ?><tr><td><span class="device-name"><?= e((string)$device['device_model']) ?></span><span class="device-sub"><?= e((string)$device['device_family']) ?> · <?= e(ucwords(str_replace('_', ' ', (string)$device['role']))) ?><?= !empty($device['management_ip']) ? ' · ' . e((string)$device['management_ip']) : '' ?></span></td><td><span class="site-platform"><?= e(sitesPlatformLabel((string)$device['platform'])) ?></span></td><td><span class="site-status <?= in_array($status, ['online', 'offline'], true) ? e($status) : '' ?>"><?= e(ucfirst($status)) ?></span></td><td><form class="device-location-form" method="post" action="<?= e(appUrl('admin/dashboard.php?page=sites')) ?>"><?= csrfField() ?><input type="hidden" name="form_action" value="assign_device"><input type="hidden" name="device_id" value="<?= (int)$device['id'] ?>"><select name="site_id" aria-label="Device location"><option value="">Not set</option><?php foreach ($sites as $site): ?><option value="<?= (int)$site['id'] ?>" <?= (string)$device['site_id'] === (string)$site['id'] ? 'selected' : '' ?> <?= $site['status'] !== 'active' && (string)$device['site_id'] !== (string)$site['id'] ? 'disabled' : '' ?>><?= e((string)$site['name']) ?><?= $site['status'] !== 'active' ? ' (inactive)' : '' ?></option><?php endforeach; ?></select><button class="sites-btn" type="submit">Save</button></form><?php if (is_numeric($device['site_latitude'] ?? null) && is_numeric($device['site_longitude'] ?? null)): ?><a class="site-map-link" href="<?= e(sitesMapLink($device['site_latitude'], $device['site_longitude'])) ?>" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-google" aria-hidden="true"></i> Open location in Google Maps</a><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
        </div>
    <?php endif; ?>
</div>
<script>
(function () {
    document.querySelectorAll('[data-maps-search]').forEach((link) => {
        const form = link.closest('form');
        if (!form) return;
        const updateMapsSearch = () => {
            const name = form.querySelector('[name="name"]')?.value.trim() || '';
            const detail = form.querySelector('[name="location_detail"]')?.value.trim() || '';
            const query = [detail, name].filter(Boolean).join(', ') || 'Tanzania';
            const url = new URL('https://www.google.com/maps/search/');
            url.searchParams.set('api', '1');
            url.searchParams.set('query', query);
            link.href = url.toString();
        };
        form.querySelectorAll('[name="name"], [name="location_detail"]').forEach((field) => {
            field.addEventListener('input', updateMapsSearch);
        });
        updateMapsSearch();
    });
})();
</script>
