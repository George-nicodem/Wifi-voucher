-- Run after admin/modules/router/install.sql in the same database selected by the application.
-- This is additive: it does not modify vouchers, packages, payments, or sales.

CREATE TABLE IF NOT EXISTS network_sites (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    location_detail VARCHAR(255) NULL,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_network_sites_status_name (status, name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Save the exact pin selected from the map (nullable for sites without a pin).
SET @network_lat_column_exists = (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'network_sites' AND COLUMN_NAME = 'latitude'
);
SET @network_lat_column_sql = IF(
    @network_lat_column_exists = 0,
    'ALTER TABLE `network_sites` ADD COLUMN `latitude` DECIMAL(10,7) NULL AFTER `location_detail`',
    'SELECT 1'
);
PREPARE network_lat_column_stmt FROM @network_lat_column_sql;
EXECUTE network_lat_column_stmt;
DEALLOCATE PREPARE network_lat_column_stmt;

SET @network_lng_column_exists = (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'network_sites' AND COLUMN_NAME = 'longitude'
);
SET @network_lng_column_sql = IF(
    @network_lng_column_exists = 0,
    'ALTER TABLE `network_sites` ADD COLUMN `longitude` DECIMAL(10,7) NULL AFTER `latitude`',
    'SELECT 1'
);
PREPARE network_lng_column_stmt FROM @network_lng_column_sql;
EXECUTE network_lng_column_stmt;
DEALLOCATE PREPARE network_lng_column_stmt;

-- Extend inventory so TP-Link, Omada, and MikroTik devices can all be registered.
SET @network_platform_type = (
    SELECT COLUMN_TYPE
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'network_devices'
      AND COLUMN_NAME = 'platform'
    LIMIT 1
);
SET @network_platform_sql = IF(
    @network_platform_type IS NULL OR LOCATE('mikrotik', @network_platform_type) > 0,
    'SELECT 1',
    'ALTER TABLE `network_devices` MODIFY COLUMN `platform` ENUM(''tp_link'',''omada'',''mikrotik'') NOT NULL'
);
PREPARE network_platform_stmt FROM @network_platform_sql;
EXECUTE network_platform_stmt;
DEALLOCATE PREPARE network_platform_stmt;

-- Attach each inventory device to a physical business site. Null means unassigned.
SET @network_site_column_exists = (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'network_devices'
      AND COLUMN_NAME = 'site_id'
);
SET @network_site_column_sql = IF(
    @network_site_column_exists = 0,
    'ALTER TABLE `network_devices` ADD COLUMN `site_id` BIGINT UNSIGNED NULL AFTER `controller_id`',
    'SELECT 1'
);
PREPARE network_site_column_stmt FROM @network_site_column_sql;
EXECUTE network_site_column_stmt;
DEALLOCATE PREPARE network_site_column_stmt;

SET @network_site_index_exists = (
    SELECT COUNT(*)
    FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'network_devices'
      AND INDEX_NAME = 'idx_network_devices_site'
);
SET @network_site_index_sql = IF(
    @network_site_index_exists = 0,
    'ALTER TABLE `network_devices` ADD KEY `idx_network_devices_site` (`site_id`)',
    'SELECT 1'
);
PREPARE network_site_index_stmt FROM @network_site_index_sql;
EXECUTE network_site_index_stmt;
DEALLOCATE PREPARE network_site_index_stmt;

SET @network_site_fk_exists = (
    SELECT COUNT(*)
    FROM information_schema.REFERENTIAL_CONSTRAINTS
    WHERE CONSTRAINT_SCHEMA = DATABASE()
      AND CONSTRAINT_NAME = 'fk_network_devices_site'
);
SET @network_site_fk_sql = IF(
    @network_site_fk_exists = 0,
    'ALTER TABLE `network_devices` ADD CONSTRAINT `fk_network_devices_site` FOREIGN KEY (`site_id`) REFERENCES `network_sites` (`id`) ON DELETE SET NULL',
    'SELECT 1'
);
PREPARE network_site_fk_stmt FROM @network_site_fk_sql;
EXECUTE network_site_fk_stmt;
DEALLOCATE PREPARE network_site_fk_stmt;
