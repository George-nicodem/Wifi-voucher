<?php
declare(strict_types=1);

global $conn;

$onlineSchemaReady = false;
$feedOnline = false;
$lastChecked = '';
$onlineUsers = [];
$endingSoonCount = 0;

try {
    $sessionSchema = $conn->query('SELECT voucher_code, device_mac, device_ip, access_point, hotspot_server, joined_at, online_for_seconds, last_seen_at FROM network_online_sessions LIMIT 0');
    $feedSchema = $conn->query('SELECT connection_status, last_seen_at FROM network_agent_status LIMIT 0');
    $onlineSchemaReady = $sessionSchema !== false && $feedSchema !== false;

    if ($sessionSchema instanceof mysqli_result) $sessionSchema->free();
    if ($feedSchema instanceof mysqli_result) $feedSchema->free();
} catch (Throwable) {
    $onlineSchemaReady = false;
}

if ($onlineSchemaReady) {
    try {
        $feedResult = $conn->query("SELECT connection_status, last_seen_at,
                CASE WHEN last_seen_at IS NOT NULL AND last_seen_at >= DATE_SUB(NOW(), INTERVAL 90 SECOND) THEN 1 ELSE 0 END AS is_fresh
            FROM network_agent_status WHERE id = 1 LIMIT 1");
        $feed = $feedResult ? ($feedResult->fetch_assoc() ?: null) : null;
        if ($feedResult instanceof mysqli_result) $feedResult->free();

        $feedOnline = is_array($feed)
            && (string)($feed['connection_status'] ?? '') === 'online'
            && (int)($feed['is_fresh'] ?? 0) === 1;
        $lastChecked = is_array($feed) ? trim((string)($feed['last_seen_at'] ?? '')) : '';

        if ($feedOnline) {
            $onlineSql = "SELECT s.voucher_code, s.device_mac, s.device_ip, s.access_point, s.hotspot_server,
                    s.joined_at, s.online_for_seconds, s.last_seen_at, v.expires_at,
                    pk.name AS package_name,
                    (SELECT pay.phone FROM payments pay
                        WHERE pay.voucher_id = v.id AND pay.status = 'SUCCESS'
                        ORDER BY pay.paid_at DESC LIMIT 1) AS phone,
                    CASE WHEN v.expires_at IS NULL THEN NULL
                        ELSE GREATEST(0, TIMESTAMPDIFF(SECOND, NOW(), v.expires_at)) END AS time_left_seconds
                FROM network_online_sessions s
                LEFT JOIN vouchers v ON v.code = s.voucher_code
                LEFT JOIN packages pk ON pk.id = v.package_id
                WHERE s.last_seen_at >= DATE_SUB(NOW(), INTERVAL 90 SECOND)
                ORDER BY s.joined_at DESC LIMIT 500";
            $onlineResult = $conn->query($onlineSql);
            if ($onlineResult instanceof mysqli_result) {
                while ($row = $onlineResult->fetch_assoc()) $onlineUsers[] = $row;
                $onlineResult->free();
            }

            $endingSoonCount = count(array_filter($onlineUsers, static fn(array $row): bool =>
                $row['time_left_seconds'] !== null
                && (int)$row['time_left_seconds'] > 0
                && (int)$row['time_left_seconds'] <= 300
            ));
        }
    } catch (Throwable $exception) {
        error_log('Online Now could not load current sessions: ' . $exception->getMessage());
        $feedOnline = false;
        $onlineUsers = [];
        $endingSoonCount = 0;
    }
}

$formatDuration = static function (int $seconds): string {
    $seconds = max(0, $seconds);
    $hours = intdiv($seconds, 3600);
    $minutes = intdiv($seconds % 3600, 60);
    $remainingSeconds = $seconds % 60;
    if ($hours > 0) return $hours . 'h ' . $minutes . 'm';
    if ($minutes > 0) return $minutes . 'm ' . $remainingSeconds . 's';
    return $remainingSeconds . 's';
};

$onlineLastCheckedLabel = '—';
if ($feedOnline && $lastChecked !== '') {
    $lastCheckedTimestamp = strtotime($lastChecked);
    if ($lastCheckedTimestamp !== false) $onlineLastCheckedLabel = date('g:i:s A', $lastCheckedTimestamp);
}
?>
<style>
.online-page{--on-ink:#1b2b45;--on-muted:#718096;--on-line:#e7edf4;color:var(--on-ink)}
.online-head{display:flex;align-items:center;justify-content:space-between;gap:14px;margin:4px 0 19px}
.online-title{margin:0;color:#17233b;font-size:27px;font-weight:850;letter-spacing:-.04em}
.online-subtitle{margin:6px 0 0;color:var(--on-muted);font-size:13px;line-height:1.5}
.online-refresh{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:40px;padding:0 14px;border:1px solid #dfe8f1;border-radius:10px;background:#fff;color:#42536c;text-decoration:none;font-size:12px;font-weight:800}
.online-refresh:hover{background:#f6f9fc}
.online-overview{position:relative;overflow:hidden;margin-bottom:16px;padding:22px;border:1px solid #e3ebf5;border-radius:18px;background:linear-gradient(125deg,#f6fbff,#edf5ff 55%,#f8fbff);box-shadow:0 10px 28px #315a8a0b}
.online-overview:after{position:absolute;right:-95px;top:-170px;width:320px;height:320px;border:1px solid #2b6fc21a;border-radius:50%;content:"";pointer-events:none}
.online-overview-top{position:relative;z-index:1;display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}
.online-state{display:inline-flex;align-items:center;gap:8px;color:#61718a;font-size:11px;font-weight:800}
.online-state i{width:8px;height:8px;border-radius:50%;background:#d2a23e;box-shadow:0 0 0 4px #d2a23e20}
.online-state.is-live{color:#24814e}.online-state.is-live i{background:#2d9c68;box-shadow:0 0 0 4px #2d9c681c}
.online-count-label{color:#72819a;font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}
.online-overview h2{position:relative;z-index:1;margin:15px 0 3px;color:#1a3456;font-size:23px;font-weight:850;letter-spacing:-.035em}
.online-overview p{position:relative;z-index:1;margin:0;color:#77869d;font-size:12px}
.online-metrics{position:relative;z-index:1;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:18px}
.online-metric{min-width:0;padding:14px 15px;border:1px solid #e4edf8;border-radius:12px;background:#ffffffd9}
.online-metric span{display:block;color:#7b8aa2;font-size:9px;font-weight:850;letter-spacing:.07em}
.online-metric strong{display:block;margin-top:6px;color:#1d3c67;font-size:25px;line-height:1.1}
.online-metric small{display:block;margin-top:4px;color:#8391a5;font-size:10px}
.online-checked{position:relative;z-index:1;display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-top:12px;color:#7b8aa2;font-size:10px}
.online-card{min-width:0;margin-bottom:16px;padding:18px;border:1px solid var(--on-line);border-radius:16px;background:#fff;box-shadow:0 8px 24px #1c315008}
.online-card-heading{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:13px}
.online-card-heading h3{margin:0;color:#263750;font-size:15px;font-weight:850}
.online-card-heading p{margin:4px 0 0;color:#7f8ba0;font-size:11px}
.online-live-pill{display:inline-flex;align-items:center;gap:7px;padding:6px 9px;border:1px solid #cfead9;border-radius:30px;background:#f2fbf5;color:#358054;font-size:9px;font-weight:850;text-transform:uppercase;letter-spacing:.06em}
.online-live-pill i{width:6px;height:6px;border-radius:50%;background:#2d9c68}
.online-table-wrap{width:100%;overflow:auto;border:1px solid #edf0f5;border-radius:11px}
.online-table{width:100%;min-width:860px;border-collapse:collapse;font-size:11px}
.online-table th,.online-table td{padding:12px 11px;border-bottom:1px solid #edf1f5;text-align:left;white-space:nowrap}
.online-table th{background:#f8fafc;color:#78869b;font-size:9px;font-weight:850;letter-spacing:.06em;text-transform:uppercase}
.online-table tbody tr:last-child td{border-bottom:0}.online-table tbody tr:hover{background:#fbfdff}.online-table td{color:#45546a}
.online-primary{display:block;color:#34445d;font-weight:800}.online-secondary{display:block;margin-top:3px;color:#8b96a7;font-size:9px}
.online-package{color:#263750;font-weight:750}.online-time{color:#586a82;font-variant-numeric:tabular-nums;font-weight:750}.online-time-left{color:#285fac;font-variant-numeric:tabular-nums;font-weight:850}.online-time-left.is-ending{color:#b7791f}
.online-empty{padding:38px 18px;text-align:center}.online-empty-icon{display:grid;width:48px;height:48px;margin:0 auto 12px;place-items:center;border-radius:15px;background:#eff6ff;color:#3678c9;font-size:18px}.online-empty h3{margin:0 0 5px;color:#293a53;font-size:15px}.online-empty p{max-width:450px;margin:0 auto;color:#8190a4;font-size:12px;line-height:1.55}
.online-schema-note{padding:16px 18px;border:1px solid #f0d89f;border-radius:12px;background:#fff8e9;color:#745311;font-size:12px;line-height:1.55}
@media(max-width:700px){.online-head{align-items:flex-start;flex-direction:column}.online-refresh{width:100%}.online-overview{padding:17px}.online-overview h2{font-size:21px}.online-metrics{grid-template-columns:1fr;gap:8px}.online-metric{display:grid;grid-template-columns:1fr auto;align-items:center;column-gap:10px;padding:12px}.online-metric span,.online-metric small{grid-column:1}.online-metric strong{grid-column:2;grid-row:1/3;margin:0;font-size:22px}.online-card{padding:13px}.online-checked{display:block;line-height:1.7}}
</style>
<main class="online-page" aria-labelledby="onlineTitle">
    <header class="online-head">
        <div>
            <h1 class="online-title" id="onlineTitle"><i class="fa-solid fa-users-viewfinder" aria-hidden="true"></i> Online Now</h1>
            <p class="online-subtitle">Customers currently using your Wi-Fi and the time remaining on their packages.</p>
        </div>
        <a class="online-refresh" href="<?= e(appUrl('admin/dashboard.php?page=online_now')) ?>"><i class="fa-solid fa-rotate-right" aria-hidden="true"></i> Refresh</a>
    </header>

    <?php if (!$onlineSchemaReady): ?>
        <section class="online-schema-note"><strong>Online data setup is incomplete.</strong> Ask the administrator to install the Online Now session tables in this application database.</section>
    <?php else: ?>
        <section class="online-overview" aria-label="Online overview">
            <div class="online-overview-top">
                <span class="online-state <?= $feedOnline ? 'is-live' : '' ?>"><i aria-hidden="true"></i><?= $feedOnline ? 'Live data connected' : 'Waiting for live data' ?></span>
                <span class="online-count-label">Current Wi-Fi activity</span>
            </div>
            <h2><?= number_format(count($onlineUsers)) ?> connected</h2>
            <p>Active customer sessions are listed below.</p>
            <div class="online-metrics">
                <div class="online-metric"><span>CONNECTED CUSTOMERS</span><strong><?= number_format(count($onlineUsers)) ?></strong><small>Customers with a current Wi-Fi session</small></div>
                <div class="online-metric"><span>ENDING IN 5 MINUTES</span><strong><?= number_format($endingSoonCount) ?></strong><small>Vouchers with five minutes or less remaining</small></div>
            </div>
            <div class="online-checked"><span>Last data update: <?= e($onlineLastCheckedLabel) ?></span><span>This page refreshes every minute</span></div>
        </section>

        <section class="online-card" aria-label="Connected customers">
            <header class="online-card-heading">
                <div><h3>Connected customers</h3><p><?= number_format(count($onlineUsers)) ?> active sessions</p></div>
                <?php if ($feedOnline): ?><span class="online-live-pill"><i aria-hidden="true"></i> Live</span><?php endif; ?>
            </header>
            <?php if (!$feedOnline): ?>
                <div class="online-empty"><span class="online-empty-icon"><i class="fa-solid fa-wifi" aria-hidden="true"></i></span><h3>Waiting for live session data</h3><p>Customer sessions will appear here when the Wi-Fi system begins sending current connection information.</p></div>
            <?php elseif (!$onlineUsers): ?>
                <div class="online-empty"><span class="online-empty-icon"><i class="fa-solid fa-user-slash" aria-hidden="true"></i></span><h3>No customers online right now</h3><p>Customers with active sessions will appear here as they connect.</p></div>
            <?php else: ?>
                <div class="online-table-wrap"><table class="online-table"><thead><tr><th>Customer</th><th>Package</th><th>Device</th><th>Access point</th><th>Joined</th><th>Online for</th><th>Time left</th></tr></thead><tbody>
                    <?php foreach ($onlineUsers as $onlineUser): ?>
                        <?php
                        $joinedTimestamp = strtotime((string)($onlineUser['joined_at'] ?? ''));
                        $deviceLabel = trim((string)($onlineUser['device_mac'] ?? ''));
                        if ($deviceLabel === '') $deviceLabel = trim((string)($onlineUser['device_ip'] ?? ''));
                        if ($deviceLabel === '') $deviceLabel = 'Device not reported';
                        $deviceIp = trim((string)($onlineUser['device_ip'] ?? ''));
                        $accessPointLabel = trim((string)($onlineUser['access_point'] ?? ''));
                        if ($accessPointLabel === '') $accessPointLabel = trim((string)($onlineUser['hotspot_server'] ?? ''));
                        if ($accessPointLabel === '') $accessPointLabel = 'Not reported';
                        $timeLeft = $onlineUser['time_left_seconds'] === null ? null : max(0, (int)$onlineUser['time_left_seconds']);
                        ?>
                        <tr>
                            <td><span class="online-primary"><?= e((string)($onlineUser['phone'] ?: 'Wi-Fi customer')) ?></span><span class="online-secondary">Voucher <?= e((string)$onlineUser['voucher_code']) ?></span></td>
                            <td><span class="online-package"><?= e((string)($onlineUser['package_name'] ?: 'Package not found')) ?></span></td>
                            <td><span class="online-primary"><?= e($deviceLabel) ?></span><?php if ($deviceIp !== '' && $deviceIp !== $deviceLabel): ?><span class="online-secondary"><?= e($deviceIp) ?></span><?php endif; ?></td>
                            <td><?= e($accessPointLabel) ?></td>
                            <td><?= $joinedTimestamp === false ? '—' : e(date('g:i A', $joinedTimestamp)) ?></td>
                            <td><span class="online-time" data-seconds="<?= max(0, (int)$onlineUser['online_for_seconds']) ?>" data-count-up="true"><?= e($formatDuration((int)$onlineUser['online_for_seconds'])) ?></span></td>
                            <td><?php if ($timeLeft === null): ?><span class="online-time-left">No expiry</span><?php else: ?><span class="online-time-left <?= $timeLeft <= 300 ? 'is-ending' : '' ?>" data-seconds="<?= $timeLeft ?>"><?= e($formatDuration($timeLeft)) ?></span><?php endif; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody></table></div>
            <?php endif; ?>
        </section>
    <?php endif; ?>
</main>
<script>
(() => {
    const page = document.querySelector('.online-page');
    if (!page) return;
    const format = (seconds) => {
        seconds = Math.max(0, Math.floor(seconds));
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const rest = seconds % 60;
        if (hours) return `${hours}h ${minutes}m`;
        if (minutes) return `${minutes}m ${rest}s`;
        return `${rest}s`;
    };
    const counters = [...page.querySelectorAll('[data-seconds]')].map((element) => ({
        element,
        seconds: Number(element.dataset.seconds) || 0,
        countUp: element.dataset.countUp === 'true'
    }));
    window.setInterval(() => {
        counters.forEach((counter) => {
            counter.seconds = Math.max(0, counter.seconds + (counter.countUp ? 1 : -1));
            counter.element.textContent = format(counter.seconds);
        });
    }, 1000);
    window.setTimeout(() => {
        if (document.visibilityState === 'visible') window.location.reload();
    }, 60000);
})();
</script>
