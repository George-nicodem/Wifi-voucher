<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/admin_auth.php';
requireAdminLogin();

global $conn;
$errors = [];
$success = '';
$settings = ['enabled' => 1, 'duration_minutes' => 5, 'cooldown_days' => 7];
$tableReady = false;

try {
    $result = $conn->query('SELECT enabled, duration_minutes, cooldown_days FROM trial_settings WHERE id = 1');
    if ($result) {
        $row = $result->fetch_assoc();
        if ($row) {
            $settings = [
                'enabled' => (int)$row['enabled'],
                'duration_minutes' => (int)$row['duration_minutes'],
                'cooldown_days' => (int)$row['cooldown_days'],
            ];
            $tableReady = true;
        }
    }
} catch (Throwable $exception) {
    error_log('Trial settings load: ' . $exception->getMessage());
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    requireAdminPostWithCsrf();
    if (!$tableReady) {
        $errors[] = 'Run admin/database/trial_voucher.sql first, then reload this page.';
    } else {
        $enabled = isset($_POST['enabled']) ? 1 : 0;
        $duration = filter_var($_POST['duration_minutes'] ?? null, FILTER_VALIDATE_INT);
        $cooldown = filter_var($_POST['cooldown_days'] ?? null, FILTER_VALIDATE_INT);
        if ($duration === false || $duration < 1 || $duration > 60) {
            $errors[] = 'Trial duration must be between 1 and 60 minutes.';
        }
        if ($cooldown === false || $cooldown < 1 || $cooldown > 365) {
            $errors[] = 'The cooldown must be between 1 and 365 days.';
        }
        if (!$errors) {
            $stmt = $conn->prepare('UPDATE trial_settings SET enabled = ?, duration_minutes = ?, cooldown_days = ? WHERE id = 1');
            if (!$stmt) {
                $errors[] = 'Unable to prepare the trial changes.';
            } else {
                $stmt->bind_param('iii', $enabled, $duration, $cooldown);
                if ($stmt->execute()) {
                    $settings = ['enabled' => $enabled, 'duration_minutes' => $duration, 'cooldown_days' => $cooldown];
                    $success = 'Trial settings have been saved.';
                } else {
                    $errors[] = 'Unable to save the settings. Check the database settings and try again.';
                }
                $stmt->close();
            }
        }
    }
}

$css = function_exists('appUrl') ? appUrl('admin/modules/trial_settings/trial-settings.css?v=1') : 'modules/trial_settings/trial-settings.css?v=1';
echo '<link rel="stylesheet" href="' . e($css) . '">';
?>
<section class="trial-admin">
    <header class="trial-admin-head">
        <div><span class="trial-admin-kicker">WI-FI ACCESS</span><h1>Trial Wi-Fi</h1><p>Set the trial duration and how long a device must wait before requesting another trial.</p></div>
        <div class="trial-admin-icon"><i class="fa-solid fa-stopwatch"></i></div>
    </header>

    <?php foreach ($errors as $message): ?><div class="trial-alert trial-alert-error"><?= e($message) ?></div><?php endforeach; ?>
    <?php if ($success !== ''): ?><div class="trial-alert trial-alert-success"><?= e($success) ?></div><?php endif; ?>

    <?php if (!$tableReady): ?>
        <div class="trial-alert trial-alert-warn"><strong>Database setup is required.</strong><br>Run <code>admin/database/trial_voucher.sql</code> on the selected system database, then reload this page.</div>
    <?php endif; ?>

    <form class="trial-admin-card" method="post" action="<?= e(function_exists('appUrl') ? appUrl('admin/dashboard.php?page=trial_settings') : 'dashboard.php?page=trial_settings') ?>">
        <?= csrfField() ?>
        <div class="trial-admin-card-title"><span class="trial-admin-icon small"><i class="fa-solid fa-sliders"></i></span><div><h2>Trial Settings</h2><p>These changes do not affect sales records or regular vouchers.</p></div></div>
        <label class="trial-toggle"><input type="checkbox" name="enabled" value="1" <?= $settings['enabled'] ? 'checked' : '' ?> <?= !$tableReady ? 'disabled' : '' ?>><span><strong>Enable trial</strong><small>Disable this to prevent new trial requests.</small></span></label>
        <div class="trial-fields">
            <div class="trial-field"><label for="duration_minutes">Trial duration</label><div class="trial-input-wrap"><input id="duration_minutes" name="duration_minutes" type="number" min="1" max="60" value="<?= (int)$settings['duration_minutes'] ?>" required <?= !$tableReady ? 'disabled' : '' ?>><span>minutes</span></div><small>The duration starts when a customer clicks “Request trial”.</small></div>
            <div class="trial-field"><label for="cooldown_days">Wait time before a device can try again</label><div class="trial-input-wrap"><input id="cooldown_days" name="cooldown_days" type="number" min="1" max="365" value="<?= (int)$settings['cooldown_days'] ?>" required <?= !$tableReady ? 'disabled' : '' ?>><span>days</span></div><small>Checks the browser token and MAC address sent by the captive portal.</small></div>
        </div>
        <button class="trial-save" type="submit" <?= !$tableReady ? 'disabled' : '' ?>><i class="fa-solid fa-floppy-disk"></i> Save Settings</button>
    </form>

    <aside class="trial-admin-note"><i class="fa-solid fa-circle-info"></i><p><strong>The router is not connected yet.</strong> The system can record a trial and prevent another request during the configured cooldown. Router/Omada integration requires an adapter to provide internet access and disconnect devices automatically when the trial expires.</p></aside>
</section>
