-- MikroTik main gateway configuration for the selected application database.
-- Safe to run more than once. Credentials are encrypted by the PHP application.

CREATE TABLE IF NOT EXISTS network_gateway_settings (
    id TINYINT UNSIGNED NOT NULL,
    name VARCHAR(100) NOT NULL DEFAULT 'Main MikroTik Gateway',
    management_host VARCHAR(253) NOT NULL,
    api_port SMALLINT UNSIGNED NOT NULL DEFAULT 8729,
    api_tls TINYINT(1) NOT NULL DEFAULT 1,
    api_username_enc TEXT NOT NULL,
    api_password_enc TEXT NOT NULL,
    config_status ENUM('draft', 'enabled', 'disabled') NOT NULL DEFAULT 'draft',
    connection_status ENUM('not_connected', 'connected', 'failed') NOT NULL DEFAULT 'not_connected',
    last_connected_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
