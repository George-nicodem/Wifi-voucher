<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';

requireAdminLogin();
global $conn;

$profileId = max(0, getInt('id', 0) ?? 0);
if ($profileId <= 0 || !routerAdminSchemaReady($conn)) {
    http_response_code(404);
    exit('Wi-Fi profile was not found.');
}

$stmt = $conn->prepare('SELECT p.id, p.name, p.platform, p.device_family, p.device_model, p.hardware_version, p.firmware_version, p.ssid, p.access_mode, p.vlan_id, p.gateway_ip, p.portal_url, p.status, p.wan_connection_type, p.wan_ip_address, p.wan_subnet_cidr, p.wan_gateway_ip, p.pppoe_username, CASE WHEN NULLIF(p.pppoe_password_enc, "") IS NULL THEN 0 ELSE 1 END AS pppoe_password_saved, p.lan_subnet_cidr, p.dhcp_enabled, p.dhcp_start_ip, p.dhcp_end_ip, p.dns_primary, p.dns_secondary, c.name AS controller_name FROM wifi_network_profiles p LEFT JOIN network_controllers c ON c.id = p.controller_id WHERE p.id = ? LIMIT 1');
if (!$stmt) {
    logDatabaseError($conn, 'Preparing Wi-Fi profile configuration download');
    http_response_code(500);
    exit('The configuration could not be generated.');
}
$stmt->bind_param('i', $profileId);
$stmt->execute();
$profile = $stmt->get_result()?->fetch_assoc();
$stmt->close();
if (!$profile) {
    http_response_code(404);
    exit('Wi-Fi profile was not found.');
}

$isOmada = (string)$profile['platform'] === 'omada';
$usesVoucher = (string)$profile['access_mode'] === 'voucher_portal';
$format = getString('format', 'json');
if (!in_array($format, ['json', 'guide'], true)) {
    http_response_code(400);
    exit('The download type was not recognized.');
}

if ($format === 'guide') {
    $safeText = static function ($value, string $fallback = 'Not set'): string {
        $value = trim((string)($value ?? ''));
        if ($value === '') {
            return $fallback;
        }
        return preg_replace('/[\r\n\t]+/u', ' ', $value) ?? $fallback;
    };
    $families = [
        'omada_eap' => 'Omada EAP / Access Point',
        'omada_gateway' => 'Omada Gateway',
        'archer' => 'TP-Link Archer',
        'deco' => 'TP-Link Deco',
        'tl_wr' => 'TP-Link TL-WR',
        'tl_mr' => 'TP-Link TL-MR / 4G LTE',
        'dsl' => 'TP-Link DSL',
        'cellular' => 'TP-Link 4G / 5G',
        'mikrotik_router' => 'MikroTik RouterOS',
        'mikrotik_ap' => 'MikroTik Access Point',
        'mikrotik_lte' => 'MikroTik LTE / 5G Gateway',
        'mikrotik_other' => 'Other MikroTik',
        'other' => 'Other / not selected',
    ];
    $family = (string)$profile['device_family'];
    $familyLabel = $families[$family] ?? $safeText($family);
    $platformLabel = (string)$profile['platform'] === 'mikrotik' ? 'MikroTik RouterOS' : ($isOmada ? 'TP-Link Omada' : 'TP-Link');
    $modeLabel = $usesVoucher ? 'Voucher / Captive Portal' : 'Guest Wi-Fi';
    $gatewayOwner = $family === 'omada_gateway'
        ? 'Omada Gateway (if this gateway will manage DHCP)'
        : (in_array($family, ['mikrotik_router', 'mikrotik_lte'], true)
            ? 'MikroTik RouterOS (if this device will be the network gateway)'
            : 'a separate gateway/router selected for this network');
    $guideLines = [
        'WI-FI VOUCHER — SETUP GUIDE',
        str_repeat('=', 48),
        'This draft guide is based on the Wi-Fi profile. It is not a router import file or device backup, and it does not apply changes to the device.',
        '',
        'PROFILE',
        'Name: ' . $safeText($profile['name']),
        'SSID: ' . $safeText($profile['ssid']),
        'Platform: ' . $platformLabel,
        'Device family: ' . $familyLabel,
        'Model: ' . $safeText($profile['device_model']),
        'Different models can be stored in separate profiles or devices.',
        'Hardware version: ' . $safeText($profile['hardware_version']),
        'Firmware version: ' . $safeText($profile['firmware_version']),
        'Wi-Fi Mode: ' . $modeLabel,
        'VLAN ID: ' . ($profile['vlan_id'] !== null ? (string)(int)$profile['vlan_id'] : 'Not set'),
        'Gateway IP: ' . $safeText($profile['gateway_ip']),
        'WAN connection type: ' . strtoupper((string)$profile['wan_connection_type']),
        'WAN IP/Subnet/Gateway: ' . implode(' / ', array_map($safeText, [$profile['wan_ip_address'], $profile['wan_subnet_cidr'], $profile['wan_gateway_ip']])),
        'PPPoE username: ' . ((string)$profile['pppoe_username'] !== '' ? 'Set (value hidden in this guide).' : 'Not set'),
        'PPPoE password: ' . ((int)$profile['pppoe_password_saved'] === 1 ? 'Stored encrypted; not included in this guide.' : 'Not set'),
        'LAN subnet: ' . $safeText($profile['lan_subnet_cidr']),
        'DHCP: ' . ((int)$profile['dhcp_enabled'] === 1 ? 'Enabled' : 'Disabled'),
        'DHCP pool: ' . implode(' – ', array_map($safeText, [$profile['dhcp_start_ip'], $profile['dhcp_end_ip']])),
        'DNS: ' . implode(' / ', array_map($safeText, [$profile['dns_primary'], $profile['dns_secondary']])),
        'Omada Controller: ' . $safeText($profile['controller_name']),
        'Portal URL: ' . $safeText($profile['portal_url'], $usesVoucher ? 'Not set yet' : 'Not applicable'),
        'Recommended DHCP owner: ' . $gatewayOwner,
        '',
        'SETUP STEPS AFTER RECEIVING THE DEVICE',
        '1. Compare the model, hardware version, and firmware with the manufacturer\'s official guide. Make sure the device supports the features you need, especially a captive/external portal for vouchers.',
        '2. Back up the router/controller before changing settings. Use official firmware and change the administrator password.',
        '3. Configure WAN mode, PPPoE, or static IP using the details from your ISP. The PPPoE password is encrypted in the database and is not included in this file.',
        '4. Configure the LAN subnet and DHCP pool. Enable DHCP on only one gateway for this network/VLAN to prevent address conflicts.',
        '5. Configure the SSID shown above. Choose Wi-Fi security and a password during setup; the Wi-Fi password is not stored in this profile.',
        '6. If a VLAN ID is set, make sure the router/gateway, switch, and all access points support it and are configured for that VLAN.',
        '7. For the voucher portal, make sure the Portal URL can be reached from phones connected to Wi-Fi. A localhost address cannot be reached by other devices.',
        '8. Connect one device first and test getting an IP address, opening the portal, starting a payment, receiving a voucher, and signing in before adding more devices.',
        '',
        'DRAFT LIMITATIONS',
        '- Captive portal support varies by model and firmware. Do not use instructions for another device without verifying them.',
        '- The system does not currently connect to or push configuration to a router/controller.',
        '- Captive portal support and final device verification will be integrated after the exact model is selected and the hardware is tested.',
    ];
    $guide = implode("\r\n", $guideLines) . "\r\n";
    $safeName = preg_replace('/[^A-Za-z0-9_-]+/', '-', (string)$profile['name']) ?: 'wifi-profile';
    $safeName = strtolower(trim($safeName, '-_')) ?: 'wifi-profile';
    header('Content-Type: text/plain; charset=utf-8');
    header('Content-Disposition: attachment; filename="wifi-setup-guide-' . $safeName . '.txt"');
    header('Content-Length: ' . strlen($guide));
    header('Cache-Control: no-store, private');
    header('X-Content-Type-Options: nosniff');
    echo $guide;
    exit;
}

$configuration = [
    'format' => 'wifi-voucher-network-config',
    'format_version' => 2,
    'generated_at' => date(DATE_ATOM),
    'profile' => [
        'id' => (int)$profile['id'],
        'name' => (string)$profile['name'],
        'status' => (string)$profile['status'],
    ],
    'platform' => [
        'type' => (string)$profile['platform'],
        'device_family' => (string)$profile['device_family'],
        'model' => $profile['device_model'] !== '' ? (string)$profile['device_model'] : null,
        'hardware_version' => $profile['hardware_version'] !== '' ? (string)$profile['hardware_version'] : null,
        'firmware_version' => $profile['firmware_version'] !== '' ? (string)$profile['firmware_version'] : null,
        'controller_name' => $profile['controller_name'] !== '' ? (string)$profile['controller_name'] : null,
    ],
    'wifi' => [
        'ssid' => (string)$profile['ssid'],
        'access_mode' => (string)$profile['access_mode'],
        'vlan_id' => $profile['vlan_id'] !== null ? (int)$profile['vlan_id'] : null,
    ],
    'network' => [
        'wan' => [
            'connection_type' => (string)$profile['wan_connection_type'],
            'ip_address' => $profile['wan_ip_address'] !== '' ? (string)$profile['wan_ip_address'] : null,
            'subnet_cidr' => $profile['wan_subnet_cidr'] !== '' ? (string)$profile['wan_subnet_cidr'] : null,
            'gateway_ip' => $profile['wan_gateway_ip'] !== '' ? (string)$profile['wan_gateway_ip'] : null,
            'pppoe_username_configured' => (string)$profile['pppoe_username'] !== '',
            'pppoe_password_configured' => (bool)$profile['pppoe_password_saved'],
        ],
        'lan' => [
            'subnet_cidr' => $profile['lan_subnet_cidr'] !== '' ? (string)$profile['lan_subnet_cidr'] : null,
            'gateway_ip' => $profile['gateway_ip'] !== '' ? (string)$profile['gateway_ip'] : null,
            'dhcp_enabled' => (bool)$profile['dhcp_enabled'],
            'dhcp_start_ip' => $profile['dhcp_start_ip'] !== '' ? (string)$profile['dhcp_start_ip'] : null,
            'dhcp_end_ip' => $profile['dhcp_end_ip'] !== '' ? (string)$profile['dhcp_end_ip'] : null,
            'dns_primary' => $profile['dns_primary'] !== '' ? (string)$profile['dns_primary'] : null,
            'dns_secondary' => $profile['dns_secondary'] !== '' ? (string)$profile['dns_secondary'] : null,
        ],
        'dhcp_routing_owner' => match ((string)$profile['device_family']) {
            'omada_gateway' => 'omada_network_gateway',
            'mikrotik_router', 'mikrotik_lte' => 'mikrotik_routeros_gateway',
            default => 'separate_hotspot_gateway_or_tp_link_device',
        },
    ],
    'captive_portal' => [
        'enabled' => $usesVoucher,
        'authentication' => !$usesVoucher ? 'none' : match ((string)$profile['platform']) {
            'omada' => 'external_portal_draft',
            'mikrotik' => 'routeros_hotspot_draft',
            default => 'upstream_hotspot_gateway',
        },
        'portal_url' => $usesVoucher && $profile['portal_url'] !== '' ? (string)$profile['portal_url'] : null,
    ],
    'setup_status' => 'draft_not_deployed',
    'setup_note' => 'This is a Wi-Fi configuration profile for the system. It is not a router backup/import file and does not apply changes. The PPPoE password is not included in the JSON. Verify the model/firmware capabilities and complete device integration before deployment.',
];

try {
    $json = json_encode($configuration, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR) . "\r\n";
} catch (JsonException) {
    http_response_code(500);
    exit('The configuration could not be generated.');
}
$safeName = preg_replace('/[^A-Za-z0-9_-]+/', '-', (string)$profile['name']) ?: 'wifi-profile';
$safeName = strtolower(trim($safeName, '-_')) ?: 'wifi-profile';
header('Content-Type: application/json; charset=utf-8');
header('Content-Disposition: attachment; filename="wifi-config-' . $safeName . '.json"');
header('Content-Length: ' . strlen($json));
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');
echo $json;
