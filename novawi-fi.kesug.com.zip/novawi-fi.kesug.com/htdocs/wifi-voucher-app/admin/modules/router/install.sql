-- Additive network/router setup tables for the database selected by the application.
-- This does not alter packages, vouchers, payments, or existing application tables.

CREATE TABLE IF NOT EXISTS network_controllers (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    controller_type ENUM('software', 'hardware', 'cloud') NOT NULL DEFAULT 'software',
    base_url VARCHAR(500) NULL,
    site_id VARCHAR(120) NULL,
    api_client_key_enc TEXT NULL,
    api_client_secret_enc TEXT NULL,
    status ENUM('draft', 'enabled', 'disabled') NOT NULL DEFAULT 'draft',
    connection_status ENUM('not_connected', 'connected', 'failed') NOT NULL DEFAULT 'not_connected',
    last_connected_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_network_controllers_status (status, connection_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS network_gateway_settings (
    id TINYINT UNSIGNED NOT NULL,
    name VARCHAR(100) NOT NULL DEFAULT 'Main MikroTik Gateway',
    management_host VARCHAR(253) NOT NULL,
    api_port SMALLINT UNSIGNED NOT NULL DEFAULT 8729,
    api_tls TINYINT(1) NOT NULL DEFAULT 1,
    api_username_enc TEXT NOT NULL,
    api_password_enc TEXT NOT NULL,
    config_status ENUM('draft', 'enabled', 'disabled') NOT NULL DEFAULT 'draft',
    connection_status ENUM('not_connected', 'connected', 'failed') NOT NULL DEFAULT 'not_connected',
    last_connected_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wifi_network_profiles (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    platform ENUM('tp_link', 'omada', 'mikrotik') NOT NULL,
    device_family VARCHAR(60) NOT NULL,
    device_model VARCHAR(100) NULL,
    hardware_version VARCHAR(50) NULL,
    firmware_version VARCHAR(80) NULL,
    ssid VARCHAR(32) NOT NULL,
    access_mode ENUM('voucher_portal', 'guest_wifi') NOT NULL DEFAULT 'voucher_portal',
    vlan_id SMALLINT UNSIGNED NULL,
    gateway_ip VARCHAR(45) NULL,
    portal_url VARCHAR(500) NULL,
    wan_connection_type ENUM('dhcp', 'static', 'pppoe') NOT NULL DEFAULT 'dhcp',
    wan_ip_address VARCHAR(45) NULL,
    wan_subnet_cidr VARCHAR(43) NULL,
    wan_gateway_ip VARCHAR(45) NULL,
    pppoe_username VARCHAR(190) NULL,
    pppoe_password_enc TEXT NULL,
    lan_subnet_cidr VARCHAR(43) NULL,
    dhcp_enabled TINYINT(1) NOT NULL DEFAULT 0,
    dhcp_start_ip VARCHAR(45) NULL,
    dhcp_end_ip VARCHAR(45) NULL,
    dns_primary VARCHAR(45) NULL,
    dns_secondary VARCHAR(45) NULL,
    controller_id BIGINT UNSIGNED NULL,
    status ENUM('draft', 'ready', 'archived') NOT NULL DEFAULT 'draft',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_wifi_profiles_platform_status (platform, status),
    KEY idx_wifi_profiles_controller (controller_id),
    CONSTRAINT fk_wifi_profile_controller FOREIGN KEY (controller_id)
        REFERENCES network_controllers (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS network_devices (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    controller_id BIGINT UNSIGNED NULL,
    platform ENUM('tp_link', 'omada', 'mikrotik') NOT NULL,
    role ENUM('access_point', 'gateway', 'router', 'other') NOT NULL DEFAULT 'access_point',
    device_family VARCHAR(60) NOT NULL,
    device_model VARCHAR(100) NOT NULL,
    hardware_version VARCHAR(50) NULL,
    firmware_version VARCHAR(80) NULL,
    management_ip VARCHAR(45) NULL,
    serial_number VARCHAR(100) NULL,
    mac_address VARCHAR(17) NULL,
    status ENUM('planned', 'online', 'offline', 'disabled') NOT NULL DEFAULT 'planned',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_network_devices_status (status),
    KEY idx_network_devices_controller (controller_id),
    CONSTRAINT fk_network_device_controller FOREIGN KEY (controller_id)
        REFERENCES network_controllers (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS network_deployments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    controller_id BIGINT UNSIGNED NULL,
    profile_id BIGINT UNSIGNED NULL,
    status ENUM('draft', 'queued', 'applied', 'failed') NOT NULL DEFAULT 'draft',
    summary VARCHAR(500) NOT NULL DEFAULT 'Waiting for network hardware and controller connection.',
    attempted_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_network_deployments_status_created (status, created_at),
    KEY idx_network_deployments_profile (profile_id),
    CONSTRAINT fk_network_deployment_controller FOREIGN KEY (controller_id)
        REFERENCES network_controllers (id) ON DELETE SET NULL,
    CONSTRAINT fk_network_deployment_profile FOREIGN KEY (profile_id)
        REFERENCES wifi_network_profiles (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
