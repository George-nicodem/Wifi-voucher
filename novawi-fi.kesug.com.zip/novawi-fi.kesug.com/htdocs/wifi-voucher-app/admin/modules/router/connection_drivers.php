<?php
declare(strict_types=1);

/** Protocol selection is explicit; unknown versions never inherit a guessed API. */
function novaNetworkDriver(string $platform, string $version): array
{
    $unknown = ['key' => 'unverified', 'label' => 'Version needs compatibility review', 'supported' => false];
    if (!preg_match('/^\d+\.\d+(?:\.\d+){0,2}$/D', $version)) return $unknown;
    if ($platform === 'mikrotik') {
        return version_compare($version, '6.43', '>=') && version_compare($version, '8.0', '<')
            ? ['key' => 'routeros_api_tls', 'label' => 'RouterOS API over TLS', 'supported' => true] : $unknown;
    }
    if ($platform !== 'omada') return $unknown;
    if (version_compare($version, '4.1.5', '>=') && version_compare($version, '4.4.6', '<=')) {
        return ['key' => 'omada_v4', 'label' => 'Omada 4 external portal API', 'supported' => true];
    }
    if (version_compare($version, '5.0.15', '>=') && version_compare($version, '6.2.0', '<=')) {
        return ['key' => 'omada_v5', 'label' => 'Omada 5 / early 6 external portal API', 'supported' => true];
    }
    if (version_compare($version, '6.2.10', '>=') && version_compare($version, '7.0', '<')) {
        return ['key' => 'omada_v6', 'label' => 'Omada 6.2.10+ external portal API', 'supported' => true];
    }
    return $unknown;
}

function novaNetworkHost(string $host): string
{
    $host = strtolower(trim($host));
    if (strlen($host) > 253 || !preg_match('/^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/D', $host)
        || str_contains($host, '..') || $host === 'localhost' || str_ends_with($host, '.localhost')) {
        throw new InvalidArgumentException('Enter a valid IPv4 address or hostname without a path.');
    }
    if (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        $first = (int)explode('.', $host)[0];
        if ($first === 0 || $first === 127 || $first >= 224 || str_starts_with($host, '169.254.')) {
            throw new InvalidArgumentException('Loopback, link-local and multicast addresses cannot be used.');
        }
    } elseif (preg_match('/^[0-9.]+$/D', $host)) {
        throw new InvalidArgumentException('The IPv4 address is invalid.');
    }
    return $host;
}

function novaNetworkBaseUrl(string $url): string
{
    $parts = parse_url(trim($url));
    if (!is_array($parts) || ($parts['scheme'] ?? '') !== 'https' || empty($parts['host'])
        || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])
        || !in_array($parts['path'] ?? '', ['', '/'], true)) {
        throw new InvalidArgumentException('Use the controller HTTPS origin, for example https://controller.example.com:8043. Enter Controller ID separately.');
    }
    $host = novaNetworkHost((string)$parts['host']);
    $port = (int)($parts['port'] ?? 443);
    if ($port < 1 || $port > 65535) throw new InvalidArgumentException('Invalid HTTPS port.');
    return 'https://' . $host . ($port === 443 ? '' : ':' . $port);
}

/** Validate DNS immediately before I/O, while allowing intended private LAN addresses. */
function novaNetworkCheckDns(string $host): void
{
    novaNetworkHost($host);
    $addresses = filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) ? [$host] : gethostbynamel($host);
    if (!$addresses) throw new RuntimeException('The router/controller hostname could not be resolved.');
    foreach ($addresses as $address) novaNetworkHost($address);
}

function novaRouterOsEncodeLength(int $length): string
{
    if ($length < 0 || $length > 65536) throw new InvalidArgumentException('RouterOS word is too large.');
    if ($length < 0x80) return chr($length);
    if ($length < 0x4000) return pack('n', $length | 0x8000);
    return substr(pack('N', $length | 0xC00000), 1);
}

final class NovaRouterOsProbe
{
    private $socket;
    private int $received = 0;
    public function __construct(string $host, int $port)
    {
        novaNetworkCheckDns($host);
        if ($port < 1 || $port > 65535) throw new InvalidArgumentException('Invalid API port.');
        $context = stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true,
            'peer_name' => $host, 'allow_self_signed' => false, 'SNI_enabled' => true]]);
        $this->socket = @stream_socket_client('tls://' . $host . ':' . $port, $errno, $message, 5, STREAM_CLIENT_CONNECT, $context);
        if (!is_resource($this->socket)) throw new RuntimeException('Cannot connect to MikroTik API-SSL. Check the server route, firewall, port and trusted TLS certificate.');
        stream_set_timeout($this->socket, 5);
    }
    public function __destruct() { if (is_resource($this->socket)) fclose($this->socket); }
    private function read(int $length): string
    {
        $value = '';
        while (strlen($value) < $length) {
            $chunk = fread($this->socket, $length - strlen($value));
            if ($chunk === false || $chunk === '') throw new RuntimeException('MikroTik API timed out or closed the connection.');
            $value .= $chunk;
            $this->received += strlen($chunk);
            if ($this->received > 1048576) throw new RuntimeException('MikroTik API reply exceeded the safety limit.');
        }
        return $value;
    }
    private function length(): int
    {
        $a = ord($this->read(1));
        if (($a & 0x80) === 0) return $a;
        if (($a & 0xC0) === 0x80) return (($a & 0x3F) << 8) | ord($this->read(1));
        if (($a & 0xE0) === 0xC0) { $b = unpack('n', $this->read(2))[1]; return (($a & 0x1F) << 16) | $b; }
        if (($a & 0xF0) === 0xE0) { $b = $this->read(3); $n = (($a & 15) << 24) | (ord($b[0]) << 16) | (ord($b[1]) << 8) | ord($b[2]); }
        elseif ($a === 0xF0) $n = unpack('N', $this->read(4))[1];
        else throw new RuntimeException('Unknown RouterOS API control byte.');
        if ($n > 65536) throw new RuntimeException('RouterOS API word exceeded the safety limit.');
        return $n;
    }
    public function command(array $words): array
    {
        $packet = '';
        foreach ($words as $word) $packet .= novaRouterOsEncodeLength(strlen($word)) . $word;
        $packet .= "\0";
        for ($offset = 0; $offset < strlen($packet);) {
            $written = fwrite($this->socket, substr($packet, $offset));
            if (!$written) throw new RuntimeException('Could not send the RouterOS API command.');
            $offset += $written;
        }
        $rows = []; $trapped = false;
        for ($sentences = 0; $sentences < 128; $sentences++) {
            $reply = [];
            for ($count = 0; $count < 128; $count++) {
                $length = $this->length();
                if ($length === 0) break;
                if ($length > 65536) throw new RuntimeException('RouterOS API word exceeded the safety limit.');
                $reply[] = $this->read($length);
            }
            if ($count === 128) throw new RuntimeException('Invalid RouterOS sentence.');
            $type = $reply[0] ?? '';
            if (in_array($type, ['!trap', '!fatal'], true)) $trapped = true;
            if ($type === '!fatal') throw new RuntimeException('MikroTik rejected the API session.');
            if ($type === '!done') {
                if ($trapped) throw new RuntimeException('MikroTik rejected the login or read permission.');
                return $rows;
            }
            if ($type === '!re') {
                $row = [];
                foreach (array_slice($reply, 1) as $word) {
                    if (str_starts_with($word, '=')) { $pair = explode('=', substr($word, 1), 2); $row[$pair[0]] = $pair[1] ?? ''; }
                }
                $rows[] = $row;
            }
        }
        throw new RuntimeException('RouterOS API reply did not finish.');
    }
}

function novaOmadaLoginToken(array $response, string $driver): string
{
    $token = '';
    if (array_key_exists('errorCode', $response) && (string)$response['errorCode'] === '0') {
        $token = $response['result']['token'] ?? '';
    } elseif ($driver === 'omada_v4' && ($response['success'] ?? null) === true) {
        $token = $response['value'] ?? '';
    }
    if (!is_string($token) || $token === '' || strlen($token) > 4096) {
        throw new RuntimeException('Omada did not confirm the Hotspot Operator login. Check the operator account and selected version.');
    }
    return $token;
}

/** Logs in and reads system identity only. It never authorizes an internet client. */
function novaNetworkTest(array $config, string $username, string $password): array
{
    if ($username === '' || $password === '') throw new RuntimeException('Save the API/operator username and password before testing.');
    $driver = novaNetworkDriver((string)$config['platform'], (string)$config['software_version']);
    if (!$driver['supported']) throw new RuntimeException('This version needs compatibility review. Enter the exact stable version; no API requests were sent.');
    if ($config['platform'] === 'mikrotik') {
        $probe = new NovaRouterOsProbe((string)$config['endpoint'], (int)$config['api_port']);
        $probe->command(['/login', '=name=' . $username, '=password=' . $password]);
        $resource = $probe->command(['/system/resource/print', '=.proplist=version,board-name']);
        $actual = (string)($resource[0]['version'] ?? '');
        if (!preg_match('/^(\d+\.\d+(?:\.\d+)?)/', $actual, $match)
            || !novaNetworkDriver('mikrotik', $match[1])['supported']) {
            throw new RuntimeException('RouterOS responded, but its version was not recognized as supported.');
        }
        return ['message' => 'API login verified. RouterOS ' . $actual, 'version' => $actual];
    }
    $base = novaNetworkBaseUrl((string)$config['endpoint']);
    novaNetworkCheckDns((string)parse_url($base, PHP_URL_HOST));
    $controllerId = (string)$config['controller_uid'];
    if ($driver['key'] !== 'omada_v4' && !preg_match('/^[A-Za-z0-9_-]{1,120}$/D', $controllerId)) {
        throw new RuntimeException('Enter the Controller ID shown in the Controller management URL.');
    }
    if (!function_exists('curl_init')) throw new RuntimeException('PHP cURL is unavailable on this server.');
    $prefix = $driver['key'] === 'omada_v4' ? '' : '/' . rawurlencode($controllerId);
    $curl = curl_init($base . $prefix . '/api/v2/hotspot/login');
    $body = '';
    curl_setopt_array($curl, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => false,
        CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_TIMEOUT => 10, CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2, CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
        CURLOPT_COOKIEFILE => '', CURLOPT_POSTFIELDS => json_encode(['name' => $username, 'password' => $password], JSON_THROW_ON_ERROR),
        CURLOPT_WRITEFUNCTION => static function ($handle, string $chunk) use (&$body): int {
            if (strlen($body) + strlen($chunk) > 262144) return 0;
            $body .= $chunk; return strlen($chunk);
        }]);
    try {
        $ok = curl_exec($curl);
        $http = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
        if ($ok === false) throw new RuntimeException('Cannot reach the Omada HTTPS API. Check the server route, firewall and trusted TLS certificate.');
        if ($http < 200 || $http >= 300) throw new RuntimeException('Omada API login was rejected (HTTP ' . $http . '). Check the controller address, version and Hotspot Operator account.');
        $response = json_decode($body, true);
        if (!is_array($response)) throw new RuntimeException('The Omada API returned an unreadable login response.');
        novaOmadaLoginToken($response, $driver['key']);
        return ['message' => 'Hotspot Operator API login verified. Client authorization still requires an on-site test.', 'version' => (string)$config['software_version']];
    } finally { curl_close($curl); }
}
