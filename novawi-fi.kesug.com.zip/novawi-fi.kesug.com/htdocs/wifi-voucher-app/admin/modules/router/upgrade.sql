-- Add missing network fields to an existing router installation.
-- Run this only after router tables already exist; it preserves all current records.
-- Safe to import again: each field is added only when it is missing.

SET @router_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wifi_network_profiles' AND COLUMN_NAME = 'wan_connection_type');
SET @router_column_sql = IF(@router_column_exists = 0, 'ALTER TABLE `wifi_network_profiles` ADD COLUMN `wan_connection_type` ENUM(''dhcp'',''static'',''pppoe'') NOT NULL DEFAULT ''dhcp''', 'SELECT 1');
PREPARE router_column_stmt FROM @router_column_sql;
EXECUTE router_column_stmt;
DEALLOCATE PREPARE router_column_stmt;

SET @router_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wifi_network_profiles' AND COLUMN_NAME = 'wan_ip_address');
SET @router_column_sql = IF(@router_column_exists = 0, 'ALTER TABLE `wifi_network_profiles` ADD COLUMN `wan_ip_address` VARCHAR(45) NULL', 'SELECT 1');
PREPARE router_column_stmt FROM @router_column_sql;
EXECUTE router_column_stmt;
DEALLOCATE PREPARE router_column_stmt;

SET @router_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wifi_network_profiles' AND COLUMN_NAME = 'wan_subnet_cidr');
SET @router_column_sql = IF(@router_column_exists = 0, 'ALTER TABLE `wifi_network_profiles` ADD COLUMN `wan_subnet_cidr` VARCHAR(43) NULL', 'SELECT 1');
PREPARE router_column_stmt FROM @router_column_sql;
EXECUTE router_column_stmt;
DEALLOCATE PREPARE router_column_stmt;

SET @router_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wifi_network_profiles' AND COLUMN_NAME = 'wan_gateway_ip');
SET @router_column_sql = IF(@router_column_exists = 0, 'ALTER TABLE `wifi_network_profiles` ADD COLUMN `wan_gateway_ip` VARCHAR(45) NULL', 'SELECT 1');
PREPARE router_column_stmt FROM @router_column_sql;
EXECUTE router_column_stmt;
DEALLOCATE PREPARE router_column_stmt;

SET @router_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wifi_network_profiles' AND COLUMN_NAME = 'pppoe_username');
SET @router_column_sql = IF(@router_column_exists = 0, 'ALTER TABLE `wifi_network_profiles` ADD COLUMN `pppoe_username` VARCHAR(190) NULL', 'SELECT 1');
PREPARE router_column_stmt FROM @router_column_sql;
EXECUTE router_column_stmt;
DEALLOCATE PREPARE router_column_stmt;

SET @router_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wifi_network_profiles' AND COLUMN_NAME = 'pppoe_password_enc');
SET @router_column_sql = IF(@router_column_exists = 0, 'ALTER TABLE `wifi_network_profiles` ADD COLUMN `pppoe_password_enc` TEXT NULL', 'SELECT 1');
PREPARE router_column_stmt FROM @router_column_sql;
EXECUTE router_column_stmt;
DEALLOCATE PREPARE router_column_stmt;

SET @router_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wifi_network_profiles' AND COLUMN_NAME = 'lan_subnet_cidr');
SET @router_column_sql = IF(@router_column_exists = 0, 'ALTER TABLE `wifi_network_profiles` ADD COLUMN `lan_subnet_cidr` VARCHAR(43) NULL', 'SELECT 1');
PREPARE router_column_stmt FROM @router_column_sql;
EXECUTE router_column_stmt;
DEALLOCATE PREPARE router_column_stmt;

SET @router_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wifi_network_profiles' AND COLUMN_NAME = 'dhcp_enabled');
SET @router_column_sql = IF(@router_column_exists = 0, 'ALTER TABLE `wifi_network_profiles` ADD COLUMN `dhcp_enabled` TINYINT(1) NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE router_column_stmt FROM @router_column_sql;
EXECUTE router_column_stmt;
DEALLOCATE PREPARE router_column_stmt;

SET @router_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wifi_network_profiles' AND COLUMN_NAME = 'dhcp_start_ip');
SET @router_column_sql = IF(@router_column_exists = 0, 'ALTER TABLE `wifi_network_profiles` ADD COLUMN `dhcp_start_ip` VARCHAR(45) NULL', 'SELECT 1');
PREPARE router_column_stmt FROM @router_column_sql;
EXECUTE router_column_stmt;
DEALLOCATE PREPARE router_column_stmt;

SET @router_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wifi_network_profiles' AND COLUMN_NAME = 'dhcp_end_ip');
SET @router_column_sql = IF(@router_column_exists = 0, 'ALTER TABLE `wifi_network_profiles` ADD COLUMN `dhcp_end_ip` VARCHAR(45) NULL', 'SELECT 1');
PREPARE router_column_stmt FROM @router_column_sql;
EXECUTE router_column_stmt;
DEALLOCATE PREPARE router_column_stmt;

SET @router_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wifi_network_profiles' AND COLUMN_NAME = 'dns_primary');
SET @router_column_sql = IF(@router_column_exists = 0, 'ALTER TABLE `wifi_network_profiles` ADD COLUMN `dns_primary` VARCHAR(45) NULL', 'SELECT 1');
PREPARE router_column_stmt FROM @router_column_sql;
EXECUTE router_column_stmt;
DEALLOCATE PREPARE router_column_stmt;

SET @router_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'wifi_network_profiles' AND COLUMN_NAME = 'dns_secondary');
SET @router_column_sql = IF(@router_column_exists = 0, 'ALTER TABLE `wifi_network_profiles` ADD COLUMN `dns_secondary` VARCHAR(45) NULL', 'SELECT 1');
PREPARE router_column_stmt FROM @router_column_sql;
EXECUTE router_column_stmt;
DEALLOCATE PREPARE router_column_stmt;

SET @router_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'network_devices' AND COLUMN_NAME = 'serial_number');
SET @router_column_sql = IF(@router_column_exists = 0, 'ALTER TABLE `network_devices` ADD COLUMN `serial_number` VARCHAR(100) NULL', 'SELECT 1');
PREPARE router_column_stmt FROM @router_column_sql;
EXECUTE router_column_stmt;
DEALLOCATE PREPARE router_column_stmt;

SET @router_column_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'network_devices' AND COLUMN_NAME = 'mac_address');
SET @router_column_sql = IF(@router_column_exists = 0, 'ALTER TABLE `network_devices` ADD COLUMN `mac_address` VARCHAR(17) NULL', 'SELECT 1');
PREPARE router_column_stmt FROM @router_column_sql;
EXECUTE router_column_stmt;
DEALLOCATE PREPARE router_column_stmt;
