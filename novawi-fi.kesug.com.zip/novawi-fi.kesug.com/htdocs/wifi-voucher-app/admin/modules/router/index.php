<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';

requireAdminLogin();
global $conn;

if (getString('tab', '') === 'connections') {
    require __DIR__ . '/connections.php';
    return;
}

$schemaReady = routerAdminSchemaReady($conn);
$gatewaySchemaReady = routerAdminGatewaySchemaReady($conn);
$onlineSchemaReady = routerAdminOnlineSchemaReady($conn);
$sitesSchemaReady = $schemaReady && routerAdminSitesSchemaReady($conn);
$encryptionReady = routerAdminEncryptionReady();
$tab = getString('tab', 'overview');
$allowedTabs = ['overview', 'online', 'gateway', 'controllers', 'wifi', 'devices', 'deployments'];
if (!in_array($tab, $allowedTabs, true)) {
    $tab = 'overview';
}
$errors = [];
$success = '';

if ($schemaReady && isPost()) {
    requireAdminPost();
    requireCsrfToken();
    $action = postString('form_action', '');

    if ($action === 'save_controller') {
        $name = trim(postString('name', ''));
        $type = strtolower(trim(postString('controller_type', 'software')));
        $baseUrl = trim(postString('base_url', ''));
        $siteId = trim(postString('site_id', ''));
        $rawKey = $_POST['api_client_key'] ?? '';
        $rawSecret = $_POST['api_client_secret'] ?? '';
        $clientKey = is_string($rawKey) ? trim($rawKey) : '';
        $clientSecret = is_string($rawSecret) ? trim($rawSecret) : '';

        if ($name === '' || routerAdminLength($name) > 100) {
            $errors[] = 'Enter a controller name (1–100 characters).';
        }
        if (!in_array($type, ['software', 'hardware', 'cloud'], true)) {
            $errors[] = 'Select a valid Omada Controller type.';
        }
        if ($baseUrl !== '') {
            $parts = parse_url($baseUrl);
            if (!filter_var($baseUrl, FILTER_VALIDATE_URL) || !is_array($parts)
                || !in_array(strtolower((string)($parts['scheme'] ?? '')), ['http', 'https'], true)
                || empty($parts['host']) || routerAdminLength($baseUrl) > 500) {
                $errors[] = 'The controller address is invalid. Enter a complete http:// or https:// URL.';
            }
        }
        if (routerAdminLength($siteId) > 120 || strlen($clientKey) > 2048 || strlen($clientSecret) > 4096) {
            $errors[] = 'Some controller details exceed the allowed length.';
        }
        if (($clientKey !== '' || $clientSecret !== '') && !$encryptionReady) {
            $errors[] = 'Encryption is not ready. Set APP_ENCRYPTION_KEY in .env before saving Open API credentials.';
        }

        if (!$errors) {
            $encryptedKey = $clientKey !== '' ? encryptData($clientKey) : null;
            $encryptedSecret = $clientSecret !== '' ? encryptData($clientSecret) : null;
            if (($clientKey !== '' && (!is_string($encryptedKey) || $encryptedKey === '' || hash_equals($clientKey, $encryptedKey)))
                || ($clientSecret !== '' && (!is_string($encryptedSecret) || $encryptedSecret === '' || hash_equals($clientSecret, $encryptedSecret)))) {
                $errors[] = 'Unable to encrypt the controller credentials; nothing was saved.';
            } else {
                $stmt = $conn->prepare("INSERT INTO network_controllers (name, controller_type, base_url, site_id, api_client_key_enc, api_client_secret_enc, status, connection_status) VALUES (?, ?, NULLIF(?, ''), NULLIF(?, ''), ?, ?, 'draft', 'not_connected')");
                if (!$stmt) {
                    logDatabaseError($conn, 'Preparing network controller draft');
                    $errors[] = 'The controller draft could not be saved.';
                } else {
                    $stmt->bind_param('ssssss', $name, $type, $baseUrl, $siteId, $encryptedKey, $encryptedSecret);
                    if (!$stmt->execute()) {
                        logDatabaseError($conn, 'Saving network controller draft');
                        $errors[] = 'The controller draft could not be saved.';
                    } else {
                        $success = 'The controller has been saved as a draft; it is not connected and no changes have been pushed.';
                        logAdminSecurityEvent('NETWORK_CONTROLLER_DRAFT_SAVED', 'Saved a network controller draft.');
                    }
                    $stmt->close();
                }
            }
        }
        $tab = 'controllers';
    } elseif ($action === 'save_main_gateway') {
        $tab = 'gateway';
        if (!routerAdminGatewaySchemaReady($conn)) {
            $errors[] = 'The MikroTik gateway table is not installed yet. Import admin/modules/router/gateway.sql into the application database first.';
        } else {
            $name = trim(postString('gateway_name', 'Main MikroTik Gateway'));
            $host = trim(postString('management_host', ''));
            $port = filter_var($_POST['api_port'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 65535]]);
            $rawUsername = $_POST['api_username'] ?? '';
            $rawPassword = $_POST['api_password'] ?? '';
            $username = is_string($rawUsername) ? trim($rawUsername) : '';
            $password = is_string($rawPassword) ? $rawPassword : '';
            $hostValid = filter_var($host, FILTER_VALIDATE_IP) !== false
                || (strlen($host) <= 253 && preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(?:\.(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))*$/i', $host) === 1);

            if ($name === '' || routerAdminLength($name) > 100) {
                $errors[] = 'Enter a gateway name (1–100 characters).';
            }
            if (!$hostValid) {
                $errors[] = 'Enter the MikroTik management IP address or hostname without http:// or https://.';
            }
            if ($port === false) {
                $errors[] = 'Enter a valid API-SSL port between 1 and 65535. The usual value is 8729.';
            }
            if (strlen($username) > 190 || strlen($password) > 4096) {
                $errors[] = 'The API username or password exceeds the allowed length.';
            }
            if (!$encryptionReady) {
                $errors[] = 'Encryption is not ready. Set APP_ENCRYPTION_KEY in .env before saving MikroTik API credentials.';
            }

            $existingGateway = null;
            if (!$errors) {
                $existingResult = $conn->query('SELECT api_username_enc, api_password_enc FROM network_gateway_settings WHERE id = 1 LIMIT 1');
                if ($existingResult) {
                    $existingGateway = $existingResult->fetch_assoc() ?: null;
                }
                if ($username === '' && !$existingGateway) {
                    $errors[] = 'Enter the MikroTik API username.';
                }
                if ($password === '' && !$existingGateway) {
                    $errors[] = 'Enter the MikroTik API password.';
                }
            }

            if (!$errors) {
                $encryptedUsername = $username !== '' ? encryptData($username) : (string)$existingGateway['api_username_enc'];
                $encryptedPassword = $password !== '' ? encryptData($password) : (string)$existingGateway['api_password_enc'];
                if (!is_string($encryptedUsername) || $encryptedUsername === '' || hash_equals($username, $encryptedUsername)
                    || !is_string($encryptedPassword) || $encryptedPassword === '' || ($password !== '' && hash_equals($password, $encryptedPassword))) {
                    $errors[] = 'Unable to encrypt the MikroTik API credentials; nothing was saved.';
                } else {
                    $stmt = $conn->prepare("INSERT INTO network_gateway_settings (id, name, management_host, api_port, api_tls, api_username_enc, api_password_enc, config_status, connection_status) VALUES (1, ?, ?, ?, 1, ?, ?, 'draft', 'not_connected') ON DUPLICATE KEY UPDATE name = VALUES(name), management_host = VALUES(management_host), api_port = VALUES(api_port), api_tls = 1, api_username_enc = VALUES(api_username_enc), api_password_enc = VALUES(api_password_enc), config_status = 'draft', connection_status = 'not_connected', last_connected_at = NULL");
                    if (!$stmt) {
                        logDatabaseError($conn, 'Preparing main MikroTik gateway configuration');
                        $errors[] = 'The MikroTik gateway details could not be saved.';
                    } else {
                        $portValue = (int)$port;
                        $stmt->bind_param('ssiss', $name, $host, $portValue, $encryptedUsername, $encryptedPassword);
                        if (!$stmt->execute()) {
                            logDatabaseError($conn, 'Saving main MikroTik gateway configuration');
                            $errors[] = 'The MikroTik gateway details could not be saved.';
                        } else {
                            $success = 'MikroTik details saved securely as a draft. The router is not connected yet.';
                            logAdminSecurityEvent('MIKROTIK_GATEWAY_DRAFT_SAVED', 'Saved the main MikroTik gateway connection details.');
                        }
                        $stmt->close();
                    }
                }
            }
        }
    } elseif ($action === 'save_wifi_profile') {
        $name = trim(postString('name', ''));
        $platform = strtolower(trim(postString('platform', 'tp_link')));
        $family = trim(postString('device_family', 'other'));
        $model = trim(postString('device_model', ''));
        $hardware = trim(postString('hardware_version', ''));
        $firmware = trim(postString('firmware_version', ''));
        $ssid = trim(postString('ssid', ''));
        $accessMode = strtolower(trim(postString('access_mode', 'voucher_portal')));
        $vlan = trim(postString('vlan_id', ''));
        $gatewayIp = trim(postString('gateway_ip', ''));
        $portalUrl = trim(postString('portal_url', ''));
        $wanMode = strtolower(trim(postString('wan_connection_type', 'dhcp')));
        $wanIp = trim(postString('wan_ip_address', ''));
        $wanSubnet = trim(postString('wan_subnet_cidr', ''));
        $wanGateway = trim(postString('wan_gateway_ip', ''));
        $pppoeUsername = trim(postString('pppoe_username', ''));
        $rawPppoePassword = $_POST['pppoe_password'] ?? '';
        $pppoePassword = is_string($rawPppoePassword) ? $rawPppoePassword : '';
        $lanSubnet = trim(postString('lan_subnet_cidr', ''));
        $dhcpEnabled = postString('dhcp_enabled', '') === '1';
        $dhcpStartIp = trim(postString('dhcp_start_ip', ''));
        $dhcpEndIp = trim(postString('dhcp_end_ip', ''));
        $dnsPrimary = trim(postString('dns_primary', ''));
        $dnsSecondary = trim(postString('dns_secondary', ''));
        $controllerId = postInt('controller_id', 0) ?? 0;
        if ($platform !== 'omada') {
            $controllerId = 0;
        }
        $families = ['other', 'omada_eap', 'omada_gateway', 'archer', 'deco', 'tl_wr', 'tl_mr', 'dsl', 'cellular', 'mikrotik_router', 'mikrotik_ap', 'mikrotik_lte', 'mikrotik_other'];

        if ($name === '' || routerAdminLength($name) > 100 || $ssid === '' || routerAdminLength($ssid) > 32) {
            $errors[] = 'Enter a profile name and SSID (up to 32 characters).';
        }
        if (!in_array($platform, ['tp_link', 'omada', 'mikrotik'], true) || !in_array($family, $families, true)
            || !in_array($accessMode, ['voucher_portal', 'guest_wifi'], true)) {
            $errors[] = 'The selected platform, family, or Wi-Fi mode is invalid.';
        }
        if ($platform === 'omada' && !in_array($family, ['omada_eap', 'omada_gateway'], true)) {
            $errors[] = 'For an Omada profile, select Omada EAP or Omada Gateway.';
        }
        if ($platform === 'mikrotik' && !str_starts_with($family, 'mikrotik_')) {
            $errors[] = 'For a MikroTik profile, select a MikroTik family.';
        }
        if ($platform === 'tp_link' && (str_starts_with($family, 'omada_') || str_starts_with($family, 'mikrotik_'))) {
            $errors[] = 'The selected family is not compatible with the standard TP-Link platform.';
        }
        if ($vlan !== '' && (!ctype_digit($vlan) || (int)$vlan < 1 || (int)$vlan > 4094)) {
            $errors[] = 'The VLAN ID must be a number between 1 and 4094.';
        }
        if ($gatewayIp !== '' && filter_var($gatewayIp, FILTER_VALIDATE_IP) === false) {
            $errors[] = 'The gateway IP address is invalid.';
        }
        if ($portalUrl !== '') {
            $portalParts = parse_url($portalUrl);
            if (!filter_var($portalUrl, FILTER_VALIDATE_URL) || !is_array($portalParts)
                || !in_array(strtolower((string)($portalParts['scheme'] ?? '')), ['http', 'https'], true)
                || empty($portalParts['host']) || routerAdminLength($portalUrl) > 500) {
                $errors[] = 'Portal URL si sahihi.';
            }
        }
        if (!in_array($wanMode, ['dhcp', 'static', 'pppoe'], true)) {
            $errors[] = 'Select a valid WAN connection type.';
        }
        if ($wanMode === 'static') {
            if (filter_var($wanIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false
                || !preg_match('/^(?:[1-9]|[12][0-9]|3[0-2])$/', (string)substr(strrchr($wanSubnet, '/') ?: '', 1))
                || !routerAdminIpv4CidrContains($wanSubnet, $wanIp)
                || filter_var($wanGateway, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false
                || !routerAdminIpv4CidrContains($wanSubnet, $wanGateway)) {
                $errors[] = 'For a static WAN, enter a valid IPv4 address, CIDR subnet, and gateway.';
            }
        } elseif ($wanIp !== '' || $wanSubnet !== '' || $wanGateway !== '') {
            $errors[] = 'Enter a WAN IP address, subnet, and gateway only when Static WAN is selected.';
        }
        if ($wanMode === 'pppoe') {
            if ($pppoeUsername === '' || $pppoePassword === '' || routerAdminLength($pppoeUsername) > 190 || strlen($pppoePassword) > 4096) {
                $errors[] = 'For PPPoE WAN, enter the username and password provided by your ISP.';
            }
            if (!$encryptionReady) {
                $errors[] = 'APP_ENCRYPTION_KEY has not been verified; save the PPPoE password after encryption is ready.';
            }
        } elseif ($pppoeUsername !== '' || $pppoePassword !== '') {
            $errors[] = 'PPPoE credentials can only be saved when PPPoE WAN is selected.';
        }
        if ($wanMode === 'dhcp' && ($wanSubnet !== '' || $wanIp !== '' || $wanGateway !== '')) {
            $errors[] = 'Clear static WAN settings when selecting DHCP.';
        }
        if ($lanSubnet !== '') {
            $cidr = explode('/', $lanSubnet, 2);
            if (count($cidr) !== 2 || !ctype_digit($cidr[1]) || (int)$cidr[1] < 1 || (int)$cidr[1] > 30
                || filter_var($cidr[0], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false) {
                $errors[] = 'Enter a valid LAN IPv4 CIDR subnet, such as 192.168.10.0/24.';
            }
        }
        if ($gatewayIp !== '' && filter_var($gatewayIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false) {
            $errors[] = 'The LAN gateway must be a valid IPv4 address.';
        } elseif ($gatewayIp !== '' && $lanSubnet !== '' && !routerAdminIpv4CidrContains($lanSubnet, $gatewayIp)) {
            $errors[] = 'The LAN gateway must be within the selected LAN subnet.';
        }
        if ($dhcpEnabled) {
            if ($lanSubnet === '' || $dhcpStartIp === '' || $dhcpEndIp === '') {
                $errors[] = 'Enter a LAN subnet and DHCP pool start/end addresses, or disable DHCP for this profile.';
            } elseif (filter_var($dhcpStartIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false
                || filter_var($dhcpEndIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false
                || !routerAdminIpv4CidrContains($lanSubnet, $dhcpStartIp)
                || !routerAdminIpv4CidrContains($lanSubnet, $dhcpEndIp)
                || sprintf('%u', ip2long($dhcpStartIp)) > sprintf('%u', ip2long($dhcpEndIp))) {
                $errors[] = 'The DHCP pool must have valid IPv4 start and end addresses within the LAN subnet, in the correct order.';
            }
        } elseif ($dhcpStartIp !== '' || $dhcpEndIp !== '') {
            $errors[] = 'Clear the DHCP pool fields or enable DHCP for this profile.';
        }
        foreach (['Primary DNS' => $dnsPrimary, 'Secondary DNS' => $dnsSecondary] as $dnsLabel => $dnsAddress) {
            if ($dnsAddress !== '' && filter_var($dnsAddress, FILTER_VALIDATE_IP) === false) {
                $errors[] = $dnsLabel . ' is not a valid IPv4 or IPv6 address.';
            }
        }
        if ($controllerId > 0) {
            $checkController = $conn->prepare('SELECT id FROM network_controllers WHERE id = ? LIMIT 1');
            if (!$checkController) {
                $errors[] = 'Unable to check the selected controller.';
            } else {
                $checkController->bind_param('i', $controllerId);
                $checkController->execute();
                $foundController = $checkController->get_result()?->fetch_assoc();
                $checkController->close();
                if (!$foundController) {
                    $errors[] = 'The selected controller does not exist.';
                }
            }
        }

        $encryptedPppoePassword = '';
        if (!$errors && $pppoePassword !== '') {
            try {
                $encryptedPppoePassword = encryptData($pppoePassword);
                if (!is_string($encryptedPppoePassword) || $encryptedPppoePassword === '' || hash_equals($pppoePassword, $encryptedPppoePassword)) {
                    $errors[] = 'Unable to encrypt the PPPoE password; the profile was not saved.';
                }
            } catch (Throwable) {
                $errors[] = 'Unable to encrypt the PPPoE password; the profile was not saved.';
            }
        }

        if (!$errors) {
            $vlanValue = $vlan === '' ? null : $vlan;
            $controllerValue = $controllerId > 0 ? (string)$controllerId : '';
            $dhcpValue = $dhcpEnabled ? 1 : 0;
            $stmt = $conn->prepare("INSERT INTO wifi_network_profiles (
                name, platform, device_family, device_model, hardware_version, firmware_version,
                ssid, access_mode, vlan_id, gateway_ip, portal_url, controller_id,
                wan_connection_type, wan_ip_address, wan_subnet_cidr, wan_gateway_ip,
                pppoe_username, pppoe_password_enc, lan_subnet_cidr, dhcp_enabled,
                dhcp_start_ip, dhcp_end_ip, dns_primary, dns_secondary, status
            ) VALUES (
                ?, ?, ?, NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), ?, ?, NULLIF(?, ''),
                NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), ?, NULLIF(?, ''), NULLIF(?, ''),
                NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), ?,
                NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), 'draft'
            )");
            if (!$stmt) {
                logDatabaseError($conn, 'Preparing Wi-Fi profile draft');
                $errors[] = 'The Wi-Fi profile could not be saved.';
            } else {
                $vlanBind = $vlanValue ?? '';
                $stmt->bind_param(
                    'sssssssssssssssssssissss',
                    $name, $platform, $family, $model, $hardware, $firmware, $ssid, $accessMode,
                    $vlanBind, $gatewayIp, $portalUrl, $controllerValue, $wanMode, $wanIp,
                    $wanSubnet, $wanGateway, $pppoeUsername, $encryptedPppoePassword, $lanSubnet,
                    $dhcpValue, $dhcpStartIp, $dhcpEndIp, $dnsPrimary, $dnsSecondary
                );
                if (!$stmt->execute()) {
                    logDatabaseError($conn, 'Saving Wi-Fi profile draft');
                    $errors[] = 'The Wi-Fi profile could not be saved.';
                } else {
                    $newProfileId = (int)$stmt->insert_id;
                    $success = 'The Wi-Fi profile has been saved as a draft. You can download its configuration from the list.';
                    logAdminSecurityEvent('WIFI_PROFILE_DRAFT_SAVED', 'Saved Wi-Fi profile draft #' . $newProfileId . '.');
                }
                $stmt->close();
            }
        }
        $tab = 'wifi';
    } elseif ($action === 'save_device') {
        $platform = strtolower(trim(postString('platform', 'tp_link')));
        $role = strtolower(trim(postString('role', 'access_point')));
        $family = trim(postString('device_family', 'other'));
        $model = trim(postString('device_model', ''));
        $hardware = trim(postString('hardware_version', ''));
        $firmware = trim(postString('firmware_version', ''));
        $managementIp = trim(postString('management_ip', ''));
        $serialNumber = trim(postString('serial_number', ''));
        $macAddress = strtoupper(trim(postString('mac_address', '')));
        $controllerId = postInt('controller_id', 0) ?? 0;
        $siteId = postInt('site_id', 0) ?? 0;
        $newSiteName = trim(postString('new_site_name', ''));
        $newSiteLocation = trim(postString('new_site_location', ''));
        $newSiteLatitude = trim(postString('new_site_latitude', ''));
        $newSiteLongitude = trim(postString('new_site_longitude', ''));
        $siteNameForMessage = '';
        if ($siteId < 0) {
            $errors[] = 'Select a valid site.';
        }
        if ($platform !== 'omada') {
            $controllerId = 0;
        }
        if (!in_array($platform, ['tp_link', 'omada', 'mikrotik'], true) || !in_array($role, ['access_point', 'gateway', 'router', 'other'], true)
            || $model === '' || routerAdminLength($model) > 100) {
            $errors[] = 'Enter the model and select the platform and device role.';
        }
        if ($managementIp !== '' && filter_var($managementIp, FILTER_VALIDATE_IP) === false) {
            $errors[] = 'Management IP si sahihi.';
        }
        if ($serialNumber !== '' && routerAdminLength($serialNumber) > 100) {
            $errors[] = 'Serial number isizidi herufi 100.';
        }
        if ($macAddress !== '' && !preg_match('/^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$/', $macAddress)) {
            $errors[] = 'Enter the MAC address in a format such as AA:BB:CC:11:22:33.';
        }
        if ($platform === 'omada' && $controllerId <= 0) {
            $errors[] = 'Select an Omada Controller for the Omada device.';
        }
        if ($role === 'access_point' && $siteId <= 0 && $newSiteName === '') {
            $errors[] = 'Select an existing site or add a new site for this Access Point.';
        }
        if (!$sitesSchemaReady && ($role === 'access_point' || $siteId > 0 || $newSiteName !== '')) {
            $errors[] = 'Site location setup is unavailable. Complete admin/modules/sites/install.sql before adding an Access Point.';
        }
        if ($siteId > 0 && $newSiteName !== '') {
            $errors[] = 'Choose an existing site or enter a new site, not both.';
        }
        if (routerAdminLength($newSiteName) > 100 || routerAdminLength($newSiteLocation) > 255) {
            $errors[] = 'The new site name must be at most 100 characters and its location details at most 255 characters.';
        }
        if ($newSiteName === '' && ($newSiteLocation !== '' || $newSiteLatitude !== '' || $newSiteLongitude !== '')) {
            $errors[] = 'Enter a new site name before adding its location details or map coordinates.';
        }
        if (($newSiteLatitude !== '' || $newSiteLongitude !== '')
            && (!is_numeric($newSiteLatitude) || !is_numeric($newSiteLongitude)
                || (float)$newSiteLatitude < -90 || (float)$newSiteLatitude > 90
                || (float)$newSiteLongitude < -180 || (float)$newSiteLongitude > 180)) {
            $errors[] = 'Enter valid latitude and longitude values, or leave both blank.';
        }
        if (!$errors) {
            if (!$conn->begin_transaction()) {
                $errors[] = 'The device could not be saved right now.';
            } else {
                if ($siteId > 0) {
                    $siteCheck = $conn->prepare("SELECT name FROM network_sites WHERE id = ? AND status = 'active' LIMIT 1");
                    if (!$siteCheck) {
                        logDatabaseError($conn, 'Preparing selected device site lookup');
                        $errors[] = 'The selected site could not be verified.';
                    } else {
                        $siteCheck->bind_param('i', $siteId);
                        if (!$siteCheck->execute()) {
                            logDatabaseError($conn, 'Checking selected device site');
                            $errors[] = 'The selected site could not be verified.';
                        } else {
                            $siteRow = $siteCheck->get_result()?->fetch_assoc();
                            if (!$siteRow) {
                                $errors[] = 'Select an active site for this device.';
                            } else {
                                $siteNameForMessage = (string)$siteRow['name'];
                            }
                        }
                        $siteCheck->close();
                    }
                } elseif ($newSiteName !== '') {
                    $siteInsert = $conn->prepare("INSERT INTO network_sites (name, location_detail, latitude, longitude, status) VALUES (?, NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), 'active')");
                    if (!$siteInsert) {
                        logDatabaseError($conn, 'Preparing site creation for network device');
                        $errors[] = 'The new site could not be saved.';
                    } else {
                        $siteInsert->bind_param('ssss', $newSiteName, $newSiteLocation, $newSiteLatitude, $newSiteLongitude);
                        if (!$siteInsert->execute()) {
                            logDatabaseError($conn, 'Creating site for network device');
                            $errors[] = 'The new site could not be saved.';
                        } else {
                            $siteId = (int)$siteInsert->insert_id;
                            $siteNameForMessage = $newSiteName;
                        }
                        $siteInsert->close();
                    }
                }

                if (!$errors) {
                    $controllerValue = $controllerId > 0 ? (string)$controllerId : '';
                    $deviceInsertSql = $sitesSchemaReady
                        ? "INSERT INTO network_devices (controller_id, site_id, platform, role, device_family, device_model, hardware_version, firmware_version, management_ip, serial_number, mac_address, status) VALUES (NULLIF(?, ''), NULLIF(?, 0), ?, ?, ?, ?, NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), 'planned')"
                        : "INSERT INTO network_devices (controller_id, platform, role, device_family, device_model, hardware_version, firmware_version, management_ip, serial_number, mac_address, status) VALUES (NULLIF(?, ''), ?, ?, ?, ?, NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), NULLIF(?, ''), 'planned')";
                    $stmt = $conn->prepare($deviceInsertSql);
                    if (!$stmt) {
                        logDatabaseError($conn, 'Preparing planned network device');
                        $errors[] = 'The device could not be saved.';
                    } else {
                        if ($sitesSchemaReady) {
                            $stmt->bind_param('sisssssssss', $controllerValue, $siteId, $platform, $role, $family, $model, $hardware, $firmware, $managementIp, $serialNumber, $macAddress);
                        } else {
                            $stmt->bind_param('ssssssssss', $controllerValue, $platform, $role, $family, $model, $hardware, $firmware, $managementIp, $serialNumber, $macAddress);
                        }
                        if (!$stmt->execute()) {
                            logDatabaseError($conn, 'Saving planned network device');
                            $errors[] = 'The device could not be saved.';
                        } else {
                            $deviceSaved = true;
                        }
                        $stmt->close();
                    }
                }

                if (!$errors && !empty($deviceSaved) && $conn->commit()) {
                    $success = $role === 'access_point' && $siteNameForMessage !== ''
                        ? 'The Access Point has been added under site ' . $siteNameForMessage . '; it is not connected yet.'
                        : 'The device has been added to the planned devices list; it is not connected yet.';
                    logAdminSecurityEvent('NETWORK_DEVICE_PLANNED', 'Added a network device to the planned inventory.');
                } else {
                    $conn->rollback();
                    if (!$errors) {
                        $errors[] = 'The device could not be saved right now.';
                    }
                }
            }
        }
        $tab = 'devices';
    } else {
        $errors[] = 'The request was not recognized.';
    }
}

if (getString('saved', '') !== '') {
    $success = match (getString('saved', '')) {
        'controller' => 'Controller draft saved.',
        'gateway' => 'MikroTik gateway draft saved.',
        'wifi' => 'Wi-Fi profile draft saved.',
        'device' => 'The device has been added to the plan.',
        default => '',
    };
}

$counts = ['controllers' => 0, 'connected' => 0, 'profiles' => 0, 'devices' => 0, 'planned' => 0, 'deployments' => 0];
$controllers = $profiles = $devices = $deployments = $siteOptions = [];
$onlineUsers = $paidNotOnline = [];
$routerAgent = null;
$routerAgentOnline = false;
$mainGateway = null;
if ($gatewaySchemaReady) {
    $gatewayResult = $conn->query('SELECT id, name, management_host, api_port, api_tls, config_status, connection_status, updated_at, CASE WHEN NULLIF(api_username_enc, "") IS NULL THEN 0 ELSE 1 END AS username_saved, CASE WHEN NULLIF(api_password_enc, "") IS NULL THEN 0 ELSE 1 END AS password_saved FROM network_gateway_settings WHERE id = 1 LIMIT 1');
    if ($gatewayResult) {
        $mainGateway = $gatewayResult->fetch_assoc() ?: null;
    }
}
$gatewayFormSubmitted = isPost() && postString('form_action', '') === 'save_main_gateway';
$gatewayFormName = $gatewayFormSubmitted
    ? postString('gateway_name', 'Main MikroTik Gateway')
    : (string)($mainGateway['name'] ?? 'Main MikroTik Gateway');
$gatewayFormHost = $gatewayFormSubmitted
    ? postString('management_host', '')
    : (string)($mainGateway['management_host'] ?? '');
$gatewayFormPort = $gatewayFormSubmitted
    ? postString('api_port', '8729')
    : (string)($mainGateway['api_port'] ?? '8729');
if ($schemaReady) {
    $countQueries = [
        'controllers' => 'SELECT COUNT(*) AS n FROM network_controllers',
        'connected' => "SELECT COUNT(*) AS n FROM network_controllers WHERE connection_status = 'connected'",
        'profiles' => "SELECT COUNT(*) AS n FROM wifi_network_profiles WHERE status <> 'archived'",
        'devices' => 'SELECT COUNT(*) AS n FROM network_devices',
        'planned' => "SELECT COUNT(*) AS n FROM network_devices WHERE status = 'planned'",
        'deployments' => 'SELECT COUNT(*) AS n FROM network_deployments',
    ];
    foreach ($countQueries as $key => $sql) {
        $result = $conn->query($sql);
        if ($result) {
            $counts[$key] = (int)($result->fetch_assoc()['n'] ?? 0);
        }
    }
    $controllerResult = $conn->query('SELECT id, name, controller_type, base_url, site_id, status, connection_status, created_at, CASE WHEN NULLIF(api_client_secret_enc, "") IS NULL THEN 0 ELSE 1 END AS secret_saved FROM network_controllers ORDER BY id DESC LIMIT 50');
    if ($controllerResult) while ($row = $controllerResult->fetch_assoc()) $controllers[] = $row;
    $profileResult = $conn->query('SELECT p.*, c.name AS controller_name FROM wifi_network_profiles p LEFT JOIN network_controllers c ON c.id = p.controller_id WHERE p.status <> "archived" ORDER BY p.id DESC LIMIT 50');
    if ($profileResult) while ($row = $profileResult->fetch_assoc()) $profiles[] = $row;
    $deviceSql = $sitesSchemaReady
        ? 'SELECT d.*, c.name AS controller_name, s.name AS site_name, s.location_detail AS site_location, s.latitude AS site_latitude, s.longitude AS site_longitude FROM network_devices d LEFT JOIN network_controllers c ON c.id = d.controller_id LEFT JOIN network_sites s ON s.id = d.site_id ORDER BY d.id DESC LIMIT 50'
        : 'SELECT d.*, c.name AS controller_name, NULL AS site_name, NULL AS site_location, NULL AS site_latitude, NULL AS site_longitude FROM network_devices d LEFT JOIN network_controllers c ON c.id = d.controller_id ORDER BY d.id DESC LIMIT 50';
    $deviceResult = $conn->query($deviceSql);
    if ($deviceResult) while ($row = $deviceResult->fetch_assoc()) $devices[] = $row;
    if ($sitesSchemaReady) {
        $siteResult = $conn->query("SELECT id, name, location_detail FROM network_sites WHERE status = 'active' ORDER BY name ASC LIMIT 200");
        if ($siteResult) while ($row = $siteResult->fetch_assoc()) $siteOptions[] = $row;
    }
    $deploymentResult = $conn->query('SELECT n.*, c.name AS controller_name, p.name AS profile_name FROM network_deployments n LEFT JOIN network_controllers c ON c.id = n.controller_id LEFT JOIN wifi_network_profiles p ON p.id = n.profile_id ORDER BY n.id DESC LIMIT 50');
    if ($deploymentResult) while ($row = $deploymentResult->fetch_assoc()) $deployments[] = $row;
}
if ($onlineSchemaReady) {
    $agentResult = $conn->query('SELECT connection_status, router_identity, router_version, last_seen_at,
            CASE WHEN last_seen_at IS NOT NULL AND last_seen_at >= DATE_SUB(NOW(), INTERVAL 90 SECOND) THEN 1 ELSE 0 END AS is_fresh
        FROM network_agent_status WHERE id = 1 LIMIT 1');
    if ($agentResult) {
        $routerAgent = $agentResult->fetch_assoc() ?: null;
        $routerAgentOnline = is_array($routerAgent)
            && (string)($routerAgent['connection_status'] ?? '') === 'online'
            && (int)($routerAgent['is_fresh'] ?? 0) === 1;
    }
    if ($routerAgentOnline) {
        $onlineSql = "SELECT s.voucher_code, s.device_mac, s.device_ip, s.access_point, s.hotspot_server,
                s.joined_at, s.online_for_seconds, s.last_seen_at,
                v.id AS voucher_id, v.expires_at, pk.name AS package_name,
                (SELECT pay.phone FROM payments pay
                    WHERE pay.voucher_id = v.id AND pay.status = 'SUCCESS'
                    ORDER BY pay.paid_at DESC LIMIT 1) AS phone,
                CASE WHEN v.expires_at IS NULL THEN NULL
                    ELSE GREATEST(0, TIMESTAMPDIFF(SECOND, NOW(), v.expires_at)) END AS time_left_seconds
            FROM network_online_sessions s
            LEFT JOIN vouchers v ON v.code = s.voucher_code
            LEFT JOIN packages pk ON pk.id = v.package_id
            WHERE s.last_seen_at >= DATE_SUB(NOW(), INTERVAL 90 SECOND)
            ORDER BY s.joined_at DESC LIMIT 500";
        $onlineResult = $conn->query($onlineSql);
        if ($onlineResult) while ($row = $onlineResult->fetch_assoc()) $onlineUsers[] = $row;

        $paidSql = "SELECT v.id, v.device_mac, v.activated_at, v.expires_at, pk.name AS package_name,
                (SELECT pay.phone FROM payments pay
                    WHERE pay.voucher_id = v.id AND pay.status = 'SUCCESS'
                    ORDER BY pay.paid_at DESC LIMIT 1) AS phone
            FROM vouchers v
            LEFT JOIN packages pk ON pk.id = v.package_id
            WHERE v.status = 'active'
              AND (v.expires_at IS NULL OR v.expires_at > NOW())
              AND EXISTS (
                  SELECT 1 FROM payments paid
                  WHERE paid.voucher_id = v.id AND paid.status = 'SUCCESS'
              )
              AND NOT EXISTS (
                  SELECT 1 FROM network_online_sessions s
                  WHERE s.voucher_code = v.code
                    AND s.last_seen_at >= DATE_SUB(NOW(), INTERVAL 90 SECOND)
              )
            ORDER BY v.activated_at DESC LIMIT 100";
        $paidResult = $conn->query($paidSql);
        if ($paidResult) while ($row = $paidResult->fetch_assoc()) $paidNotOnline[] = $row;
    }
}
$controllerOptions = $controllers;
$deviceRoleCounts = ['access_points' => 0, 'routers' => 0, 'other' => 0];
if ($schemaReady && $tab === 'devices') {
    $roleResult = $conn->query("SELECT SUM(role = 'access_point') AS access_points, SUM(role IN ('router', 'gateway')) AS routers, SUM(role NOT IN ('access_point', 'router', 'gateway')) AS other FROM network_devices");
    if ($roleResult && ($roleRow = $roleResult->fetch_assoc())) {
        foreach ($deviceRoleCounts as $roleKey => $roleCount) $deviceRoleCounts[$roleKey] = (int)($roleRow[$roleKey] ?? 0);
    }
}
$devicePlatformCounts = ['tp_link' => 0, 'omada' => 0, 'mikrotik' => 0];
foreach ($devices as $deviceRow) {
    $devicePlatformKey = strtolower((string)($deviceRow['platform'] ?? ''));
    if (isset($devicePlatformCounts[$devicePlatformKey])) {
        $devicePlatformCounts[$devicePlatformKey]++;
    }
}
$tabs = ['connections' => 'Connections', 'overview' => 'Overview', 'online' => 'Online now', 'gateway' => 'Main Gateway', 'controllers' => 'Controllers', 'wifi' => 'Wi-Fi & Portal', 'devices' => 'Devices', 'deployments' => 'Deployments'];
?>
<style>
.net-page{--n-ink:#17233b;--n-muted:#71809a;--n-line:#e5ebf3;--n-teal:#0b8e82;color:var(--n-ink)}.net-head{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin:6px 0 20px}.net-title{margin:0;font-size:26px;font-weight:850;letter-spacing:-.04em}.net-lead{max-width:760px;margin:7px 0 0;color:var(--n-muted);font-size:14px;line-height:1.6}.net-tabs{display:flex;gap:7px;overflow:auto;padding:5px;margin:0 0 17px;border-bottom:1px solid var(--n-line)}.net-tabs a{white-space:nowrap;padding:10px 13px;border-radius:9px 9px 0 0;color:#52627b;text-decoration:none;font-size:13px;font-weight:700}.net-tabs a.active{background:#eaf7f5;color:#087e73}.net-card{background:#fff;border:1px solid var(--n-line);border-radius:15px;padding:20px;box-shadow:0 8px 25px #1c31500a;margin-bottom:16px}.net-card h2{margin:0 0 14px;font-size:16px}.net-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.net-field{display:flex;flex-direction:column;gap:6px}.net-field.full{grid-column:1/-1}.net-field label{font-size:12px;font-weight:750}.net-field input,.net-field select{min-height:42px;border:1px solid #d7e0eb;border-radius:9px;padding:9px 11px;font:inherit;font-size:13px;color:var(--n-ink);background:#fff}.net-hint{font-size:11px;color:var(--n-muted);line-height:1.5}.net-btn{display:inline-flex;align-items:center;gap:8px;margin-top:15px;min-height:42px;padding:0 15px;border:0;border-radius:9px;background:#087f74;color:#fff;font-weight:800;cursor:pointer}.net-note,.net-message{padding:13px 15px;margin:0 0 15px;border-radius:11px;font-size:12px;line-height:1.55}.net-note{background:#fff8e9;border:1px solid #f0d89f;color:#745311}.net-message{background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46}.net-error{background:#fff1f2;border:1px solid #fecdd3;color:#9f1239}.net-error ul{margin:5px 0 0;padding-left:19px}.net-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:16px}.net-stat{background:#fff;border:1px solid var(--n-line);border-radius:13px;padding:16px}.net-stat span{display:block;color:var(--n-muted);font-size:11px}.net-stat strong{display:block;margin-top:6px;font-size:22px}.net-table-wrap{overflow:auto}.net-table{width:100%;border-collapse:collapse;font-size:12px}.net-table th,.net-table td{text-align:left;padding:11px 9px;border-bottom:1px solid #edf1f5;white-space:nowrap}.net-table th{color:#677792;font-size:10px;text-transform:uppercase;letter-spacing:.05em}.net-badge{display:inline-flex;padding:4px 8px;border-radius:99px;background:#fff7e6;color:#966300;font-size:10px;font-weight:800}.net-empty{padding:20px;text-align:center;color:var(--n-muted);font-size:13px}.net-list-links{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.net-list-links a{padding:15px;background:#f8fafc;border:1px solid var(--n-line);border-radius:11px;color:var(--n-ink);text-decoration:none}.net-list-links strong{display:block;margin-bottom:5px}.net-list-links span{color:var(--n-muted);font-size:12px;line-height:1.45}
@media(max-width:800px){.net-stats{grid-template-columns:repeat(2,1fr)}.net-list-links{grid-template-columns:1fr}}@media(max-width:560px){.net-grid{grid-template-columns:1fr}.net-field.full{grid-column:auto}.net-card{padding:16px}.net-head{display:block}.net-stats{gap:8px}.net-stat{padding:12px}}
.net-config-section{grid-column:1/-1;padding:13px;border:1px solid #dce5ef;border-radius:12px;background:#f8fafc}.net-config-section>summary{display:flex;align-items:center;gap:8px;color:#34445d;font-size:12px;font-weight:800;cursor:pointer}.net-config-section>.net-grid{margin-top:13px}.net-map-help{grid-column:1/-1}.net-map-help a{color:#087f74;font-weight:800}
</style>
<style>
.net-head{align-items:center;margin:2px 0 18px}.net-head-actions{display:flex;align-items:center;gap:9px;flex-wrap:wrap}.net-back,.net-head-add{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:40px;padding:0 14px;border-radius:11px;text-decoration:none;font-size:12px;font-weight:800}.net-back{border:1px solid #f0d9cb;background:#fff8f3;color:#9a4c27}.net-head-add{border:1px solid #e87537;background:#e87537;color:#fff;cursor:pointer}.net-back:hover{background:#ffefe5}.net-head-add:hover{border-color:#ce5b25;background:#ce5b25;color:#fff}
.net-add-panel{margin:0 0 16px;border:1px solid #f1dfd3;border-radius:14px;background:#fff}.net-add-panel summary{display:flex;align-items:center;gap:9px;padding:15px 17px;color:#914721;font-size:13px;font-weight:800;cursor:pointer;list-style:none}.net-add-panel summary::-webkit-details-marker{display:none}.net-add-panel summary:after{content:'+';margin-left:auto;color:#e87537;font-size:20px}.net-add-panel[open] summary:after{content:'−'}.net-add-panel .net-add-content{padding:0 17px 16px;border-top:1px solid #f5eae2}
.net-inventory-toolbar{padding:15px;margin-bottom:15px;border:1px solid #f0e7e1;border-radius:14px;background:linear-gradient(120deg,#fffaf7,#fff)}.net-device-search{position:relative;display:block;margin-bottom:13px}.net-device-search i{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#9a8b83}.net-device-search input{width:100%;min-height:44px;padding:10px 14px 10px 40px;border:1px solid #eadfd9;border-radius:11px;background:#fff;font:inherit;font-size:13px;outline:none}.net-device-search input:focus{border-color:#e87537;box-shadow:0 0 0 3px #e875371c}.net-platform-filters{display:flex;gap:7px;overflow:auto;padding:2px 0 4px}.net-platform-filters button{display:inline-flex;align-items:center;gap:7px;min-height:36px;padding:0 13px;border:1px solid transparent;border-radius:22px;background:transparent;color:#657184;font:inherit;font-size:12px;font-weight:750;white-space:nowrap;cursor:pointer}.net-platform-filters button:hover{background:#fff1e8;color:#a34f26}.net-platform-filters button.active{border-color:#e87537;background:#e87537;color:#fff}.net-platform-filters span{font-size:10px;opacity:.78}.net-inventory-result{margin:10px 0 0;color:#8b7c73;font-size:11px}
.net-device-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px}.net-device-card{display:flex;min-width:0;flex-direction:column;padding:16px;border:1px solid #eee6e1;border-radius:16px;background:#fff;box-shadow:0 6px 20px #55321b0a;transition:transform .18s ease,box-shadow .18s ease}.net-device-card[hidden],.net-device-empty[hidden]{display:none!important}.net-device-card:hover{transform:translateY(-2px);box-shadow:0 12px 26px #55321b12}.net-device-top{display:flex;align-items:flex-start;gap:12px}.net-device-icon{display:grid;width:54px;height:54px;flex:0 0 54px;place-items:center;border:1px solid #f3d9c9;border-radius:13px;background:#fff0e7;color:#d9692e;font-size:20px}.net-device-heading{min-width:0;flex:1}.net-device-heading h2{overflow:hidden;margin:2px 0 4px;color:#263246;font-size:15px;font-weight:850;text-overflow:ellipsis;white-space:nowrap}.net-device-heading p{overflow:hidden;margin:0;color:#7e8999;font-size:11px;text-overflow:ellipsis;white-space:nowrap}.net-device-badges{display:flex;gap:6px;flex-wrap:wrap;margin:12px 0}.net-device-badge{display:inline-flex;align-items:center;gap:5px;padding:5px 8px;border-radius:20px;background:#f5f6f8;color:#596579;font-size:10px;font-weight:800}.net-device-badge.is-planned{background:#fff5e8;color:#a46117}.net-device-badge.is-online{background:#e9f8ef;color:#23824a}.net-device-badge.is-offline,.net-device-badge.is-disabled{background:#fff0ef;color:#b84a43}.net-device-description{min-height:36px;margin:0 0 13px;color:#747f8e;font-size:11px;line-height:1.55}.net-device-actions{display:flex;align-items:center;gap:8px;margin-top:auto;padding-top:12px;border-top:1px solid #f1eeeb}.net-device-details{flex:1;min-width:0}.net-device-details summary{display:inline-flex;align-items:center;gap:6px;color:#657184;font-size:11px;font-weight:750;cursor:pointer;list-style:none}.net-device-details summary::-webkit-details-marker{display:none}.net-device-setup{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:34px;padding:0 11px;border-radius:9px;background:#e87537;color:#fff;text-decoration:none;font-size:11px;font-weight:800;white-space:nowrap}.net-device-setup:hover{background:#ce5b25;color:#fff}.net-device-info{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:11px;padding:11px;border-radius:10px;background:#fffaf7}.net-device-info div{min-width:0}.net-device-info span{display:block;color:#9a8b83;font-size:9px}.net-device-info strong{display:block;overflow:hidden;margin-top:3px;color:#465266;font-size:10px;text-overflow:ellipsis;white-space:nowrap}.net-device-empty{grid-column:1/-1;padding:24px 16px;border:1px dashed #e7ddd6;border-radius:14px;background:#fffdfa;text-align:center;color:#897c74;font-size:13px}
@media(max-width:1050px){.net-device-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:680px){.net-head{display:flex;align-items:flex-start;flex-direction:column}.net-head-actions{width:100%}.net-device-grid{grid-template-columns:1fr}.net-inventory-toolbar{padding:11px}.net-platform-filters button{padding:0 10px}.net-device-card{padding:14px}}
</style>
<style>
.net-online-summary{position:relative;overflow:hidden;margin:0 0 16px;padding:24px;border:1px solid #dce8f8;border-radius:19px;background:linear-gradient(125deg,#f7fbff 0%,#edf5ff 54%,#f8faff 100%);box-shadow:0 12px 32px #315a8a0d}.net-online-summary:after{position:absolute;right:-70px;top:-120px;width:310px;height:310px;border:1px solid #2b6fc21a;border-radius:50%;content:"";pointer-events:none}.net-online-summary-top{position:relative;z-index:1;display:flex;align-items:center;justify-content:space-between;gap:12px}.net-live-label,.net-online-agent{display:inline-flex;align-items:center;gap:8px;font-size:10px;font-weight:850;letter-spacing:.09em}.net-live-label{color:#2469bd}.net-live-label i,.net-online-live-pill i{width:8px;height:8px;border-radius:50%;background:#2d9c68;box-shadow:0 0 0 4px #2d9c681c}.net-online-agent{padding:8px 11px;border:1px solid #e3eaf3;border-radius:99px;background:#fff;color:#64748b;letter-spacing:0}.net-online-agent.is-connected{border-color:#bce6cf;background:#f0fbf4;color:#23814b}.net-online-agent.is-waiting{border-color:#efdfbd;background:#fffaf0;color:#97701d}.net-online-summary h2{position:relative;z-index:1;margin:16px 0 4px;color:#172b49;font-size:25px;font-weight:850;letter-spacing:-.04em}.net-online-intro{position:relative;z-index:1;margin:0;color:#72819a;font-size:13px}.net-online-metrics{position:relative;z-index:1;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-top:21px}.net-online-metrics>div{min-width:0;padding:15px 16px;border:1px solid #e4edf8;border-radius:13px;background:#ffffffd9}.net-online-metrics span{display:block;color:#7b8aa2;font-size:9px;font-weight:850;letter-spacing:.07em}.net-online-metrics strong{display:block;margin-top:7px;color:#1d3c67;font-size:27px;line-height:1.1}.net-online-metrics small{display:block;margin-top:5px;color:#8391a5;font-size:10px;line-height:1.4}.net-online-last-checked{position:relative;z-index:1;display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-top:13px;color:#7b8aa2;font-size:10px}.net-online-card{min-width:0;margin:0 0 16px;padding:19px;border:1px solid #e5ebf3;border-radius:16px;background:#fff;box-shadow:0 8px 25px #1c31500a}.net-online-card-heading{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:13px}.net-online-card-heading h3{margin:0;color:#22334e;font-size:15px;font-weight:850}.net-online-card-heading p{margin:4px 0 0;color:#7f8ba0;font-size:11px}.net-online-live-pill{display:inline-flex;align-items:center;gap:7px;padding:6px 9px;border:1px solid #cfead9;border-radius:30px;background:#f2fbf5;color:#358054;font-size:9px;font-weight:850;text-transform:uppercase;letter-spacing:.06em}.net-online-live-pill i{width:6px;height:6px;box-shadow:none}.net-online-table-wrap{width:100%;overflow:auto;border:1px solid #edf0f5;border-radius:11px}.net-online-table{width:100%;min-width:840px;border-collapse:collapse;font-size:11px}.net-online-table th,.net-online-table td{padding:12px 11px;border-bottom:1px solid #edf1f5;text-align:left;white-space:nowrap}.net-online-table th{background:#f8fafc;color:#78869b;font-size:9px;font-weight:850;letter-spacing:.06em;text-transform:uppercase}.net-online-table tbody tr:last-child td{border-bottom:0}.net-online-table tbody tr:hover{background:#fbfdff}.net-online-table td{color:#45546a}.net-online-footnote{margin:11px 0 0;color:#8490a2;font-size:10px;line-height:1.5}.net-online-empty-state{padding:34px 18px;text-align:center}.net-online-empty-state>i{display:grid;width:48px;height:48px;margin:0 auto 12px;place-items:center;border-radius:15px;background:#eff6ff;color:#3678c9;font-size:18px}.net-online-empty-state h3{margin:0 0 5px;color:#293a53;font-size:15px}.net-online-empty-state p{max-width:440px;margin:0 auto;color:#8190a4;font-size:12px;line-height:1.55}.net-online-unlimited,.net-online-authorized{color:#25824f;font-size:10px;font-weight:800}.net-online-not-visible{display:block;margin-top:3px;color:#8b96a7;font-size:9px}.net-time-left{color:#285fac;font-variant-numeric:tabular-nums;font-weight:850}.net-time-left.is-ending{color:#b7791f}.net-time-left.is-expired{color:#b33d3d}
@media(max-width:700px){.net-online-summary{padding:18px;border-radius:16px}.net-online-summary h2{font-size:22px}.net-online-metrics{grid-template-columns:1fr;gap:8px;margin-top:16px}.net-online-metrics>div{display:grid;grid-template-columns:1fr auto;align-items:center;column-gap:12px;padding:12px 13px}.net-online-metrics span{grid-column:1}.net-online-metrics strong{grid-column:2;grid-row:1/3;margin:0;font-size:23px}.net-online-metrics small{grid-column:1;margin-top:3px}.net-online-card{padding:14px}.net-online-last-checked{display:block;line-height:1.7}.net-online-last-checked span{display:block}}
</style>
<style>.net-online-duration{color:#596a82;font-variant-numeric:tabular-nums;font-weight:750}.net-live-label.is-offline{color:#9a711e}.net-live-label.is-offline i{background:#c58a26;box-shadow:0 0 0 4px #c58a261c}</style>
<div class="net-page">
    <header class="net-head"><div><h1 class="net-title"><i class="fa-solid fa-network-wired" aria-hidden="true"></i> Routers</h1><p class="net-lead">Register TP-Link, Omada, and MikroTik devices; save SSID, WAN/LAN, DHCP, and DNS as preparation profiles. Device discovery and automatic deployment require a controller/API and physical hardware.</p></div><div class="net-head-actions"><a class="net-back" href="<?= e(appUrl('admin/dashboard.php?page=dashboard')) ?>"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i> Dashboard</a><?php if ($tab === 'devices' && $schemaReady): ?><button class="net-head-add" type="button" id="openDeviceForm"><i class="fa-solid fa-plus" aria-hidden="true"></i> Add Device</button><?php endif; ?></div></header>
    <?php if (!$schemaReady): ?><div class="net-note"><strong>The database is missing some network configuration tables.</strong> If the database already has router tables, create a backup and then run <code>admin/modules/router/upgrade.sql</code> once. If the router tables do not exist yet, run <code>admin/modules/router/install.sql</code> first.</div><?php endif; ?>
    <div class="net-note"><strong>Current status: preparation only.</strong> Prepare either MikroTik or Omada for each location in Connections. Verify API login before testing portal access on the installed network. Credentials are encrypted when saved.</div>
    <?php if ($success !== ''): ?><div class="net-message"><?= e($success) ?></div><?php endif; ?>
    <?php if ($errors): ?><div class="net-message net-error"><strong>Some details need to be corrected:</strong><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
    <nav class="net-tabs" aria-label="Router setup sections"><?php foreach ($tabs as $key => $label): ?><a class="<?= $tab === $key ? 'active' : '' ?>" href="<?= e(appUrl('admin/dashboard.php?page=router&tab=' . $key)) ?>"><?= e($label) ?></a><?php endforeach; ?></nav>

    <?php if (!$schemaReady): ?>
        <section class="net-card"><h2>Database setup</h2><p>The SQL only adds tables for Router/Network setup. This will not change existing packages, vouchers, payments, or tables.</p></section>
    <?php elseif ($tab === 'overview'): ?>
        <div class="net-stats"><div class="net-stat"><span>Controllers</span><strong><?= number_format($counts['controllers']) ?></strong></div><div class="net-stat"><span>Zilizounganishwa</span><strong><?= number_format($counts['connected']) ?></strong></div><div class="net-stat"><span>Wi-Fi profiles</span><strong><?= number_format($counts['profiles']) ?></strong></div><div class="net-stat"><span>Devices vilivyopangwa</span><strong><?= number_format($counts['planned']) ?></strong></div></div>
        <section class="net-card"><h2>Setup Checklist</h2><div class="net-list-links"><a href="<?= e(appUrl('admin/dashboard.php?page=router&tab=connections')) ?>"><strong>1. Choose MikroTik or Omada</strong><span>Prepare the connection, software version and account for each site.</span></a><a href="<?= e(appUrl('admin/dashboard.php?page=router&tab=wifi')) ?>"><strong>2. Wi-Fi & Portal</strong><span>Save the SSID and portal profile as a draft for the access points.</span></a><a href="<?= e(appUrl('admin/dashboard.php?page=router&tab=devices')) ?>"><strong>3. Access Points</strong><span>Register EAP110, WAVLINK and other access points with their site locations.</span></a></div></section>
        <section class="net-card"><h2>How the network will work</h2><ol><li>Choose MikroTik HotSpot or an Omada-managed network for each site.</li><li>For MikroTik, the gateway will control voucher access while compatible access points distribute Wi-Fi.</li><li>For Omada, the Controller and supported managed devices will handle external portal authorization.</li><li>The web application must reach the selected platform securely. Portal access, package speed and expiry require an on-site test before live use.</li></ol></section>
    <?php elseif ($tab === 'online'): ?>
        <?php
        $endingSoonCount = count(array_filter($onlineUsers, static fn(array $row): bool =>
            $row['time_left_seconds'] !== null
            && (int)$row['time_left_seconds'] > 0
            && (int)$row['time_left_seconds'] <= 300
        ));
        $agentLastChecked = trim((string)($routerAgent['last_seen_at'] ?? ''));
        $agentIdentity = trim((string)($routerAgent['router_identity'] ?? ''));
        $agentVersion = trim((string)($routerAgent['router_version'] ?? ''));
        $formatOnlineDuration = static function (int $seconds): string {
            $seconds = max(0, $seconds);
            $hours = intdiv($seconds, 3600);
            $minutes = intdiv($seconds % 3600, 60);
            if ($hours > 0) return $hours . 'h ' . $minutes . 'm';
            if ($minutes > 0) return $minutes . 'm ' . intdiv($seconds % 60, 1) . 's';
            return $seconds . 's';
        };
        ?>
        <?php if (!$onlineSchemaReady): ?>
            <section class="net-online-card"><h2>Online now</h2><p>Import <code>admin/modules/router/online_users.sql</code> into the same database. It creates only the online-session reporting tables.</p></section>
        <?php else: ?>
            <section class="net-online-summary">
                <div class="net-online-summary-top">
                    <span class="net-live-label <?= $routerAgentOnline ? '' : 'is-offline' ?>"><i aria-hidden="true"></i> <?= $routerAgentOnline ? 'LIVE' : 'OFFLINE' ?></span>
                    <div class="net-online-agent <?= $routerAgentOnline ? 'is-connected' : 'is-waiting' ?>">
                        <i class="fa-solid <?= $routerAgentOnline ? 'fa-circle-check' : 'fa-clock' ?>" aria-hidden="true"></i>
                        <?= $routerAgentOnline ? 'Router reporting' : 'Waiting for router connector' ?>
                    </div>
                </div>
                <h2>Online now</h2>
                <p class="net-online-intro">See who is using your Wi-Fi and how long each voucher has left.</p>
                <div class="net-online-metrics">
                    <div><span>USERS ONLINE</span><strong><?= number_format(count($onlineUsers)) ?></strong></div>
                    <div><span>ENDING WITHIN 5 MINUTES</span><strong><?= number_format($endingSoonCount) ?></strong><small><?= $endingSoonCount === 0 ? 'Nobody is about to drop off' : 'These vouchers are nearly finished' ?></small></div>
                    <div><span>PAID, NOT ONLINE</span><strong><?= number_format(count($paidNotOnline)) ?></strong><small>Customers with a live voucher who are not connected</small></div>
                </div>
                <div class="net-online-last-checked">
                    <span>Last checked <?= $routerAgentOnline && $agentLastChecked !== '' ? e(date('g:i:s A', strtotime($agentLastChecked))) : '—' ?> · refreshes every minute</span>
                    <?php if ($routerAgentOnline && ($agentIdentity !== '' || $agentVersion !== '')): ?><span><?= e(implode(' · ', array_filter([$agentIdentity, $agentVersion]))) ?></span><?php endif; ?>
                </div>
            </section>
            <?php if (!$routerAgentOnline): ?>
                <section class="net-online-card net-online-empty-state"><i class="fa-solid fa-wifi" aria-hidden="true"></i><h3>No live router data yet</h3><p>The online list will fill in after the MikroTik connector is installed and reports active Hotspot sessions.</p></section>
            <?php else: ?>
                <?php if (!$onlineUsers): ?>
                    <section class="net-online-card net-online-empty-state"><i class="fa-solid fa-user-slash" aria-hidden="true"></i><h3>No customers online right now</h3><p>Customers with active vouchers will appear here when their devices connect to the Wi-Fi.</p></section>
                <?php else: ?>
                    <section class="net-online-card">
                        <header class="net-online-card-heading"><div><h3>Connected customers</h3><p><?= number_format(count($onlineUsers)) ?> on the Wi-Fi</p></div><span class="net-online-live-pill"><i aria-hidden="true"></i> Live</span></header>
                        <div class="net-online-table-wrap"><table class="net-online-table"><thead><tr><th>Phone</th><th>Package</th><th>Device</th><th>Access point / interface</th><th>Joined</th><th>Online for</th><th>Time left</th></tr></thead><tbody>
                            <?php foreach ($onlineUsers as $onlineUser): ?>
                                <?php
                                $joinedTimestamp = strtotime((string)($onlineUser['joined_at'] ?? ''));
                                $leftSeconds = $onlineUser['time_left_seconds'] === null ? null : max(0, (int)$onlineUser['time_left_seconds']);
                                $deviceLabel = trim((string)($onlineUser['device_mac'] ?? ''));
                                if ($deviceLabel === '') $deviceLabel = trim((string)($onlineUser['device_ip'] ?? ''));
                                if ($deviceLabel === '') $deviceLabel = 'Unknown device';
                                $accessPointLabel = trim((string)($onlineUser['access_point'] ?? ''));
                                if ($accessPointLabel === '') $accessPointLabel = trim((string)($onlineUser['hotspot_server'] ?? ''));
                                if ($accessPointLabel === '') $accessPointLabel = 'Not reported by router';
                                ?>
                                <tr>
                                    <td><?= e((string)($onlineUser['phone'] ?: '—')) ?></td>
                                    <td><?= e((string)($onlineUser['package_name'] ?: 'Unknown package')) ?></td>
                                    <td><?= e($deviceLabel) ?></td>
                                    <td><?= e($accessPointLabel) ?></td>
                                    <td><?= $joinedTimestamp === false ? '—' : e(date('g:i:s A', $joinedTimestamp)) ?></td>
                                    <td><span class="net-online-duration" data-seconds="<?= max(0, (int)$onlineUser['online_for_seconds']) ?>" data-count-up="true"><?= e($formatOnlineDuration((int)$onlineUser['online_for_seconds'])) ?></span></td>
                                    <td><?php if ($leftSeconds === null): ?><span class="net-online-unlimited">No expiry</span><?php else: ?><span class="net-time-left" data-seconds="<?= $leftSeconds ?>"><?= e($formatOnlineDuration($leftSeconds)) ?></span><?php endif; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody></table></div>
                        <p class="net-online-footnote">Access point details depend on what the router or access-point controller reports. If several APs share one bridge, the router may only identify the shared interface.</p>
                    </section>
                <?php endif; ?>

                <section class="net-online-card">
                    <header class="net-online-card-heading"><div><h3>Paid, not online</h3><p><?= number_format(count($paidNotOnline)) ?> customers with time remaining who are not connected</p></div></header>
                    <?php if (!$paidNotOnline): ?><div class="net-empty">No paid vouchers are waiting to connect.</div><?php else: ?>
                        <div class="net-online-table-wrap"><table class="net-online-table"><thead><tr><th>Phone</th><th>Package</th><th>Device</th><th>Paid / activated</th><th>Expires</th><th>Status</th></tr></thead><tbody>
                            <?php foreach ($paidNotOnline as $waitingCustomer): ?>
                                <?php
                                $paidTimestamp = strtotime((string)($waitingCustomer['activated_at'] ?? ''));
                                $expiryTimestamp = strtotime((string)($waitingCustomer['expires_at'] ?? ''));
                                $waitingMac = trim((string)($waitingCustomer['device_mac'] ?? ''));
                                ?>
                                <tr>
                                    <td><?= e((string)($waitingCustomer['phone'] ?: '—')) ?></td>
                                    <td><?= e((string)($waitingCustomer['package_name'] ?: 'Unknown package')) ?></td>
                                    <td><?= e($waitingMac !== '' ? $waitingMac : 'Not registered') ?></td>
                                    <td><?= $paidTimestamp === false ? '—' : e(date('m/d/Y, g:i:s A', $paidTimestamp)) ?></td>
                                    <td><?= $expiryTimestamp === false ? 'No expiry' : e(date('m/d/Y, g:i:s A', $expiryTimestamp)) ?></td>
                                    <td><span class="net-online-authorized">Voucher active</span><span class="net-online-not-visible">Not online</span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody></table></div>
                    <?php endif; ?>
                </section>
            <?php endif; ?>
        <?php endif; ?>
    <?php elseif ($tab === 'gateway'): ?>
        <?php if (!$gatewaySchemaReady): ?>
            <section class="net-card"><h2>Main MikroTik Gateway</h2><p class="net-note">The gateway setup table is not installed yet. Import <strong>admin/modules/router/gateway.sql</strong> into the same database connected to this application to enable this form.</p></section>
        <?php else: ?>
            <section class="net-card"><h2>Main MikroTik Gateway</h2><p class="net-hint">This will be the central router for voucher access, package speed limits and expiry. Credentials are encrypted before saving. Saving details does not connect to or change the router.</p>
                <?php if ($mainGateway): ?><div class="net-note">Saved gateway: <strong><?= e((string)$mainGateway['name']) ?></strong> · <?= e((string)$mainGateway['management_host']) ?>:<?= (int)$mainGateway['api_port'] ?> · <?= (int)$mainGateway['username_saved'] && (int)$mainGateway['password_saved'] ? 'API credentials saved encrypted' : 'API credentials incomplete' ?> · <strong>Not connected</strong></div><?php endif; ?>
                <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=router&tab=gateway')) ?>"><?= csrfField() ?><input type="hidden" name="form_action" value="save_main_gateway"><div class="net-grid">
                    <div class="net-field"><label for="gateway_name">Gateway name</label><input id="gateway_name" name="gateway_name" maxlength="100" value="<?= e($gatewayFormName) ?>" required></div>
                    <div class="net-field"><label for="management_host">MikroTik management IP or hostname</label><input id="management_host" name="management_host" maxlength="253" value="<?= e($gatewayFormHost) ?>" placeholder="192.168.88.1" required><small class="net-hint">Enter the address only, without http:// or https://.</small></div>
                    <div class="net-field"><label for="api_port">RouterOS API-SSL port</label><input id="api_port" name="api_port" type="number" min="1" max="65535" value="<?= e($gatewayFormPort) ?>" required><small class="net-hint">The usual secure API port is 8729.</small></div>
                    <div class="net-field"><label for="api_username">RouterOS API username</label><input id="api_username" name="api_username" maxlength="190" autocomplete="username" placeholder="<?= (int)($mainGateway['username_saved'] ?? 0) ? 'Saved securely; leave blank to keep it' : 'Create a limited API user on MikroTik' ?>"></div>
                    <div class="net-field"><label for="api_password">RouterOS API password</label><input id="api_password" name="api_password" type="password" maxlength="4096" autocomplete="new-password" placeholder="<?= (int)($mainGateway['password_saved'] ?? 0) ? 'Saved securely; leave blank to keep it' : 'Enter the API user password' ?>"></div>
                    <div class="net-field"><label>Connection security</label><input type="text" value="API over TLS (API-SSL) is required" readonly><small class="net-hint">Restrict API-SSL access on the router firewall to the application server or approved management network.</small></div>
                </div><button class="net-btn" type="submit"><i class="fa-solid fa-lock"></i> Save Gateway Details</button></form>
            </section>
            <section class="net-card"><h2>Connection status</h2><p class="net-note">Status: <strong>Not connected</strong>. This screen only stores encrypted connection details. A connection test and voucher delivery to MikroTik still need to be implemented and tested with the actual router.</p></section>
        <?php endif; ?>
    <?php elseif ($tab === 'controllers'): ?>
        <section class="net-card"><h2>Add Omada Controller Draft</h2><p class="net-hint">Save the preparation details now. The controller will not connect until API integration is built and the hardware is available.</p><form method="post" action="<?= e(appUrl('admin/dashboard.php?page=router&tab=controllers')) ?>"><?= csrfField() ?><input type="hidden" name="form_action" value="save_controller"><div class="net-grid"><div class="net-field"><label for="controller_name">Controller Name</label><input id="controller_name" name="name" maxlength="100" placeholder="Example: Main Wi-Fi Controller" required></div><div class="net-field"><label for="controller_type">Type</label><select id="controller_type" name="controller_type"><option value="software">Software Controller</option><option value="hardware">Hardware Controller (OC200/OC300)</option><option value="cloud">Cloud Controller</option></select></div><div class="net-field"><label for="base_url">Controller URL</label><input id="base_url" name="base_url" type="url" maxlength="500" placeholder="https://192.168.1.10:8043"><span class="net-hint">You can leave this blank until the controller is available.</span></div><div class="net-field"><label for="site_id">Site ID/Name</label><input id="site_id" name="site_id" maxlength="120" placeholder="Mfano: Default"></div><div class="net-field"><label for="client_key">Open API Client Key</label><input id="client_key" name="api_client_key" type="password" maxlength="2048" autocomplete="new-password"></div><div class="net-field"><label for="client_secret">Open API Client Secret</label><input id="client_secret" name="api_client_secret" type="password" maxlength="4096" autocomplete="new-password"></div></div><button class="net-btn" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save Controller Draft</button></form></section>
        <section class="net-card"><h2>Saved Controllers</h2><?php if (!$controllers): ?><div class="net-empty">There are no controllers yet. You can prepare a draft above.</div><?php else: ?><div class="net-table-wrap"><table class="net-table"><thead><tr><th>Name</th><th>Type</th><th>URL</th><th>Open API secret</th><th>Status</th></tr></thead><tbody><?php foreach ($controllers as $controller): ?><tr><td><?= e((string)$controller['name']) ?></td><td><?= e(ucfirst((string)$controller['controller_type'])) ?></td><td><?= e((string)($controller['base_url'] ?: 'Not set')) ?></td><td><?= (int)$controller['secret_saved'] ? 'Encrypted and saved' : 'Not set' ?></td><td><span class="net-badge">Not connected</span></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
    <?php elseif ($tab === 'wifi'): ?>
        <section class="net-card"><h2>Create Wi-Fi Profile Draft</h2><p class="net-hint">The profile will be saved for future use and can be downloaded as JSON. It does not configure the router automatically.</p><form method="post" action="<?= e(appUrl('admin/dashboard.php?page=router&tab=wifi')) ?>"><?= csrfField() ?><input type="hidden" name="form_action" value="save_wifi_profile"><div class="net-grid"><div class="net-field"><label for="profile_name">Profile Name</label><input id="profile_name" name="name" maxlength="100" placeholder="Customer Wi-Fi" required></div><div class="net-field"><label for="platform">Platform</label><select id="platform" name="platform"><option value="tp_link">Standard TP-Link</option><option value="omada">Omada Controller</option><option value="mikrotik">MikroTik RouterOS</option></select></div><div class="net-field"><label for="device_family">Device family</label><select id="device_family" name="device_family"><option value="other">Other / not selected</option><option value="omada_eap">Omada EAP / Access Point</option><option value="omada_gateway">Omada Gateway / ER</option><option value="archer">Archer</option><option value="deco">Deco</option><option value="tl_wr">TL-WR</option><option value="tl_mr">TL-MR / 4G LTE</option><option value="dsl">DSL</option><option value="cellular">4G / 5G</option><option value="mikrotik_router">MikroTik RouterOS</option><option value="mikrotik_ap">MikroTik Access Point</option><option value="mikrotik_lte">MikroTik LTE / 5G</option><option value="mikrotik_other">Other MikroTik</option></select></div><div class="net-field"><label for="device_model">Model</label><input id="device_model" name="device_model" maxlength="100" placeholder="You can leave this blank until the device is purchased."></div><div class="net-field"><label for="hardware_version">Hardware version</label><input id="hardware_version" name="hardware_version" maxlength="50"></div><div class="net-field"><label for="firmware_version">Firmware version</label><input id="firmware_version" name="firmware_version" maxlength="80"></div><div class="net-field"><label for="ssid">Wi-Fi Name (SSID)</label><input id="ssid" name="ssid" maxlength="32" required></div><div class="net-field"><label for="access_mode">Access Mode</label><select id="access_mode" name="access_mode"><option value="voucher_portal">Voucher / Captive Portal</option><option value="guest_wifi">Guest Wi-Fi tu</option></select></div><div class="net-field"><label for="vlan_id">VLAN ID (optional)</label><input id="vlan_id" name="vlan_id" inputmode="numeric" maxlength="4"></div><div class="net-field"><label for="gateway_ip">Gateway IP (optional)</label><input id="gateway_ip" name="gateway_ip" maxlength="45" placeholder="192.168.10.1"></div><details class="net-config-section"><summary><i class="fa-solid fa-globe" aria-hidden="true"></i> WAN Connection</summary><div class="net-grid"><div class="net-field"><label for="wan_connection_type">WAN Type</label><select id="wan_connection_type" name="wan_connection_type"><option value="dhcp">DHCP / Automatic</option><option value="static">Static IP</option><option value="pppoe">PPPoE</option></select><small>Select the internet connection type provided by your ISP.</small></div><div class="net-field"><label for="wan_ip_address">Static WAN IP</label><input id="wan_ip_address" name="wan_ip_address" maxlength="45" placeholder="10.0.0.2"></div><div class="net-field"><label for="wan_subnet_cidr">WAN subnet (CIDR)</label><input id="wan_subnet_cidr" name="wan_subnet_cidr" maxlength="43" placeholder="10.0.0.0/24"></div><div class="net-field"><label for="wan_gateway_ip">WAN gateway</label><input id="wan_gateway_ip" name="wan_gateway_ip" maxlength="45" placeholder="10.0.0.1"></div><div class="net-field"><label for="pppoe_username">PPPoE username</label><input id="pppoe_username" name="pppoe_username" maxlength="190" autocomplete="username"></div><div class="net-field"><label for="pppoe_password">PPPoE password</label><input id="pppoe_password" name="pppoe_password" type="password" maxlength="4096" autocomplete="new-password"><small>Stored encrypted; not included in downloads.</small></div></div></details><details class="net-config-section"><summary><i class="fa-solid fa-network-wired" aria-hidden="true"></i> LAN, DHCP & DNS</summary><div class="net-grid"><div class="net-field"><label for="lan_subnet_cidr">LAN subnet (CIDR)</label><input id="lan_subnet_cidr" name="lan_subnet_cidr" maxlength="43" placeholder="192.168.10.0/24"></div><div class="net-field"><label for="dhcp_enabled">DHCP Server</label><select id="dhcp_enabled" name="dhcp_enabled"><option value="0">Disabled</option><option value="1">Enabled</option></select></div><div class="net-field"><label for="dhcp_start_ip">DHCP pool start</label><input id="dhcp_start_ip" name="dhcp_start_ip" maxlength="45" placeholder="192.168.10.100"></div><div class="net-field"><label for="dhcp_end_ip">DHCP pool end</label><input id="dhcp_end_ip" name="dhcp_end_ip" maxlength="45" placeholder="192.168.10.200"></div><div class="net-field"><label for="dns_primary">Primary DNS</label><input id="dns_primary" name="dns_primary" maxlength="45" placeholder="1.1.1.1"></div><div class="net-field"><label for="dns_secondary">Secondary DNS</label><input id="dns_secondary" name="dns_secondary" maxlength="45" placeholder="8.8.8.8"></div></div></details><div class="net-field"><label for="portal_url">Portal URL (optional for a draft)</label><input id="portal_url" name="portal_url" type="url" maxlength="500" placeholder="https://wifi.example.com"></div><div class="net-field"><label for="controller_id">Omada Controller (optional)</label><select id="controller_id" name="controller_id"><option value="0">None yet / standard TP-Link</option><?php foreach ($controllers as $controller): ?><option value="<?= (int)$controller['id'] ?>"><?= e((string)$controller['name']) ?></option><?php endforeach; ?></select></div></div><button class="net-btn" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save Wi-Fi Draft</button></form></section>
        <section class="net-card"><h2>Wi-Fi profiles</h2><?php if (!$profiles): ?><div class="net-empty">There are no Wi-Fi profiles yet.</div><?php else: ?><div class="net-table-wrap"><table class="net-table"><thead><tr><th>Profile / SSID</th><th>Platform</th><th>Model</th><th>Mode</th><th>Status</th><th>Configuration</th></tr></thead><tbody><?php foreach ($profiles as $profile): ?><tr><td><?= e((string)$profile['name']) ?><br><?= e((string)$profile['ssid']) ?></td><td><?= e(strtoupper((string)$profile['platform'])) ?></td><td><?= e((string)($profile['device_model'] ?: $profile['device_family'])) ?></td><td><?= e(str_replace('_', ' ', (string)$profile['access_mode'])) ?></td><td><span class="net-badge">Draft</span></td><td><a href="<?= e(appUrl('admin/modules/router/download.php?id=' . (int)$profile['id'])) ?>">Download JSON</a></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
    <?php elseif ($tab === 'devices'): ?>
        <section class="net-stats" aria-label="Registered hardware summary">
            <div class="net-stat"><span>Registered devices</span><strong><?= number_format($counts['devices']) ?></strong></div>
            <div class="net-stat"><span>Access points</span><strong><?= number_format($deviceRoleCounts['access_points']) ?></strong></div>
            <div class="net-stat"><span>Routers / Gateways</span><strong><?= number_format($deviceRoleCounts['routers']) ?></strong></div>
            <div class="net-stat"><span>Other hardware</span><strong><?= number_format($deviceRoleCounts['other']) ?></strong></div>
        </section>
        <section class="net-card"><h2>Hardware inventory</h2><p class="net-hint">Added devices appear here with their model, site, IP and MAC address. Live device monitoring is not connected yet; registration and API login checks do not confirm that an access point is online.</p><a class="net-btn" href="<?= e(appUrl('admin/dashboard.php?page=router&tab=connections')) ?>"><i class="fa-solid fa-plug" aria-hidden="true"></i> Manage connections</a></section>
        <details class="net-add-panel" id="deviceFormPanel" <?= $errors && $tab === 'devices' ? 'open' : '' ?>><summary><i class="fa-solid fa-plus" aria-hidden="true"></i> Register a device</summary><div class="net-add-content"><p class="net-hint">Save the model you plan to use. The device will appear as planned until it is connected.</p><form method="post" action="<?= e(appUrl('admin/dashboard.php?page=router&tab=devices')) ?>"><?= csrfField() ?><input type="hidden" name="form_action" value="save_device"><div class="net-grid"><div class="net-field"><label for="device_platform">Platform</label><select id="device_platform" name="platform"><option value="tp_link">Standard TP-Link</option><option value="omada">Omada</option><option value="mikrotik">MikroTik</option></select></div><div class="net-field"><label for="device_role">Jukumu</label><select id="device_role" name="role"><option value="access_point">Access Point</option><option value="gateway">Gateway</option><option value="router">Router</option><option value="other">Other</option></select></div><div class="net-field"><label for="device_family_inventory">Family</label><input id="device_family_inventory" name="device_family" maxlength="60" placeholder="Example: Omada EAP, Archer" required></div><div class="net-field"><label for="device_model_inventory">Model</label><input id="device_model_inventory" name="device_model" maxlength="100" placeholder="Mfano: EAP225" required></div><div class="net-field"><label for="hardware_inventory">Hardware version</label><input id="hardware_inventory" name="hardware_version" maxlength="50"></div><div class="net-field"><label for="firmware_inventory">Firmware version</label><input id="firmware_inventory" name="firmware_version" maxlength="80"></div><div class="net-field"><label for="management_ip">Management IP (optional)</label><input id="management_ip" name="management_ip" maxlength="45"></div><div class="net-field"><label for="serial_number">Serial number</label><input id="serial_number" name="serial_number" maxlength="100"></div><div class="net-field"><label for="mac_address">MAC address</label><input id="mac_address" name="mac_address" maxlength="17" placeholder="AA:BB:CC:11:22:33"></div><?php if ($sitesSchemaReady): ?><div class="net-field"><label for="device_site_id">Site / Location <span>(required for Access Point)</span></label><select id="device_site_id" name="site_id"><option value="0">Choose a saved site</option><?php foreach ($siteOptions as $siteOption): ?><option value="<?= (int)$siteOption['id'] ?>" <?= (int)($_POST['site_id'] ?? 0) === (int)$siteOption['id'] ? 'selected' : '' ?>><?= e((string)$siteOption['name']) ?><?= !empty($siteOption['location_detail']) ? ' · ' . e((string)$siteOption['location_detail']) : '' ?></option><?php endforeach; ?></select><small class="net-hint">Select where this Access Point will be installed, or create a site below.</small></div><details class="net-config-section" <?= $errors && (postString('new_site_name', '') !== '' || postString('new_site_location', '') !== '' || postString('new_site_latitude', '') !== '' || postString('new_site_longitude', '') !== '') ? 'open' : '' ?>><summary><i class="fa-solid fa-location-dot" aria-hidden="true"></i> Add a new site and use it for this device</summary><div class="net-grid"><div class="net-field"><label for="new_site_name">Site name</label><input id="new_site_name" name="new_site_name" maxlength="100" placeholder="Magomeni" value="<?= e(postString('new_site_name', '')) ?>"></div><div class="net-field"><label for="new_site_location">Location details</label><input id="new_site_location" name="new_site_location" maxlength="255" placeholder="Street, building, or landmark" value="<?= e(postString('new_site_location', '')) ?>"></div><div class="net-field"><label for="new_site_latitude">Latitude (optional)</label><input id="new_site_latitude" name="new_site_latitude" type="number" step="any" min="-90" max="90" placeholder="-6.7800000" value="<?= e(postString('new_site_latitude', '')) ?>"></div><div class="net-field"><label for="new_site_longitude">Longitude (optional)</label><input id="new_site_longitude" name="new_site_longitude" type="number" step="any" min="-180" max="180" placeholder="39.2400000" value="<?= e(postString('new_site_longitude', '')) ?>"></div><p class="net-hint net-map-help">Open <a href="https://www.google.com/maps/search/?api=1&amp;query=Tanzania" target="_blank" rel="noopener noreferrer">Google Maps</a> to find the site, then enter its latitude and longitude above.</p></div></details><?php else: ?><p class="net-hint">Site locations are unavailable until the Sites setup is installed.</p><?php endif; ?><div class="net-field"><label for="device_controller">Controller</label><select id="device_controller" name="controller_id"><option value="0">Not connected</option><?php foreach ($controllers as $controller): ?><option value="<?= (int)$controller['id'] ?>"><?= e((string)$controller['name']) ?></option><?php endforeach; ?></select></div></div><button class="net-btn" type="submit"><i class="fa-solid fa-plus"></i> Save device</button></form></div></details>
        <section class="net-inventory-toolbar" aria-label="Search and filter devices"><label class="net-device-search"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i><input type="search" id="deviceSearch" maxlength="120" placeholder="Search devices, model, controller, or IP" autocomplete="off"></label><nav class="net-platform-filters" aria-label="Filter by platform"><button type="button" class="active" aria-pressed="true" data-device-platform="all">All devices <span><?= number_format(count($devices)) ?></span></button><button type="button" aria-pressed="false" data-device-platform="tp_link">TP-Link <span><?= number_format($devicePlatformCounts['tp_link']) ?></span></button><button type="button" aria-pressed="false" data-device-platform="omada">Omada <span><?= number_format($devicePlatformCounts['omada']) ?></span></button><button type="button" aria-pressed="false" data-device-platform="mikrotik">MikroTik <span><?= number_format($devicePlatformCounts['mikrotik']) ?></span></button></nav><p class="net-inventory-result" id="deviceResultCount" aria-live="polite"><?= number_format(count($devices)) ?> devices<?= $counts['devices'] > count($devices) ? ' (latest 50; totals include all registered devices)' : '' ?></p></section>
        <section class="net-device-grid" id="deviceCardGrid" aria-label="Network devices">
            <?php if (!$devices): ?><div class="net-device-empty">No registered devices yet. Use Add Device to register an access point, MikroTik, Omada or other TP-Link device and its location.</div><?php else: ?>
                <?php foreach ($devices as $device): ?>
                    <?php
                    $devicePlatform = strtolower((string)($device['platform'] ?? ''));
                    $devicePlatformLabel = match ($devicePlatform) { 'omada' => 'Omada', 'mikrotik' => 'MikroTik', default => 'TP-Link' };
                    $deviceStatus = strtolower((string)($device['status'] ?? 'planned'));
                    $deviceStatusLabel = match ($deviceStatus) {
                        'online' => 'Recorded: online', 'offline' => 'Recorded: offline', 'disabled' => 'Disabled', default => 'Registered',
                    };
                    $deviceStatusClass = match ($deviceStatus) {
                        'online' => 'is-online', 'offline' => 'is-offline', 'disabled' => 'is-disabled', default => 'is-planned',
                    };
                    $deviceRoleLabel = ucwords(str_replace('_', ' ', (string)($device['role'] ?? 'access_point')));
                    $deviceSearchText = strtolower(implode(' ', array_map('strval', [
                        $devicePlatformLabel, $device['device_family'] ?? '', $device['device_model'] ?? '',
                        $deviceRoleLabel, $device['hardware_version'] ?? '', $device['firmware_version'] ?? '',
                        $device['management_ip'] ?? '', $device['serial_number'] ?? '', $device['mac_address'] ?? '', $device['controller_name'] ?? '', $device['site_name'] ?? '', $device['site_location'] ?? '', $deviceStatusLabel,
                    ])));
                    ?>
                    <article class="net-device-card" data-platform="<?= e($devicePlatform) ?>" data-search="<?= e($deviceSearchText) ?>">
                        <div class="net-device-top"><span class="net-device-icon"><i class="<?= $devicePlatform === 'omada' ? 'fa-solid fa-wifi' : ($devicePlatform === 'mikrotik' ? 'fa-solid fa-network-wired' : 'fa-solid fa-router') ?>" aria-hidden="true"></i></span><div class="net-device-heading"><h2><?= e($devicePlatformLabel) ?></h2><p><?= e((string)($device['device_family'] ?? 'Network device')) ?> · <?= e((string)($device['device_model'] ?? 'Model not set')) ?></p></div></div>
                        <div class="net-device-badges"><span class="net-device-badge <?= e($deviceStatusClass) ?>"><i class="fa-solid <?= $deviceStatus === 'online' ? 'fa-circle-check' : ($deviceStatus === 'offline' ? 'fa-circle-xmark' : 'fa-clock') ?>" aria-hidden="true"></i> <?= e($deviceStatusLabel) ?></span><span class="net-device-badge"><?= e($deviceRoleLabel) ?></span></div>
                        <p class="net-hint">Connection: <strong>Not verified</strong> · Last checked: Not checked</p>
                        <p class="net-device-description"><?= e((string)($device['controller_name'] ?: 'Controller not assigned')) ?><?= !empty($device['management_ip']) ? ' · ' . e((string)$device['management_ip']) : '' ?><br><?= !empty($device['site_name']) ? 'Site: ' . e((string)$device['site_name']) : 'Location not set' ?><?= !empty($device['site_location']) ? ' · ' . e((string)$device['site_location']) : '' ?><?php if (is_numeric($device['site_latitude'] ?? null) && is_numeric($device['site_longitude'] ?? null)): ?> · <a href="https://www.google.com/maps/search/?api=1&amp;query=<?= rawurlencode((string)$device['site_latitude'] . ',' . (string)$device['site_longitude']) ?>" target="_blank" rel="noopener noreferrer">Google Maps</a><?php endif; ?></p>
                        <div class="net-device-actions"><details class="net-device-details"><summary><i class="fa-regular fa-eye" aria-hidden="true"></i> Details</summary><div class="net-device-info"><div><span>Serial</span><strong><?= e((string)($device['serial_number'] ?: 'Not set')) ?></strong></div><div><span>MAC address</span><strong><?= e((string)($device['mac_address'] ?: 'Not set')) ?></strong></div><div><span>Hardware</span><strong><?= e((string)($device['hardware_version'] ?: 'Not set')) ?></strong></div><div><span>Firmware</span><strong><?= e((string)($device['firmware_version'] ?: 'Not set')) ?></strong></div><div><span>Controller</span><strong><?= e((string)($device['controller_name'] ?: 'Not connected')) ?></strong></div><div><span>Site</span><strong><?= e((string)($device['site_name'] ?: 'Location not set')) ?></strong></div><div><span>Status</span><strong><?= e($deviceStatusLabel) ?></strong></div></div></details><a class="net-device-setup" href="<?= e(appUrl('admin/dashboard.php?page=router&tab=wifi')) ?>"><i class="fa-solid fa-sliders" aria-hidden="true"></i> Setup</a></div>
                    </article>
                <?php endforeach; ?>
            <?php endif; ?>
            <div class="net-device-empty" id="deviceFilterEmpty" hidden>No devices match this search.</div>
        </section>
    <?php else: ?>
        <section class="net-card"><h2>Configuration deployments</h2><p>This section will show connection tests and submitted settings. No deployment is running because the hardware/controller is not available yet.</p><?php if (!$deployments): ?><div class="net-empty">No deployments have been run. Wi-Fi drafts are not sent to devices.</div><?php else: ?><div class="net-table-wrap"><table class="net-table"><thead><tr><th>Date</th><th>Controller</th><th>Profile</th><th>Status</th><th>Details</th></tr></thead><tbody><?php foreach ($deployments as $deployment): ?><tr><td><?= e((string)$deployment['created_at']) ?></td><td><?= e((string)($deployment['controller_name'] ?: '—')) ?></td><td><?= e((string)($deployment['profile_name'] ?: '—')) ?></td><td><?= e((string)$deployment['status']) ?></td><td><?= e((string)$deployment['summary']) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
    <?php endif; ?>
</div>
<script>
(function () {
    const platform = document.getElementById('platform');
    const family = document.getElementById('device_family');
    if (!platform || !family) return;
    platform.addEventListener('change', function () {
        if (platform.value === 'omada' && !['omada_eap', 'omada_gateway'].includes(family.value)) {
            family.value = 'omada_eap';
        } else if (platform.value === 'mikrotik' && !family.value.startsWith('mikrotik_')) {
            family.value = 'mikrotik_router';
        } else if (platform.value === 'tp_link' && (family.value.startsWith('omada_') || family.value.startsWith('mikrotik_'))) {
            family.value = 'other';
        }
    });
    family.addEventListener('change', function () {
        if (['omada_eap', 'omada_gateway'].includes(family.value)) platform.value = 'omada';
        else if (family.value.startsWith('mikrotik_')) platform.value = 'mikrotik';
        else platform.value = 'tp_link';
    });
})();
(function () {
    const searchInput = document.getElementById('deviceSearch');
    const cards = Array.from(document.querySelectorAll('.net-device-card'));
    const filters = Array.from(document.querySelectorAll('[data-device-platform]'));
    const countLabel = document.getElementById('deviceResultCount');
    const emptyMessage = document.getElementById('deviceFilterEmpty');
    const addButton = document.getElementById('openDeviceForm');
    const addPanel = document.getElementById('deviceFormPanel');
    let selectedPlatform = 'all';

    function applyDeviceFilters() {
        const searchTerm = (searchInput ? searchInput.value : '').trim().toLocaleLowerCase();
        let visibleCount = 0;
        cards.forEach(function (card) {
            const platformMatches = selectedPlatform === 'all' || card.dataset.platform === selectedPlatform;
            const searchMatches = searchTerm === '' || (card.dataset.search || '').toLocaleLowerCase().includes(searchTerm);
            const visible = platformMatches && searchMatches;
            card.hidden = !visible;
            if (visible) visibleCount++;
        });
        if (countLabel) countLabel.textContent = visibleCount + (visibleCount === 1 ? ' device' : ' devices');
        if (emptyMessage) emptyMessage.hidden = visibleCount !== 0 || cards.length === 0;
    }

    if (searchInput) searchInput.addEventListener('input', applyDeviceFilters);
    filters.forEach(function (filter) {
        filter.addEventListener('click', function () {
            selectedPlatform = filter.dataset.devicePlatform || 'all';
            filters.forEach(function (button) {
                const isActive = button === filter;
                button.classList.toggle('active', isActive);
                button.setAttribute('aria-pressed', isActive ? 'true' : 'false');
            });
            applyDeviceFilters();
        });
    });
    if (addButton && addPanel) {
        addButton.addEventListener('click', function () {
            addPanel.open = true;
            addPanel.scrollIntoView({ behavior: 'smooth', block: 'center' });
        });
    }
    applyDeviceFilters();
})();
(function () {
    if (!document.querySelector('.net-online-summary')) return;
    const counters = Array.from(document.querySelectorAll('[data-seconds]'));
    function formatDuration(seconds) {
        seconds = Math.max(0, Math.floor(seconds));
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const remaining = seconds % 60;
        if (hours > 0) return hours + 'h ' + minutes + 'm';
        if (minutes > 0) return minutes + 'm ' + remaining + 's';
        return seconds + 's';
    }
    window.setInterval(function () {
        counters.forEach(function (counter) {
            let seconds = Number(counter.dataset.seconds || 0);
            if (!Number.isFinite(seconds)) seconds = 0;
            seconds = counter.dataset.countUp === 'true' ? seconds + 1 : Math.max(0, seconds - 1);
            counter.dataset.seconds = String(seconds);
            counter.textContent = formatDuration(seconds);
            if (counter.dataset.countUp !== 'true') {
                counter.classList.toggle('is-ending', seconds > 0 && seconds <= 300);
                counter.classList.toggle('is-expired', seconds === 0);
            }
        });
    }, 1000);
    window.setTimeout(function () { window.location.reload(); }, 60000);
})();
</script>
