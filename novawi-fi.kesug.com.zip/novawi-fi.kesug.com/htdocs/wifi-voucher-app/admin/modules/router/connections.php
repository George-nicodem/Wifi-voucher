<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/admin_auth.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/connection_drivers.php';
require_once __DIR__ . '/network_readiness.php';
requireAdminLogin();
global $conn;
$niHosting = novaNetworkHostingProfile((string)($_SERVER['DOCUMENT_ROOT'] ?? ''), appUrl(''));

$niErrors = []; $niSuccess = ''; $niReady = false; $niRows = [];
$niEdit = max(0, (int)(getInt('connection_id', 0) ?? 0));
$niForm = ['id' => 0, 'name' => '', 'platform' => 'mikrotik', 'controller_type' => 'software',
    'software_version' => '', 'controller_uid' => '', 'endpoint' => '', 'api_port' => 8729, 'site_id' => null];
$niColumns = 'id,name,platform,controller_type,software_version,controller_uid,endpoint,api_port,site_id,revision,test_status,test_message,last_tested_at,reported_version';
try {
    $niResult = $conn->query('SHOW TABLES LIKE \'network_connection_profiles\'');
    $niReady = $niResult instanceof mysqli_result && $niResult->num_rows > 0;
    if ($niResult instanceof mysqli_result) $niResult->free();
} catch (Throwable) { $niErrors[] = 'Could not check connection storage.'; }
if (empty($_SESSION['network_connection_nonce'])) $_SESSION['network_connection_nonce'] = bin2hex(random_bytes(24));
$niCsrf = csrfField();
$niNonce = (string)$_SESSION['network_connection_nonce'];

if (isPost()) {
    requireAdminRole(['admin', 'super_admin', 'superadmin']);
    requireAdminPost(); requireCsrfToken();
    try {
        $nonce = $_POST['connection_nonce'] ?? '';
        if (!is_string($nonce) || !hash_equals($niNonce, $nonce)) throw new RuntimeException('This form has already been submitted or expired. Reload the page before trying again.');
        $_SESSION['network_connection_nonce'] = bin2hex(random_bytes(24));
        $niNonce = (string)$_SESSION['network_connection_nonce'];
        $action = postString('network_action', '');
        if ($action === 'prepare_storage') {
            $sql = "CREATE TABLE IF NOT EXISTS network_connection_profiles (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL, platform VARCHAR(16) NOT NULL,
                controller_type VARCHAR(20) NOT NULL DEFAULT 'software', software_version VARCHAR(40) NOT NULL DEFAULT '',
                controller_uid VARCHAR(120) NOT NULL DEFAULT '', endpoint VARCHAR(500) NOT NULL DEFAULT '',
                api_port SMALLINT UNSIGNED NOT NULL DEFAULT 8729, site_id BIGINT UNSIGNED NULL,
                username_enc TEXT NULL, password_enc TEXT NULL, revision INT UNSIGNED NOT NULL DEFAULT 1,
                test_status VARCHAR(24) NOT NULL DEFAULT 'not_tested', test_message VARCHAR(500) NOT NULL DEFAULT '',
                reported_version VARCHAR(100) NOT NULL DEFAULT '', last_tested_at DATETIME NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                KEY idx_network_connection_site (site_id), KEY idx_network_connection_platform (platform)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
            if (!$conn->query($sql)) throw new RuntimeException('Connection storage could not be prepared.');
            $niReady = true; $niSuccess = 'Connection profiles are ready. Add a MikroTik or Omada profile below.';
            logAdminSecurityEvent('NETWORK_CONNECTION_STORAGE_PREPARED', 'Prepared additive network connection profile storage.');
        } elseif ($action === 'save_connection' && $niReady) {
            $niForm = ['id' => max(0, (int)postInt('connection_id')), 'name' => trim(postString('connection_name', '')),
                'platform' => postString('connection_platform', ''), 'controller_type' => postString('controller_type', ''),
                'software_version' => trim(postString('software_version', '')), 'controller_uid' => trim(postString('controller_uid', '')),
                'endpoint' => trim(postString('endpoint', '')), 'api_port' => (int)postInt('api_port'),
                'site_id' => max(0, (int)postInt('network_site_id')) ?: null];
            if ($niForm['name'] === '' || routerAdminLength($niForm['name']) > 100) throw new RuntimeException('Enter a name up to 100 characters.');
            if (!in_array($niForm['platform'], ['mikrotik','omada'], true) || !in_array($niForm['controller_type'], ['software','hardware','cloud'], true)) throw new RuntimeException('Choose a valid platform and controller type.');
            if (strlen($niForm['software_version']) > 40 || ($niForm['software_version'] !== '' && !preg_match('/^[A-Za-z0-9.() _-]+$/D', $niForm['software_version']))) throw new RuntimeException('Enter a valid software version up to 40 characters.');
            if ($niForm['controller_uid'] !== '' && !preg_match('/^[A-Za-z0-9_-]{1,120}$/D', $niForm['controller_uid'])) throw new RuntimeException('Controller ID may contain letters, numbers, underscores and hyphens.');
            if ($niForm['platform'] === 'omada') {
                $niForm['endpoint'] = $niForm['endpoint'] !== '' ? novaNetworkBaseUrl($niForm['endpoint']) : '';
                $niForm['api_port'] = (int)(parse_url($niForm['endpoint'], PHP_URL_PORT) ?: 443);
            } else {
                $niForm['controller_uid'] = '';
                $niForm['endpoint'] = $niForm['endpoint'] !== '' ? novaNetworkHost($niForm['endpoint']) : '';
                if ($niForm['api_port'] < 1 || $niForm['api_port'] > 65535) throw new RuntimeException('Enter a valid MikroTik API-SSL port.');
            }
            if ($niForm['site_id'] !== null) {
                $check = $conn->prepare('SELECT id FROM network_sites WHERE id = ? LIMIT 1');
                if (!$check) throw new RuntimeException('Site lookup is unavailable.');
                $check->bind_param('i', $niForm['site_id']); $check->execute(); $found = $check->get_result()?->fetch_assoc(); $check->close();
                if (!$found) throw new RuntimeException('Choose an existing site.');
            }
            $username = $_POST['connection_username'] ?? ''; $password = $_POST['connection_password'] ?? '';
            if (!is_string($username) || !is_string($password) || strlen($username) > 190 || strlen($password) > 4096) throw new RuntimeException('The credentials exceed the allowed length.');
            $username = trim($username); $old = null;
            if ($niForm['id'] > 0) {
                $stmt = $conn->prepare('SELECT platform,endpoint,api_port,controller_uid,username_enc,password_enc FROM network_connection_profiles WHERE id = ? LIMIT 1');
                if (!$stmt) throw new RuntimeException('The connection could not be loaded.');
                $stmt->bind_param('i', $niForm['id']); $stmt->execute(); $old = $stmt->get_result()?->fetch_assoc(); $stmt->close();
                if (!$old) throw new RuntimeException('This connection no longer exists.');
                $destinationChanged = (string)$old['platform'] !== $niForm['platform']
                    || (string)$old['endpoint'] !== $niForm['endpoint']
                    || (int)$old['api_port'] !== $niForm['api_port']
                    || (string)$old['controller_uid'] !== $niForm['controller_uid'];
                if ($destinationChanged && (!empty($old['username_enc']) || !empty($old['password_enc']))
                    && ($username === '' || $password === '')) {
                    throw new RuntimeException('Re-enter the username and password when changing the platform, address, port or Controller ID.');
                }
            }
            if (($username !== '' || $password !== '') && !routerAdminEncryptionReady()) throw new RuntimeException('Encryption must be configured before saving credentials.');
            $userEnc = $username !== '' ? encryptData($username) : ($old['username_enc'] ?? null);
            $passEnc = $password !== '' ? encryptData($password) : ($old['password_enc'] ?? null);
            if (($username !== '' && (!is_string($userEnc) || $userEnc === '' || hash_equals($username, $userEnc)))
                || ($password !== '' && (!is_string($passEnc) || $passEnc === '' || hash_equals($password, $passEnc)))) throw new RuntimeException('The credentials could not be encrypted.');
            $fields = [$niForm['name'],$niForm['platform'],$niForm['controller_type'],$niForm['software_version'],$niForm['controller_uid'],$niForm['endpoint'],$niForm['api_port'],$niForm['site_id'],$userEnc,$passEnc];
            if ($niForm['id'] > 0) {
                $stmt = $conn->prepare("UPDATE network_connection_profiles SET name=?,platform=?,controller_type=?,software_version=?,controller_uid=?,endpoint=?,api_port=?,site_id=?,username_enc=?,password_enc=?,revision=revision+1,test_status='not_tested',test_message='',last_tested_at=NULL,reported_version='' WHERE id=?");
                $fields[] = $niForm['id']; $types = 'ssssssiissi';
            } else {
                $stmt = $conn->prepare('INSERT INTO network_connection_profiles (name,platform,controller_type,software_version,controller_uid,endpoint,api_port,site_id,username_enc,password_enc) VALUES (?,?,?,?,?,?,?,?,?,?)');
                $types = 'ssssssiiss';
            }
            if (!$stmt) throw new RuntimeException('Could not prepare the connection save.');
            $stmt->bind_param($types, ...$fields);
            if (!$stmt->execute()) { $stmt->close(); throw new RuntimeException('The connection could not be saved.'); }
            if ($niForm['id'] === 0) $niForm['id'] = (int)$conn->insert_id;
            $stmt->close(); $niEdit = (int)$niForm['id'];
            $niSuccess = 'Connection profile saved. Run Test API login when the device is available.';
            logAdminSecurityEvent('NETWORK_CONNECTION_SAVED', 'Saved connection profile #' . $niEdit . '.');
        } elseif ($action === 'test_connection' && $niReady) {
            $id = max(0, (int)postInt('connection_id'));
            if (time() - (int)($_SESSION['network_last_test_at'] ?? 0) < 10) throw new RuntimeException('Wait ten seconds between connection tests.');
            $_SESSION['network_last_test_at'] = time();
            $stmt = $conn->prepare('SELECT * FROM network_connection_profiles WHERE id=? LIMIT 1');
            if (!$stmt) throw new RuntimeException('Could not load the saved connection.');
            $stmt->bind_param('i', $id); $stmt->execute(); $config = $stmt->get_result()?->fetch_assoc(); $stmt->close();
            if (!$config) throw new RuntimeException('Choose a saved connection.');
            $preflight = novaNetworkConnectionReadiness($config + [
                'username_saved' => !empty($config['username_enc']), 'password_saved' => !empty($config['password_enc'])
            ], $niHosting);
            if (!$preflight['can_attempt_login']) throw new RuntimeException(implode(' ', $preflight['issues']));
            $user = !empty($config['username_enc']) ? decryptData((string)$config['username_enc']) : '';
            $pass = !empty($config['password_enc']) ? decryptData((string)$config['password_enc']) : '';
            if (!is_string($user) || !is_string($pass)) throw new RuntimeException('The saved credentials could not be decrypted. Save them again.');
            // The existing request remains authorized; do not lock other admin pages during network I/O.
            session_write_close(); $status = 'failed'; $reported = '';
            try { $test = novaNetworkTest($config, $user, $pass); $message = $test['message']; $reported = $test['version']; $status = 'login_verified'; }
            catch (Throwable $error) { $message = $error->getMessage(); }
            $message = substr($message, 0, 500); $revision = (int)$config['revision'];
            $update = $conn->prepare('UPDATE network_connection_profiles SET test_status=?,test_message=?,reported_version=?,last_tested_at=NOW() WHERE id=? AND revision=?');
            if (!$update) throw new RuntimeException('The connection result could not be recorded.');
            $update->bind_param('sssii', $status, $message, $reported, $id, $revision);
            if (!$update->execute()) { $update->close(); throw new RuntimeException('The connection result could not be saved.'); }
            $changed = $update->affected_rows; $update->close();
            if ($changed !== 1) throw new RuntimeException('Connection settings changed during the test. Test the latest settings again.');
            if ($status === 'login_verified') $niSuccess = $message; else $niErrors[] = $message;
        } else throw new RuntimeException('The connection action is not available.');
    } catch (Throwable $error) { $niErrors[] = $error->getMessage(); }
}
$niSites = [];
try { $r = $conn->query('SELECT id,name FROM network_sites ORDER BY name LIMIT 500'); if ($r instanceof mysqli_result) { $niSites = $r->fetch_all(MYSQLI_ASSOC); $r->free(); } } catch (Throwable) {}
if ($niReady) {
    try {
        $r = $conn->query('SELECT ' . $niColumns . ',CASE WHEN NULLIF(username_enc,\'\') IS NULL THEN 0 ELSE 1 END AS username_saved,CASE WHEN NULLIF(password_enc,\'\') IS NULL THEN 0 ELSE 1 END AS password_saved FROM network_connection_profiles ORDER BY id DESC LIMIT 500');
        if ($r instanceof mysqli_result) { $niRows = $r->fetch_all(MYSQLI_ASSOC); $r->free(); }
        foreach ($niRows as $row) if ((int)$row['id'] === $niEdit) { $niForm = $row; break; }
    } catch (Throwable) { $niErrors[] = 'Connection profiles could not be loaded.'; }
}
$niUrl = appUrl('admin/dashboard.php?page=router&tab=connections');
?>
<style>
.ni{max-width:1120px;margin:auto;color:#26334a}.ni *{box-sizing:border-box}.ni-head,.ni-nav,.ni-actions{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}.ni h1{font-size:25px;margin:0 0 8px}.ni p{color:#65738b;line-height:1.55}.ni a{color:#2367ab}.ni-card{background:#fff;border:1px solid #e3e9f2;border-radius:18px;padding:22px;margin:18px 0;box-shadow:0 8px 22px #243a5a06}.ni-nav{justify-content:flex-start;margin:20px 0}.ni-nav a,.ni-button{display:inline-flex;align-items:center;gap:8px;border:1px solid #dbe3ee;border-radius:10px;padding:10px 14px;text-decoration:none;background:white;color:#284866;font-size:13px;font-weight:650;cursor:pointer}.ni-button.primary,.ni-nav .selected{background:#2468b5;color:#fff;border-color:#2468b5}.ni-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:17px}.ni label{display:block;font-size:13px;font-weight:650;margin-bottom:7px}.ni input,.ni select{width:100%;min-width:0;border:1px solid #d7e0ec;border-radius:10px;padding:11px;font:inherit;background:#fff}.ni small{display:block;color:#748197;line-height:1.5;margin-top:6px}.ni-pill{display:inline-block;border-radius:30px;padding:5px 10px;background:#edf3fa;color:#37658e;font-size:12px}.ni-success,.ni-error{padding:14px;border-radius:11px;margin:12px 0;background:#eaf8f0;color:#216140}.ni-error{background:#fff0ee;color:#9a4038}.ni-table{width:100%;border-collapse:collapse;font-size:13px}.ni-table th,.ni-table td{text-align:left;padding:13px 9px;border-bottom:1px solid #e9eef5;vertical-align:top}.ni-scroll{overflow:auto}.ni-table form{display:inline}.ni-note{padding:13px 16px;background:#f0f6fc;border-radius:12px}.ni details summary{cursor:pointer;font-weight:700}.ni h2{font-size:18px;margin:0 0 10px}@media(max-width:650px){.ni-grid{grid-template-columns:1fr}.ni-card{padding:17px}.ni h1{font-size:23px}}
</style>
<div class="ni">
<div class="ni-head"><div><h1><i class="fa-solid fa-plug"></i> Network connections</h1><p>Prepare MikroTik and Omada connections for each location.</p></div><a class="ni-button" href="<?= e(appUrl('admin/dashboard.php?page=router')) ?>">Back to routers</a></div>
<nav class="ni-nav"><a href="<?= e(appUrl('admin/dashboard.php?page=router')) ?>">Overview</a><a class="selected" href="<?= e($niUrl) ?>">Connections</a><a href="<?= e(appUrl('admin/dashboard.php?page=router&tab=wifi')) ?>">Wi-Fi profiles</a><a href="<?= e(appUrl('admin/dashboard.php?page=router&tab=devices')) ?>">Devices</a></nav>
<?php foreach ($niErrors as $error): ?><div class="ni-error" role="alert"><?= e($error) ?></div><?php endforeach; ?>
<?php if ($niSuccess !== ''): ?><div class="ni-success" role="status"><?= e($niSuccess) ?></div><?php endif; ?>
<p class="ni-note">API login tests check credentials and connectivity. Internet authorization, package speed and expiry must be verified on the installed network before live use.</p>
<section class="ni-card"><h2>Hosting &amp; network readiness</h2>
<?php if ($niHosting['restricted_free_host']): ?>
<div class="ni-error" role="status"><strong>Hosting change required for the planned direct integration.</strong> InfinityFree Free blocks the usual MikroTik API-SSL port (8729) and Omada software management port (8043). Incoming payment webhooks and automated router updates are also restricted.</div>
<?php elseif ($niHosting['free_domain_hint']): ?>
<p class="ni-note">This address uses a free-hosting domain. Confirm outbound management ports and incoming webhook support with the host before deployment; the domain alone does not prove the server restrictions.</p>
<?php else: ?><p>Hosting restrictions have not been verified. A successful browser page load does not confirm router or webhook connectivity.</p><?php endif; ?>
<div class="ni-scroll"><table class="ni-table"><thead><tr><th>Requirement</th><th>Current state</th></tr></thead><tbody>
<tr><td>Encrypted credential storage</td><td><?= routerAdminEncryptionReady() ? 'Configured' : 'Not configured' ?></td></tr>
<tr><td>PHP HTTPS client for Omada</td><td><?= function_exists('curl_init') ? 'Available; API connectivity not yet confirmed' : 'PHP cURL unavailable' ?></td></tr>
<tr><td>PHP TLS transport for MikroTik</td><td><?= function_exists('stream_socket_client') && extension_loaded('openssl') ? 'Available; router connectivity not yet confirmed' : 'Socket or OpenSSL support unavailable' ?></td></tr>
<tr><td>Voucher → network authorization</td><td>Not connected to checkout yet</td></tr>
<tr><td>Package speed and expiry enforcement</td><td>Router/controller integration and physical tests required</td></tr>
<tr><td>Live clients and device status</td><td>Telemetry integration required</td></tr>
</tbody></table></div>
<details><summary>Deployment requirements</summary><p>Use a server that permits API calls and payment webhooks, with a secure route to the management network. Keep router/controller management access restricted. APs behind a MikroTik gateway must use the intended client network; Omada-managed portal sites need a compatible Controller and adopted devices.</p><p>For Omada, use Hotspot Operator credentials for portal authorization. Open API Client ID/Secret serve a separate purpose, including supported management/inventory calls. Never disable TLS certificate verification to make a test pass.</p><p>Acceptance tests: captive redirect → confirmed payment or valid voucher → internet access → package speed → expiry disconnect → portal return. Reconnection must preserve the original voucher expiry.</p></details>
<p><a href="https://forum.infinityfree.com/t/can-i-connect-to-other-servers-from-my-website-sockets-curl-and-apis/49348" target="_blank" rel="noopener noreferrer">Hosting port restrictions</a> · <a href="https://forum.infinityfree.com/t/why-isnt-api-access-working-on-my-website/115198/1" target="_blank" rel="noopener noreferrer">Webhook restrictions</a></p>
</section>
<?php if (!$niReady): ?>
<section class="ni-card"><h2>Prepare connection profiles</h2><p>Add storage for multiple MikroTik and Omada connections.</p><form method="post" action="<?= e($niUrl) ?>"><?= $niCsrf ?><input type="hidden" name="connection_nonce" value="<?= e($niNonce) ?>"><input type="hidden" name="network_action" value="prepare_storage"><button class="ni-button primary" type="submit">Prepare connections</button></form></section>
<?php else: ?>
<section class="ni-card"><h2><?= (int)$niForm['id'] > 0 ? 'Edit connection' : 'Add connection' ?></h2>
<form method="post" action="<?= e($niUrl) ?>" autocomplete="off">
<?= $niCsrf ?><input type="hidden" name="connection_nonce" value="<?= e($niNonce) ?>"><input type="hidden" name="network_action" value="save_connection"><input type="hidden" name="connection_id" value="<?= (int)$niForm['id'] ?>">
<div class="ni-grid">
<div><label for="ni-name">Connection name</label><input id="ni-name" name="connection_name" maxlength="100" required value="<?= e((string)$niForm['name']) ?>" placeholder="Magomeni gateway"></div>
<div><label for="ni-platform">Platform</label><select id="ni-platform" name="connection_platform"><option value="mikrotik" <?= $niForm['platform'] === 'mikrotik' ? 'selected' : '' ?>>MikroTik RouterOS</option><option value="omada" <?= $niForm['platform'] === 'omada' ? 'selected' : '' ?>>TP-Link Omada</option></select></div>
<div><label for="ni-site">Site / location</label><select id="ni-site" name="network_site_id"><option value="0">Choose later</option><?php foreach ($niSites as $site): ?><option value="<?= (int)$site['id'] ?>" <?= (int)$niForm['site_id'] === (int)$site['id'] ? 'selected' : '' ?>><?= e((string)$site['name']) ?></option><?php endforeach; ?></select></div>
<div><label for="ni-version">Software / controller version</label><input id="ni-version" name="software_version" maxlength="40" value="<?= e((string)$niForm['software_version']) ?>" placeholder="e.g. 7.20.1 or 6.2.10"><small>Enter the exact version. Leave empty while planning.</small></div>
<div><label for="ni-endpoint">Management address</label><input id="ni-endpoint" name="endpoint" maxlength="500" value="<?= e((string)$niForm['endpoint']) ?>"><small id="ni-address-hint">MikroTik: IP or hostname. Omada: HTTPS origin including its port.</small></div>
<div id="ni-mikrotik-port"><label for="ni-port">MikroTik API-SSL port</label><input id="ni-port" type="number" min="1" max="65535" name="api_port" value="<?= (int)$niForm['api_port'] ?>"><small>Usually 8729. A trusted TLS certificate is required.</small></div>
<div data-ni-omada><label for="ni-kind">Omada Controller type</label><select id="ni-kind" name="controller_type"><option value="software" <?= $niForm['controller_type'] === 'software' ? 'selected' : '' ?>>Software Controller</option><option value="hardware" <?= $niForm['controller_type'] === 'hardware' ? 'selected' : '' ?>>Hardware Controller / OC200 / OC300</option><option value="cloud" <?= $niForm['controller_type'] === 'cloud' ? 'selected' : '' ?>>Cloud-Based Controller</option></select></div>
<div data-ni-omada><label for="ni-uid">Omada Controller ID</label><input id="ni-uid" name="controller_uid" maxlength="120" value="<?= e((string)$niForm['controller_uid']) ?>"><small>Required by Omada 5 and 6. Copy the ID from its management URL.</small></div>
<div><label for="ni-user" id="ni-user-label">API / Hotspot Operator username</label><input id="ni-user" name="connection_username" maxlength="190" autocomplete="off"><small><?= !empty($niForm['username_saved']) ? 'Username saved. Leave blank to retain it.' : 'Optional while preparing a draft.' ?></small></div>
<div><label for="ni-pass">Password</label><input id="ni-pass" type="password" name="connection_password" maxlength="4096" autocomplete="new-password"><small><?= !empty($niForm['password_saved']) ? 'Password saved. Leave blank to retain it.' : 'Stored with application encryption.' ?></small></div>
</div><p id="ni-operator-note">Omada requires a Hotspot Operator account; its Open API Client ID and Client Secret are separate credentials.</p><div class="ni-actions"><button class="ni-button primary" type="submit">Save connection</button><?php if ((int)$niForm['id'] > 0): ?><a class="ni-button" href="<?= e($niUrl) ?>">Add another connection</a><?php endif; ?></div>
</form></section>
<section class="ni-card"><h2>Saved connections</h2><?php if (!$niRows): ?><p>No connections saved yet.</p><?php else: ?><div class="ni-scroll"><table class="ni-table"><thead><tr><th>Connection</th><th>Version / API family</th><th>Status</th><th>Actions</th></tr></thead><tbody>
<?php foreach ($niRows as $row): $driver = novaNetworkDriver((string)$row['platform'], (string)$row['software_version']); ?><tr><td><strong><?= e((string)$row['name']) ?></strong><small><?= $row['platform'] === 'mikrotik' ? 'MikroTik' : 'Omada' ?> · <?= e((string)($row['endpoint'] ?: 'Address not set')) ?></small></td><td><?= e((string)($row['software_version'] ?: 'Version not set')) ?><small><?= e($driver['label']) ?></small></td><td><span class="ni-pill"><?= $row['test_status'] === 'login_verified' ? 'API login verified' : ($row['test_status'] === 'failed' ? 'Test failed' : 'Not tested') ?></span><small><?= e((string)$row['test_message']) ?></small><?php if ($row['last_tested_at']): ?><small><?= e((string)$row['last_tested_at']) ?></small><?php endif; ?></td><td><a class="ni-button" href="<?= e($niUrl . '&connection_id=' . (int)$row['id']) ?>">Edit</a> <form method="post" action="<?= e($niUrl) ?>"><?= $niCsrf ?><input type="hidden" name="connection_nonce" value="<?= e($niNonce) ?>"><input type="hidden" name="network_action" value="test_connection"><input type="hidden" name="connection_id" value="<?= (int)$row['id'] ?>"><button type="submit" class="ni-button">Test API login</button></form></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
<?php endif; ?>
<details class="ni-card"><summary>Version compatibility and network requirements</summary><p>MikroTik: RouterOS 6.43+ and 7.x use API-SSL. Omada: separate API families cover 4.1.5–4.4.6, 5.0.15–6.2.0 and 6.2.10+ within 6.x. Unknown versions require review before testing.</p><p>The application server must reach the router/controller address. A private LAN address is reachable only from a server on that network or through an appropriate secure route. Configure trusted certificates before testing.</p><p>Successful API login does not prove portal authorization or speed enforcement. These require tests on the installed router, controller and access points.</p></details>
</div>
<script>(function(){const platform=document.getElementById('ni-platform');if(!platform)return;function update(){const omada=platform.value==='omada';document.querySelectorAll('[data-ni-omada]').forEach(el=>{el.hidden=!omada;});document.getElementById('ni-mikrotik-port').hidden=omada;document.getElementById('ni-operator-note').hidden=!omada;document.getElementById('ni-user-label').textContent=omada?'Hotspot Operator username':'RouterOS API username';document.getElementById('ni-endpoint').placeholder=omada?'https://controller.example.com:8043':'router.example.com';}platform.addEventListener('change',update);update();})();</script>
