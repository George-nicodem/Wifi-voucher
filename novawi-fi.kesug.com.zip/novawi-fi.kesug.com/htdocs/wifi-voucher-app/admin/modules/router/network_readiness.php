<?php
declare(strict_types=1);

/** Pure checks only: no DNS lookups, credential access or network traffic. */
function novaNetworkHostingProfile(string $documentRoot, string $applicationUrl): array
{
    $host = strtolower((string)parse_url($applicationUrl, PHP_URL_HOST));
    $root = strtolower(str_replace('\\', '/', $documentRoot));
    $knownFreeRoot = str_contains($root, '/infinityfree.com/')
        || preg_match('~/home/vol[^/]+/[^/]+/(?:epizy\.com|byethost[^/]*\.com)/~', $root) === 1;
    $freeDomainHint = $host === 'kesug.com' || str_ends_with($host, '.kesug.com')
        || str_ends_with($host, '.infinityfreeapp.com');
    // A domain hint is displayed separately; it is not proof of hosting restrictions.
    return ['restricted_free_host' => $knownFreeRoot, 'free_domain_hint' => $freeDomainHint];
}

function novaNetworkConnectionReadiness(array $profile, array $hosting): array
{
    $issues = []; $warnings = [];
    $platform = (string)($profile['platform'] ?? '');
    $version = (string)($profile['software_version'] ?? '');
    $driver = novaNetworkDriver($platform, $version);
    if (!$driver['supported']) $issues[] = 'Enter a documented software version before testing API login.';
    $endpoint = (string)($profile['endpoint'] ?? '');
    $port = 0; $host = '';
    try {
        if ($endpoint === '') throw new InvalidArgumentException();
        if ($platform === 'mikrotik') {
            $host = novaNetworkHost($endpoint); $port = (int)($profile['api_port'] ?? 0);
            if ($port < 1 || $port > 65535) throw new InvalidArgumentException();
        } elseif ($platform === 'omada') {
            $url = novaNetworkBaseUrl($endpoint);
            $host = (string)parse_url($url, PHP_URL_HOST);
            $port = (int)(parse_url($url, PHP_URL_PORT) ?: 443);
            if ($driver['key'] !== 'omada_v4' && !preg_match('/^[A-Za-z0-9_-]{1,120}$/D', (string)($profile['controller_uid'] ?? ''))) {
                $issues[] = 'Enter the Omada Controller ID.';
            }
        } else throw new InvalidArgumentException();
    } catch (Throwable) { $issues[] = 'Set a valid management address and port.'; }
    if (empty($profile['username_saved']) || empty($profile['password_saved'])) $issues[] = 'Save both the API/operator username and password.';
    if (!empty($hosting['restricted_free_host'])) {
        if ($port && !in_array($port, [80,443,587], true)) $issues[] = 'InfinityFree Free blocks this management port. Use hosting with the required network access.';
        if ($host !== '' && filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)
            && !filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            $issues[] = 'This private management IP cannot be reached directly from the public hosting server.';
        }
    }
    if ($platform === 'omada' && ($profile['controller_type'] ?? '') === 'cloud') {
        $warnings[] = 'Cloud Controller portal support and operator API access require separate verification; software/hardware examples do not prove cloud compatibility.';
    }
    $warnings[] = 'A reachable address and trusted TLS certificate are required. These checks do not make a connection.';
    return ['can_attempt_login' => !$issues, 'issues' => $issues, 'warnings' => $warnings,
        'internet_ready' => false];
}
