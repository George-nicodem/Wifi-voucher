<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../config/app.php';
require_once __DIR__ . '/../../../config/security.php';
require_once __DIR__ . '/../../../includes/functions.php';

function routerAdminSchemaReady(mysqli $conn): bool
{
    $required = ['network_controllers', 'wifi_network_profiles', 'network_devices', 'network_deployments'];
    $result = $conn->query('SHOW TABLES');
    if (!$result) {
        return false;
    }
    $tables = [];
    while ($row = $result->fetch_row()) {
        $tables[(string)$row[0]] = true;
    }
    foreach ($required as $table) {
        if (!isset($tables[$table])) {
            return false;
        }
    }

    $requiredColumns = [
        'wifi_network_profiles' => [
            'wan_connection_type', 'wan_ip_address', 'wan_subnet_cidr', 'wan_gateway_ip',
            'pppoe_username', 'pppoe_password_enc', 'lan_subnet_cidr', 'dhcp_enabled',
            'dhcp_start_ip', 'dhcp_end_ip', 'dns_primary', 'dns_secondary',
        ],
        'network_devices' => ['serial_number', 'mac_address'],
    ];
    foreach ($requiredColumns as $table => $columns) {
        foreach ($columns as $column) {
            $columnResult = $conn->query("SHOW COLUMNS FROM `{$table}` LIKE '{$column}'");
            if (!$columnResult || $columnResult->num_rows === 0) {
                return false;
            }
        }
    }
    return true;
}

function routerAdminGatewaySchemaReady(mysqli $conn): bool
{
    try {
        $result = $conn->query('SELECT id, name, management_host, api_port, api_tls, api_username_enc, api_password_enc, config_status, connection_status, last_connected_at, updated_at FROM network_gateway_settings LIMIT 0');
        return $result !== false;
    } catch (Throwable) {
        return false;
    }
}

function routerAdminSitesSchemaReady(mysqli $conn): bool
{
    try {
        $siteColumns = $conn->query('SELECT id, name, location_detail, latitude, longitude, status FROM network_sites LIMIT 0');
        $deviceSite = $conn->query('SELECT site_id FROM network_devices LIMIT 0');
        return $siteColumns !== false && $deviceSite !== false;
    } catch (Throwable) {
        return false;
    }
}

function routerAdminEncryptionReady(): bool
{
    if (!function_exists('encryptData') || !function_exists('decryptData')) {
        return false;
    }
    try {
        $probe = bin2hex(random_bytes(24));
        $encrypted = encryptData($probe);
        if (!is_string($encrypted) || $encrypted === '' || hash_equals($probe, $encrypted)) {
            return false;
        }
        $decrypted = decryptData($encrypted);
        return is_string($decrypted) && hash_equals($probe, $decrypted);
    } catch (Throwable) {
        return false;
    }
}

function routerAdminLength(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
}

function routerAdminIpv4CidrContains(string $cidr, string $ip): bool
{
    $parts = explode('/', $cidr, 2);
    if (count($parts) !== 2 || !ctype_digit($parts[1])) {
        return false;
    }

    $prefix = (int)$parts[1];
    if ($prefix < 0 || $prefix > 32
        || filter_var($parts[0], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false
        || filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) === false) {
        return false;
    }

    $network = inet_pton($parts[0]);
    $address = inet_pton($ip);
    if ($network === false || $address === false) {
        return false;
    }

    $wholeBytes = intdiv($prefix, 8);
    $remainingBits = $prefix % 8;
    if (substr($network, 0, $wholeBytes) !== substr($address, 0, $wholeBytes)) {
        return false;
    }
    if ($remainingBits === 0) {
        return true;
    }

    $mask = (0xff << (8 - $remainingBits)) & 0xff;
    return (ord($network[$wholeBytes]) & $mask) === (ord($address[$wholeBytes]) & $mask);
}


function routerAdminOnlineSchemaReady(mysqli $conn): bool
{
    try {
        $sessions = $conn->query('SELECT id, voucher_code, device_mac, device_ip, access_point, hotspot_server, joined_at, online_for_seconds, last_seen_at FROM network_online_sessions LIMIT 0');
        $agent = $conn->query('SELECT id, connection_status, router_identity, router_version, last_seen_at, updated_at FROM network_agent_status LIMIT 0');
        return $sessions !== false && $agent !== false;
    } catch (Throwable) {
        return false;
    }
}
