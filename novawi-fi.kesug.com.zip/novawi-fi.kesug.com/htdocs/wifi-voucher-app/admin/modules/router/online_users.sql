-- Online hotspot sessions reported by the local MikroTik connector.
-- Safe to import more than once. This does not change vouchers or payments.

CREATE TABLE IF NOT EXISTS network_online_sessions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    voucher_code VARCHAR(50) NOT NULL,
    device_mac VARCHAR(50) NULL,
    device_ip VARCHAR(45) NULL,
    access_point VARCHAR(120) NULL,
    hotspot_server VARCHAR(100) NULL,
    joined_at DATETIME NOT NULL,
    online_for_seconds INT UNSIGNED NOT NULL DEFAULT 0,
    last_seen_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_network_online_voucher_device (voucher_code, device_mac),
    KEY idx_network_online_last_seen (last_seen_at),
    KEY idx_network_online_access_point (access_point)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS network_agent_status (
    id TINYINT UNSIGNED NOT NULL,
    connection_status ENUM('offline', 'online', 'failed') NOT NULL DEFAULT 'offline',
    router_identity VARCHAR(100) NULL,
    router_version VARCHAR(80) NULL,
    last_seen_at DATETIME NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
