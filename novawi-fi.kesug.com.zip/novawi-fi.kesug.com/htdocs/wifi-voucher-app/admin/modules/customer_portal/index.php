<?php
declare(strict_types=1);

if (!defined('WIFI_VOUCHER_CUSTOMER_PORTAL_PAGE')) {
    define('WIFI_VOUCHER_CUSTOMER_PORTAL_PAGE', true);
}

require dirname(__DIR__) . '/settings/index.php';
