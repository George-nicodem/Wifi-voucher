<?php
declare(strict_types=1);

header('Location: ../../dashboard.php?page=users', true, 302);
exit;