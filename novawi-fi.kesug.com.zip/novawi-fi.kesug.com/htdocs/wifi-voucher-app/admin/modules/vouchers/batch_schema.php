<?php
declare(strict_types=1);

function ensureVoucherBatchSchema(mysqli $conn): bool
{
    $sql = "CREATE TABLE IF NOT EXISTS voucher_batches (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        package_id INT UNSIGNED NOT NULL,
        package_name VARCHAR(190) NOT NULL,
        package_price DECIMAL(12,2) NOT NULL DEFAULT 0,
        duration_minutes INT UNSIGNED NOT NULL DEFAULT 0,
        voucher_count INT UNSIGNED NOT NULL DEFAULT 0,
        codes_json LONGTEXT NOT NULL,
        batch_type VARCHAR(16) NOT NULL DEFAULT 'generated',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_voucher_batches_package (package_id),
        KEY idx_voucher_batches_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

    if ($conn->query($sql)) {
        return true;
    }

    logDatabaseError($conn, 'Creating voucher batch storage');
    return false;
}
