<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';

requireAdminLogin();

$showVoucherEditError = static function (): void {
    ?>
    <div class="voucher-edit-page">
        <div class="voucher-error-card" role="alert">
            <div class="voucher-error-icon"><i class="fa-solid fa-circle-exclamation"></i></div>
            <h2>Could not load voucher</h2>
            <p>Please try again. If the problem continues, contact the administrator.</p>
            <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>" class="voucher-btn voucher-btn-primary">
                <i class="fa-solid fa-arrow-left"></i> Back to Vouchers
            </a>
        </div>
    </div>
    <?php
};

/*
|--------------------------------------------------------------------------
| AUTO EXPIRE ACTIVE VOUCHERS
|--------------------------------------------------------------------------
*/
expireVouchers($conn);

/*
|--------------------------------------------------------------------------
| GET VOUCHER ID
|--------------------------------------------------------------------------
*/
$id = getInt('id');

if ($id <= 0) {
    ?>
    <div class="voucher-edit-page">
        <div class="voucher-error-card">
            <div class="voucher-error-icon">
                <i class="fa-solid fa-circle-exclamation"></i>
            </div>

            <h2>Invalid Voucher</h2>
            <p>The voucher ID provided is invalid.</p>

            <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>"
               class="voucher-btn voucher-btn-primary">
                <i class="fa-solid fa-arrow-left"></i>
                Back to Vouchers
            </a>
        </div>
    </div>
    <?php
    return;
}

/*
|--------------------------------------------------------------------------
| LOAD VOUCHER
|--------------------------------------------------------------------------
*/
$stmt = $conn->prepare("
    SELECT
        v.id,
        v.code,
        v.package_id,
        v.status,
        v.source,
        v.username,
        v.device_mac,
        v.device_ip,
        v.activated_at,
        v.expires_at,
        v.created_at,
        v.sold_at,
        v.sold_price,
        p.name AS package_name,
        p.price AS package_price,
        p.duration_minutes,
        p.speed_limit
    FROM vouchers v
    LEFT JOIN packages p
        ON p.id = v.package_id
    WHERE v.id = ?
    LIMIT 1
");

if (!$stmt) {
    logDatabaseError($conn, 'Preparing voucher edit query');
    $showVoucherEditError();
    return;
}

$stmt->bind_param('i', $id);

if (!$stmt->execute()) {
    logDatabaseError($conn, 'Executing voucher edit query');
    $stmt->close();
    $showVoucherEditError();
    return;
}

$result = $stmt->get_result();
$voucher = $result ? $result->fetch_assoc() : null;

$stmt->close();

if (!$voucher) {
    ?>
    <div class="voucher-edit-page">
        <div class="voucher-error-card">
            <div class="voucher-error-icon">
                <i class="fa-solid fa-ticket"></i>
            </div>

            <h2>Voucher Not Found</h2>
            <p>The voucher does not exist or could not be found.</p>

            <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>"
               class="voucher-btn voucher-btn-primary">
                <i class="fa-solid fa-arrow-left"></i>
                Back to Vouchers
            </a>
        </div>
    </div>
    <?php
    return;
}

/*
|--------------------------------------------------------------------------
| CURRENT VALUES
|--------------------------------------------------------------------------
*/
$voucherStatus = (string)($voucher['status'] ?? 'unused');
$currentPackageId = (int)($voucher['package_id'] ?? 0);

$errors = [];
$success = '';

/*
|--------------------------------------------------------------------------
| LOAD ACTIVE PACKAGES
|--------------------------------------------------------------------------
*/
$packages = [];

$packageResult = $conn->query("
    SELECT
        id,
        name,
        price,
        duration_minutes,
        speed_limit
    FROM packages
    WHERE status = 'active'
    ORDER BY name ASC
");

if ($packageResult) {
    while ($row = $packageResult->fetch_assoc()) {
        $packages[] = $row;
    }
}

/*
|--------------------------------------------------------------------------
| PACKAGE EXISTS IN ACTIVE LIST?
|--------------------------------------------------------------------------
*/
$currentPackageIsActive = false;

foreach ($packages as $package) {
    if ((int)$package['id'] === $currentPackageId) {
        $currentPackageIsActive = true;
        break;
    }
}

/*
|--------------------------------------------------------------------------
| EDIT RULES
|--------------------------------------------------------------------------
|
| unused:
|   - package can be changed
|   - status can remain unused or be disabled
|
| active:
|   - package cannot be changed
|   - activation/expiry cannot be changed
|   - status may be changed to disabled
|
| expired:
|   - package cannot be changed
|   - cannot be reactivated from this page
|   - may be disabled
|
| disabled:
|   - package cannot be changed
|   - may remain disabled
|
*/
$canChangePackage = ($voucherStatus === 'unused');
$canChangeStatus  = in_array(
    $voucherStatus,
    ['unused', 'active', 'expired'],
    true
);

$allowedStatuses = [];

if ($voucherStatus === 'unused') {
    $allowedStatuses = [
        'unused'   => 'Unused',
        'disabled' => 'Disabled'
    ];
} elseif ($voucherStatus === 'active') {
    $allowedStatuses = [
        'active'   => 'Active',
        'disabled' => 'Disabled'
    ];
} elseif ($voucherStatus === 'expired') {
    $allowedStatuses = [
        'expired'  => 'Expired',
        'disabled' => 'Disabled'
    ];
} else {
    $allowedStatuses = [
        'disabled' => 'Disabled'
    ];
}

/*
|--------------------------------------------------------------------------
| HANDLE POST
|--------------------------------------------------------------------------
*/
if (isPost()) {

    requireAdminPost();
    requireCsrfToken();

    $submittedPackageId = postInt('package_id');
    $submittedStatus = strtolower(trim(postString('status', '')));

    /*
    |--------------------------------------------------------------------------
    | VALIDATE STATUS
    |--------------------------------------------------------------------------
    */
    if (!array_key_exists($submittedStatus, $allowedStatuses)) {
        $errors[] = 'The selected status is not allowed for this voucher.';
    }

    /*
    |--------------------------------------------------------------------------
    | PACKAGE RULE
    |--------------------------------------------------------------------------
    */
    if ($canChangePackage) {

        if ($submittedPackageId <= 0) {
            $errors[] = 'Please select a package.';
        } else {

            $packageStmt = $conn->prepare("
                SELECT id
                FROM packages
                WHERE id = ?
                  AND status = 'active'
                LIMIT 1
            ");

            if (!$packageStmt) {

                logDatabaseError($conn, 'Preparing package validation');

                $errors[] = 'Unable to validate the selected package.';

            } else {

                $packageStmt->bind_param('i', $submittedPackageId);

                if (!$packageStmt->execute()) {

                    logDatabaseError(
                        $conn,
                        'Executing package validation'
                    );

                    $errors[] =
                        'Unable to validate the selected package.';

                } else {

                    $packageResult = $packageStmt->get_result();

                    if (!$packageResult || !$packageResult->fetch_assoc()) {
                        $errors[] =
                            'The selected package is not available.';
                    }
                }

                $packageStmt->close();
            }
        }

    } else {

        /*
        |--------------------------------------------------------------------------
        | IMPORTANT:
        | Existing active/expired/disabled vouchers keep their package.
        |--------------------------------------------------------------------------
        */
        $submittedPackageId = $currentPackageId;
    }

    /*
    |--------------------------------------------------------------------------
    | PREVENT INVALID REACTIVATION
    |--------------------------------------------------------------------------
    */
    if (
        $voucherStatus === 'expired' &&
        $submittedStatus === 'active'
    ) {
        $errors[] =
            'An expired voucher cannot be reactivated from the edit page.';
    }

    if (
        $voucherStatus === 'disabled' &&
        $submittedStatus !== 'disabled'
    ) {
        $errors[] =
            'A disabled voucher cannot be reactivated from the edit page.';
    }

    /*
    |--------------------------------------------------------------------------
    | SAVE CHANGES
    |--------------------------------------------------------------------------
    */
    if (!$errors) {

        /*
        |--------------------------------------------------------------------------
        | Re-read the row before update.
        |
        | This prevents updating a voucher based on stale page data.
        |--------------------------------------------------------------------------
        */
        $checkStmt = $conn->prepare("
            SELECT
                package_id,
                status
            FROM vouchers
            WHERE id = ?
            LIMIT 1
        ");

        if (!$checkStmt) {

            logDatabaseError(
                $conn,
                'Preparing voucher concurrency check'
            );

            $errors[] =
                'Unable to verify the voucher before saving.';

        } else {

            $checkStmt->bind_param('i', $id);

            if (!$checkStmt->execute()) {

                logDatabaseError(
                    $conn,
                    'Executing voucher concurrency check'
                );

                $errors[] =
                    'Unable to verify the voucher before saving.';

            } else {

                $checkResult = $checkStmt->get_result();
                $latestVoucher =
                    $checkResult
                        ? $checkResult->fetch_assoc()
                        : null;

                if (!$latestVoucher) {

                    $errors[] =
                        'The voucher no longer exists.';

                } else {

                    $latestStatus =
                        (string)$latestVoucher['status'];

                    $latestPackageId =
                        (int)$latestVoucher['package_id'];

                    /*
                    |--------------------------------------------------------------------------
                    | Never overwrite activation/expiry here.
                    |--------------------------------------------------------------------------
                    */

                    if ($canChangePackage) {

                        if ($latestStatus !== 'unused') {

                            $errors[] =
                                'The voucher status changed. Please reload the page and try again.';

                        } elseif ($submittedStatus === 'unused') {

                            $updateStmt = $conn->prepare("
                                UPDATE vouchers
                                SET
                                    package_id = ?,
                                    status = ?
                                WHERE id = ?
                                  AND status = 'unused'
                            ");

                            if (!$updateStmt) {

                                logDatabaseError(
                                    $conn,
                                    'Preparing unused voucher update'
                                );

                                $errors[] =
                                    'Unable to prepare the voucher update.';

                            } else {

                                $updateStmt->bind_param(
                                    'isi',
                                    $submittedPackageId,
                                    $submittedStatus,
                                    $id
                                );

                                if (!$updateStmt->execute()) {

                                    logDatabaseError(
                                        $conn,
                                        'Executing unused voucher update'
                                    );

                                    $errors[] =
                                        'Unable to save voucher changes.';

                                } elseif ($updateStmt->affected_rows === 0) {

                                    $errors[] =
                                        'The voucher was changed by another process. Please reload the page.';

                                }

                                $updateStmt->close();
                            }

                        } elseif ($submittedStatus === 'disabled') {

                            $updateStmt = $conn->prepare("
                                UPDATE vouchers
                                SET
                                    package_id = ?,
                                    status = 'disabled'
                                WHERE id = ?
                                  AND status = 'unused'
                            ");

                            if (!$updateStmt) {

                                logDatabaseError(
                                    $conn,
                                    'Preparing voucher disable update'
                                );

                                $errors[] =
                                    'Unable to prepare the voucher update.';

                            } else {

                                $updateStmt->bind_param(
                                    'ii',
                                    $submittedPackageId,
                                    $id
                                );

                                if (!$updateStmt->execute()) {

                                    logDatabaseError(
                                        $conn,
                                        'Executing voucher disable update'
                                    );

                                    $errors[] =
                                        'Unable to save voucher changes.';

                                }

                                $updateStmt->close();
                            }
                        }

                    } else {

                        /*
                        |--------------------------------------------------------------------------
                        | Existing active/expired/disabled voucher.
                        |
                        | Only status can be changed according to the rules.
                        |--------------------------------------------------------------------------
                        */
                        if ($latestStatus !== $voucherStatus) {

                            $errors[] =
                                'The voucher status changed. Please reload the page and try again.';

                        } else {

                            $updateStmt = $conn->prepare("
                                UPDATE vouchers
                                SET status = ?
                                WHERE id = ?
                                  AND status = ?
                            ");

                            if (!$updateStmt) {

                                logDatabaseError(
                                    $conn,
                                    'Preparing voucher status update'
                                );

                                $errors[] =
                                    'Unable to prepare the voucher update.';

                            } else {

                                $updateStmt->bind_param(
                                    'sis',
                                    $submittedStatus,
                                    $id,
                                    $voucherStatus
                                );

                                if (!$updateStmt->execute()) {

                                    logDatabaseError(
                                        $conn,
                                        'Executing voucher status update'
                                    );

                                    $errors[] =
                                        'Unable to save voucher changes.';

                                }

                                $updateStmt->close();
                            }
                        }
                    }
                }
            }

            $checkStmt->close();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | SUCCESS
    |--------------------------------------------------------------------------
    */
    if (!$errors) {

        logAdminSecurityEvent(
            'VOUCHER_UPDATED',
            'Voucher ID #' . $id .
            ' updated. Package ID #' . $submittedPackageId .
            ', status changed from ' . $voucherStatus .
            ' to ' . $submittedStatus . '.'
        );

        $success = 'Voucher updated successfully.';

        /*
        |--------------------------------------------------------------------------
        | Reload voucher
        |--------------------------------------------------------------------------
        */
        $reloadStmt = $conn->prepare("
            SELECT
                v.id,
                v.code,
                v.package_id,
                v.status,
                v.source,
                v.username,
                v.device_mac,
                v.device_ip,
                v.activated_at,
                v.expires_at,
                v.created_at,
                v.sold_at,
                v.sold_price,
                p.name AS package_name,
                p.price AS package_price,
                p.duration_minutes,
                p.speed_limit
            FROM vouchers v
            LEFT JOIN packages p
                ON p.id = v.package_id
            WHERE v.id = ?
            LIMIT 1
        ");

        if ($reloadStmt) {

            $reloadStmt->bind_param('i', $id);

            if ($reloadStmt->execute()) {

                $reloadResult = $reloadStmt->get_result();
                $newVoucher = $reloadResult
                    ? $reloadResult->fetch_assoc()
                    : null;

                if ($newVoucher) {
                    $voucher = $newVoucher;
                }
            }

            $reloadStmt->close();
        }

        /*
        |--------------------------------------------------------------------------
        | Refresh current state
        |--------------------------------------------------------------------------
        */
        $voucherStatus =
            (string)($voucher['status'] ?? $submittedStatus);

        $currentPackageId =
            (int)($voucher['package_id'] ?? $submittedPackageId);

        $canChangePackage =
            ($voucherStatus === 'unused');

        $canChangeStatus =
            in_array(
                $voucherStatus,
                ['unused', 'active', 'expired'],
                true
            );

        if ($voucherStatus === 'unused') {

            $allowedStatuses = [
                'unused'   => 'Unused',
                'disabled' => 'Disabled'
            ];

        } elseif ($voucherStatus === 'active') {

            $allowedStatuses = [
                'active'   => 'Active',
                'disabled' => 'Disabled'
            ];

        } elseif ($voucherStatus === 'expired') {

            $allowedStatuses = [
                'expired'  => 'Expired',
                'disabled' => 'Disabled'
            ];

        } else {

            $allowedStatuses = [
                'disabled' => 'Disabled'
            ];
        }
    }
}

/*
|--------------------------------------------------------------------------
| CURRENT PACKAGE INFORMATION
|--------------------------------------------------------------------------
*/
$selectedPackage = null;

foreach ($packages as $package) {

    if ((int)$package['id'] === $currentPackageId) {
        $selectedPackage = $package;
        break;
    }
}

$currentPackageName =
    $voucher['package_name'] ?? 'Unknown package';

$currentPackagePrice =
    $voucher['package_price'] !== null
        ? formatMoney((float)$voucher['package_price'])
        : '—';

$currentDurationMinutes =
    (int)($voucher['duration_minutes'] ?? 0);

$currentSpeed =
    trim((string)($voucher['speed_limit'] ?? ''));

if ($currentSpeed === '') {
    $currentSpeed = 'No limit specified';
}

$statusClass =
    voucherStatusClass($voucherStatus);

$statusLabel =
    voucherStatusLabel($voucherStatus);

$code =
    (string)($voucher['code'] ?? '');

?>

<style>
/* =========================================================
   VOUCHER EDIT PAGE
   ========================================================= */

.voucher-edit-page {
    width: 100%;
    max-width: 1120px;
    margin: 0 auto;
    padding: 10px 0 35px;
    box-sizing: border-box;
}

.voucher-edit-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 20px;
    margin-bottom: 22px;
}

.voucher-edit-heading h1 {
    margin: 0 0 7px;
    color: #172033;
    font-size: 27px;
    font-weight: 750;
    line-height: 1.2;
}

.voucher-edit-heading p {
    margin: 0;
    color: #6b7280;
    font-size: 14px;
}

.voucher-edit-header-actions {
    display: flex;
    gap: 10px;
    flex-shrink: 0;
}

.voucher-edit-card {
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(15, 23, 42, .045);
    overflow: hidden;
    margin-bottom: 20px;
}

.voucher-edit-card-header {
    padding: 20px 23px;
    border-bottom: 1px solid #e8ebf0;
    background: #fafcff;
}

.voucher-edit-card-header h2 {
    margin: 0;
    font-size: 16px;
    color: #172033;
    font-weight: 750;
}

.voucher-edit-card-header p {
    margin: 5px 0 0;
    color: #64748b;
    font-size: 12px;
}

.voucher-edit-card-body {
    padding: 23px;
}

.voucher-code-display {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 16px 18px;
    border-radius: 11px;
    background: #f8fafc;
    border: 1px solid #e5e7eb;
    margin-bottom: 22px;
}

.voucher-code-display-icon {
    width: 40px;
    height: 40px;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 9px;
    background: #dbeafe;
    color: #2563eb;
}

.voucher-code-display-text {
    font-family: "Courier New", monospace;
    font-size: 20px;
    font-weight: 800;
    letter-spacing: 1.5px;
    color: #172033;
    overflow-wrap: anywhere;
}

.voucher-form-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 20px;
}

.voucher-field {
    min-width: 0;
}

.voucher-field.full {
    grid-column: 1 / -1;
}

.voucher-field label {
    display: block;
    margin-bottom: 8px;
    color: #334155;
    font-size: 13px;
    font-weight: 700;
}

.voucher-field label span {
    color: #dc2626;
}

.voucher-field select {
    width: 100%;
    min-height: 45px;
    padding: 0 13px;
    border: 1px solid #d8dee8;
    border-radius: 9px;
    background: #fff;
    color: #263244;
    font-size: 14px;
    outline: none;
    transition: .15s ease;
    box-sizing: border-box;
}

.voucher-field select:focus {
    border-color: #93c5fd;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, .09);
}

.voucher-field select:disabled {
    background: #f8fafc;
    color: #64748b;
    cursor: not-allowed;
}

.voucher-field-help {
    margin-top: 7px;
    color: #94a3b8;
    font-size: 11px;
    line-height: 1.5;
}

.voucher-package-preview {
    margin-top: 10px;
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 9px;
}

.voucher-preview-item {
    padding: 11px;
    border: 1px solid #e5e7eb;
    background: #f8fafc;
    border-radius: 9px;
}

.voucher-preview-label {
    display: block;
    color: #94a3b8;
    font-size: 10px;
    text-transform: uppercase;
    font-weight: 700;
    letter-spacing: .4px;
    margin-bottom: 4px;
}

.voucher-preview-value {
    color: #334155;
    font-size: 12px;
    font-weight: 650;
}

.voucher-current-status {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 7px 11px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 700;
    border: 1px solid transparent;
}

.voucher-current-status.status-active {
    background: #ecfdf3;
    color: #15803d;
    border-color: #bbf7d0;
}

.voucher-current-status.status-unused {
    background: #eff6ff;
    color: #1d4ed8;
    border-color: #bfdbfe;
}

.voucher-current-status.status-expired {
    background: #fff7ed;
    color: #c2410c;
    border-color: #fed7aa;
}

.voucher-current-status.status-disabled {
    background: #fef2f2;
    color: #b91c1c;
    border-color: #fecaca;
}

.voucher-current-status.status-unknown {
    background: #f1f5f9;
    color: #475569;
    border-color: #e2e8f0;
}

.voucher-alert {
    display: flex;
    align-items: flex-start;
    gap: 11px;
    padding: 13px 15px;
    border-radius: 10px;
    margin-bottom: 20px;
    font-size: 13px;
    line-height: 1.55;
}

.voucher-alert i {
    margin-top: 2px;
    flex-shrink: 0;
}

.voucher-alert-success {
    background: #f0fdf4;
    color: #166534;
    border: 1px solid #bbf7d0;
}

.voucher-alert-error {
    background: #fef2f2;
    color: #991b1b;
    border: 1px solid #fecaca;
}

.voucher-alert-info {
    background: #eff6ff;
    color: #1e40af;
    border: 1px solid #bfdbfe;
}

.voucher-alert-warning {
    background: #fffbeb;
    color: #92400e;
    border: 1px solid #fde68a;
}

.voucher-error-list {
    margin: 0;
    padding-left: 18px;
}

.voucher-error-list li + li {
    margin-top: 4px;
}

.voucher-protected-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 11px;
}

.voucher-protected-item {
    padding: 13px;
    border: 1px solid #e8edf3;
    border-radius: 10px;
    background: #f8fafc;
}

.voucher-protected-label {
    display: block;
    color: #94a3b8;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .45px;
    margin-bottom: 5px;
}

.voucher-protected-value {
    color: #475569;
    font-size: 12px;
    font-weight: 600;
    overflow-wrap: anywhere;
}

.voucher-form-actions {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    margin-top: 20px;
}

.voucher-btn {
    min-height: 42px;
    padding: 0 15px;
    border-radius: 9px;
    border: 1px solid transparent;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    text-decoration: none;
    font-size: 13px;
    font-weight: 650;
    cursor: pointer;
    transition: .15s ease;
    box-sizing: border-box;
}

.voucher-btn:hover {
    transform: translateY(-1px);
}

.voucher-btn-primary {
    background: #2563eb;
    color: #fff;
    box-shadow: 0 5px 14px rgba(37, 99, 235, .16);
}

.voucher-btn-primary:hover {
    background: #1d4ed8;
    color: #fff;
}

.voucher-btn-secondary {
    background: #fff;
    color: #374151;
    border-color: #d9dee8;
}

.voucher-btn-secondary:hover {
    background: #f8fafc;
}

.voucher-error-card {
    max-width: 550px;
    margin: 50px auto;
    padding: 40px 30px;
    text-align: center;
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(15, 23, 42, .05);
}

.voucher-error-icon {
    width: 58px;
    height: 58px;
    margin: 0 auto 17px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #fef2f2;
    color: #dc2626;
    font-size: 22px;
}

.voucher-error-card h2 {
    margin: 0 0 8px;
    color: #172033;
    font-size: 20px;
}

.voucher-error-card p {
    margin: 0 0 22px;
    color: #64748b;
    font-size: 14px;
    line-height: 1.6;
}

@media (max-width: 900px) {

    .voucher-protected-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

}

@media (max-width: 700px) {

    .voucher-edit-header {
        flex-direction: column;
    }

    .voucher-edit-header-actions {
        width: 100%;
    }

    .voucher-edit-header-actions .voucher-btn {
        flex: 1;
    }

    .voucher-form-grid {
        grid-template-columns: 1fr;
    }

    .voucher-field.full {
        grid-column: auto;
    }

    .voucher-package-preview {
        grid-template-columns: 1fr;
    }

    .voucher-edit-card-body {
        padding: 18px;
    }

}

@media (max-width: 480px) {

    .voucher-edit-heading h1 {
        font-size: 23px;
    }

    .voucher-edit-header-actions {
        flex-direction: column;
    }

    .voucher-edit-header-actions .voucher-btn {
        width: 100%;
    }

    .voucher-code-display-text {
        font-size: 17px;
    }

    .voucher-protected-grid {
        grid-template-columns: 1fr;
    }

    .voucher-form-actions {
        flex-direction: column;
    }

    .voucher-form-actions .voucher-btn {
        width: 100%;
    }

}
</style>


<div class="voucher-edit-page">

    <!-- =====================================================
         HEADER
         ====================================================== -->
    <div class="voucher-edit-header">

        <div class="voucher-edit-heading">
            <h1>Edit Voucher</h1>
            <p>
                Update permitted voucher settings without changing
                activation history.
            </p>
        </div>

        <div class="voucher-edit-header-actions">

            <a href="<?= e(appUrl(
                'admin/dashboard.php?page=vouchers&action=view&id=' . $id
            )) ?>"
               class="voucher-btn voucher-btn-secondary">
                <i class="fa-solid fa-eye"></i>
                View
            </a>

            <a href="<?= e(appUrl(
                'admin/dashboard.php?page=vouchers'
            )) ?>"
               class="voucher-btn voucher-btn-secondary">
                <i class="fa-solid fa-arrow-left"></i>
                Back
            </a>

        </div>

    </div>


    <!-- =====================================================
         ALERTS
         ====================================================== -->

    <?php if ($success !== ''): ?>

        <div class="voucher-alert voucher-alert-success">

            <i class="fa-solid fa-circle-check"></i>

            <div>
                <?= e($success) ?>
            </div>

        </div>

    <?php endif; ?>


    <?php if ($errors): ?>

        <div class="voucher-alert voucher-alert-error">

            <i class="fa-solid fa-circle-exclamation"></i>

            <div>
                <ul class="voucher-error-list">

                    <?php foreach ($errors as $error): ?>

                        <li><?= e($error) ?></li>

                    <?php endforeach; ?>

                </ul>
            </div>

        </div>

    <?php endif; ?>


    <!-- =====================================================
         VOUCHER EDIT FORM
         ====================================================== -->

    <form method="post"
          action="<?= e(appUrl(
              'admin/dashboard.php?page=vouchers&action=edit&id=' . $id
          )) ?>"
          autocomplete="off">

        <?= csrfField() ?>


        <!-- =================================================
             BASIC INFORMATION
             ================================================== -->

        <div class="voucher-edit-card">

            <div class="voucher-edit-card-header">

                <h2>Voucher Information</h2>

                <p>
                    Voucher code and status information.
                </p>

            </div>

            <div class="voucher-edit-card-body">

                <div class="voucher-code-display">

                    <div class="voucher-code-display-icon">
                        <i class="fa-solid fa-ticket"></i>
                    </div>

                    <div class="voucher-code-display-text">
                        <?= e($code) ?>
                    </div>

                </div>


                <div class="voucher-form-grid">


                    <!-- STATUS -->

                    <div class="voucher-field">

                        <label for="status">
                            Status
                            <span>*</span>
                        </label>

                        <select
                            name="status"
                            id="status"
                            <?= !$canChangeStatus ? 'disabled' : '' ?>
                            required
                        >

                            <?php foreach ($allowedStatuses as $value => $label): ?>

                                <option
                                    value="<?= e($value) ?>"
                                    <?= $voucherStatus === $value ? 'selected' : '' ?>
                                >
                                    <?= e($label) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                        <?php if (!$canChangeStatus): ?>

                            <div class="voucher-field-help">
                                This voucher status is protected and
                                cannot be changed from this page.
                            </div>

                        <?php else: ?>

                            <div class="voucher-field-help">
                                Status changes are restricted according
                                to the voucher lifecycle.
                            </div>

                        <?php endif; ?>

                    </div>


                    <!-- CURRENT STATUS -->

                    <div class="voucher-field">

                        <label>
                            Current Status
                        </label>

                        <div style="padding-top: 2px;">

                            <span class="voucher-current-status <?= e($statusClass) ?>">

                                <i class="fa-solid fa-circle"></i>

                                <?= e($statusLabel) ?>

                            </span>

                        </div>

                    </div>


                    <!-- PACKAGE -->

                    <div class="voucher-field full">

                        <label for="package_id">
                            Package
                            <?php if ($canChangePackage): ?>
                                <span>*</span>
                            <?php endif; ?>
                        </label>

                        <select
                            name="package_id"
                            id="package_id"
                            <?= !$canChangePackage ? 'disabled' : '' ?>
                            <?= $canChangePackage ? 'required' : '' ?>
                        >

                            <?php if (!$canChangePackage): ?>

                                <option value="<?= $currentPackageId ?>" selected>
                                    <?= e($currentPackageName) ?>
                                </option>

                            <?php else: ?>

                                <option value="">
                                    Select package
                                </option>

                                <?php foreach ($packages as $package): ?>

                                    <option
                                        value="<?= (int)$package['id'] ?>"
                                        data-price="<?= e((string)$package['price']) ?>"
                                        data-duration="<?= (int)$package['duration_minutes'] ?>"
                                        data-speed="<?= e((string)($package['speed_limit'] ?? '')) ?>"
                                        <?= $currentPackageId === (int)$package['id'] ? 'selected' : '' ?>
                                    >
                                        <?= e((string)$package['name']) ?>
                                        —
                                        <?= e(formatMoney((float)$package['price'])) ?>
                                    </option>

                                <?php endforeach; ?>

                            <?php endif; ?>

                        </select>

                        <?php if (!$canChangePackage): ?>

                            <div class="voucher-field-help">
                                Package is locked because this voucher
                                has already moved beyond the unused stage.
                            </div>

                        <?php else: ?>

                            <div class="voucher-field-help">
                                Only active packages are available.
                            </div>

                        <?php endif; ?>


                        <!-- PACKAGE PREVIEW -->

                        <div class="voucher-package-preview"
                             id="packagePreview">

                            <div class="voucher-preview-item">

                                <span class="voucher-preview-label">
                                    Price
                                </span>

                                <div class="voucher-preview-value"
                                     id="previewPrice">
                                    <?= e($currentPackagePrice) ?>
                                </div>

                            </div>

                            <div class="voucher-preview-item">

                                <span class="voucher-preview-label">
                                    Duration
                                </span>

                                <div class="voucher-preview-value"
                                     id="previewDuration">
                                    <?= $currentDurationMinutes > 0
                                        ? e((string)$currentDurationMinutes . ' min')
                                        : '—'
                                    ?>
                                </div>

                            </div>

                            <div class="voucher-preview-item">

                                <span class="voucher-preview-label">
                                    Speed
                                </span>

                                <div class="voucher-preview-value"
                                     id="previewSpeed">
                                    <?= e($currentSpeed) ?>
                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- =================================================
             PROTECTED INFORMATION
             ================================================== -->

        <div class="voucher-edit-card">

            <div class="voucher-edit-card-header">

                <h2>Protected Voucher Information</h2>

                <p>
                    These values are intentionally not editable here.
                </p>

            </div>

            <div class="voucher-edit-card-body">

                <div class="voucher-alert voucher-alert-info">

                    <i class="fa-solid fa-shield-halved"></i>

                    <div>
                        Activation and expiration values are protected
                        to prevent an administrator from accidentally
                        extending or resetting an already-used voucher.
                    </div>

                </div>


                <div class="voucher-protected-grid">

                    <div class="voucher-protected-item">

                        <span class="voucher-protected-label">
                            Username
                        </span>

                        <div class="voucher-protected-value">
                            <?= e(
                                trim((string)($voucher['username'] ?? '')) !== ''
                                    ? (string)$voucher['username']
                                    : 'Not assigned'
                            ) ?>
                        </div>

                    </div>


                    <div class="voucher-protected-item">

                        <span class="voucher-protected-label">
                            Device MAC
                        </span>

                        <div class="voucher-protected-value">
                            <?= e(
                                trim((string)($voucher['device_mac'] ?? '')) !== ''
                                    ? (string)$voucher['device_mac']
                                    : 'Not assigned'
                            ) ?>
                        </div>

                    </div>


                    <div class="voucher-protected-item">

                        <span class="voucher-protected-label">
                            Device IP
                        </span>

                        <div class="voucher-protected-value">
                            <?= e(
                                trim((string)($voucher['device_ip'] ?? '')) !== ''
                                    ? (string)$voucher['device_ip']
                                    : 'Not assigned'
                            ) ?>
                        </div>

                    </div>


                    <div class="voucher-protected-item">

                        <span class="voucher-protected-label">
                            Source
                        </span>

                        <div class="voucher-protected-value">
                            <?= e(
                                voucherSourceLabel(
                                    (string)($voucher['source'] ?? '')
                                )
                            ) ?>
                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- =================================================
             WARNING
             ================================================== -->

        <?php if ($voucherStatus === 'active'): ?>

            <div class="voucher-alert voucher-alert-warning">

                <i class="fa-solid fa-triangle-exclamation"></i>

                <div>
                    This voucher is currently active. Changing it to
                    <strong>Disabled</strong> will prevent normal use.
                    Its activation and expiration times will not be changed.
                </div>

            </div>

        <?php elseif ($voucherStatus === 'expired'): ?>

            <div class="voucher-alert voucher-alert-warning">

                <i class="fa-solid fa-clock"></i>

                <div>
                    This voucher has expired. It cannot be reactivated
                    from this page.
                </div>

            </div>

        <?php elseif ($voucherStatus === 'disabled'): ?>

            <div class="voucher-alert voucher-alert-warning">

                <i class="fa-solid fa-ban"></i>

                <div>
                    This voucher is disabled. It cannot be reactivated
                    from this page.
                </div>

            </div>

        <?php endif; ?>


        <!-- =================================================
             FORM ACTIONS
             ================================================== -->

        <div class="voucher-form-actions">

            <a href="<?= e(appUrl(
                'admin/dashboard.php?page=vouchers&action=view&id=' . $id
            )) ?>"
               class="voucher-btn voucher-btn-secondary">

                <i class="fa-solid fa-xmark"></i>
                Cancel

            </a>

            <button type="submit"
                    class="voucher-btn voucher-btn-primary">

                <i class="fa-solid fa-floppy-disk"></i>
                Save Changes

            </button>

        </div>

    </form>

</div>


<script>
(function () {

    const packageSelect =
        document.getElementById('package_id');

    const previewPrice =
        document.getElementById('previewPrice');

    const previewDuration =
        document.getElementById('previewDuration');

    const previewSpeed =
        document.getElementById('previewSpeed');

    if (!packageSelect || packageSelect.disabled) {
        return;
    }

    function formatMoney(value) {

        const number = Number(value);

        if (!Number.isFinite(number)) {
            return '—';
        }

        return new Intl.NumberFormat('en-TZ', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(number) + ' TZS';
    }

    function formatDuration(minutes) {

        const value = Number(minutes);

        if (!Number.isFinite(value) || value <= 0) {
            return '—';
        }

        if (value < 60) {
            return value + ' min';
        }

        if (value % 60 === 0) {

            const hours = value / 60;

            if (hours >= 24 && hours % 24 === 0) {

                const days = hours / 24;

                return days +
                    (days === 1 ? ' day' : ' days');
            }

            return hours +
                (hours === 1 ? ' hour' : ' hours');
        }

        const hours = Math.floor(value / 60);
        const remaining = value % 60;

        return hours + 'h ' + remaining + 'm';
    }

    function updatePreview() {

        const selected =
            packageSelect.options[
                packageSelect.selectedIndex
            ];

        if (!selected || !selected.value) {

            previewPrice.textContent = '—';
            previewDuration.textContent = '—';
            previewSpeed.textContent = '—';

            return;
        }

        previewPrice.textContent =
            formatMoney(
                selected.dataset.price || ''
            );

        previewDuration.textContent =
            formatDuration(
                selected.dataset.duration || ''
            );

        previewSpeed.textContent =
            selected.dataset.speed || 'No limit specified';
    }

    packageSelect.addEventListener(
        'change',
        updatePreview
    );

    updatePreview();

})();
</script>
