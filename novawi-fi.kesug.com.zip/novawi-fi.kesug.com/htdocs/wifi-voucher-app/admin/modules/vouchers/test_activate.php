<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';

requireAdminLogin();

$error = '';
$success = '';
$lookupFailed = false;
$voucher = null;
$code = strtoupper(trim(postString('code', getString('code', ''))));
$stats = getVoucherStatistics($conn);

$loadVoucher = static function (string $voucherCode) use ($conn, &$lookupFailed): ?array {
    $stmt = $conn->prepare("
        SELECT
            v.id,
            v.code,
            v.package_id,
            v.status,
            v.source,
            v.activated_at,
            v.expires_at,
            v.created_at,
            p.name AS package_name,
            p.duration_minutes,
            p.speed_limit,
            p.status AS package_status
        FROM vouchers v
        LEFT JOIN packages p ON p.id = v.package_id
        WHERE v.code = ?
        LIMIT 1
    ");

    if (!$stmt) {
        logDatabaseError($conn, 'Preparing voucher test lookup');
        $lookupFailed = true;
        return null;
    }

    $stmt->bind_param('s', $voucherCode);

    if (!$stmt->execute()) {
        logDatabaseError($conn, 'Executing voucher test lookup');
        $stmt->close();
        $lookupFailed = true;
        return null;
    }

    $result = $stmt->get_result();
    $row = $result ? $result->fetch_assoc() : null;
    $stmt->close();

    return $row ?: null;
};

if (isPost()) {
    requireAdminPost();
    requireCsrfToken();

    $code = strtoupper(trim(postString('code', '')));
    $mode = postString('mode', 'lookup');

    if ($code === '') {
        $error = 'Enter a voucher code first.';
    } else {
        $voucher = $loadVoucher($code);

        if ($lookupFailed) {
            $error = publicErrorMessage('Unable to look up the voucher.');
        } elseif (!$voucher) {
            $error = 'No voucher was found with that code.';
        } elseif ($mode === 'activate') {
            if ((string)$voucher['status'] !== 'unused') {
                $error = 'Only an unused voucher can be activated with this test tool.';
            } elseif ((string)($voucher['package_status'] ?? '') !== 'active') {
                $error = 'This voucher’s package is not active, so it cannot be activated.';
            } else {
                $updateStmt = $conn->prepare("
                    UPDATE vouchers AS v
                    INNER JOIN packages AS p ON p.id = v.package_id
                    SET
                        v.status = 'active',
                        v.activated_at = NOW(),
                        v.sold_price = COALESCE(v.sold_price, p.price),
                        v.expires_at = CASE
                            WHEN p.duration_minutes > 0
                                THEN DATE_ADD(NOW(), INTERVAL p.duration_minutes MINUTE)
                            ELSE NULL
                        END
                    WHERE v.id = ?
                      AND v.package_id = ?
                      AND v.status = 'unused'
                      AND p.status = 'active'
                ");

                if (!$updateStmt) {
                    logDatabaseError($conn, 'Preparing test voucher activation');
                    $error = publicErrorMessage('Unable to prepare voucher activation.');
                } else {
                    $voucherId = (int)$voucher['id'];
                    $packageId = (int)$voucher['package_id'];
                    $updateStmt->bind_param('ii', $voucherId, $packageId);

                    if (!$updateStmt->execute()) {
                        logDatabaseError($conn, 'Executing test voucher activation');
                        $error = publicErrorMessage('Voucher activation failed.');
                    } elseif ($updateStmt->affected_rows !== 1) {
                        $error = 'The voucher changed or its package was deactivated. Look it up again and retry if it is still unused.';
                    } else {
                        logAdminSecurityEvent(
                            'VOUCHER_TEST_ACTIVATED',
                            'Test-activated voucher ID #' . $voucherId . ' using the admin voucher test tool.'
                        );
                        $success = 'Voucher activated for testing. Its expiry is based on the package duration.';
                    }

                    $updateStmt->close();
                }

                $lookupFailed = false;
                $voucher = $loadVoucher($code);
                if (!$voucher && $error === '') {
                    $error = publicErrorMessage('The voucher was updated, but its latest details could not be loaded.');
                }
            }
        }
    }
}

$voucherStatus = $voucher ? (string)$voucher['status'] : '';
$canTestActivate = $voucher
    && $voucherStatus === 'unused'
    && (string)($voucher['package_status'] ?? '') === 'active';
?>

<style>
.voucher-test-page{max-width:1080px;margin:0 auto;padding:5px 0 32px;color:#172033}
.voucher-test-header{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;margin-bottom:22px}
.voucher-test-header h1{margin:0 0 7px;font-size:25px;line-height:1.2;font-weight:750}
.voucher-test-header p{margin:0;color:#64748b;font-size:14px}
.voucher-test-card{background:#fff;border:1px solid #e5e7eb;border-radius:15px;box-shadow:0 4px 18px rgba(15,23,42,.045);overflow:hidden;margin-bottom:20px}
.voucher-test-card-head{padding:19px 23px;border-bottom:1px solid #edf0f4}
.voucher-test-card-head h2{margin:0;font-size:16px;font-weight:700}
.voucher-test-card-head p{margin:6px 0 0;color:#64748b;font-size:13px}
.voucher-test-body{padding:22px}
.voucher-test-notice{padding:13px 15px;border:1px solid #bfdbfe;border-radius:10px;background:#eff6ff;color:#1e40af;font-size:13px;line-height:1.6;margin-bottom:18px}
.voucher-test-alert{padding:13px 15px;border-radius:10px;font-size:14px;margin-bottom:17px}
.voucher-test-error{background:#fef2f2;border:1px solid #fecaca;color:#991b1b}
.voucher-test-success{background:#ecfdf5;border:1px solid #bbf7d0;color:#166534}
.voucher-test-search{display:flex;gap:10px;max-width:700px}
.voucher-test-search input{flex:1;min-width:0;height:44px;padding:0 12px;border:1px solid #d8e0e9;border-radius:9px;font:inherit;box-sizing:border-box}
.voucher-test-button{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:42px;padding:0 15px;border:1px solid #2563eb;border-radius:9px;background:#2563eb;color:#fff;text-decoration:none;font-size:13px;font-weight:700;cursor:pointer}
.voucher-test-button:hover{background:#1d4ed8;color:#fff}
.voucher-test-button-muted{border-color:#dbe2ea;background:#fff;color:#334155}
.voucher-test-stats{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;margin:18px 0 20px}
.voucher-test-stat{padding:15px;background:#fff;border:1px solid #e5e7eb;border-radius:12px}
.voucher-test-stat span{display:block;color:#64748b;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.4px}
.voucher-test-stat strong{display:block;margin-top:7px;font-size:22px;color:#172033}
.voucher-test-details{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:18px}
.voucher-test-detail{padding:13px 14px;border:1px solid #edf0f4;border-radius:10px;min-width:0}
.voucher-test-detail span{display:block;color:#64748b;font-size:12px;margin-bottom:5px}
.voucher-test-detail strong{display:block;color:#172033;font-size:14px;overflow-wrap:anywhere}
.voucher-test-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}
@media(max-width:760px){.voucher-test-stats{grid-template-columns:repeat(2,minmax(0,1fr))}.voucher-test-header{flex-direction:column}.voucher-test-body{padding:17px}}
@media(max-width:520px){.voucher-test-search{flex-direction:column}.voucher-test-search .voucher-test-button{width:100%;box-sizing:border-box}.voucher-test-details{grid-template-columns:1fr}.voucher-test-stats{grid-template-columns:1fr 1fr}}
</style>

<div class="voucher-test-page">
    <header class="voucher-test-header">
        <div>
            <h1><i class="fa-solid fa-flask"></i> Voucher test console</h1>
            <p>Look up a voucher and, when appropriate, activate it for an admin-side test.</p>
        </div>
        <a class="voucher-test-button voucher-test-button-muted" href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>"><i class="fa-solid fa-arrow-left"></i> Back to vouchers</a>
    </header>

    <section class="voucher-test-card">
        <div class="voucher-test-card-head">
            <h2><i class="fa-solid fa-magnifying-glass"></i> Find a voucher</h2>
            <p>Enter the exact voucher code to inspect its status and package.</p>
        </div>
        <div class="voucher-test-body">
            <div class="voucher-test-notice"><strong>Test activation changes the voucher record.</strong> It marks an unused voucher active and sets its expiry from the package duration. It does not verify a payment or connect to Router/MikroTik.</div>

            <?php if ($success !== ''): ?>
                <div class="voucher-test-alert voucher-test-success" role="status"><i class="fa-solid fa-circle-check"></i> <?= e($success) ?></div>
            <?php endif; ?>
            <?php if ($error !== ''): ?>
                <div class="voucher-test-alert voucher-test-error" role="alert"><i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?></div>
            <?php endif; ?>

            <form class="voucher-test-search" method="post" action="<?= e(appUrl('admin/dashboard.php?page=vouchers&action=test_activate')) ?>">
                <?= csrfField() ?>
                <input type="text" name="code" value="<?= e($code) ?>" maxlength="64" required autocomplete="off" placeholder="Voucher code" aria-label="Voucher code">
                <button class="voucher-test-button" type="submit" name="mode" value="lookup"><i class="fa-solid fa-magnifying-glass"></i> Look up</button>
            </form>
        </div>
    </section>

    <section class="voucher-test-stats" aria-label="Voucher status totals">
        <div class="voucher-test-stat"><span>Total</span><strong><?= number_format($stats['total']) ?></strong></div>
        <div class="voucher-test-stat"><span>Unused</span><strong><?= number_format($stats['unused']) ?></strong></div>
        <div class="voucher-test-stat"><span>Active</span><strong><?= number_format($stats['active']) ?></strong></div>
        <div class="voucher-test-stat"><span>Expired</span><strong><?= number_format($stats['expired']) ?></strong></div>
        <div class="voucher-test-stat"><span>Disabled</span><strong><?= number_format($stats['disabled']) ?></strong></div>
    </section>

    <?php if ($voucher): ?>
        <section class="voucher-test-card">
            <div class="voucher-test-card-head">
                <h2><i class="fa-solid fa-ticket"></i> Voucher details</h2>
                <p>Current saved state from the database.</p>
            </div>
            <div class="voucher-test-body">
                <div class="voucher-test-details">
                    <div class="voucher-test-detail"><span>Code</span><strong><?= e((string)$voucher['code']) ?></strong></div>
                    <div class="voucher-test-detail"><span>Status</span><strong><span class="voucher-status <?= e(voucherStatusClass($voucherStatus)) ?>"><?= e(voucherStatusLabel($voucherStatus)) ?></span></strong></div>
                    <div class="voucher-test-detail"><span>Package</span><strong><?= e((string)($voucher['package_name'] ?? 'Unknown package')) ?></strong></div>
                    <div class="voucher-test-detail"><span>Package availability</span><strong><?= e(ucfirst((string)($voucher['package_status'] ?? 'unavailable'))) ?></strong></div>
                    <div class="voucher-test-detail"><span>Duration</span><strong><?= (int)($voucher['duration_minutes'] ?? 0) > 0 ? number_format((int)$voucher['duration_minutes']) . ' minutes' : 'Unlimited' ?></strong></div>
                    <div class="voucher-test-detail"><span>Activated</span><strong><?= e(formatVoucherExpiry($voucher['activated_at'] ?? null)) ?></strong></div>
                    <div class="voucher-test-detail"><span>Expires</span><strong><?= e(formatVoucherExpiry($voucher['expires_at'] ?? null)) ?></strong></div>
                    <div class="voucher-test-detail"><span>Source</span><strong><?= e(voucherSourceLabel((string)$voucher['source'])) ?></strong></div>
                </div>

                <?php if ($canTestActivate): ?>
                    <form class="voucher-test-actions" method="post" action="<?= e(appUrl('admin/dashboard.php?page=vouchers&action=test_activate')) ?>" onsubmit="return confirm('Activate this unused voucher for testing? This changes its status in the database.');">
                        <?= csrfField() ?>
                        <input type="hidden" name="code" value="<?= e($code) ?>">
                        <button class="voucher-test-button" type="submit" name="mode" value="activate"><i class="fa-solid fa-bolt"></i> Activate for testing</button>
                    </form>
                <?php elseif ($voucherStatus !== 'unused'): ?>
                    <div class="voucher-test-notice" style="margin:18px 0 0">This voucher is <?= e(strtolower(voucherStatusLabel($voucherStatus))) ?>. Test activation is available only for unused vouchers; it cannot reactivate or alter an active, expired, or disabled voucher.</div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>
</div>
