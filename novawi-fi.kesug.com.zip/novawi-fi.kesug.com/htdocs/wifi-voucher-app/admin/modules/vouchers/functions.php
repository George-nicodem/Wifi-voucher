<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/security.php';
require_once __DIR__ . '/../../../includes/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';


/*
|--------------------------------------------------------------------------
| Voucher Statuses
|--------------------------------------------------------------------------
*/

function voucherStatuses(): array
{
    return [
        'unused'   => 'Unused',
        'active'   => 'Active',
        'expired'  => 'Expired',
        'disabled' => 'Disabled'
    ];
}


/*
|--------------------------------------------------------------------------
| Voucher Sources
|--------------------------------------------------------------------------
*/

function voucherSources(): array
{
    return [
        'auto'   => 'Automatic',
        'manual' => 'Manual'
    ];
}


/*
|--------------------------------------------------------------------------
| Automatically Expire Vouchers
|--------------------------------------------------------------------------
*/

function expireVouchers(mysqli $conn): int
{
    $stmt = $conn->prepare("
        UPDATE vouchers
        SET status = 'expired'
        WHERE status = 'active'
          AND expires_at IS NOT NULL
          AND expires_at <= NOW()
    ");

    if (!$stmt) {
        logDatabaseError($conn, 'Preparing voucher auto-expiry');
        return 0;
    }

    if (!$stmt->execute()) {
        logDatabaseError($conn, 'Executing voucher auto-expiry');
        $stmt->close();
        return 0;
    }

    $affected = $stmt->affected_rows;

    $stmt->close();

    return $affected;
}


/*
|--------------------------------------------------------------------------
| Voucher Status Class
|--------------------------------------------------------------------------
*/

function voucherStatusClass(string $status): string
{
    return match (strtolower(trim($status))) {

        'active'   => 'status-active',
        'unused'   => 'status-unused',
        'expired'  => 'status-expired',
        'disabled' => 'status-disabled',

        default => 'status-unknown'
    };
}


/*
|--------------------------------------------------------------------------
| Voucher Status Label
|--------------------------------------------------------------------------
*/

function voucherStatusLabel(string $status): string
{
    return voucherStatuses()[$status]
        ?? ucfirst($status);
}


/*
|--------------------------------------------------------------------------
| Voucher Source Label
|--------------------------------------------------------------------------
*/

function voucherSourceLabel(string $source): string
{
    return voucherSources()[$source]
        ?? ucfirst($source);
}


/*
|--------------------------------------------------------------------------
| Format Expiry
|--------------------------------------------------------------------------
*/

function formatVoucherExpiry(?string $expiresAt): string
{
    if (!$expiresAt) {
        return '—';
    }

    $timestamp = strtotime($expiresAt);

    if ($timestamp === false) {
        return '—';
    }

    return date('d M Y, H:i', $timestamp);
}


/*
|--------------------------------------------------------------------------
| Get Voucher Statistics
|--------------------------------------------------------------------------
*/

function getVoucherStatistics(mysqli $conn): array
{
    $stats = [
        'total'   => 0,
        'unused'  => 0,
        'active'  => 0,
        'expired' => 0,
        'disabled'=> 0
    ];

    $result = $conn->query("
        SELECT
            COUNT(*) AS total,
            SUM(status = 'unused') AS unused,
            SUM(status = 'active') AS active,
            SUM(status = 'expired') AS expired,
            SUM(status = 'disabled') AS disabled
        FROM vouchers
    ");

    if (!$result) {
        logDatabaseError($conn, 'Voucher statistics');
        return $stats;
    }

    $row = $result->fetch_assoc();

    if ($row) {
        $stats['total']    = (int)($row['total'] ?? 0);
        $stats['unused']   = (int)($row['unused'] ?? 0);
        $stats['active']   = (int)($row['active'] ?? 0);
        $stats['expired']  = (int)($row['expired'] ?? 0);
        $stats['disabled'] = (int)($row['disabled'] ?? 0);
    }

    return $stats;
}


/*
|--------------------------------------------------------------------------
| Get Package Name
|--------------------------------------------------------------------------
*/

function getVoucherPackageName(
    mysqli $conn,
    int $packageId
): string {

    if ($packageId <= 0) {
        return 'Unknown package';
    }

    $stmt = $conn->prepare("
        SELECT name
        FROM packages
        WHERE id = ?
        LIMIT 1
    ");

    if (!$stmt) {
        return 'Unknown package';
    }

    $stmt->bind_param('i', $packageId);

    if (!$stmt->execute()) {
        $stmt->close();
        return 'Unknown package';
    }

    $result = $stmt->get_result();

    $name = 'Unknown package';

    if ($result) {
        $row = $result->fetch_assoc();

        if ($row && isset($row['name'])) {
            $name = (string)$row['name'];
        }
    }

    $stmt->close();

    return $name;
}