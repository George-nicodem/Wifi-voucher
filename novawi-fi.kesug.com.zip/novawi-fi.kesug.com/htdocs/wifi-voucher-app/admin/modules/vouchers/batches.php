<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
requireAdminLogin();
require_once __DIR__ . '/batch_schema.php';

$batchId = max(0, getInt('batch_id'));
$error = '';
$batches = [];
$batch = null;
$batchCodes = [];
$batchSchemaReady = ensureVoucherBatchSchema($conn);

if (!$batchSchemaReady) {
    $error = 'Unable to prepare voucher batch storage. Please try again later.';
} elseif ($batchId > 0) {
    $batchStmt = $conn->prepare('SELECT id, package_id, package_name, package_price, duration_minutes, voucher_count, codes_json, batch_type, created_at FROM voucher_batches WHERE id = ? LIMIT 1');
    if ($batchStmt) {
        $batchStmt->bind_param('i', $batchId);
        if ($batchStmt->execute()) {
            $batchResult = $batchStmt->get_result();
            $batch = $batchResult ? $batchResult->fetch_assoc() : null;
            if ($batch) {
                $decodedCodes = json_decode((string)($batch['codes_json'] ?? ''), true);
                if (is_array($decodedCodes)) {
                    $batchCodes = array_values(array_filter($decodedCodes, static function ($code): bool {
                        return is_string($code) && trim($code) !== '';
                    }));
                }
            }
        } else {
            logDatabaseError($conn, 'Loading voucher batch details');
            $error = 'Unable to load this voucher batch.';
        }
        $batchStmt->close();
    } else {
        logDatabaseError($conn, 'Preparing voucher batch details');
        $error = 'Unable to load this voucher batch.';
    }
} else {
    /* Group older manual vouchers by package so existing codes are still easy to find. */
    $knownCodes = [];
    $knownBatchResult = $conn->query('SELECT codes_json FROM voucher_batches');
    if ($knownBatchResult) {
        while ($knownBatch = $knownBatchResult->fetch_assoc()) {
            $knownList = json_decode((string)($knownBatch['codes_json'] ?? ''), true);
            if (is_array($knownList)) {
                foreach ($knownList as $knownCode) {
                    if (is_string($knownCode)) {
                        $knownCodes[$knownCode] = true;
                    }
                }
            }
        }
    } else {
        logDatabaseError($conn, 'Checking previously grouped voucher codes');
    }

    $legacyGroups = [];
    $legacyVoucherResult = $conn->query("SELECT v.package_id, COALESCE(p.name, CONCAT('Package ', v.package_id)) AS package_name, COALESCE(p.price, 0) AS package_price, COALESCE(p.duration_minutes, 0) AS duration_minutes, v.code FROM vouchers v LEFT JOIN packages p ON p.id = v.package_id WHERE v.source = 'manual' ORDER BY v.package_id ASC, v.id ASC");
    if ($legacyVoucherResult) {
        while ($legacyVoucher = $legacyVoucherResult->fetch_assoc()) {
            $code = (string)($legacyVoucher['code'] ?? '');
            if ($code === '' || isset($knownCodes[$code])) {
                continue;
            }
            $packageKey = (int)($legacyVoucher['package_id'] ?? 0);
            if (!isset($legacyGroups[$packageKey])) {
                $legacyGroups[$packageKey] = [
                    'package_id' => $packageKey,
                    'package_name' => (string)($legacyVoucher['package_name'] ?? 'Previous package'),
                    'package_price' => (float)($legacyVoucher['package_price'] ?? 0),
                    'duration_minutes' => (int)($legacyVoucher['duration_minutes'] ?? 0),
                    'codes' => []
                ];
            }
            $legacyGroups[$packageKey]['codes'][] = $code;
            $knownCodes[$code] = true;
        }
    } else {
        logDatabaseError($conn, 'Loading existing manual vouchers for batch grouping');
    }

    if ($legacyGroups) {
        $legacyBatches = [];
        $legacyResult = $conn->query("SELECT id, package_id, codes_json FROM voucher_batches WHERE batch_type = 'legacy'");
        if ($legacyResult) {
            while ($legacyBatch = $legacyResult->fetch_assoc()) {
                $legacyBatches[(int)$legacyBatch['package_id']] = [
                    'id' => (int)$legacyBatch['id'],
                    'codes' => json_decode((string)$legacyBatch['codes_json'], true)
                ];
            }
        }

        $insertLegacy = $conn->prepare("INSERT INTO voucher_batches (package_id, package_name, package_price, duration_minutes, voucher_count, codes_json, batch_type) VALUES (?, ?, ?, ?, ?, ?, 'legacy')");
        $updateLegacy = $conn->prepare("UPDATE voucher_batches SET package_name = ?, package_price = ?, duration_minutes = ?, voucher_count = ?, codes_json = ? WHERE id = ?");
        if (!$insertLegacy || !$updateLegacy) {
            logDatabaseError($conn, 'Preparing legacy voucher batch grouping');
        } else {
            foreach ($legacyGroups as $packageKey => $group) {
                $codes = $group['codes'];
                if (isset($legacyBatches[$packageKey]) && is_array($legacyBatches[$packageKey]['codes'])) {
                    $codes = array_values(array_unique(array_merge($legacyBatches[$packageKey]['codes'], $codes)));
                    $legacyId = $legacyBatches[$packageKey]['id'];
                    $packageName = $group['package_name'];
                    $packagePrice = $group['package_price'];
                    $durationMinutes = $group['duration_minutes'];
                    $voucherCount = count($codes);
                    $codesJson = json_encode($codes, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    if (is_string($codesJson)) {
                        $updateLegacy->bind_param('sdiisi', $packageName, $packagePrice, $durationMinutes, $voucherCount, $codesJson, $legacyId);
                        if (!$updateLegacy->execute()) {
                            logDatabaseError($conn, 'Updating existing voucher group');
                        }
                    }
                } else {
                    $packageIdForBatch = $group['package_id'];
                    $packageName = $group['package_name'];
                    $packagePrice = $group['package_price'];
                    $durationMinutes = $group['duration_minutes'];
                    $voucherCount = count($codes);
                    $codesJson = json_encode($codes, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    if (is_string($codesJson)) {
                        $insertLegacy->bind_param('isdiis', $packageIdForBatch, $packageName, $packagePrice, $durationMinutes, $voucherCount, $codesJson);
                        if (!$insertLegacy->execute()) {
                            logDatabaseError($conn, 'Saving existing vouchers as a group');
                        }
                    }
                }
            }
            $insertLegacy->close();
            $updateLegacy->close();
        }
    }

    $listResult = $conn->query('SELECT id, package_name, package_price, duration_minutes, voucher_count, batch_type, created_at FROM voucher_batches ORDER BY created_at DESC, id DESC');
    if ($listResult) {
        while ($row = $listResult->fetch_assoc()) {
            $batches[] = $row;
        }
    } else {
        logDatabaseError($conn, 'Loading voucher batch list');
        $error = 'Unable to load voucher batches.';
    }
}

$durationLabel = '';
if ($batch) {
    $durationMinutes = (int)($batch['duration_minutes'] ?? 0);
    if ($durationMinutes >= 1440) {
        $durationLabel = rtrim(rtrim(number_format($durationMinutes / 1440, 2, '.', ''), '0'), '.') . ' days';
    } elseif ($durationMinutes >= 60) {
        $durationLabel = rtrim(rtrim(number_format($durationMinutes / 60, 2, '.', ''), '0'), '.') . ' hours';
    } elseif ($durationMinutes > 0) {
        $durationLabel = $durationMinutes . ' minutes';
    }
}
$batchVoucherStatuses = [];
if ($batch && $batchCodes) {
    $placeholders = implode(',', array_fill(0, count($batchCodes), '?'));
    $statusStmt = $conn->prepare("SELECT code, status, activated_at FROM vouchers WHERE code IN ({$placeholders})");
    if ($statusStmt) {
        $statusTypes = str_repeat('s', count($batchCodes));
        $statusParams = array_merge([$statusTypes], $batchCodes);
        $statusParamReferences = [];
        foreach ($statusParams as &$statusParam) {
            $statusParamReferences[] = &$statusParam;
        }
        unset($statusParam);
        call_user_func_array([$statusStmt, 'bind_param'], $statusParamReferences);
        if ($statusStmt->execute()) {
            $statusResult = $statusStmt->get_result();
            if ($statusResult) {
                while ($statusRow = $statusResult->fetch_assoc()) {
                    $statusCode = trim((string)($statusRow['code'] ?? ''));
                    if ($statusCode !== '') {
                        $batchVoucherStatuses[$statusCode] = [
                            'status' => strtolower(trim((string)($statusRow['status'] ?? ''))),
                            'activated_at' => trim((string)($statusRow['activated_at'] ?? ''))
                        ];
                    }
                }
            }
        } else {
            logDatabaseError($conn, 'Loading voucher usage status for batch');
        }
        $statusStmt->close();
    } else {
        logDatabaseError($conn, 'Preparing voucher usage status for batch');
    }
}

$printPages = $batchCodes ? array_chunk($batchCodes, 22) : [];
?>
<style>
.voucher-batches-page{max-width:1180px;margin:0 auto;padding:6px 0 34px;color:#172033}
.voucher-batches-header{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:20px}
.voucher-batches-header h1{margin:0 0 6px;font-size:26px;line-height:1.2;font-weight:750}
.voucher-batches-header p{margin:0;color:#64748b;font-size:14px}
.voucher-batches-actions{display:flex;gap:9px;flex-wrap:wrap}
.voucher-batches-actions a,.voucher-batches-actions button{min-height:42px;padding:0 14px;border:0;border-radius:9px;display:inline-flex;align-items:center;justify-content:center;gap:8px;text-decoration:none;font:700 13px inherit;cursor:pointer}
.voucher-batches-primary{background:#e85d24;color:#fff}
.voucher-batches-secondary{background:#eff4fa;color:#1f3a5f}
.voucher-batches-card{overflow:hidden;background:#fff;border:1px solid #e5eaf0;border-radius:14px;box-shadow:0 4px 16px rgba(15,23,42,.04)}
.voucher-batches-table-wrap{overflow-x:auto}
.voucher-batches-table{width:100%;border-collapse:collapse;min-width:650px}
.voucher-batches-table th,.voucher-batches-table td{padding:14px 16px;text-align:left;border-bottom:1px solid #edf1f5;font-size:13px;vertical-align:middle}
.voucher-batches-table th{background:#f8fafc;color:#64748b;font-size:11px;text-transform:uppercase;letter-spacing:.04em}
.voucher-batch-name{font-size:14px;font-weight:750;color:#172033}
.voucher-batch-meta{margin-top:4px;color:#738196;font-size:12px}
.voucher-batch-count{font-weight:750;color:#172033}
.voucher-batch-tag{display:inline-flex;margin-top:5px;padding:3px 8px;border-radius:20px;background:#fff4eb;color:#b45309;font-size:11px;font-weight:700}
.voucher-batch-open{display:inline-flex;min-height:36px;padding:0 12px;align-items:center;justify-content:center;gap:7px;border-radius:8px;background:#e85d24;color:#fff;text-decoration:none;font-size:12px;font-weight:700;white-space:nowrap}
.voucher-batches-empty{padding:36px 20px;text-align:center;color:#64748b}
.voucher-batches-empty h2{margin:0 0 7px;color:#172033;font-size:18px}
.voucher-batch-detail{max-width:1180px;margin:0 auto}
.voucher-batch-detail-card{padding:20px 22px;margin-bottom:18px;background:#fff;border:1px solid #e5eaf0;border-radius:14px;box-shadow:0 4px 16px rgba(15,23,42,.04)}
.voucher-batch-detail-card h2{margin:0 0 6px;font-size:21px}
.voucher-batch-detail-card p{margin:0;color:#64748b;font-size:13px}
.voucher-batch-summary{display:flex;gap:22px;flex-wrap:wrap;margin-top:15px;color:#334155;font-size:13px}
.voucher-batch-notice{padding:13px 15px;margin-bottom:16px;border-radius:10px;background:#eff6ff;color:#1e3a8a;font-size:13px;line-height:1.5}
.voucher-batch-print-pages{display:flex;flex-direction:column;align-items:center;gap:16px}
.voucher-batch-print-page{width:min(100%,800px);aspect-ratio:210/297;padding:2.85%;box-sizing:border-box;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));grid-template-rows:repeat(11,minmax(0,1fr));gap:2mm;background:#fff;border:1px solid #d8dee8;border-radius:5px}
.voucher-batch-ticket{min-width:0;overflow:hidden;border:1px solid #475569;border-radius:8px;background:#fff;text-align:center;color:#111827;break-inside:avoid;page-break-inside:avoid}
.voucher-batch-ticket-brand{padding:5px 7px;background:#142b69;color:#fff;font-size:11px;font-weight:750;letter-spacing:.5px;text-transform:uppercase;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.voucher-batch-ticket-body{padding:5px 7px}
.voucher-batch-ticket-status-row{display:flex;justify-content:flex-end;min-height:12px;margin:0 0 2px}
.voucher-batch-ticket-status{display:inline-flex;align-items:center;padding:1px 5px;border-radius:999px;font-size:7px;line-height:1.2;font-weight:800;letter-spacing:.3px;white-space:nowrap}
.voucher-batch-ticket-status.is-used{background:#ecfdf3;color:#15803d;border:1px solid #bbf7d0}
.voucher-batch-ticket-status.is-unused{background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe}
.voucher-batch-ticket-status.is-disabled{background:#fef2f2;color:#b91c1c;border:1px solid #fecaca}
.voucher-batch-ticket-status.is-unknown{background:#f1f5f9;color:#475569;border:1px solid #e2e8f0}
.voucher-batch-ticket-label{margin-bottom:2px;color:#64748b;font-size:9px;letter-spacing:1.5px}
.voucher-batch-ticket-code{color:#111827;font-size:17px;line-height:1.15;font-weight:800;letter-spacing:2px;overflow-wrap:anywhere}
.voucher-batch-ticket-duration{margin-top:2px;color:#475569;font-size:11px}
.voucher-batch-ticket-price{margin-top:2px;color:#111827;font-size:12px;font-weight:800}
@media(max-width:700px){.voucher-batches-header{display:block}.voucher-batches-actions{margin-top:14px}.voucher-batches-actions a,.voucher-batches-actions button{flex:1}.voucher-batch-summary{gap:10px 18px}.voucher-batch-ticket-brand{font-size:8px}.voucher-batch-ticket-body{padding:2px}.voucher-batch-ticket-code{font-size:clamp(8px,2.2vw,15px);letter-spacing:.5px}.voucher-batch-ticket-label{font-size:7px}.voucher-batch-ticket-duration,.voucher-batch-ticket-price{font-size:8px}}
@media print{
    @page{size:A4 portrait;margin:6mm}
    body *{visibility:hidden!important}
    #voucher-batch-print-area,#voucher-batch-print-area *{visibility:visible!important}
    #voucher-batch-print-area{position:absolute;left:0;top:0;width:198mm;margin:0!important;padding:0!important;border:0!important;background:#fff!important}
    .voucher-batch-print-pages{display:block}
    .voucher-batch-print-page{width:198mm;height:285mm;padding:0;aspect-ratio:auto;display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr));grid-template-rows:repeat(11,minmax(0,1fr));gap:2mm;margin:0;border:0;border-radius:0;break-after:page;page-break-after:always;-webkit-print-color-adjust:exact;print-color-adjust:exact}
    .voucher-batch-print-page:last-child{break-after:auto;page-break-after:auto}
    .voucher-batch-ticket{border:1px solid #475569;border-radius:2mm;box-shadow:none}
    .voucher-batch-ticket-status-row{display:none!important}
    .voucher-batch-ticket-brand{padding:1.2mm 1.5mm;font-size:8pt;letter-spacing:.3mm}
    .voucher-batch-ticket-body{padding:1.5mm}
    .voucher-batch-ticket-label{font-size:7pt;letter-spacing:.6mm}
    .voucher-batch-ticket-code{font-size:14pt;letter-spacing:1.2mm}
    .voucher-batch-ticket-duration{font-size:8pt}
    .voucher-batch-ticket-price{font-size:9pt}
}
</style>

<div class="voucher-batches-page">
<?php if ($batchId > 0): ?>
    <div class="voucher-batches-header">
        <div>
            <h1>Voucher batch</h1>
            <p>View the package vouchers together and print them on A4 paper.</p>
        </div>
        <div class="voucher-batches-actions">
            <a class="voucher-batches-secondary" href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>"><i class="fa-solid fa-arrow-left"></i> Back to batches</a>
            <?php if ($batch && $batchCodes): ?><button class="voucher-batches-primary" type="button" onclick="window.print()"><i class="fa-solid fa-print"></i> Print batch</button><?php endif; ?>
        </div>
    </div>

    <?php if ($error !== ''): ?><div class="alert alert-danger"><?= e($error) ?></div><?php elseif (!$batch): ?><div class="alert alert-warning">This voucher batch could not be found.</div><?php elseif (!$batchCodes): ?><div class="alert alert-warning">This batch has no voucher codes to display.</div><?php else: ?>
        <section class="voucher-batch-detail-card">
            <h2><?= e((string)$batch['package_name']) ?></h2>
            <p>Batch #<?= (int)$batch['id'] ?><?= ($batch['batch_type'] ?? '') === 'legacy' ? ' · Existing vouchers grouped by package' : '' ?></p>
            <div class="voucher-batch-summary">
                <span><strong><?= number_format(count($batchCodes)) ?></strong> vouchers</span>
                <?php if ($durationLabel !== ''): ?><span><?= e($durationLabel) ?></span><?php endif; ?>
                <span><?= e(formatMoney((float)$batch['package_price'])) ?></span>
                <?php if (($batch['batch_type'] ?? '') !== 'legacy'): ?><span>Created <?= e(date('d M Y, H:i', strtotime((string)$batch['created_at']))) ?></span><?php endif; ?>
            </div>
        </section>
        <section id="voucher-batch-print-area" class="voucher-batch-print-pages" aria-label="Printable voucher batch">
            <?php foreach ($printPages as $pageIndex => $pageCodes): ?>
                <div class="voucher-batch-print-page" aria-label="A4 page <?= $pageIndex + 1 ?>">
                    <?php foreach ($pageCodes as $voucherCode): ?>
                        <?php
                        $voucherState = $batchVoucherStatuses[trim($voucherCode)] ?? null;
                        $storedStatus = (string)($voucherState['status'] ?? '');
                        $activationTime = (string)($voucherState['activated_at'] ?? '');
                        $hasActivationTime = $activationTime !== '' && substr($activationTime, 0, 10) !== '0000-00-00';
                        $wasUsed = in_array($storedStatus, ['active', 'expired', 'used'], true) || $hasActivationTime;
                        $ticketStatusLabel = $wasUsed ? 'Used' : ($storedStatus === 'unused' ? 'Unused' : ($storedStatus === 'disabled' ? 'Disabled' : 'Unknown'));
                        $ticketStatusClass = $wasUsed ? 'is-used' : ($storedStatus === 'unused' ? 'is-unused' : ($storedStatus === 'disabled' ? 'is-disabled' : 'is-unknown'));
                        ?>
                        <article class="voucher-batch-ticket">
                            <div class="voucher-batch-ticket-brand">WiFi Voucher</div>
                            <div class="voucher-batch-ticket-body">
                                <div class="voucher-batch-ticket-status-row"><span class="voucher-batch-ticket-status <?= e($ticketStatusClass) ?>"><?= e($ticketStatusLabel) ?></span></div>
                                <div class="voucher-batch-ticket-label">VOUCHER</div>
                                <div class="voucher-batch-ticket-code"><?= e($voucherCode) ?></div>
                                <?php if ($durationLabel !== ''): ?><div class="voucher-batch-ticket-duration"><?= e($durationLabel) ?></div><?php endif; ?>
                                <div class="voucher-batch-ticket-price"><?= e(formatMoney((float)$batch['package_price'])) ?></div>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>
<?php else: ?>
    <div class="voucher-batches-header">
        <div>
            <h1>Voucher batches</h1>
            <p>Each generated batch is listed once under its package. Open it to view and print all its vouchers.</p>
        </div>
        <div class="voucher-batches-actions">
            <a class="voucher-batches-primary" href="<?= e(appUrl('admin/dashboard.php?page=vouchers&action=bulk')) ?>"><i class="fa-solid fa-layer-group"></i> Generate batch</a>
            
        </div>
    </div>

    <?php if ($error !== ''): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
    <div class="voucher-batches-card">
        <?php if (!$batches): ?>
            <div class="voucher-batches-empty"><h2>No voucher batches yet</h2><p>Generate vouchers in bulk and each batch will appear here under its package name.</p></div>
        <?php else: ?>
            <div class="voucher-batches-table-wrap">
                <table class="voucher-batches-table">
                    <thead><tr><th>Package / batch</th><th>Vouchers</th><th>Created</th><th>Action</th></tr></thead>
                    <tbody>
                    <?php foreach ($batches as $voucherBatch): ?>
                        <tr>
                            <td><div class="voucher-batch-name"><?= e((string)$voucherBatch['package_name']) ?></div><div class="voucher-batch-meta">Batch #<?= (int)$voucherBatch['id'] ?></div><?php if (($voucherBatch['batch_type'] ?? '') === 'legacy'): ?><span class="voucher-batch-tag">Existing voucher group</span><?php endif; ?></td>
                            <td class="voucher-batch-count"><?= number_format((int)$voucherBatch['voucher_count']) ?></td>
                            <td><?= ($voucherBatch['batch_type'] ?? '') === 'legacy' ? 'Grouped from existing codes' : e(date('d M Y, H:i', strtotime((string)$voucherBatch['created_at']))) ?></td>
                            <td><a class="voucher-batch-open" href="<?= e(appUrl('admin/dashboard.php?page=vouchers&batch_id=' . (int)$voucherBatch['id'])) ?>"><i class="fa-regular fa-eye"></i> View / Print</a></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>
</div>