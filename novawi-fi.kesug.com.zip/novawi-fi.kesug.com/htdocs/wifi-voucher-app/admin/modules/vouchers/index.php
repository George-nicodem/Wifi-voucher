<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/batch_schema.php';

requireAdminLogin();

/*
|--------------------------------------------------------------------------
| AUTO EXPIRE ACTIVE VOUCHERS
|--------------------------------------------------------------------------
*/
expireVouchers($conn);

/*
|--------------------------------------------------------------------------
| ROUTING
|--------------------------------------------------------------------------
| Default:
|   dashboard.php?page=vouchers
|   = Voucher List
|
| Actions:
|   ?page=vouchers&action=create
|   ?page=vouchers&action=view&id=1
|   ?page=vouchers&action=edit&id=1
|--------------------------------------------------------------------------
*/

$action = getString('action', '');

if ($action === 'create') {
    require __DIR__ . '/create.php';
    return;
}

if ($action === 'test_activate') {
    require __DIR__ . '/test_activate.php';
    return;
}
if ($action === 'bulk') {
    require __DIR__ . '/bulk.php';
    return;
}
if ($action === 'view') {
    require __DIR__ . '/view.php';
    return;
}

if ($action === 'edit') {
    require __DIR__ . '/edit.php';
    return;
}

$batchId = max(0, getInt('batch_id'));
if ($batchId > 0) {
    require __DIR__ . '/batches.php';
    return;
}

/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/

$batchSchemaReady = ensureVoucherBatchSchema($conn);
if ($batchSchemaReady) {
    /* Group older manual vouchers by package so existing codes are still easy to find. */
    $knownCodes = [];
    $knownBatchResult = $conn->query('SELECT codes_json FROM voucher_batches');
    if ($knownBatchResult) {
        while ($knownBatch = $knownBatchResult->fetch_assoc()) {
            $knownList = json_decode((string)($knownBatch['codes_json'] ?? ''), true);
            if (is_array($knownList)) {
                foreach ($knownList as $knownCode) {
                    if (is_string($knownCode)) {
                        $knownCodes[$knownCode] = true;
                    }
                }
            }
        }
    } else {
        logDatabaseError($conn, 'Checking previously grouped voucher codes');
    }

    $legacyGroups = [];
    $legacyVoucherResult = $conn->query("SELECT v.package_id, COALESCE(p.name, CONCAT('Package ', v.package_id)) AS package_name, COALESCE(p.price, 0) AS package_price, COALESCE(p.duration_minutes, 0) AS duration_minutes, v.code FROM vouchers v LEFT JOIN packages p ON p.id = v.package_id WHERE v.source = 'manual' ORDER BY v.package_id ASC, v.id ASC");
    if ($legacyVoucherResult) {
        while ($legacyVoucher = $legacyVoucherResult->fetch_assoc()) {
            $code = (string)($legacyVoucher['code'] ?? '');
            if ($code === '' || isset($knownCodes[$code])) {
                continue;
            }
            $packageKey = (int)($legacyVoucher['package_id'] ?? 0);
            if (!isset($legacyGroups[$packageKey])) {
                $legacyGroups[$packageKey] = [
                    'package_id' => $packageKey,
                    'package_name' => (string)($legacyVoucher['package_name'] ?? 'Previous package'),
                    'package_price' => (float)($legacyVoucher['package_price'] ?? 0),
                    'duration_minutes' => (int)($legacyVoucher['duration_minutes'] ?? 0),
                    'codes' => []
                ];
            }
            $legacyGroups[$packageKey]['codes'][] = $code;
            $knownCodes[$code] = true;
        }
    } else {
        logDatabaseError($conn, 'Loading existing manual vouchers for batch grouping');
    }

    if ($legacyGroups) {
        $legacyBatches = [];
        $legacyResult = $conn->query("SELECT id, package_id, codes_json FROM voucher_batches WHERE batch_type = 'legacy'");
        if ($legacyResult) {
            while ($legacyBatch = $legacyResult->fetch_assoc()) {
                $legacyBatches[(int)$legacyBatch['package_id']] = [
                    'id' => (int)$legacyBatch['id'],
                    'codes' => json_decode((string)$legacyBatch['codes_json'], true)
                ];
            }
        }

        $insertLegacy = $conn->prepare("INSERT INTO voucher_batches (package_id, package_name, package_price, duration_minutes, voucher_count, codes_json, batch_type) VALUES (?, ?, ?, ?, ?, ?, 'legacy')");
        $updateLegacy = $conn->prepare("UPDATE voucher_batches SET package_name = ?, package_price = ?, duration_minutes = ?, voucher_count = ?, codes_json = ? WHERE id = ?");
        if (!$insertLegacy || !$updateLegacy) {
            logDatabaseError($conn, 'Preparing legacy voucher batch grouping');
        } else {
            foreach ($legacyGroups as $packageKey => $group) {
                $codes = $group['codes'];
                if (isset($legacyBatches[$packageKey]) && is_array($legacyBatches[$packageKey]['codes'])) {
                    $codes = array_values(array_unique(array_merge($legacyBatches[$packageKey]['codes'], $codes)));
                    $legacyId = $legacyBatches[$packageKey]['id'];
                    $packageName = $group['package_name'];
                    $packagePrice = $group['package_price'];
                    $durationMinutes = $group['duration_minutes'];
                    $voucherCount = count($codes);
                    $codesJson = json_encode($codes, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    if (is_string($codesJson)) {
                        $updateLegacy->bind_param('sdiisi', $packageName, $packagePrice, $durationMinutes, $voucherCount, $codesJson, $legacyId);
                        if (!$updateLegacy->execute()) {
                            logDatabaseError($conn, 'Updating existing voucher group');
                        }
                    }
                } else {
                    $packageIdForBatch = $group['package_id'];
                    $packageName = $group['package_name'];
                    $packagePrice = $group['package_price'];
                    $durationMinutes = $group['duration_minutes'];
                    $voucherCount = count($codes);
                    $codesJson = json_encode($codes, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    if (is_string($codesJson)) {
                        $insertLegacy->bind_param('isdiis', $packageIdForBatch, $packageName, $packagePrice, $durationMinutes, $voucherCount, $codesJson);
                        if (!$insertLegacy->execute()) {
                            logDatabaseError($conn, 'Saving existing vouchers as a group');
                        }
                    }
                }
            }
            $insertLegacy->close();
            $updateLegacy->close();
        }
    }

}

$batchListResult = $conn->query('SELECT id, package_name, package_price, duration_minutes, voucher_count, batch_type, created_at FROM voucher_batches ORDER BY created_at DESC, id DESC');
$stats = getVoucherStatistics($conn);
?>
<style>
.voucher-batches-page{max-width:1180px;margin:0 auto;padding:8px 0 32px;color:#172033}
.voucher-batches-header{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:18px}
.voucher-batches-header h1{margin:0 0 6px;font-size:26px;font-weight:750}
.voucher-batches-header p{margin:0;color:#64748b;font-size:14px}
.voucher-batches-actions a,.voucher-batch-open{min-height:40px;padding:0 14px;border-radius:9px;display:inline-flex;align-items:center;justify-content:center;gap:8px;text-decoration:none;font-weight:700;font-size:13px}
.voucher-batches-primary{background:#e85d24;color:#fff}
.voucher-batches-card{overflow:hidden;background:#fff;border:1px solid #e5eaf0;border-radius:14px;box-shadow:0 4px 16px rgba(15,23,42,.04)}
.voucher-batches-table{width:100%;border-collapse:collapse;min-width:560px}
.voucher-batches-table th,.voucher-batches-table td{padding:13px 16px;text-align:left;border-bottom:1px solid #edf1f5;font-size:13px}
.voucher-batches-table th{background:#f8fafc;color:#64748b;font-size:11px;text-transform:uppercase}
.voucher-batch-name{font-size:14px;font-weight:750}.voucher-batch-meta{margin-top:4px;color:#738196;font-size:12px}
.voucher-batch-open{background:#eff4fa;color:#1f3a5f;white-space:nowrap}
.voucher-batches-empty{padding:28px;text-align:center}.voucher-batches-empty h2{margin:0 0 7px;font-size:18px}.voucher-batches-empty p{margin:0;color:#64748b;font-size:14px}
@media(max-width:640px){.voucher-batches-header{flex-direction:column}.voucher-batches-card{overflow:auto}}
.voucher-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:13px;margin:0 0 20px}.voucher-stat{background:#fff;border:1px solid #e5e7eb;border-radius:13px;padding:15px;box-shadow:0 4px 16px rgba(15,23,42,.035)}.voucher-stat-top{display:flex;align-items:center;justify-content:space-between;gap:10px}.voucher-stat-icon{width:37px;height:37px;display:flex;align-items:center;justify-content:center;border-radius:9px;background:#eff6ff;color:#2563eb}.voucher-stat-label{margin-top:12px;color:#64748b;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px}.voucher-stat-value{margin-top:4px;color:#172033;font-size:22px;font-weight:800}@media(max-width:900px){.voucher-stats{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:560px){.voucher-stats{grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.voucher-stat{padding:12px}.voucher-stat-value{font-size:19px}}
</style>
<div class="voucher-batches-page">
  <div class="voucher-batches-header">
    <div><h1>Voucher batches</h1><p>Each generated batch appears once under its package. Open a batch to view and print all its vouchers.</p></div>
    <div class="voucher-batches-actions"><a class="voucher-batches-primary" href="<?= e(appUrl('admin/dashboard.php?page=vouchers&action=bulk')) ?>"><i class="fa-solid fa-layer-group"></i> Generate batch</a></div>
  </div>
<div class="voucher-stats">

        <div class="voucher-stat">

            <div class="voucher-stat-top">

                <div class="voucher-stat-icon">
                    <i class="fa-solid fa-ticket"></i>
                </div>

            </div>

            <div class="voucher-stat-label">
                Total
            </div>

            <div class="voucher-stat-value">
                <?= number_format($stats['total']) ?>
            </div>

        </div>


        <div class="voucher-stat">

            <div class="voucher-stat-top">

                <div class="voucher-stat-icon">
                    <i class="fa-solid fa-ticket-simple"></i>
                </div>

            </div>

            <div class="voucher-stat-label">
                Unused
            </div>

            <div class="voucher-stat-value">
                <?= number_format($stats['unused']) ?>
            </div>

        </div>


        <div class="voucher-stat">

            <div class="voucher-stat-top">

                <div class="voucher-stat-icon">
                    <i class="fa-solid fa-circle-check"></i>
                </div>

            </div>

            <div class="voucher-stat-label">
                Active
            </div>

            <div class="voucher-stat-value">
                <?= number_format($stats['active']) ?>
            </div>

        </div>


        <div class="voucher-stat">

            <div class="voucher-stat-top">

                <div class="voucher-stat-icon">
                    <i class="fa-solid fa-clock"></i>
                </div>

            </div>

            <div class="voucher-stat-label">
                Expired
            </div>

            <div class="voucher-stat-value">
                <?= number_format($stats['expired']) ?>
            </div>

        </div>


        

    </div>



  <div class="voucher-batches-card">
  <?php if ($batchListResult && $batchListResult->num_rows > 0): ?>
    <table class="voucher-batches-table"><thead><tr><th>Package / batch</th><th>Vouchers</th><th>Created</th><th>Action</th></tr></thead><tbody>
    <?php while ($voucherBatch = $batchListResult->fetch_assoc()): ?>
      <tr>
        <td><div class="voucher-batch-name"><?= e((string)$voucherBatch['package_name']) ?></div><div class="voucher-batch-meta">Batch #<?= (int)$voucherBatch['id'] ?></div></td>
        <td><strong><?= number_format((int)$voucherBatch['voucher_count']) ?></strong></td>
        <td><?= ($voucherBatch['batch_type'] ?? '') === 'legacy' ? 'Existing voucher group' : e(date('d M Y, H:i', strtotime((string)$voucherBatch['created_at']))) ?></td>
        <td><a class="voucher-batch-open" href="<?= e(appUrl('admin/dashboard.php?page=vouchers&batch_id=' . (int)$voucherBatch['id'])) ?>"><i class="fa-regular fa-eye"></i> View / Print</a></td>
      </tr>
    <?php endwhile; ?>
    </tbody></table>
  <?php elseif (!$batchListResult): ?>
    <div class="voucher-batches-empty"><h2>Unable to load voucher batches</h2><p>Please check the voucher batch storage and try again.</p></div>
  <?php else: ?>
    <div class="voucher-batches-empty"><h2>No voucher batches yet</h2><p>Generate vouchers in bulk and each batch will appear here under its package name.</p></div>
  <?php endif; ?>
  </div>
</div>
<?php return; ?>
require __DIR__ . '/batches.php';
return;

$search = trim(getString('search', ''));
$status = strtolower(trim(getString('status', '')));
$source = strtolower(trim(getString('source', '')));
$packageId = max(0, getInt('package_id'));
$voucherPackageOptions = [];
$voucherPackageResult = $conn->query("SELECT p.id, p.name, p.price, COUNT(v.id) AS voucher_count FROM packages p LEFT JOIN vouchers v ON v.package_id = p.id GROUP BY p.id, p.name, p.price HAVING COUNT(v.id) > 0 ORDER BY p.name ASC");
if ($voucherPackageResult) {
    while ($packageOption = $voucherPackageResult->fetch_assoc()) {
        $voucherPackageOptions[] = $packageOption;
    }
} else {
    logDatabaseError($conn, 'Loading voucher package filter options');
}

$validStatuses = [
    'unused',
    'active',
    'expired',
    'disabled'
];

$validSources = [
    'auto',
    'manual'
];

if ($status !== '' && !in_array($status, $validStatuses, true)) {
    $status = '';
}

if ($source !== '' && !in_array($source, $validSources, true)) {
    $source = '';
}


/*
|--------------------------------------------------------------------------
| PAGINATION
|--------------------------------------------------------------------------
*/

$perPage = 20;

$page = getInt('p');

if ($page < 1) {
    $page = 1;
}


/*
|--------------------------------------------------------------------------
| BUILD WHERE CONDITIONS
|--------------------------------------------------------------------------
*/

$where = [];
$params = [];
$types = '';

if ($search !== '') {

    $where[] = "
        (
            v.code LIKE ?
            OR v.username LIKE ?
            OR v.device_mac LIKE ?
            OR v.device_ip LIKE ?
            OR p.name LIKE ?
        )
    ";

    $searchValue = '%' . $search . '%';

    $params[] = $searchValue;
    $params[] = $searchValue;
    $params[] = $searchValue;
    $params[] = $searchValue;
    $params[] = $searchValue;

    $types .= 'sssss';
}

if ($status !== '') {

    $where[] = "v.status = ?";

    $params[] = $status;
    $types .= 's';
}

if ($source !== '') {

    $where[] = "v.source = ?";

    $params[] = $source;
    $types .= 's';
}


if ($packageId > 0) {
    $where[] = "v.package_id = ?";
    $params[] = $packageId;
    $types .= 'i';
}
$whereSql = '';

if ($where) {
    $whereSql = 'WHERE ' . implode(' AND ', $where);
}


/*
|--------------------------------------------------------------------------
| COUNT VOUCHERS
|--------------------------------------------------------------------------
*/

$totalRows = 0;

$countSql = "
    SELECT COUNT(*) AS total
    FROM vouchers v
    LEFT JOIN packages p
        ON p.id = v.package_id
    $whereSql
";

$countStmt = $conn->prepare($countSql);

if ($countStmt) {

    if ($params) {
        $countStmt->bind_param($types, ...$params);
    }

    if ($countStmt->execute()) {

        $countResult = $countStmt->get_result();

        if ($countResult) {

            $countRow = $countResult->fetch_assoc();

            if ($countRow) {
                $totalRows = (int)($countRow['total'] ?? 0);
            }
        }

    } else {

        logDatabaseError(
            $conn,
            'Executing voucher count query'
        );
    }

    $countStmt->close();

} else {

    logDatabaseError(
        $conn,
        'Preparing voucher count query'
    );
}


/*
|--------------------------------------------------------------------------
| PAGINATION CALCULATION
|--------------------------------------------------------------------------
*/

$totalPages = max(
    1,
    (int)ceil($totalRows / $perPage)
);

if ($page > $totalPages) {
    $page = $totalPages;
}

$offset = ($page - 1) * $perPage;


/*
|--------------------------------------------------------------------------
| GET VOUCHERS
|--------------------------------------------------------------------------
*/

$vouchers = [];

$listSql = "
    SELECT
        v.id,
        v.code,
        v.package_id,
        v.status,
        v.source,
        v.username,
        v.device_mac,
        v.device_ip,
        v.activated_at,
        v.expires_at,
        v.created_at,
        v.sold_at,
        v.sold_price,
        p.name AS package_name

    FROM vouchers v

    LEFT JOIN packages p
        ON p.id = v.package_id

    $whereSql

    ORDER BY v.id DESC

    LIMIT ? OFFSET ?
";

$listStmt = $conn->prepare($listSql);

if ($listStmt) {

    $listParams = $params;
    $listTypes = $types . 'ii';

    $listParams[] = $perPage;
    $listParams[] = $offset;

    $listStmt->bind_param(
        $listTypes,
        ...$listParams
    );

    if ($listStmt->execute()) {

        $listResult = $listStmt->get_result();

        if ($listResult) {

            while ($row = $listResult->fetch_assoc()) {
                $vouchers[] = $row;
            }
        }

    } else {

        logDatabaseError(
            $conn,
            'Executing voucher list query'
        );
    }

    $listStmt->close();

} else {

    logDatabaseError(
        $conn,
        'Preparing voucher list query'
    );
}


/*
|--------------------------------------------------------------------------
| STATISTICS
|--------------------------------------------------------------------------
*/

$stats = getVoucherStatistics($conn);


/*
|--------------------------------------------------------------------------
| PAGINATION URL
|--------------------------------------------------------------------------
*/

$buildPageUrl = static function (
    int $pageNumber
) use (
    $search,
    $status,
    $source,
    $packageId
): string {

    $query = [
        'page' => 'vouchers',
        'p' => $pageNumber
    ];

    if ($search !== '') {
        $query['search'] = $search;
    }

    if ($status !== '') {
        $query['status'] = $status;
    }

    if ($source !== '') {
    $query['source'] = $source;
}
if ($packageId > 0) {
    $query['package_id'] = $packageId;
}

    return appUrl(
        'admin/dashboard.php?' .
        http_build_query($query)
    );
};

$voucherBatchRows = [];
$voucherBatchResult = $conn->query('SELECT id, package_name, voucher_count, batch_type, created_at FROM voucher_batches ORDER BY created_at DESC, id DESC');
if ($voucherBatchResult) {
    while ($voucherBatchRow = $voucherBatchResult->fetch_assoc()) {
        $voucherBatchRows[] = $voucherBatchRow;
    }
} else {
    logDatabaseError($conn, 'Loading voucher batches above individual list');
}

?>

<style>
.voucher-inline-batches{max-width:1250px;margin:0 auto 18px;padding:18px;background:#fff;border:1px solid #e5e7eb;border-radius:13px;box-shadow:0 4px 16px rgba(15,23,42,.035);box-sizing:border-box}
.voucher-inline-batches-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px}
.voucher-inline-batches-head h2{margin:0 0 4px;color:#172033;font-size:18px;font-weight:750}
.voucher-inline-batches-head p{margin:0;color:#64748b;font-size:12px}
.voucher-inline-batches-actions{display:flex;gap:8px;flex-wrap:wrap}
.voucher-inline-batches-actions a,.voucher-inline-batch-link{display:inline-flex;align-items:center;justify-content:center;gap:7px;min-height:36px;padding:0 12px;border-radius:8px;text-decoration:none;font-size:12px;font-weight:700;white-space:nowrap}
.voucher-inline-batches-primary,.voucher-inline-batch-link{background:#e85d24;color:#fff}
.voucher-inline-batches-secondary{background:#eff4fa;color:#1f3a5f}
.voucher-inline-batch-list{display:grid;gap:8px}
.voucher-inline-batch{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:12px 14px;border:1px solid #e7ecf2;border-radius:10px;background:#fbfdff;text-decoration:none;color:#172033;transition:.15s ease}
.voucher-inline-batch:hover{border-color:#f1b49a;background:#fffaf7}
.voucher-inline-batch-info{min-width:0}
.voucher-inline-batch-name{font-size:13px;font-weight:750;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.voucher-inline-batch-meta{margin-top:4px;color:#718096;font-size:11px}
.voucher-inline-batch-count{flex:none;color:#334155;font-size:12px;font-weight:750;text-align:right}
.voucher-inline-batch-count small{display:block;margin-top:2px;color:#718096;font-weight:500}
.voucher-inline-batches-empty{padding:18px;border-radius:9px;background:#f8fafc;color:#64748b;font-size:12px;text-align:center}
@media(max-width:650px){.voucher-inline-batches{padding:14px}.voucher-inline-batches-head{align-items:flex-start;flex-direction:column}.voucher-inline-batches-actions{width:100%}.voucher-inline-batches-actions a{flex:1}.voucher-inline-batch{padding:10px}.voucher-inline-batch-link{padding:0 9px;font-size:11px}}
</style>
<section class="voucher-inline-batches" aria-labelledby="voucher-batches-title">
    <div class="voucher-inline-batches-head">
        <div><h2 id="voucher-batches-title">Voucher batches</h2><p>Open a package batch to view or print all its voucher codes.</p></div>
        <div class="voucher-inline-batches-actions">
            <a class="voucher-inline-batches-primary" href="<?= e(appUrl('admin/dashboard.php?page=vouchers&action=bulk')) ?>"><i class="fa-solid fa-layer-group"></i> Generate batch</a>
            <a class="voucher-inline-batches-secondary" href="#individual-vouchers"><i class="fa-solid fa-list"></i> Individual vouchers ↓</a>
        </div>
    </div>
    <?php if ($voucherBatchRows): ?>
        <div class="voucher-inline-batch-list">
            <?php foreach ($voucherBatchRows as $voucherBatchRow): ?>
                <?php $batchCreatedAt = strtotime((string)($voucherBatchRow['created_at'] ?? '')); ?>
                <div class="voucher-inline-batch">
                    <div class="voucher-inline-batch-info">
                        <div class="voucher-inline-batch-name"><?= e((string)($voucherBatchRow['package_name'] ?? 'Voucher package')) ?></div>
                        <div class="voucher-inline-batch-meta">Batch #<?= (int)$voucherBatchRow['id'] ?><?php if (($voucherBatchRow['batch_type'] ?? '') === 'legacy'): ?> · Existing voucher group<?php elseif ($batchCreatedAt): ?> · <?= e(date('d M Y, H:i', $batchCreatedAt)) ?><?php endif; ?></div>
                    </div>
                    <div class="voucher-inline-batch-count"><?= number_format((int)($voucherBatchRow['voucher_count'] ?? 0)) ?><small>vouchers</small></div>
                    <a class="voucher-inline-batch-link" href="<?= e(appUrl('admin/dashboard.php?page=vouchers&batch_id=' . (int)$voucherBatchRow['id'])) ?>"><i class="fa-regular fa-eye"></i> View / Print</a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="voucher-inline-batches-empty">No voucher batches yet. Generate a batch and it will appear here.</div>
    <?php endif; ?>
</section>

<style>
/* =========================================================
   VOUCHER LIST PAGE
   ========================================================= */

.voucher-page {
    width: 100%;
    max-width: 1250px;
    margin: 0 auto;
    padding: 5px 0 35px;
    box-sizing: border-box;
}

.voucher-page-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 20px;
    margin-bottom: 22px;
}

.voucher-page-title h1 {
    margin: 0 0 7px;
    font-size: 27px;
    line-height: 1.2;
    font-weight: 750;
    color: #172033;
    letter-spacing: -.4px;
}

.voucher-page-title p {
    margin: 0;
    color: #6b7280;
    font-size: 14px;
}

.voucher-header-actions { display:flex; align-items:center; justify-content:flex-end; gap:10px; flex-wrap:wrap; }
.voucher-test-link { min-height:43px; padding:0 14px; display:inline-flex; align-items:center; justify-content:center; gap:8px; background:#fff; color:#334155; border:1px solid #dbe2ea; border-radius:9px; text-decoration:none; font-size:13px; font-weight:700; white-space:nowrap; transition:.15s ease; }
.voucher-test-link:hover { background:#f8fafc; color:#1e293b; border-color:#cbd5e1; }.voucher-bulk-btn { min-height:43px; padding:0 16px; display:inline-flex; align-items:center; justify-content:center; gap:8px; background:#fff; color:#334155; border:1px solid #dbe2ea; border-radius:9px; text-decoration:none; font-size:13px; font-weight:700; white-space:nowrap; transition:.15s ease; }
.voucher-bulk-btn:hover { background:#f8fafc; color:#1e293b; border-color:#cbd5e1; }.voucher-create-btn {
    min-height: 43px;
    padding: 0 16px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    background: #2563eb;
    color: #fff;
    border-radius: 9px;
    text-decoration: none;
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 5px 15px rgba(37, 99, 235, .16);
    transition: .15s ease;
    white-space: nowrap;
}

.voucher-create-btn:hover {
    background: #1d4ed8;
    color: #fff;
    transform: translateY(-1px);
}


/* =========================================================
   STATISTICS
   ========================================================= */

.voucher-stats {
    display: grid;
    grid-template-columns: repeat(5, minmax(0, 1fr));
    gap: 13px;
    margin-bottom: 20px;
}

.voucher-stat {
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 13px;
    padding: 17px;
    box-shadow: 0 4px 16px rgba(15, 23, 42, .035);
}

.voucher-stat-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
}

.voucher-stat-icon {
    width: 37px;
    height: 37px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 9px;
    background: #eff6ff;
    color: #2563eb;
}

.voucher-stat-label {
    margin-top: 12px;
    color: #64748b;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .5px;
}

.voucher-stat-value {
    margin-top: 4px;
    color: #172033;
    font-size: 22px;
    font-weight: 800;
}


/* =========================================================
   FILTER CARD
   ========================================================= */

.voucher-filter-card {
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 13px;
    padding: 17px;
    margin-bottom: 18px;
    box-shadow: 0 4px 16px rgba(15, 23, 42, .035);
}

.voucher-filter-form {
    display: grid;
    grid-template-columns: minmax(200px, 1fr) 180px 180px auto auto;
    gap: 10px;
    align-items: end;
}

.voucher-filter-group label {
    display: block;
    margin-bottom: 6px;
    color: #475569;
    font-size: 11px;
    font-weight: 700;
}

.voucher-filter-input,
.voucher-filter-select {
    width: 100%;
    height: 42px;
    padding: 0 12px;
    border: 1px solid #d8dee8;
    border-radius: 8px;
    background: #fff;
    color: #263244;
    outline: none;
    box-sizing: border-box;
    font-size: 13px;
}

.voucher-filter-input:focus,
.voucher-filter-select:focus {
    border-color: #93c5fd;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, .08);
}

.voucher-filter-btn,
.voucher-reset-btn {
    height: 42px;
    padding: 0 14px;
    border-radius: 8px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 7px;
    text-decoration: none;
    font-size: 12px;
    font-weight: 700;
    box-sizing: border-box;
}

.voucher-filter-btn {
    border: 1px solid #2563eb;
    background: #2563eb;
    color: #fff;
    cursor: pointer;
}

.voucher-filter-btn:hover {
    background: #1d4ed8;
}

.voucher-reset-btn {
    border: 1px solid #d9dee8;
    background: #fff;
    color: #475569;
}

.voucher-reset-btn:hover {
    background: #f8fafc;
}


/* =========================================================
   TABLE CARD
   ========================================================= */

.voucher-table-card {
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 13px;
    overflow: hidden;
    box-shadow: 0 4px 16px rgba(15, 23, 42, .035);
}

.voucher-table-header {
    padding: 17px 19px;
    border-bottom: 1px solid #e8ebf0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
}

.voucher-table-header h2 {
    margin: 0;
    font-size: 15px;
    font-weight: 750;
    color: #172033;
}

.voucher-table-count {
    color: #64748b;
    font-size: 12px;
}

.voucher-table-wrapper {
    width: 100%;
    overflow-x: auto;
}

.voucher-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 950px;
}

.voucher-table th {
    padding: 12px 15px;
    background: #f8fafc;
    color: #64748b;
    font-size: 10px;
    font-weight: 750;
    text-align: left;
    text-transform: uppercase;
    letter-spacing: .5px;
    white-space: nowrap;
    border-bottom: 1px solid #e5e7eb;
}

.voucher-table td {
    padding: 14px 15px;
    color: #334155;
    font-size: 12px;
    border-bottom: 1px solid #edf0f4;
    vertical-align: middle;
}

.voucher-table tbody tr:hover {
    background: #fafcff;
}

.voucher-table tbody tr:last-child td {
    border-bottom: none;
}

.voucher-code-cell {
    font-family: "Courier New", monospace;
    font-weight: 800;
    letter-spacing: .8px;
    color: #172033;
    white-space: nowrap;
}

.voucher-package-cell {
    font-weight: 650;
    color: #334155;
}

.voucher-customer-cell {
    max-width: 150px;
}

.voucher-customer-main {
    font-weight: 600;
    color: #334155;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.voucher-customer-sub {
    margin-top: 3px;
    color: #94a3b8;
    font-size: 10px;
}

.voucher-muted {
    color: #94a3b8;
}


/* =========================================================
   BADGES
   ========================================================= */

.voucher-status,
.voucher-source {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    border-radius: 999px;
    padding: 6px 9px;
    font-size: 10px;
    font-weight: 750;
    white-space: nowrap;
}

.voucher-status.status-active {
    color: #15803d;
    background: #ecfdf3;
    border: 1px solid #bbf7d0;
}

.voucher-status.status-unused {
    color: #1d4ed8;
    background: #eff6ff;
    border: 1px solid #bfdbfe;
}

.voucher-status.status-expired {
    color: #c2410c;
    background: #fff7ed;
    border: 1px solid #fed7aa;
}

.voucher-status.status-disabled {
    color: #b91c1c;
    background: #fef2f2;
    border: 1px solid #fecaca;
}

.voucher-status.status-unknown {
    color: #475569;
    background: #f1f5f9;
    border: 1px solid #e2e8f0;
}

.voucher-source {
    color: #475569;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
}


/* =========================================================
   ACTIONS
   ========================================================= */

.voucher-actions {
    display: flex;
    align-items: center;
    gap: 6px;
}

.voucher-action-btn {
    width: 34px;
    height: 34px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    border: 1px solid #dfe4eb;
    background: #fff;
    color: #64748b;
    text-decoration: none;
    transition: .15s ease;
}

.voucher-action-btn:hover {
    background: #f8fafc;
    color: #2563eb;
    border-color: #bfdbfe;
}


/* =========================================================
   EMPTY STATE
   ========================================================= */

.voucher-empty {
    padding: 55px 25px;
    text-align: center;
}

.voucher-empty-icon {
    width: 60px;
    height: 60px;
    margin: 0 auto 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: #eff6ff;
    color: #2563eb;
    font-size: 23px;
}

.voucher-empty h3 {
    margin: 0 0 7px;
    color: #172033;
    font-size: 17px;
}

.voucher-empty p {
    margin: 0 0 19px;
    color: #64748b;
    font-size: 13px;
}


/* =========================================================
   PAGINATION
   ========================================================= */

.voucher-pagination {
    padding: 15px 18px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    border-top: 1px solid #e8ebf0;
}

.voucher-pagination-info {
    color: #64748b;
    font-size: 11px;
}

.voucher-pagination-links {
    display: flex;
    align-items: center;
    gap: 5px;
}

.voucher-page-link {
    min-width: 34px;
    height: 34px;
    padding: 0 9px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 7px;
    border: 1px solid #dfe4eb;
    background: #fff;
    color: #475569;
    text-decoration: none;
    font-size: 11px;
    font-weight: 650;
}

.voucher-page-link:hover {
    background: #f8fafc;
    color: #2563eb;
}

.voucher-page-link.active {
    background: #2563eb;
    border-color: #2563eb;
    color: #fff;
}


/* =========================================================
   RESPONSIVE
   ========================================================= */

@media (max-width: 1100px) {

    .voucher-stats {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }

    .voucher-filter-form {
        grid-template-columns: 1fr 1fr;
    }

}

@media (max-width: 700px) {

    .voucher-page-header {
        flex-direction: column;
    }

    .voucher-create-btn {
        width: 100%;
    }

    .voucher-stats {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .voucher-filter-form {
        grid-template-columns: 1fr;
    }

    .voucher-pagination {
        flex-direction: column;
        align-items: stretch;
    }

    .voucher-pagination-links {
        justify-content: center;
        flex-wrap: wrap;
    }

}

@media (max-width: 450px) {

    .voucher-stats {
        grid-template-columns: 1fr;
    }

    .voucher-stat {
        padding: 14px;
    }

}
@media (max-width: 700px) {
    .voucher-header-actions { width:100%; display:grid; grid-template-columns:1fr 1fr; }
    .voucher-header-actions > a { width:100%; box-sizing:border-box; }
}</style>


<div class="voucher-page" id="individual-vouchers">

    <!-- =====================================================
         PAGE HEADER
         ====================================================== -->

    <div class="voucher-page-header">

        <div class="voucher-page-title">

            <h1>Vouchers</h1>

            <p>
                Manage, view and monitor all Wi-Fi access vouchers.
            </p>

        </div>

        <div class="voucher-header-actions">
            <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers&action=bulk')) ?>" class="voucher-bulk-btn">
                <i class="fa-solid fa-layer-group"></i> Bulk Generate
            </a>
            <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers&action=test_activate')) ?>" class="voucher-test-link">
                <i class="fa-solid fa-flask"></i> Test / Activate
            </a>
            <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers&action=create')) ?>" class="voucher-create-btn">
                <i class="fa-solid fa-plus"></i> Create Voucher
            </a>
        </div>

    </div>


    <!-- =====================================================
         STATISTICS
         ====================================================== -->

    <div class="voucher-stats">

        <div class="voucher-stat">

            <div class="voucher-stat-top">

                <div class="voucher-stat-icon">
                    <i class="fa-solid fa-ticket"></i>
                </div>

            </div>

            <div class="voucher-stat-label">
                Total
            </div>

            <div class="voucher-stat-value">
                <?= number_format($stats['total']) ?>
            </div>

        </div>


        <div class="voucher-stat">

            <div class="voucher-stat-top">

                <div class="voucher-stat-icon">
                    <i class="fa-solid fa-ticket-simple"></i>
                </div>

            </div>

            <div class="voucher-stat-label">
                Unused
            </div>

            <div class="voucher-stat-value">
                <?= number_format($stats['unused']) ?>
            </div>

        </div>


        <div class="voucher-stat">

            <div class="voucher-stat-top">

                <div class="voucher-stat-icon">
                    <i class="fa-solid fa-circle-check"></i>
                </div>

            </div>

            <div class="voucher-stat-label">
                Active
            </div>

            <div class="voucher-stat-value">
                <?= number_format($stats['active']) ?>
            </div>

        </div>


        <div class="voucher-stat">

            <div class="voucher-stat-top">

                <div class="voucher-stat-icon">
                    <i class="fa-solid fa-clock"></i>
                </div>

            </div>

            <div class="voucher-stat-label">
                Expired
            </div>

            <div class="voucher-stat-value">
                <?= number_format($stats['expired']) ?>
            </div>

        </div>


        <div class="voucher-stat">

            <div class="voucher-stat-top">

                <div class="voucher-stat-icon">
                    <i class="fa-solid fa-ban"></i>
                </div>

            </div>

            <div class="voucher-stat-label">
                Disabled
            </div>

            <div class="voucher-stat-value">
                <?= number_format($stats['disabled']) ?>
            </div>

        </div>

    </div>


    <!-- =====================================================
         FILTERS
         ====================================================== -->

    <div class="voucher-filter-card">

        <form
            method="get"
            action="<?= e(appUrl('admin/dashboard.php')) ?>"
            class="voucher-filter-form"
        >

            <input
                type="hidden"
                name="page"
                value="vouchers"
            >

            
<div class="voucher-filter-group">
    <label for="voucherPackage">Package</label>
    <select id="voucherPackage" name="package_id" class="voucher-filter-select" onchange="this.form.submit()">
        <option value="">All Packages</option>
        <?php foreach ($voucherPackageOptions as $packageOption): ?>
            <option value="<?= (int)$packageOption['id'] ?>" <?= $packageId === (int)$packageOption['id'] ? 'selected' : '' ?>>
                <?= e((string)$packageOption['name']) ?> — <?= e(formatMoney((float)$packageOption['price'])) ?> (<?= number_format((int)$packageOption['voucher_count']) ?> vouchers)
            </option>
        <?php endforeach; ?>
    </select>
</div>
<div class="voucher-filter-group">
<label for="voucherSearch">
                    Search
                </label>

                <input
                    type="text"
                    id="voucherSearch"
                    name="search"
                    class="voucher-filter-input"
                    placeholder="Code, username, MAC, IP..."
                    value="<?= e($search) ?>"
                >

            </div>


            <div class="voucher-filter-group">

                <label for="voucherStatus">
                    Status
                </label>

                <select
                    id="voucherStatus"
                    name="status"
                    class="voucher-filter-select"
                >

                    <option value="">
                        All Statuses
                    </option>

                    <option
                        value="unused"
                        <?= $status === 'unused' ? 'selected' : '' ?>
                    >
                        Unused
                    </option>

                    <option
                        value="active"
                        <?= $status === 'active' ? 'selected' : '' ?>
                    >
                        Active
                    </option>

                    <option
                        value="expired"
                        <?= $status === 'expired' ? 'selected' : '' ?>
                    >
                        Expired
                    </option>

                    <option
                        value="disabled"
                        <?= $status === 'disabled' ? 'selected' : '' ?>
                    >
                        Disabled
                    </option>

                </select>

            </div>


            <div class="voucher-filter-group">

                <label for="voucherSource">
                    Source
                </label>

                <select
                    id="voucherSource"
                    name="source"
                    class="voucher-filter-select"
                >

                    <option value="">
                        All Sources
                    </option>

                    <option
                        value="manual"
                        <?= $source === 'manual' ? 'selected' : '' ?>
                    >
                        Manual
                    </option>

                    <option
                        value="auto"
                        <?= $source === 'auto' ? 'selected' : '' ?>
                    >
                        Automatic
                    </option>

                </select>

            </div>


            <button
                type="submit"
                class="voucher-filter-btn"
            >
                <i class="fa-solid fa-filter"></i>
                Filter
            </button>


            <a
                href="<?= e(appUrl(
                    'admin/dashboard.php?page=vouchers'
                )) ?>"
                class="voucher-reset-btn"
            >
                <i class="fa-solid fa-rotate-left"></i>
                Reset
            </a>

        </form>

    </div>


    <!-- =====================================================
         VOUCHER TABLE
         ====================================================== -->

    <div class="voucher-table-card">

        <div class="voucher-table-header">

            <h2>
                Voucher List
            </h2>

            <div class="voucher-table-count">

                <?php if ($totalRows > 0): ?>

                    <?= number_format($totalRows) ?>
                    voucher<?= $totalRows === 1 ? '' : 's' ?>

                <?php else: ?>

                    No vouchers found

                <?php endif; ?>

            </div>

        </div>


        <?php if (!$vouchers): ?>

            <!-- EMPTY STATE -->

            <div class="voucher-empty">

                <div class="voucher-empty-icon">
                    <i class="fa-solid fa-ticket"></i>
                </div>

                <h3>
                    No Vouchers Found
                </h3>

                <p>
                    There are no vouchers matching your current filters.
                </p>

                <?php if (
                    $search !== '' ||
                    $status !== '' ||
                    $source !== ''
                ): ?>

                    <a
                        href="<?= e(appUrl(
                            'admin/dashboard.php?page=vouchers'
                        )) ?>"
                        class="voucher-reset-btn"
                    >
                        <i class="fa-solid fa-rotate-left"></i>
                        Clear Filters
                    </a>

                <?php else: ?>

                    <a
                        href="<?= e(appUrl(
                            'admin/dashboard.php?page=vouchers&action=create'
                        )) ?>"
                        class="voucher-create-btn"
                    >
                        <i class="fa-solid fa-plus"></i>
                        Create First Voucher
                    </a>

                <?php endif; ?>

            </div>


        <?php else: ?>

            <div class="voucher-table-wrapper">

                <table class="voucher-table">

                    <thead>

                        <tr>

                            <th>
                                Voucher
                            </th>

                            <th>
                                Package
                            </th>

                            <th>
                                Status
                            </th>

                            <th>
                                Source
                            </th>

                            <th>
                                Customer / Device
                            </th>

                            <th>
                                Expires
                            </th>

                            <th>
                                Created
                            </th>

                            <th>
                                Actions
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                    <?php foreach ($vouchers as $voucher): ?>

                        <?php

                        $voucherId =
                            (int)($voucher['id'] ?? 0);

                        $voucherCode =
                            (string)($voucher['code'] ?? '');

                        $voucherStatus =
                            (string)($voucher['status'] ?? '');

                        $voucherSource =
                            (string)($voucher['source'] ?? '');

                        $packageName =
                            (string)(
                                $voucher['package_name']
                                ?? 'Unknown package'
                            );

                        $username =
                            trim(
                                (string)(
                                    $voucher['username']
                                    ?? ''
                                )
                            );

                        $deviceMac =
                            trim(
                                (string)(
                                    $voucher['device_mac']
                                    ?? ''
                                )
                            );

                        $deviceIp =
                            trim(
                                (string)(
                                    $voucher['device_ip']
                                    ?? ''
                                )
                            );

                        $statusClass =
                            voucherStatusClass(
                                $voucherStatus
                            );

                        $statusLabel =
                            voucherStatusLabel(
                                $voucherStatus
                            );

                        $sourceLabel =
                            voucherSourceLabel(
                                $voucherSource
                            );

                        $expires =
                            formatVoucherExpiry(
                                $voucher['expires_at']
                                ?? null
                            );

                        $created =
                            formatVoucherExpiry(
                                $voucher['created_at']
                                ?? null
                            );

                        ?>

                        <tr>

                            <!-- VOUCHER -->

                            <td>

                                <div class="voucher-code-cell">
                                    <?= e($voucherCode) ?>
                                </div>

                            </td>


                            <!-- PACKAGE -->

                            <td>

                                <div class="voucher-package-cell">
                                    <?= e($packageName) ?>
                                </div>

                            </td>


                            <!-- STATUS -->

                            <td>

                                <span
                                    class="voucher-status <?= e($statusClass) ?>"
                                >

                                    <i class="fa-solid fa-circle"></i>

                                    <?= e($statusLabel) ?>

                                </span>

                            </td>


                            <!-- SOURCE -->

                            <td>

                                <span class="voucher-source">

                                    <i class="fa-solid fa-layer-group"></i>

                                    <?= e($sourceLabel) ?>

                                </span>

                            </td>


                            <!-- CUSTOMER -->

                            <td class="voucher-customer-cell">

                                <?php if ($username !== ''): ?>

                                    <div class="voucher-customer-main">
                                        <?= e($username) ?>
                                    </div>

                                <?php else: ?>

                                    <div class="voucher-customer-main voucher-muted">
                                        Not assigned
                                    </div>

                                <?php endif; ?>


                                <?php if ($deviceIp !== ''): ?>

                                    <div class="voucher-customer-sub">
                                        IP: <?= e($deviceIp) ?>
                                    </div>

                                <?php elseif ($deviceMac !== ''): ?>

                                    <div class="voucher-customer-sub">
                                        MAC: <?= e($deviceMac) ?>
                                    </div>

                                <?php else: ?>

                                    <div class="voucher-customer-sub">
                                        No device
                                    </div>

                                <?php endif; ?>

                            </td>


                            <!-- EXPIRES -->

                            <td>

                                <?php if ($expires !== '—'): ?>

                                    <?= e($expires) ?>

                                <?php else: ?>

                                    <span class="voucher-muted">
                                        —
                                    </span>

                                <?php endif; ?>

                            </td>


                            <!-- CREATED -->

                            <td>
                                <?= e($created) ?>
                            </td>


                            <!-- ACTIONS -->

                            <td>

                                <div class="voucher-actions">

                                    <!-- VIEW -->

                                    <a
                                        href="<?= e(appUrl(
                                            'admin/dashboard.php?page=vouchers&action=view&id=' .
                                            $voucherId
                                        )) ?>"
                                        class="voucher-action-btn"
                                        title="View Voucher"
                                        aria-label="View Voucher"
                                    >
                                        <i class="fa-solid fa-eye"></i>
                                    </a>


                                    <!-- EDIT -->

                                    <a
                                        href="<?= e(appUrl(
                                            'admin/dashboard.php?page=vouchers&action=edit&id=' .
                                            $voucherId
                                        )) ?>"
                                        class="voucher-action-btn"
                                        title="Edit Voucher"
                                        aria-label="Edit Voucher"
                                    >
                                        <i class="fa-solid fa-pen"></i>
                                    </a>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>


            <!-- =================================================
                 PAGINATION
                 ================================================== -->

            <?php if ($totalPages > 1): ?>

                <div class="voucher-pagination">

                    <div class="voucher-pagination-info">

                        Page
                        <?= number_format($page) ?>
                        of
                        <?= number_format($totalPages) ?>

                    </div>


                    <div class="voucher-pagination-links">

                        <?php if ($page > 1): ?>

                            <a
                                href="<?= e(
                                    $buildPageUrl($page - 1)
                                ) ?>"
                                class="voucher-page-link"
                                title="Previous"
                            >
                                <i class="fa-solid fa-chevron-left"></i>
                            </a>

                        <?php endif; ?>


                        <?php

                        $startPage =
                            max(1, $page - 2);

                        $endPage =
                            min(
                                $totalPages,
                                $page + 2
                            );

                        ?>


                        <?php for (
                            $i = $startPage;
                            $i <= $endPage;
                            $i++
                        ): ?>

                            <a
                                href="<?= e(
                                    $buildPageUrl($i)
                                ) ?>"
                                class="voucher-page-link <?= $i === $page ? 'active' : '' ?>"
                            >
                                <?= $i ?>
                            </a>

                        <?php endfor; ?>


                        <?php if ($page < $totalPages): ?>

                            <a
                                href="<?= e(
                                    $buildPageUrl($page + 1)
                                ) ?>"
                                class="voucher-page-link"
                                title="Next"
                            >
                                <i class="fa-solid fa-chevron-right"></i>
                            </a>

                        <?php endif; ?>

                    </div>

                </div>

            <?php endif; ?>

        <?php endif; ?>

    </div>

</div>
