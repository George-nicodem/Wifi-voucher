<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';

requireAdminLogin();

$message = '';
$error = '';
$createdVoucher = null;

/*
|--------------------------------------------------------------------------
| LOAD ACTIVE PACKAGES
|--------------------------------------------------------------------------
*/

$packages = [];

$result = $conn->query("
    SELECT
        id,
        name,
        price,
        duration_minutes,
        speed_limit
    FROM packages
    WHERE status = 'active'
    ORDER BY name ASC
");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $packages[] = $row;
    }
}

/*
|--------------------------------------------------------------------------
| FORM VALUES
|--------------------------------------------------------------------------
*/

$packageId = postInt('package_id');
$source = 'manual';

/*
|--------------------------------------------------------------------------
| CREATE VOUCHER
|--------------------------------------------------------------------------
*/

if (isPost()) {

    requireAdminPost();
    requireCsrfToken();

    /*
    | Admin-created vouchers are always manual.
    | Automatic vouchers should be created by the payment system.
    */
    $source = 'manual';

    if ($packageId === null || $packageId <= 0) {

        $error = 'Please select a valid package.';

    } else {

        /*
        |--------------------------------------------------------------------------
        | VERIFY PACKAGE
        |--------------------------------------------------------------------------
        */

        $packageStmt = $conn->prepare("
            SELECT
                id,
                name,
                price,
                duration_minutes,
                speed_limit
            FROM packages
            WHERE id = ?
              AND status = 'active'
            LIMIT 1
        ");

        if (!$packageStmt) {

            logDatabaseError(
                $conn,
                'Preparing active package verification'
            );

            $error = publicErrorMessage();

        } else {

            $packageStmt->bind_param(
                'i',
                $packageId
            );

            if (!$packageStmt->execute()) {

                logDatabaseError(
                    $conn,
                    'Executing active package verification'
                );

                $error = publicErrorMessage();

            } else {

                $packageResult =
                    $packageStmt->get_result();

                $selectedPackage =
                    $packageResult
                    ? $packageResult->fetch_assoc()
                    : null;

                if (!$selectedPackage) {

                    $error =
                        'The selected package is not available. Please choose another package.';

                } else {

                    /*
                    |--------------------------------------------------------------------------
                    | GENERATE UNIQUE VOUCHER CODE
                    |--------------------------------------------------------------------------
                    */

                    $voucherCode = null;

                    /*
                    | random attempts protect against an extremely unlikely
                    | duplicate code collision.
                    */
                    for ($attempt = 1; $attempt <= 10; $attempt++) {

                        $candidate =
                            generateVoucherCode(
                                VOUCHER_CODE_LENGTH
                            );

                        $checkStmt = $conn->prepare("
                            SELECT id
                            FROM vouchers
                            WHERE code = ?
                            LIMIT 1
                        ");

                        if (!$checkStmt) {

                            logDatabaseError(
                                $conn,
                                'Preparing voucher code uniqueness check'
                            );

                            $error =
                                publicErrorMessage();

                            break;
                        }

                        $checkStmt->bind_param(
                            's',
                            $candidate
                        );

                        if (!$checkStmt->execute()) {

                            logDatabaseError(
                                $conn,
                                'Executing voucher code uniqueness check'
                            );

                            $checkStmt->close();

                            $error =
                                publicErrorMessage();

                            break;
                        }

                        $checkResult =
                            $checkStmt->get_result();

                        $exists =
                            $checkResult
                            && $checkResult->num_rows > 0;

                        $checkStmt->close();

                        if (!$exists) {

                            $voucherCode =
                                $candidate;

                            break;
                        }
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | INSERT VOUCHER
                    |--------------------------------------------------------------------------
                    */

                    if (
                        $error === ''
                        && $voucherCode !== null
                    ) {

                        $insertStmt = $conn->prepare("
                            INSERT INTO vouchers
                            (
                                code,
                                package_id,
                                status,
                                source
                            )
                            VALUES
                            (
                                ?,
                                ?,
                                'unused',
                                ?
                            )
                        ");

                        if (!$insertStmt) {

                            logDatabaseError(
                                $conn,
                                'Preparing voucher creation'
                            );

                            $error =
                                publicErrorMessage();

                        } else {

                            $insertStmt->bind_param(
                                'sis',
                                $voucherCode,
                                $packageId,
                                $source
                            );

                            if (
                                $insertStmt->execute()
                            ) {

                                $createdVoucher = [
                                    'id' =>
                                        (int)$insertStmt->insert_id,

                                    'code' =>
                                        $voucherCode,

                                    'package_name' =>
                                        (string)$selectedPackage['name'],

                                    'price' =>
                                        $selectedPackage['price'],

                                    'duration_minutes' =>
                                        (int)$selectedPackage[
                                            'duration_minutes'
                                        ],

                                    'speed_limit' =>
                                        $selectedPackage[
                                            'speed_limit'
                                        ]
                                ];

                                /*
                                |--------------------------------------------------------------------------
                                | AUDIT LOG
                                |--------------------------------------------------------------------------
                                */

                                logAdminSecurityEvent(
                                    'VOUCHER_CREATED',
                                    'Created a manual voucher for package ID '
                                    . $packageId
                                );

                            } else {

                                /*
                                |--------------------------------------------------------------------------
                                | UNIQUE CODE COLLISION
                                |--------------------------------------------------------------------------
                                |
                                | The database UNIQUE constraint is the final
                                | protection against duplicate voucher codes.
                                */

                                if (
                                    (int)$conn->errno === 1062
                                ) {

                                    $error =
                                        'A voucher code collision occurred. Please try again.';

                                } else {

                                    logDatabaseError(
                                        $conn,
                                        'Inserting new voucher'
                                    );

                                    $error =
                                        publicErrorMessage();
                                }
                            }

                            $insertStmt->close();
                        }
                    }

                    if (
                        $error === ''
                        && $voucherCode === null
                    ) {

                        $error =
                            'Unable to generate a unique voucher code. Please try again.';
                    }
                }
            }

            $packageStmt->close();
        }
    }
}
$pageTitle = 'Create Voucher';
?>

<style>
.voucher-create-page{max-width:1180px;margin:0 auto;padding:2px 0 32px;color:#0f172a}
.voucher-create-header{display:flex;align-items:center;justify-content:space-between;gap:20px;margin:0 0 22px}
.voucher-create-heading{display:flex;align-items:center;gap:15px;min-width:0}
.voucher-create-heading-icon{width:52px;height:52px;flex:0 0 52px;display:grid;place-items:center;border-radius:15px;background:#eff6ff;color:#2563eb;font-size:22px}
.voucher-create-eyebrow{margin:0 0 4px;color:#64748b;font-size:11px;font-weight:750;text-transform:uppercase;letter-spacing:.08em}
.voucher-create-header h1{margin:0;color:#111827;font-size:25px;line-height:1.2;font-weight:750}
.voucher-create-header p{margin:6px 0 0;color:#64748b;font-size:14px}
.voucher-create-back,.voucher-create-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:42px;padding:0 15px;border:1px solid #dbe2ea;border-radius:10px;background:#fff;color:#334155;text-decoration:none;font-size:13px;font-weight:700;white-space:nowrap;transition:.15s ease}
.voucher-create-back:hover{background:#f8fafc;color:#111827}
.voucher-create-btn-primary{border-color:#2563eb;background:#2563eb;color:#fff;cursor:pointer}
.voucher-create-btn-primary:hover{border-color:#1d4ed8;background:#1d4ed8;color:#fff}
.voucher-create-layout{display:grid;grid-template-columns:minmax(0,1fr) 300px;align-items:start;gap:18px}
.voucher-create-card{min-width:0;overflow:hidden;border:1px solid #e5eaf0;border-radius:16px;background:#fff;box-shadow:0 4px 18px rgba(15,23,42,.045)}
.voucher-create-card-head{display:flex;align-items:flex-start;gap:12px;padding:20px 23px;border-bottom:1px solid #edf0f4}
.voucher-create-card-icon{width:38px;height:38px;flex:0 0 38px;display:grid;place-items:center;border-radius:11px;background:#f1f5f9;color:#475569}
.voucher-create-card-head h2{margin:0;color:#111827;font-size:16px;font-weight:750}
.voucher-create-card-head p{margin:5px 0 0;color:#64748b;font-size:13px;line-height:1.5}
.voucher-create-form-body{padding:23px}
.voucher-create-field{display:flex;flex-direction:column;gap:8px}
.voucher-create-field label{color:#334155;font-size:13px;font-weight:700}
.voucher-create-required{color:#dc2626}
.voucher-create-select{width:100%;height:48px;box-sizing:border-box;padding:0 13px;border:1px solid #d8e0e9;border-radius:10px;background:#fff;color:#111827;font:inherit;font-size:14px;outline:none;transition:.15s ease}
.voucher-create-select:focus{border-color:#3b82f6;box-shadow:0 0 0 3px rgba(59,130,246,.13)}
.voucher-create-help{color:#64748b;font-size:12px;line-height:1.5}
.voucher-create-preview{display:none;margin-top:18px;padding:17px;border:1px solid #dbeafe;border-radius:12px;background:linear-gradient(135deg,#f8fbff,#eff6ff)}
.voucher-create-preview-title{display:flex;align-items:center;gap:8px;margin:0 0 14px;color:#1e3a8a;font-size:13px;font-weight:750}
.voucher-create-preview-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
.voucher-create-preview-item{min-width:0;padding:11px 12px;border:1px solid rgba(191,219,254,.85);border-radius:9px;background:rgba(255,255,255,.8)}
.voucher-create-preview-label{display:block;margin-bottom:5px;color:#64748b;font-size:11px}
.voucher-create-preview-value{display:block;overflow-wrap:anywhere;color:#172033;font-size:13px;font-weight:700}
.voucher-create-summary{display:flex;align-items:flex-start;gap:11px;margin-top:18px;padding:14px;border:1px solid #e5e7eb;border-radius:11px;background:#f8fafc}
.voucher-create-summary-icon{color:#2563eb;margin-top:2px}
.voucher-create-summary strong{display:block;color:#334155;font-size:12px}
.voucher-create-summary p{margin:4px 0 0;color:#64748b;font-size:12px;line-height:1.5}
.voucher-create-form-actions{display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap;margin-top:22px;padding-top:18px;border-top:1px solid #edf0f4}
.voucher-create-aside{padding:20px}
.voucher-create-aside h3{display:flex;align-items:center;gap:9px;margin:0;color:#111827;font-size:14px;font-weight:750}
.voucher-create-aside h3 i{color:#2563eb}
.voucher-create-aside-intro{margin:7px 0 17px;color:#64748b;font-size:12px;line-height:1.55}
.voucher-create-steps{display:grid;gap:14px}
.voucher-create-step{display:grid;grid-template-columns:30px minmax(0,1fr);gap:10px;align-items:start}
.voucher-create-step-icon{width:30px;height:30px;display:grid;place-items:center;border-radius:9px;background:#eff6ff;color:#2563eb;font-size:12px}
.voucher-create-step strong{display:block;margin:1px 0 3px;color:#334155;font-size:12px}
.voucher-create-step span{display:block;color:#64748b;font-size:11px;line-height:1.5}
.voucher-create-alert{display:flex;align-items:flex-start;gap:10px;padding:13px 15px;margin:0 0 17px;border:1px solid #fecaca;border-radius:11px;background:#fef2f2;color:#991b1b;font-size:13px;line-height:1.55}
.voucher-create-alert i{margin-top:2px}
.voucher-create-empty{padding:24px;border:1px solid #fde68a;border-radius:11px;background:#fffbeb;color:#92400e}
.voucher-create-empty strong{display:block;font-size:14px}
.voucher-create-empty p{margin:5px 0 14px;font-size:12px;line-height:1.5}
.voucher-create-empty a{color:#1d4ed8;font-size:13px;font-weight:700;text-decoration:none}
.voucher-create-success{text-align:center;padding:32px 24px}
.voucher-create-success-icon{width:62px;height:62px;display:grid;place-items:center;margin:0 auto 15px;border-radius:50%;background:#ecfdf5;color:#15803d;font-size:25px}
.voucher-create-success h2{margin:0;color:#111827;font-size:21px}
.voucher-create-success-copy{margin:7px 0 19px;color:#64748b;font-size:13px}
.voucher-create-code-box{max-width:460px;margin:0 auto 18px;padding:17px;border:1px dashed #93c5fd;border-radius:13px;background:#f8fbff}
.voucher-create-code-label{display:block;color:#64748b;font-size:10px;font-weight:750;letter-spacing:.1em;text-transform:uppercase}
.voucher-create-code-row{display:flex;align-items:center;justify-content:center;gap:10px;margin-top:8px}
.voucher-create-code{overflow-wrap:anywhere;color:#172554;font:750 27px/1.2 ui-monospace,SFMono-Regular,Consolas,monospace;letter-spacing:2px}
.voucher-create-copy{width:36px;height:36px;flex:0 0 36px;display:grid;place-items:center;border:1px solid #dbeafe;border-radius:9px;background:#fff;color:#2563eb;cursor:pointer}
.voucher-create-success-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));max-width:600px;margin:0 auto 22px;gap:10px;text-align:left}
.voucher-create-success-item{padding:12px;border:1px solid #edf0f4;border-radius:10px}
.voucher-create-success-item span{display:block;margin-bottom:5px;color:#64748b;font-size:11px}
.voucher-create-success-item strong{display:block;color:#172033;font-size:13px;overflow-wrap:anywhere}
.voucher-create-success-actions{display:flex;justify-content:center;gap:10px;flex-wrap:wrap}
@media(max-width:900px){.voucher-create-layout{grid-template-columns:minmax(0,1fr) 260px}.voucher-create-preview-grid{grid-template-columns:1fr 1fr}}
@media(max-width:700px){.voucher-create-header{align-items:flex-start;flex-direction:column}.voucher-create-header .voucher-create-back{align-self:flex-start}.voucher-create-layout{grid-template-columns:1fr}.voucher-create-aside{order:2}}
@media(max-width:520px){.voucher-create-heading{align-items:flex-start}.voucher-create-heading-icon{width:44px;height:44px;flex-basis:44px;border-radius:12px;font-size:18px}.voucher-create-header h1{font-size:21px}.voucher-create-form-body{padding:17px}.voucher-create-card-head{padding:17px}.voucher-create-preview-grid,.voucher-create-success-grid{grid-template-columns:1fr}.voucher-create-form-actions{flex-direction:column-reverse}.voucher-create-form-actions>*{width:100%;box-sizing:border-box}.voucher-create-code{font-size:22px}.voucher-create-success{padding:24px 17px}}
</style>

<div class="voucher-create-page">
    <header class="voucher-create-header">
        <div class="voucher-create-heading">
            <div class="voucher-create-heading-icon"><i class="fa-solid fa-ticket"></i></div>
            <div>
                <div class="voucher-create-eyebrow">Vouchers / Create</div>
                <h1>Create Voucher</h1>
                <p>Create a new Wi-Fi voucher manually.</p>
            </div>
        </div>
        <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>" class="voucher-create-back">
            <i class="fa-solid fa-arrow-left"></i> Back to Vouchers
        </a>
    </header>

    <?php if ($error !== ''): ?>
        <div class="voucher-create-alert" role="alert">
            <i class="fa-solid fa-circle-exclamation"></i>
            <div><?= e($error) ?></div>
        </div>
    <?php endif; ?>

    <?php if ($createdVoucher !== null): ?>
        <section class="voucher-create-card voucher-create-success" aria-labelledby="voucher-create-success-title">
            <div class="voucher-create-success-icon"><i class="fa-solid fa-check"></i></div>
            <h2 id="voucher-create-success-title">Voucher created successfully</h2>
            <p class="voucher-create-success-copy">The voucher is saved and ready to use. Its current status is unused.</p>

            <div class="voucher-create-code-box">
                <span class="voucher-create-code-label">Voucher code</span>
                <div class="voucher-create-code-row">
                    <strong class="voucher-create-code" id="created-voucher-code"><?= e((string)$createdVoucher['code']) ?></strong>
                    <button class="voucher-create-copy" type="button" id="copy-created-voucher" aria-label="Copy voucher code" title="Copy voucher code">
                        <i class="fa-regular fa-copy"></i>
                    </button>
                </div>
            </div>

            <div class="voucher-create-success-grid">
                <div class="voucher-create-success-item"><span>Package</span><strong><?= e((string)$createdVoucher['package_name']) ?></strong></div>
                <div class="voucher-create-success-item"><span>Price</span><strong><?= e(formatMoney($createdVoucher['price'])) ?></strong></div>
                <div class="voucher-create-success-item"><span>Duration</span><strong><?= (int)$createdVoucher['duration_minutes'] > 0 ? number_format((int)$createdVoucher['duration_minutes']) . ' minutes' : 'Unlimited' ?></strong></div>
                <div class="voucher-create-success-item"><span>Speed limit</span><strong><?= e((string)($createdVoucher['speed_limit'] ?: 'No speed limit')) ?></strong></div>
                <div class="voucher-create-success-item"><span>Status</span><strong>Unused</strong></div>
                <div class="voucher-create-success-item"><span>Source</span><strong>Manual</strong></div>
            </div>

            <div class="voucher-create-success-actions">
                <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>" class="voucher-create-btn voucher-create-btn-primary">
                    <i class="fa-solid fa-list"></i> Back to Vouchers
                </a>
                <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers&action=create')) ?>" class="voucher-create-btn">
                    <i class="fa-solid fa-plus"></i> Create Another
                </a>
            </div>
        </section>
    <?php else: ?>
        <div class="voucher-create-layout">
            <section class="voucher-create-card">
                <div class="voucher-create-card-head">
                    <div class="voucher-create-card-icon"><i class="fa-solid fa-ticket"></i></div>
                    <div>
                        <h2>Voucher details</h2>
                        <p>Select an active package. The voucher code will be generated securely when you submit.</p>
                    </div>
                </div>

                <div class="voucher-create-form-body">
                    <?php if (empty($packages)): ?>
                        <div class="voucher-create-empty">
                            <strong><i class="fa-solid fa-triangle-exclamation"></i> No active packages found</strong>
                            <p>You need at least one active package before creating a voucher.</p>
                            <a href="<?= e(appUrl('admin/dashboard.php?page=packages')) ?>"><i class="fa-solid fa-box"></i> Manage Packages</a>
                        </div>
                    <?php else: ?>
                        <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=vouchers&action=create')) ?>" autocomplete="off">
                            <?= csrfField() ?>
                            <div class="voucher-create-field">
                                <label for="package_id">Package <span class="voucher-create-required">*</span></label>
                                <select name="package_id" id="package_id" class="voucher-create-select" required>
                                    <option value="">Select an active package</option>
                                    <?php foreach ($packages as $package): ?>
                                        <option
                                            value="<?= (int)$package['id'] ?>"
                                            data-price="<?= e((string)$package['price']) ?>"
                                            data-duration="<?= (int)$package['duration_minutes'] ?>"
                                            data-speed="<?= e((string)($package['speed_limit'] ?? '')) ?>"
                                            <?= $packageId === (int)$package['id'] ? 'selected' : '' ?>
                                        ><?= e((string)$package['name']) ?> — <?= e(formatMoney($package['price'])) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <span class="voucher-create-help">Only active packages are available. Choose one to preview its price, duration and speed.</span>
                            </div>

                            <div id="package-preview" class="voucher-create-preview" aria-live="polite">
                                <h3 class="voucher-create-preview-title"><i class="fa-solid fa-circle-info"></i> Selected package</h3>
                                <div class="voucher-create-preview-grid">
                                    <div class="voucher-create-preview-item"><span class="voucher-create-preview-label">Price</span><strong id="preview-price" class="voucher-create-preview-value">—</strong></div>
                                    <div class="voucher-create-preview-item"><span class="voucher-create-preview-label">Duration</span><strong id="preview-duration" class="voucher-create-preview-value">—</strong></div>
                                    <div class="voucher-create-preview-item"><span class="voucher-create-preview-label">Speed limit</span><strong id="preview-speed" class="voucher-create-preview-value">—</strong></div>
                                </div>
                            </div>

                            <div class="voucher-create-summary">
                                <i class="voucher-create-summary-icon fa-solid fa-shield-halved"></i>
                                <div>
                                    <strong>Manual voucher · starts unused</strong>
                                    <p>Admin-created vouchers are recorded as manual. A unique code is generated automatically.</p>
                                </div>
                            </div>

                            <div class="voucher-create-form-actions">
                                <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>" class="voucher-create-btn">
                                    <i class="fa-solid fa-xmark"></i> Cancel
                                </a>
                                <button type="submit" class="voucher-create-btn voucher-create-btn-primary">
                                    <i class="fa-solid fa-plus"></i> Create Voucher
                                </button>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </section>

            <aside class="voucher-create-card voucher-create-aside">
                <h3><i class="fa-solid fa-circle-question"></i> What happens next?</h3>
                <p class="voucher-create-aside-intro">A quick guide to the voucher you are creating.</p>
                <div class="voucher-create-steps">
                    <div class="voucher-create-step">
                        <div class="voucher-create-step-icon"><i class="fa-solid fa-key"></i></div>
                        <div><strong>Secure code</strong><span>The system generates a unique voucher code for you.</span></div>
                    </div>
                    <div class="voucher-create-step">
                        <div class="voucher-create-step-icon"><i class="fa-solid fa-circle-pause"></i></div>
                        <div><strong>Unused status</strong><span>The voucher remains unused until your activation flow starts it.</span></div>
                    </div>
                    <div class="voucher-create-step">
                        <div class="voucher-create-step-icon"><i class="fa-solid fa-user-shield"></i></div>
                        <div><strong>Admin record</strong><span>It is saved as a manual voucher and protected by admin access and CSRF checks.</span></div>
                    </div>
                </div>
            </aside>
        </div>
    <?php endif; ?>
</div>

<script>
(function () {
    const packageSelect = document.getElementById('package_id');
    const preview = document.getElementById('package-preview');
    const price = document.getElementById('preview-price');
    const duration = document.getElementById('preview-duration');
    const speed = document.getElementById('preview-speed');

    if (packageSelect && preview && price && duration && speed) {
        function updatePreview() {
            const option = packageSelect.options[packageSelect.selectedIndex];
            if (!option || !option.value) {
                preview.style.display = 'none';
                return;
            }

            const numericPrice = Number(option.dataset.price || '0');
            price.textContent = Number.isFinite(numericPrice)
                ? numericPrice.toLocaleString('en-US') + ' TZS'
                : (option.dataset.price || '0') + ' TZS';

            const minutes = Number(option.dataset.duration || '0');
            if (minutes <= 0) {
                duration.textContent = 'Unlimited';
            } else if (minutes < 60) {
                duration.textContent = minutes + ' minutes';
            } else if (minutes % 60 === 0) {
                const hours = minutes / 60;
                duration.textContent = hours + (hours === 1 ? ' hour' : ' hours');
            } else {
                duration.textContent = Math.floor(minutes / 60) + 'h ' + (minutes % 60) + ' min';
            }

            speed.textContent = option.dataset.speed || 'No speed limit';
            preview.style.display = 'block';
        }

        packageSelect.addEventListener('change', updatePreview);
        updatePreview();
    }

    const copyButton = document.getElementById('copy-created-voucher');
    const voucherCode = document.getElementById('created-voucher-code');
    if (copyButton && voucherCode) {
        copyButton.addEventListener('click', async function () {
            const code = voucherCode.textContent.trim();
            try {
                await navigator.clipboard.writeText(code);
            } catch (error) {
                const temporaryInput = document.createElement('textarea');
                temporaryInput.value = code;
                temporaryInput.setAttribute('readonly', '');
                temporaryInput.style.position = 'fixed';
                temporaryInput.style.opacity = '0';
                document.body.appendChild(temporaryInput);
                temporaryInput.select();
                document.execCommand('copy');
                temporaryInput.remove();
            }
            copyButton.innerHTML = '<i class="fa-solid fa-check"></i>';
            copyButton.setAttribute('aria-label', 'Voucher code copied');
        });
    }
}());
</script>
