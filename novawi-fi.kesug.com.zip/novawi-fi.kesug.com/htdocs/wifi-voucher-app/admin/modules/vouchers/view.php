<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';

requireAdminLogin();

/*
|--------------------------------------------------------------------------
| AUTO EXPIRE
|--------------------------------------------------------------------------
*/
expireVouchers($conn);

/*
|--------------------------------------------------------------------------
| GET VOUCHER ID
|--------------------------------------------------------------------------
*/
$id = getInt('id');

if ($id <= 0) {
    ?>
    <div class="voucher-view-page">
        <div class="voucher-error-card">
            <div class="voucher-error-icon">
                <i class="fa-solid fa-circle-exclamation"></i>
            </div>

            <h2>Invalid Voucher</h2>
            <p>The voucher ID provided is invalid.</p>

            <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>"
               class="voucher-btn voucher-btn-primary">
                <i class="fa-solid fa-arrow-left"></i>
                Back to Vouchers
            </a>
        </div>
    </div>
    <?php
    return;
}

/*
|--------------------------------------------------------------------------
| GET VOUCHER
|--------------------------------------------------------------------------
*/
$stmt = $conn->prepare("
    SELECT
        v.id,
        v.code,
        v.package_id,
        v.status,
        v.source,
        v.username,
        v.device_mac,
        v.device_ip,
        v.activated_at,
        v.expires_at,
        v.created_at,
        v.sold_at,
        v.sold_price,

        p.name AS package_name,
        p.price AS package_price,
        p.duration_minutes,
        p.speed_limit

    FROM vouchers v

    LEFT JOIN packages p
        ON p.id = v.package_id

    WHERE v.id = ?

    LIMIT 1
");

if (!$stmt) {
    logDatabaseError($conn, 'Preparing voucher view query');

    ?>
    <div class="voucher-view-page">
        <div class="voucher-error-card">
            <div class="voucher-error-icon">
                <i class="fa-solid fa-database"></i>
            </div>

            <h2>Unable to Load Voucher</h2>
            <p>Something went wrong while loading the voucher.</p>

            <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>"
               class="voucher-btn voucher-btn-primary">
                <i class="fa-solid fa-arrow-left"></i>
                Back to Vouchers
            </a>
        </div>
    </div>
    <?php
    return;
}

$stmt->bind_param('i', $id);

if (!$stmt->execute()) {
    logDatabaseError($conn, 'Executing voucher view query');
    $stmt->close();

    ?>
    <div class="voucher-view-page">
        <div class="voucher-error-card">
            <div class="voucher-error-icon">
                <i class="fa-solid fa-triangle-exclamation"></i>
            </div>

            <h2>Unable to Load Voucher</h2>
            <p>The voucher could not be loaded at this time.</p>

            <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>"
               class="voucher-btn voucher-btn-primary">
                <i class="fa-solid fa-arrow-left"></i>
                Back to Vouchers
            </a>
        </div>
    </div>
    <?php
    return;
}

$result = $stmt->get_result();
$voucher = $result ? $result->fetch_assoc() : null;

$stmt->close();

/*
|--------------------------------------------------------------------------
| VOUCHER NOT FOUND
|--------------------------------------------------------------------------
*/
if (!$voucher) {
    ?>
    <div class="voucher-view-page">
        <div class="voucher-error-card">
            <div class="voucher-error-icon">
                <i class="fa-solid fa-ticket"></i>
            </div>

            <h2>Voucher Not Found</h2>
            <p>The voucher you are looking for does not exist or has been removed.</p>

            <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>"
               class="voucher-btn voucher-btn-primary">
                <i class="fa-solid fa-arrow-left"></i>
                Back to Vouchers
            </a>
        </div>
    </div>
    <?php
    return;
}

/*
|--------------------------------------------------------------------------
| HELPER VALUES
|--------------------------------------------------------------------------
*/
$status = (string)($voucher['status'] ?? 'unknown');
$source = (string)($voucher['source'] ?? 'unknown');

$statusClass = voucherStatusClass($status);
$statusLabel = voucherStatusLabel($status);
$sourceLabel = voucherSourceLabel($source);

$code = (string)($voucher['code'] ?? '');
$packageName = (string)($voucher['package_name'] ?? 'Unknown package');

$packagePrice = $voucher['package_price'] !== null
    ? formatMoney((float)$voucher['package_price'])
    : '—';

$soldPrice = $voucher['sold_price'] !== null
    ? formatMoney((float)$voucher['sold_price'])
    : '—';

$durationMinutes = (int)($voucher['duration_minutes'] ?? 0);

if ($durationMinutes > 0) {
    if ($durationMinutes < 60) {
        $durationText = $durationMinutes . ' minutes';
    } elseif ($durationMinutes % 60 === 0) {
        $hours = intdiv($durationMinutes, 60);

        if ($hours >= 24 && $hours % 24 === 0) {
            $days = intdiv($hours, 24);
            $durationText = $days . ($days === 1 ? ' day' : ' days');
        } else {
            $durationText = $hours . ($hours === 1 ? ' hour' : ' hours');
        }
    } else {
        $hours = intdiv($durationMinutes, 60);
        $minutes = $durationMinutes % 60;

        $durationText = $hours . 'h ' . $minutes . 'm';
    }
} else {
    $durationText = '—';
}

$speedLimit = trim((string)($voucher['speed_limit'] ?? ''));

if ($speedLimit === '') {
    $speedLimit = 'No speed limit';
}

/*
|--------------------------------------------------------------------------
| DATE FORMATTER
|--------------------------------------------------------------------------
*/
$formatDate = static function (?string $date): string {
    if (!$date) {
        return '—';
    }

    $timestamp = strtotime($date);

    if ($timestamp === false) {
        return '—';
    }

    return date('d M Y, H:i', $timestamp);
};

$createdAt  = $formatDate($voucher['created_at'] ?? null);
$soldAt     = $formatDate($voucher['sold_at'] ?? null);
$activatedAt = $formatDate($voucher['activated_at'] ?? null);
$expiresAt  = $formatDate($voucher['expires_at'] ?? null);

$username = trim((string)($voucher['username'] ?? ''));
$deviceMac = trim((string)($voucher['device_mac'] ?? ''));
$deviceIp = trim((string)($voucher['device_ip'] ?? ''));

if ($username === '') {
    $username = 'Not assigned';
}

if ($deviceMac === '') {
    $deviceMac = 'Not assigned';
}

if ($deviceIp === '') {
    $deviceIp = 'Not assigned';
}

/*
|--------------------------------------------------------------------------
| STATUS ICON
|--------------------------------------------------------------------------
*/
$statusIcon = match ($status) {
    'active'   => 'fa-circle-check',
    'unused'   => 'fa-ticket',
    'expired'  => 'fa-clock',
    'disabled' => 'fa-ban',
    default    => 'fa-circle-question'
};

?>

<style>
/* =========================================================
   VOUCHER VIEW PAGE
   ========================================================= */

.voucher-view-page {
    width: 100%;
    max-width: 1180px;
    margin: 0 auto;
    padding: 10px 0 30px;
    box-sizing: border-box;
}

.voucher-view-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 20px;
    margin-bottom: 24px;
}

.voucher-view-heading {
    min-width: 0;
}

.voucher-view-heading h1 {
    margin: 0 0 7px;
    font-size: 27px;
    font-weight: 750;
    line-height: 1.2;
    color: #172033;
    letter-spacing: -0.4px;
}

.voucher-view-heading p {
    margin: 0;
    color: #6b7280;
    font-size: 14px;
}

.voucher-view-actions {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-shrink: 0;
}

.voucher-btn {
    min-height: 42px;
    padding: 0 15px;
    border-radius: 9px;
    border: 1px solid transparent;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    text-decoration: none;
    font-size: 13px;
    font-weight: 650;
    cursor: pointer;
    transition:
        transform .15s ease,
        box-shadow .15s ease,
        background .15s ease,
        border-color .15s ease;
    box-sizing: border-box;
}

.voucher-btn:hover {
    transform: translateY(-1px);
}

.voucher-btn-primary {
    background: #2563eb;
    color: #fff;
    box-shadow: 0 5px 14px rgba(37, 99, 235, .16);
}

.voucher-btn-primary:hover {
    background: #1d4ed8;
    color: #fff;
}

.voucher-btn-secondary {
    background: #fff;
    color: #374151;
    border-color: #d9dee8;
}

.voucher-btn-secondary:hover {
    background: #f8fafc;
    border-color: #cbd5e1;
}

.voucher-main-card {
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(15, 23, 42, .045);
    overflow: hidden;
    margin-bottom: 20px;
}

.voucher-code-section {
    padding: 26px;
    background: linear-gradient(135deg, #f8fbff 0%, #ffffff 70%);
    border-bottom: 1px solid #e8ebf0;
}

.voucher-code-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    margin-bottom: 14px;
}

.voucher-section-label {
    font-size: 12px;
    font-weight: 750;
    text-transform: uppercase;
    letter-spacing: .7px;
    color: #64748b;
}

.voucher-code-box {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    padding: 18px 20px;
    border: 1px dashed #b9c7dc;
    border-radius: 12px;
    background: #fff;
}

.voucher-code {
    font-family: "Courier New", monospace;
    font-size: 25px;
    font-weight: 800;
    letter-spacing: 2px;
    color: #172033;
    word-break: break-all;
}

.voucher-copy-btn {
    flex-shrink: 0;
    width: 42px;
    height: 42px;
    border: 1px solid #d7dde8;
    border-radius: 9px;
    background: #fff;
    color: #475569;
    cursor: pointer;
    transition: .15s ease;
}

.voucher-copy-btn:hover {
    background: #f1f5f9;
    color: #2563eb;
    border-color: #bfdbfe;
}

.voucher-copy-btn.copied {
    color: #15803d;
    border-color: #bbf7d0;
    background: #f0fdf4;
}

.voucher-status-row {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 15px;
}

.voucher-status {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 7px 11px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 700;
    border: 1px solid transparent;
}

.voucher-status.status-active {
    background: #ecfdf3;
    color: #15803d;
    border-color: #bbf7d0;
}

.voucher-status.status-unused {
    background: #eff6ff;
    color: #1d4ed8;
    border-color: #bfdbfe;
}

.voucher-status.status-expired {
    background: #fff7ed;
    color: #c2410c;
    border-color: #fed7aa;
}

.voucher-status.status-disabled {
    background: #fef2f2;
    color: #b91c1c;
    border-color: #fecaca;
}

.voucher-status.status-unknown {
    background: #f1f5f9;
    color: #475569;
    border-color: #e2e8f0;
}

.voucher-source {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 7px 11px;
    border-radius: 999px;
    background: #f8fafc;
    color: #475569;
    border: 1px solid #e2e8f0;
    font-size: 12px;
    font-weight: 650;
}

.voucher-info-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 20px;
}

.voucher-info-card {
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 15px;
    padding: 22px;
    box-shadow: 0 5px 20px rgba(15, 23, 42, .035);
}

.voucher-info-card.full-width {
    grid-column: 1 / -1;
}

.voucher-card-title {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0 0 20px;
    font-size: 15px;
    font-weight: 750;
    color: #172033;
}

.voucher-card-title-icon {
    width: 34px;
    height: 34px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 9px;
    background: #eff6ff;
    color: #2563eb;
    flex-shrink: 0;
}

.voucher-details {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 18px 28px;
}

.voucher-detail {
    min-width: 0;
}

.voucher-detail-label {
    display: block;
    margin-bottom: 6px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .55px;
    color: #94a3b8;
}

.voucher-detail-value {
    color: #263244;
    font-size: 14px;
    font-weight: 600;
    overflow-wrap: anywhere;
}

.voucher-detail-value.muted {
    color: #94a3b8;
    font-weight: 500;
}

.voucher-package-highlight {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 15px;
    border-radius: 11px;
    background: #f8fafc;
    border: 1px solid #e8edf3;
    margin-bottom: 18px;
}

.voucher-package-icon {
    width: 44px;
    height: 44px;
    border-radius: 11px;
    background: #dbeafe;
    color: #2563eb;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    font-size: 17px;
}

.voucher-package-name {
    font-size: 16px;
    font-weight: 750;
    color: #172033;
}

.voucher-package-subtitle {
    margin-top: 3px;
    font-size: 12px;
    color: #64748b;
}

.voucher-lifecycle {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 12px;
}

.voucher-lifecycle-item {
    padding: 15px;
    background: #f8fafc;
    border: 1px solid #e8edf3;
    border-radius: 11px;
}

.voucher-lifecycle-icon {
    color: #64748b;
    font-size: 14px;
    margin-bottom: 9px;
}

.voucher-lifecycle-label {
    font-size: 11px;
    color: #94a3b8;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .45px;
    margin-bottom: 5px;
}

.voucher-lifecycle-value {
    font-size: 13px;
    color: #334155;
    font-weight: 650;
    line-height: 1.45;
}

.voucher-bottom-actions {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    margin-top: 20px;
}

.voucher-error-card {
    max-width: 550px;
    margin: 50px auto;
    padding: 40px 30px;
    text-align: center;
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(15, 23, 42, .05);
}

.voucher-error-icon {
    width: 58px;
    height: 58px;
    margin: 0 auto 17px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #fef2f2;
    color: #dc2626;
    font-size: 22px;
}

.voucher-error-card h2 {
    margin: 0 0 8px;
    color: #172033;
    font-size: 20px;
}

.voucher-error-card p {
    margin: 0 0 22px;
    color: #64748b;
    font-size: 14px;
    line-height: 1.6;
}

@media (max-width: 900px) {
    .voucher-info-grid {
        grid-template-columns: 1fr;
    }

    .voucher-info-card.full-width {
        grid-column: auto;
    }

    .voucher-lifecycle {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 700px) {
    .voucher-view-header {
        flex-direction: column;
    }

    .voucher-view-actions {
        width: 100%;
    }

    .voucher-view-actions .voucher-btn {
        flex: 1;
    }

    .voucher-code-section {
        padding: 20px;
    }

    .voucher-code-box {
        padding: 15px;
    }

    .voucher-code {
        font-size: 20px;
        letter-spacing: 1.5px;
    }

    .voucher-details {
        grid-template-columns: 1fr;
    }

    .voucher-info-card {
        padding: 18px;
    }
}

@media (max-width: 480px) {
    .voucher-view-page {
        padding-top: 5px;
    }

    .voucher-view-heading h1 {
        font-size: 23px;
    }

    .voucher-view-actions {
        flex-direction: column;
    }

    .voucher-view-actions .voucher-btn {
        width: 100%;
    }

    .voucher-code-top {
        align-items: flex-start;
        flex-direction: column;
    }

    .voucher-code-box {
        align-items: flex-start;
    }

    .voucher-code {
        font-size: 18px;
        line-height: 1.5;
    }

    .voucher-lifecycle {
        grid-template-columns: 1fr;
    }

    .voucher-bottom-actions {
        flex-direction: column;
    }

    .voucher-bottom-actions .voucher-btn {
        width: 100%;
    }
}
</style>

<div class="voucher-view-page">

    <!-- =====================================================
         HEADER
         ====================================================== -->
    <div class="voucher-view-header">

        <div class="voucher-view-heading">
            <h1>Voucher Details</h1>
            <p>View complete information about this Wi-Fi voucher.</p>
        </div>

        <div class="voucher-view-actions">

            <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>"
               class="voucher-btn voucher-btn-secondary">
                <i class="fa-solid fa-arrow-left"></i>
                Back
            </a>

            <a href="<?= e(appUrl(
                'admin/dashboard.php?page=vouchers&action=edit&id=' . (int)$voucher['id']
            )) ?>"
               class="voucher-btn voucher-btn-primary">
                <i class="fa-solid fa-pen"></i>
                Edit Voucher
            </a>

        </div>

    </div>


    <!-- =====================================================
         MAIN VOUCHER CARD
         ====================================================== -->
    <div class="voucher-main-card">

        <div class="voucher-code-section">

            <div class="voucher-code-top">
                <span class="voucher-section-label">
                    Voucher Code
                </span>
            </div>

            <div class="voucher-code-box">

                <div class="voucher-code" id="voucherCode">
                    <?= e($code) ?>
                </div>

                <button
                    type="button"
                    class="voucher-copy-btn"
                    id="copyVoucherBtn"
                    title="Copy voucher code"
                    aria-label="Copy voucher code"
                >
                    <i class="fa-regular fa-copy"></i>
                </button>

            </div>

            <div class="voucher-status-row">

                <span class="voucher-status <?= e($statusClass) ?>">
                    <i class="fa-solid <?= e($statusIcon) ?>"></i>
                    <?= e($statusLabel) ?>
                </span>

                <span class="voucher-source">
                    <i class="fa-solid fa-layer-group"></i>
                    <?= e($sourceLabel) ?>
                </span>

            </div>

        </div>

    </div>


    <!-- =====================================================
         INFORMATION GRID
         ====================================================== -->
    <div class="voucher-info-grid">


        <!-- =================================================
             PACKAGE INFORMATION
             ================================================== -->
        <div class="voucher-info-card">

            <h2 class="voucher-card-title">
                <span class="voucher-card-title-icon">
                    <i class="fa-solid fa-box-open"></i>
                </span>

                Package Information
            </h2>

            <div class="voucher-package-highlight">

                <div class="voucher-package-icon">
                    <i class="fa-solid fa-wifi"></i>
                </div>

                <div>
                    <div class="voucher-package-name">
                        <?= e($packageName) ?>
                    </div>

                    <div class="voucher-package-subtitle">
                        Wi-Fi access package
                    </div>
                </div>

            </div>

            <div class="voucher-details">

                <div class="voucher-detail">
                    <span class="voucher-detail-label">
                        Package Price
                    </span>

                    <div class="voucher-detail-value">
                        <?= e($packagePrice) ?>
                    </div>
                </div>

                <div class="voucher-detail">
                    <span class="voucher-detail-label">
                        Duration
                    </span>

                    <div class="voucher-detail-value">
                        <?= e($durationText) ?>
                    </div>
                </div>

                <div class="voucher-detail">
                    <span class="voucher-detail-label">
                        Speed Limit
                    </span>

                    <div class="voucher-detail-value">
                        <?= e($speedLimit) ?>
                    </div>
                </div>

                <div class="voucher-detail">
                    <span class="voucher-detail-label">
                        Sold Price
                    </span>

                    <div class="voucher-detail-value">
                        <?= e($soldPrice) ?>
                    </div>
                </div>

            </div>

        </div>


        <!-- =================================================
             CUSTOMER / DEVICE
             ================================================== -->
        <div class="voucher-info-card">

            <h2 class="voucher-card-title">
                <span class="voucher-card-title-icon">
                    <i class="fa-solid fa-user"></i>
                </span>

                Customer & Device
            </h2>

            <div class="voucher-details">

                <div class="voucher-detail">
                    <span class="voucher-detail-label">
                        Username
                    </span>

                    <div class="voucher-detail-value <?= $username === 'Not assigned' ? 'muted' : '' ?>">
                        <?= e($username) ?>
                    </div>
                </div>

                <div class="voucher-detail">
                    <span class="voucher-detail-label">
                        Device MAC
                    </span>

                    <div class="voucher-detail-value <?= $deviceMac === 'Not assigned' ? 'muted' : '' ?>">
                        <?= e($deviceMac) ?>
                    </div>
                </div>

                <div class="voucher-detail">
                    <span class="voucher-detail-label">
                        Device IP
                    </span>

                    <div class="voucher-detail-value <?= $deviceIp === 'Not assigned' ? 'muted' : '' ?>">
                        <?= e($deviceIp) ?>
                    </div>
                </div>

                <div class="voucher-detail">
                    <span class="voucher-detail-label">
                        Voucher ID
                    </span>

                    <div class="voucher-detail-value">
                        #<?= (int)$voucher['id'] ?>
                    </div>
                </div>

            </div>

        </div>


        <!-- =================================================
             LIFECYCLE
             ================================================== -->
        <div class="voucher-info-card full-width">

            <h2 class="voucher-card-title">
                <span class="voucher-card-title-icon">
                    <i class="fa-solid fa-clock-rotate-left"></i>
                </span>

                Voucher Lifecycle
            </h2>

            <div class="voucher-lifecycle">

                <div class="voucher-lifecycle-item">

                    <div class="voucher-lifecycle-icon">
                        <i class="fa-regular fa-calendar-plus"></i>
                    </div>

                    <div class="voucher-lifecycle-label">
                        Created
                    </div>

                    <div class="voucher-lifecycle-value">
                        <?= e($createdAt) ?>
                    </div>

                </div>


                <div class="voucher-lifecycle-item">

                    <div class="voucher-lifecycle-icon">
                        <i class="fa-solid fa-cart-shopping"></i>
                    </div>

                    <div class="voucher-lifecycle-label">
                        Sold
                    </div>

                    <div class="voucher-lifecycle-value">
                        <?= e($soldAt) ?>
                    </div>

                </div>


                <div class="voucher-lifecycle-item">

                    <div class="voucher-lifecycle-icon">
                        <i class="fa-solid fa-power-off"></i>
                    </div>

                    <div class="voucher-lifecycle-label">
                        Activated
                    </div>

                    <div class="voucher-lifecycle-value">
                        <?= e($activatedAt) ?>
                    </div>

                </div>


                <div class="voucher-lifecycle-item">

                    <div class="voucher-lifecycle-icon">
                        <i class="fa-regular fa-clock"></i>
                    </div>

                    <div class="voucher-lifecycle-label">
                        Expires
                    </div>

                    <div class="voucher-lifecycle-value">
                        <?= e($expiresAt) ?>
                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- =====================================================
         BOTTOM ACTIONS
         ====================================================== -->
    <div class="voucher-bottom-actions">

        <a href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>"
           class="voucher-btn voucher-btn-secondary">

            <i class="fa-solid fa-arrow-left"></i>
            Back to Vouchers

        </a>

        <a href="<?= e(appUrl(
            'admin/dashboard.php?page=vouchers&action=edit&id=' . (int)$voucher['id']
        )) ?>"
           class="voucher-btn voucher-btn-primary">

            <i class="fa-solid fa-pen"></i>
            Edit Voucher

        </a>

    </div>

</div>


<script>
(function () {

    const copyButton = document.getElementById('copyVoucherBtn');
    const codeElement = document.getElementById('voucherCode');

    if (!copyButton || !codeElement) {
        return;
    }

    copyButton.addEventListener('click', async function () {

        const code = codeElement.textContent.trim();

        if (!code) {
            return;
        }

        try {

            await navigator.clipboard.writeText(code);

            copyButton.classList.add('copied');

            copyButton.innerHTML =
                '<i class="fa-solid fa-check"></i>';

            copyButton.title = 'Copied';

            setTimeout(function () {

                copyButton.classList.remove('copied');

                copyButton.innerHTML =
                    '<i class="fa-regular fa-copy"></i>';

                copyButton.title = 'Copy voucher code';

            }, 1800);

        } catch (error) {

            /*
             * Fallback for browsers where clipboard API
             * is unavailable.
             */

            const textarea = document.createElement('textarea');

            textarea.value = code;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';

            document.body.appendChild(textarea);

            textarea.focus();
            textarea.select();

            try {
                document.execCommand('copy');

                copyButton.classList.add('copied');

                copyButton.innerHTML =
                    '<i class="fa-solid fa-check"></i>';

                setTimeout(function () {

                    copyButton.classList.remove('copied');

                    copyButton.innerHTML =
                        '<i class="fa-regular fa-copy"></i>';

                }, 1800);

            } catch (fallbackError) {
                // Do nothing if clipboard access is unavailable.
            }

            document.body.removeChild(textarea);
        }

    });

})();
</script>
