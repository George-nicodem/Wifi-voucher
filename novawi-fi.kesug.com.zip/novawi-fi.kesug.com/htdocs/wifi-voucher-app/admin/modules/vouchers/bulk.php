<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';

requireAdminLogin();
require_once __DIR__ . '/batch_schema.php';
$batchSchemaReady = ensureVoucherBatchSchema($conn);

$packages = [];
$packageResult = $conn->query("SELECT id, name, price, duration_minutes, speed_limit FROM packages WHERE status = 'active' ORDER BY name ASC");
if ($packageResult) {
    while ($row = $packageResult->fetch_assoc()) {
        $packages[] = $row;
    }
} else {
    logDatabaseError($conn, 'Loading active packages for bulk voucher generation');
}

$error = '';
if (!$packageResult) {
    $error = publicErrorMessage('Unable to load active packages.');
}
$createdCodes = [];
$createdBatchId = 0;
$createdPackageName = '';
$packageId = postInt('package_id') ?? 0;
$quantity = postInt('quantity') ?? 1;
$maximumQuantity = 500;

if (isPost()) {
    requireAdminPost();
    requireCsrfToken();

    $packageId = postInt('package_id') ?? 0;
    $quantity = postInt('quantity') ?? 0;

    if (!$batchSchemaReady) {
        $error = publicErrorMessage('Unable to prepare batch storage.');
    } elseif ($packageId <= 0) {
        $error = 'Please select an active package.';
    } elseif ($quantity < 1 || $quantity > $maximumQuantity) {
        $error = 'Choose a quantity from 1 to ' . number_format($maximumQuantity) . '.';
    } else {
        $packageStmt = $conn->prepare("SELECT id, name, price, duration_minutes FROM packages WHERE id = ? AND status = 'active' LIMIT 1");

        if (!$packageStmt) {
            logDatabaseError($conn, 'Preparing active package validation for bulk vouchers');
            $error = publicErrorMessage('Unable to validate the selected package.');
        } else {
            $packageStmt->bind_param('i', $packageId);

            if (!$packageStmt->execute()) {
                logDatabaseError($conn, 'Executing active package validation for bulk vouchers');
                $error = publicErrorMessage('Unable to validate the selected package.');
            } else {
                $packageResult = $packageStmt->get_result();
                $selectedPackage = $packageResult ? $packageResult->fetch_assoc() : null;

                if (!$selectedPackage) {
                    $error = 'The selected package is no longer active. Refresh the page and choose another package.';
                } else {
                    $createdPackageName = (string)$selectedPackage['name'];
                    $createdPackagePrice = (float)$selectedPackage['price'];
                    $createdPackageDuration = (int)$selectedPackage['duration_minutes'];
                    $createdPackageDurationLabel = $createdPackageDuration >= 1440 ? rtrim(rtrim(number_format($createdPackageDuration / 1440, 2, '.', ''), '0'), '.') . ' days' : ($createdPackageDuration >= 60 ? rtrim(rtrim(number_format($createdPackageDuration / 60, 2, '.', ''), '0'), '.') . ' hours' : $createdPackageDuration . ' minutes');
                    $transactionStarted = $conn->begin_transaction();

                    if (!$transactionStarted) {
                        logDatabaseError($conn, 'Starting bulk voucher transaction');
                        $error = publicErrorMessage('Unable to start voucher generation.');
                    } else {
                        $insertStmt = $conn->prepare("INSERT INTO vouchers (code, package_id, status, source) VALUES (?, ?, 'unused', 'manual')");

                        if (!$insertStmt) {
                            logDatabaseError($conn, 'Preparing bulk voucher insert');
                            $error = publicErrorMessage('Unable to prepare voucher generation.');
                            $conn->rollback();
                        } else {
                            $failed = false;
                            $code = '';
                            $insertStmt->bind_param('si', $code, $packageId);

                            for ($number = 0; $number < $quantity && !$failed; $number++) {
                                $inserted = false;

                                for ($attempt = 0; $attempt < 20; $attempt++) {
                                    $code = generateVoucherCode(VOUCHER_CODE_LENGTH);

                                    if ($insertStmt->execute()) {
                                        $createdCodes[] = $code;
                                        $inserted = true;
                                        break;
                                    }

                                    if ((int)$insertStmt->errno === 1062) {
                                        continue;
                                    }

                                    logDatabaseError($conn, 'Inserting bulk generated voucher');
                                    $error = publicErrorMessage('Voucher generation failed.');
                                    $failed = true;
                                    break;
                                }

                                if (!$inserted && !$failed) {
                                    $error = 'Could not generate a unique code. No vouchers were saved; please try again.';
                                    $failed = true;
                                }
                            }

                            $insertStmt->close();

                            if (!$failed) {
                                $codesJson = json_encode($createdCodes, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                                $batchVoucherCount = count($createdCodes);
                                $batchStmt = $conn->prepare("INSERT INTO voucher_batches (package_id, package_name, package_price, duration_minutes, voucher_count, codes_json, batch_type) VALUES (?, ?, ?, ?, ?, ?, 'generated')");
                                if (!is_string($codesJson) || !$batchStmt) {
                                    if ($batchStmt) {
                                        $batchStmt->close();
                                    }
                                    logDatabaseError($conn, 'Preparing voucher batch record');
                                    $error = publicErrorMessage('Unable to save the voucher batch.');
                                    $failed = true;
                                } else {
                                    $batchStmt->bind_param('isdiis', $packageId, $createdPackageName, $createdPackagePrice, $createdPackageDuration, $batchVoucherCount, $codesJson);
                                    if (!$batchStmt->execute()) {
                                        logDatabaseError($conn, 'Saving voucher batch record');
                                        $error = publicErrorMessage('Unable to save the voucher batch.');
                                        $failed = true;
                                    } else {
                                        $createdBatchId = (int)$conn->insert_id;
                                    }
                                    $batchStmt->close();
                                }
                            }

                            if ($failed) {
                                $conn->rollback();
                                $createdCodes = [];
                                $createdBatchId = 0;
                            } elseif (!$conn->commit()) {
                                logDatabaseError($conn, 'Committing bulk voucher generation');
                                $conn->rollback();
                                $createdCodes = [];
                                $createdBatchId = 0;
                                $error = publicErrorMessage('Voucher generation could not be saved.');
                            } else {
                                logAdminSecurityEvent(
                                    'VOUCHERS_BULK_CREATED',
                                    'Created ' . count($createdCodes) . ' manual vouchers for package ID ' . $packageId . '.'
                                );
                            }
                        }
                    }
                }
            }

            $packageStmt->close();
        }
    }
}
if ($createdBatchId > 0): ?>
<script>window.location.replace(<?= json_encode(appUrl('admin/dashboard.php?page=vouchers&batch_id=' . $createdBatchId), JSON_UNESCAPED_SLASHES) ?>);</script>
<?php endif; ?>

<style>
.voucher-bulk-page{max-width:980px;margin:0 auto;padding:5px 0 32px;color:#172033}
.voucher-bulk-header{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;margin-bottom:22px}
.voucher-bulk-header h1{margin:0 0 7px;font-size:26px;line-height:1.2;font-weight:750}
.voucher-bulk-header p{margin:0;color:#64748b;font-size:14px}
.voucher-bulk-card{background:#fff;border:1px solid #e5e7eb;border-radius:15px;box-shadow:0 4px 18px rgba(15,23,42,.045);overflow:hidden}
.voucher-bulk-card-head{padding:20px 24px;border-bottom:1px solid #edf0f4}
.voucher-bulk-card-head h2{margin:0;font-size:16px;font-weight:700}
.voucher-bulk-card-head p{margin:6px 0 0;color:#64748b;font-size:13px}
.voucher-bulk-form{padding:24px}
.voucher-bulk-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}
.voucher-bulk-field{display:flex;flex-direction:column;gap:8px}
.voucher-bulk-field label{font-size:13px;font-weight:650;color:#334155}
.voucher-bulk-field select,.voucher-bulk-field input{height:44px;width:100%;box-sizing:border-box;padding:0 12px;border:1px solid #d8e0e9;border-radius:9px;background:#fff;color:#111827;font:inherit}
.voucher-bulk-hint{font-size:12px;color:#64748b;line-height:1.5}
.voucher-bulk-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:22px;padding-top:18px;border-top:1px solid #edf0f4}
.voucher-bulk-btn-primary,.voucher-bulk-btn-secondary{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:42px;padding:0 15px;border-radius:9px;text-decoration:none;font-size:13px;font-weight:700;cursor:pointer}
.voucher-bulk-btn-primary{border:1px solid #2563eb;background:#2563eb;color:#fff}.voucher-bulk-btn-primary:hover{background:#1d4ed8;color:#fff}
.voucher-bulk-btn-secondary{border:1px solid #dbe2ea;background:#fff;color:#334155}
.voucher-bulk-alert{padding:13px 15px;margin:0 0 18px;border-radius:10px;font-size:14px}
.voucher-bulk-alert-error{background:#fef2f2;border:1px solid #fecaca;color:#991b1b}
.voucher-bulk-alert-success{background:#ecfdf5;border:1px solid #bbf7d0;color:#166534}
.voucher-bulk-result{margin-top:18px;padding:18px;border:1px solid #e5e7eb;border-radius:12px;background:#f8fafc}
.voucher-bulk-result-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px}
.voucher-bulk-result textarea{display:block;width:100%;min-height:180px;box-sizing:border-box;padding:12px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;color:#0f172a;font:14px/1.7 ui-monospace,SFMono-Regular,Consolas,monospace;resize:vertical}
@media(max-width:700px){.voucher-bulk-header{flex-direction:column}.voucher-bulk-grid{grid-template-columns:1fr}.voucher-bulk-form{padding:18px}.voucher-bulk-actions{flex-direction:column-reverse}.voucher-bulk-actions>*{width:100%;box-sizing:border-box}}
    .voucher-bulk-result-head { flex-wrap: wrap; }
.voucher-print-page { margin-top: 20px; }
.voucher-print-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
.voucher-print-card { overflow: hidden; border: 1.5px solid #475569; border-radius: 11px; background: #fff; text-align: center; color: #111827; break-inside: avoid; page-break-inside: avoid; }
.voucher-print-brand { padding: 8px 10px; background: #142b69; color: #fff; font-size: 13px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; }
.voucher-print-content { padding: 10px 12px 12px; }
.voucher-print-label { margin-bottom: 3px; color: #64748b; font-size: 11px; letter-spacing: 2px; }
.voucher-print-code { color: #111827; font-size: 20px; line-height: 1.25; font-weight: 800; letter-spacing: 4px; overflow-wrap: anywhere; }
.voucher-print-duration { margin-top: 3px; color: #475569; font-size: 13px; }
.voucher-print-price { margin-top: 3px; color: #111827; font-size: 15px; font-weight: 800; }
@media (max-width: 700px) { .voucher-print-grid { grid-template-columns: 1fr; } }
@media print {
    @page { size: A4 portrait; margin: 6mm; }
    body * { visibility: hidden !important; }
    #voucher-print-area, #voucher-print-area * { visibility: visible !important; }
    #voucher-print-area { position: absolute; left: 0; top: 0; width: 198mm; margin: 0 !important; padding: 0 !important; border: 0 !important; background: #fff !important; }
    .voucher-bulk-page { max-width: none; margin: 0; padding: 0; }
    .voucher-bulk-result { margin: 0; padding: 0; border: 0; border-radius: 0; background: #fff; }
    .voucher-bulk-result-head, #voucher-codes { display: none !important; }
    .voucher-print-page { width: 198mm; height: 285mm; margin: 0; padding: 0; overflow: hidden; box-sizing: border-box; break-after: page; page-break-after: always; }
    .voucher-print-page:last-child { break-after: auto; page-break-after: auto; }
    .voucher-print-grid { width: 198mm; height: 285mm; box-sizing: border-box; display: grid !important; grid-template-columns: repeat(2, minmax(0, 1fr)); grid-template-rows: repeat(11, minmax(0, 1fr)); gap: 1mm; margin: 0 !important; }
    .voucher-print-card { display: flex; flex-direction: column; justify-content: center; box-sizing: border-box; height: auto; min-height: 0; border-radius: 2mm; box-shadow: none; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .voucher-print-brand { padding: 1mm; font-size: 7pt; letter-spacing: .4mm; line-height: 1.1; }
    .voucher-print-content { padding: 1mm; line-height: 1.05; }
    .voucher-print-label { margin: 0; font-size: 6.5pt; line-height: 1.1; letter-spacing: .5mm; }
    .voucher-print-code { font-size: 13pt; line-height: 1.15; letter-spacing: 1.2mm; }
    .voucher-print-duration { margin-top: 1mm; font-size: 7pt; line-height: 1.1; }
    .voucher-print-price { margin-top: .5mm; font-size: 8pt; line-height: 1.1; }
}
</style>

<div class="voucher-bulk-page">
    <header class="voucher-bulk-header">
        <div>
            <h1><i class="fa-solid fa-layer-group"></i> Bulk generate vouchers</h1>
            <p>Generate a batch of unused manual vouchers for an active package.</p>
        </div>
        <a class="voucher-bulk-btn-secondary" href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>"><i class="fa-solid fa-arrow-left"></i> Back to vouchers</a>
    </header>

    <?php if ($error !== ''): ?>
        <div class="voucher-bulk-alert voucher-bulk-alert-error" role="alert"><i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?></div>
    <?php endif; ?>

    <section class="voucher-bulk-card">
        <div class="voucher-bulk-card-head">
            <h2><i class="fa-solid fa-ticket"></i> Batch details</h2>
            <p>Codes are generated securely and saved as unused manual vouchers.</p>
        </div>

        <?php if (!$packages): ?>
            <div class="voucher-bulk-form">
                <div class="voucher-bulk-alert voucher-bulk-alert-error">No active packages are available. Activate a package before generating vouchers.</div>
                <a class="voucher-bulk-btn-primary" href="<?= e(appUrl('admin/dashboard.php?page=packages')) ?>"><i class="fa-solid fa-box"></i> Manage packages</a>
            </div>
        <?php else: ?>
            <form class="voucher-bulk-form" method="post" action="<?= e(appUrl('admin/dashboard.php?page=vouchers&action=bulk')) ?>">
                <?= csrfField() ?>
                <div class="voucher-bulk-grid">
                    <div class="voucher-bulk-field">
                        <label for="bulk-package">Package</label>
                        <select id="bulk-package" name="package_id" required>
                            <option value="">Select an active package</option>
                            <?php foreach ($packages as $package): ?>
                                <option value="<?= (int)$package['id'] ?>" <?= $packageId === (int)$package['id'] ? 'selected' : '' ?>>
                                    <?= e((string)$package['name']) ?> — <?= e(formatMoney($package['price'])) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <span class="voucher-bulk-hint">Only currently active packages can be assigned to new vouchers.</span>
                    </div>
                    <div class="voucher-bulk-field">
                        <label for="bulk-quantity">Number of vouchers</label>
                        <input id="bulk-quantity" name="quantity" type="number" min="1" max="<?= $maximumQuantity ?>" step="1" required value="<?= e((string)$quantity) ?>">
                        <span class="voucher-bulk-hint">Choose from 1 to <?= number_format($maximumQuantity) ?> per batch.</span>
                    </div>
                </div>
                <div class="voucher-bulk-actions">
                    <a class="voucher-bulk-btn-secondary" href="<?= e(appUrl('admin/dashboard.php?page=vouchers')) ?>">Cancel</a>
                    <button class="voucher-bulk-btn-primary" type="submit"><i class="fa-solid fa-wand-magic-sparkles"></i> Generate vouchers</button>
                </div>
            </form>
        <?php endif; ?>
    </section>

    <?php if ($createdCodes): ?>
<?php $voucherPrintPages = array_chunk($createdCodes, 22); ?>
        <section id="voucher-print-area" class="voucher-bulk-result" aria-labelledby="voucher-bulk-results-title">
            <div class="voucher-bulk-result-head">
                <div>
                    <strong id="voucher-bulk-results-title"><?= number_format(count($createdCodes)) ?> vouchers created</strong>
                    <div class="voucher-bulk-hint">Package: <?= e($createdPackageName) ?>. Copy and store these codes securely.</div>
                </div>
                <a class="voucher-bulk-btn-secondary" href="<?= e(appUrl('admin/dashboard.php?page=vouchers&batch_id=' . $createdBatchId)) ?>"><i class="fa-solid fa-folder-open"></i> Open batch</a>
                <button class="voucher-bulk-btn-secondary" type="button" id="copy-voucher-codes"><i class="fa-regular fa-copy"></i> Copy codes</button>
                <button class="voucher-bulk-btn-secondary" type="button" onclick="window.print()"><i class="fa-solid fa-print"></i> Print vouchers</button>
            </div>
            <textarea id="voucher-codes" readonly aria-label="Generated voucher codes"><?= e(implode("\n", $createdCodes)) ?></textarea>
            <?php foreach ($voucherPrintPages as $pageIndex => $pageCodes): ?>
            <div class="voucher-print-page" aria-label="A4 print page <?= (int)$pageIndex + 1 ?>">
                <div class="voucher-print-grid" aria-label="Printable vouchers">
                <?php foreach ($pageCodes as $voucherCode): ?>
                    <article class="voucher-print-card">
                        <div class="voucher-print-brand">WiFi Voucher</div>
                        <div class="voucher-print-content">
                            <div class="voucher-print-label">VOUCHER</div>
                            <div class="voucher-print-code"><?= e((string)$voucherCode) ?></div>
                            <div class="voucher-print-duration"><?= e($createdPackageDurationLabel) ?></div>
                            <div class="voucher-print-price"><?= e(formatMoney($createdPackagePrice)) ?></div>
                        </div>
                    </article>
                <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </section>
        <script>
        (function () {
            const button = document.getElementById('copy-voucher-codes');
            const codes = document.getElementById('voucher-codes');
            if (!button || !codes) return;
            button.addEventListener('click', async function () {
                try {
                    await navigator.clipboard.writeText(codes.value);
                    button.innerHTML = '<i class="fa-solid fa-check"></i> Copied';
                } catch (error) {
                    codes.focus();
                    codes.select();
                    document.execCommand('copy');
                    button.innerHTML = '<i class="fa-solid fa-check"></i> Copied';
                }
            });
        }());
        </script>
    <?php endif; ?>
</div>