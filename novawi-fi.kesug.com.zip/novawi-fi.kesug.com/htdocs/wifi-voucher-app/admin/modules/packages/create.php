<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../config/app.php';
require_once __DIR__ . '/../../../config/security.php';
require_once __DIR__ . '/../../../includes/functions.php';
require_once __DIR__ . '/../../../includes/csrf.php';
require_once __DIR__ . '/../../includes/admin_auth.php';
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/functions.php';

requireAdminLogin();

if (!isset($conn) || !($conn instanceof mysqli)) {
    die('Database connection error.');
}

$error = '';

$name = '';
$price = '';
$durationAmount = '';
$durationUnit = 'hours';
$speedLimit = '';
$speedLimitEnabled = false;
$dataLimitValue = '';
$dataLimitUnit = 'MB';
$dataLimitMb = null;
$status = 'active';

/*
|--------------------------------------------------------------------------
| CREATE PACKAGE
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    requireAdminPostWithCsrf();

    /*
    |--------------------------------------------------------------------------
    | GET FORM VALUES
    |--------------------------------------------------------------------------
    */

    $name = trim((string)($_POST['name'] ?? ''));
    $price = trim((string)($_POST['price'] ?? ''));
    $durationAmount = trim((string)($_POST['duration_value'] ?? $_POST['duration_hours'] ?? ''));
    $durationUnit = trim((string)($_POST['duration_unit'] ?? 'hours'));
    $speedLimitEnabled = isset($_POST['speed_limit_enabled'])
        && (string)$_POST['speed_limit_enabled'] === '1';
    $speedLimit = $speedLimitEnabled
        ? trim((string)($_POST['speed_limit'] ?? ''))
        : '';
    $status = trim((string)($_POST['status'] ?? 'active'));
    $dataLimitValue = trim((string)($_POST['data_limit_value'] ?? ''));
    $dataLimitUnit = strtoupper(trim((string)($_POST['data_limit_unit'] ?? 'MB')));
    $dataLimitMb = wifiPackageDataLimitToMb($dataLimitValue, $dataLimitUnit);

    /*
    |--------------------------------------------------------------------------
    | CONVERT VALUES
    |--------------------------------------------------------------------------
    */

    $priceValue = is_numeric($price)
        ? (float)$price
        : -1;

    $durationValue = packageDurationToMinutes($durationAmount, $durationUnit) ?? 0;

    /*
    |--------------------------------------------------------------------------
    | VALIDATE
    |--------------------------------------------------------------------------
    */

    $errors = validatePackageData(
        $name,
        $priceValue,
        $durationValue,
        $speedLimit,
        $speedLimitEnabled,
        $status
    );

    if ($dataLimitValue !== '' && $dataLimitMb === null) {
        $errors[] = 'Enter a valid data allowance amount and unit.';
    }

    if (!empty($errors)) {

        $error = implode(' ', $errors);

    } else {

        /*
        |--------------------------------------------------------------------------
        | INSERT PACKAGE
        |--------------------------------------------------------------------------
        */

        $stmt = $conn->prepare("
            INSERT INTO packages
            (
                name,
                price,
                duration_minutes,
                speed_limit,
        data_limit_mb,
                status
            )
            VALUES (?, ?, ?, NULLIF(?, ''), ?, ?)
        ");

        if (!$stmt) {

            $error = 'Unable to prepare package creation request.';

        } else {

            $stmt->bind_param(
                'sdisis',
                $name,
                $priceValue,
                $durationValue,
                $speedLimit, $dataLimitMb,
                $status
            );

            if ($stmt->execute()) {

                $newPackageId = $stmt->insert_id;

                /*
                |--------------------------------------------------------------------------
                | SECURITY LOG
                |--------------------------------------------------------------------------
                */

                if (function_exists('logAdminSecurityEvent')) {

                    logAdminSecurityEvent(
                        'package_created',
                        'Created package ID: ' .
                        $newPackageId .
                        ', name: ' .
                        $name
                    );
                }

                $stmt->close();

                /*
                |--------------------------------------------------------------------------
                | REDIRECT
                |--------------------------------------------------------------------------
                |
                | This module is loaded inside dashboard.php after the
                | admin header/sidebar have already produced output.
                |
                | Therefore we use JavaScript instead of PHP header().
                |
                */

                $redirectUrl = appUrl(
                    'admin/dashboard.php?page=packages&created=1'
                );

                echo '<script>';
                echo 'window.location.href = ' .
                    json_encode($redirectUrl, JSON_UNESCAPED_SLASHES) .
                    ';';
                echo '</script>';

                exit;

            } else {

                $error =
                    'Failed to create package. Please try again.';

                $stmt->close();
            }
        }
    }
}
?>
<div class="package-form-page">
    <header class="package-page-heading">
        <div><h1><i class="fa-solid fa-box-open"></i> Create package</h1><p>Add a Wi-Fi voucher package to your catalog.</p></div>
        <a class="package-back-link" href="<?= e(appUrl('admin/dashboard.php?page=packages')) ?>"><i class="fa-solid fa-arrow-left"></i> Packages</a>
    </header>
    <?php if ($error !== ''): ?><div class="package-alert package-alert-error" role="alert"><i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?></div><?php endif; ?>
    <section class="package-panel">
        <div class="package-panel-heading"><h2><i class="fa-solid fa-sliders"></i> Package information</h2><p>Set the name, price, access duration, speed and availability.</p></div>
        <form class="package-form" method="post" action="<?= e(appUrl('admin/dashboard.php?page=packages&action=create')) ?>">
            <?= csrfField() ?>
            <div class="package-form-grid">
                <div class="package-field"><label for="package-name">Package name</label><input id="package-name" name="name" type="text" required value="<?= e($name) ?>" placeholder="e.g. Daily 5 Mbps"></div>
                <div class="package-field"><label for="package-price">Price</label><input id="package-price" name="price" type="number" min="0" step="0.01" required value="<?= e($price) ?>" placeholder="0.00"><span class="package-field-hint">Enter the amount customers pay for this package.</span></div>
                <div class="package-field">
                    <label for="package-duration">Duration</label>
                    <div class="package-duration-input" style="display:grid;grid-template-columns:minmax(0,1fr) minmax(110px,1fr);gap:10px">
                        <input id="package-duration" name="duration_value" type="number" min="0.000001" step="any" required value="<?= e($durationAmount) ?>" placeholder="1">
                        <select id="package-duration-unit" name="duration_unit" required aria-label="Duration unit">
                            <?php foreach (packageDurationUnits() as $unitValue => $unit): ?>
                                <option value="<?= e($unitValue) ?>" <?= $durationUnit === $unitValue ? 'selected' : '' ?>><?= e($unit['label']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <span class="package-field-hint">Choose the amount and unit. One month equals 30 days.</span>
                </div>
                <div class="package-field package-field-full package-speed-option">
                    <label class="package-speed-toggle" for="package-speed-enabled">
                        <input id="package-speed-enabled" name="speed_limit_enabled" type="checkbox" value="1" <?= $speedLimitEnabled ? 'checked' : '' ?>>
                        <span><strong>Enable speed limit</strong><small>Turn this off to sell the package without a speed cap.</small></span>
                    </label>
                </div>
                <div class="package-field package-field-full package-speed-field" id="package-speed-field" <?= $speedLimitEnabled ? '' : 'hidden' ?>>
                    <label for="package-speed">Speed limit</label>
                    <input id="package-speed" name="speed_limit" type="text" value="<?= e($speedLimit) ?>" placeholder="e.g. 5M" <?= $speedLimitEnabled ? 'required' : 'disabled' ?>>
                    <span class="package-field-hint">Use the speed format expected by your router.</span>
                </div>
                    <div class="package-field package-field-full"><label for="package-data-limit">Optional data allowance</label><div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(110px,1fr);gap:10px"><input id="package-data-limit" name="data_limit_value" type="number" min="0.01" step="any" value="<?= e($dataLimitValue) ?>" placeholder="e.g. 500"><select name="data_limit_unit" aria-label="Data allowance unit"><option value="MB" <?= $dataLimitUnit === 'MB' ? 'selected' : '' ?>>MB</option><option value="GB" <?= $dataLimitUnit === 'GB' ? 'selected' : '' ?>>GB</option></select></div><span class="package-field-hint">Optional. Leave blank for no data allowance.</span></div>
<div class="package-field package-field-full"><label for="package-status">Status</label><select id="package-status" name="status" required><?php foreach (packageStatuses() as $statusValue => $statusText): ?><option value="<?= e((string)$statusValue) ?>" <?= $status === (string)$statusValue ? 'selected' : '' ?>><?= e((string)$statusText) ?></option><?php endforeach; ?></select><span class="package-field-hint">Inactive packages cannot be selected for new vouchers.</span></div>
            </div>
            <div class="package-form-actions"><a class="package-button package-button-secondary" href="<?= e(appUrl('admin/dashboard.php?page=packages')) ?>">Cancel</a><button class="package-button package-button-primary" type="submit"><i class="fa-solid fa-check"></i> Create package</button></div>
        </form>
    </section>
</div>
<script>
(() => {
    const toggle = document.getElementById('package-speed-enabled');
    const field = document.getElementById('package-speed-field');
    const input = document.getElementById('package-speed');
    if (!toggle || !field || !input) return;
    const syncSpeedLimit = () => {
        field.hidden = !toggle.checked;
        input.disabled = !toggle.checked;
        input.required = toggle.checked;
    };
    toggle.addEventListener('change', syncSpeedLimit);
    syncSpeedLimit();
})();
</script>
