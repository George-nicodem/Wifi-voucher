<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| PACKAGES MODULE FUNCTIONS
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/../../../config/app.php';
require_once __DIR__ . '/../../../config/security.php';
require_once __DIR__ . '/../../../includes/functions.php';


/*
|--------------------------------------------------------------------------
| Package Statuses
|--------------------------------------------------------------------------
*/

function packageStatuses(): array
{
    return [
        'active'   => 'Active',
        'inactive' => 'Inactive',
    ];
}


/*
|--------------------------------------------------------------------------
| Status Label
|--------------------------------------------------------------------------
*/

function packageStatusLabel(string $status): string
{
    $statuses = packageStatuses();

    return $statuses[$status] ?? ucfirst($status);
}


/*
|--------------------------------------------------------------------------
| Format Duration
|--------------------------------------------------------------------------
*/

function formatPackageDuration(?int $minutes): string
{
    if ($minutes === null || $minutes <= 0) {
        return 'Unlimited';
    }

    if ($minutes < 60) {
        return $minutes . ' min';
    }

    $hours = intdiv($minutes, 60);
    $remainingMinutes = $minutes % 60;

    if ($remainingMinutes === 0) {
        return $hours . ' ' . ($hours === 1 ? 'hour' : 'hours');
    }

    return $hours . 'h ' . $remainingMinutes . 'min';
}


function packageDurationUnits(): array
{
    return [
        'minutes' => ['label' => 'Minutes', 'minutes' => 1],
        'hours' => ['label' => 'Hours', 'minutes' => 60],
        'days' => ['label' => 'Days', 'minutes' => 1440],
        'weeks' => ['label' => 'Weeks', 'minutes' => 10080],
        'months' => ['label' => 'Months', 'minutes' => 43200],
    ];
}

/* Store every selected duration in the existing duration_minutes column. */
function packageDurationToMinutes(string $value, string $unit): ?int
{
    $value = trim($value);
    $units = packageDurationUnits();
    if ($value === '' || !is_numeric($value) || !isset($units[$unit])) {
        return null;
    }
    $amount = (float)$value;
    $multiplier = (int)$units[$unit]['minutes'];
    $minutes = $amount * $multiplier;
    if (!is_finite($amount) || !is_finite($minutes) || $minutes < 1 || $minutes > 2147483647) {
        return null;
    }
    return (int)round($minutes);
}

/* Prefer exact whole units when opening an existing package for editing. */
function packageMinutesToDuration(?int $minutes): array
{
    if ($minutes === null || $minutes <= 0) {
        return ['value' => '', 'unit' => 'hours'];
    }
    $units = packageDurationUnits();
    foreach (['months', 'weeks', 'days', 'hours', 'minutes'] as $unit) {
        $multiplier = (int)$units[$unit]['minutes'];
        if ($minutes % $multiplier === 0) {
            return ['value' => (string)intdiv($minutes, $multiplier), 'unit' => $unit];
        }
    }
    return ['value' => (string)$minutes, 'unit' => 'minutes'];
}

/* Convert the admin's hour input to the existing database minute value. */
function packageHoursToMinutes(string $hours): ?int
{
    $hours = trim($hours);
    if ($hours === '' || !is_numeric($hours)) {
        return null;
    }

    $hoursValue = (float)$hours;
    if (!is_finite($hoursValue) || $hoursValue <= 0 || $hoursValue > (2147483647 / 60)) {
        return null;
    }

    $minutes = (int)round($hoursValue * 60);
    return $minutes > 0 ? $minutes : null;
}


/* Show the stored minutes as hours when loading the edit form. */
function packageMinutesToHours(?int $minutes): string
{
    if ($minutes === null || $minutes <= 0) {
        return '';
    }

    $hours = number_format($minutes / 60, 6, '.', '');
    return rtrim(rtrim($hours, '0'), '.');
}


/*
|--------------------------------------------------------------------------
| Package Price
|--------------------------------------------------------------------------
*/

function formatPackagePrice(float $price): string
{
    return number_format(
        $price,
        2,
        '.',
        ','
    ) . ' TZS';
}


/*
|--------------------------------------------------------------------------
| Count Vouchers Using Package
|--------------------------------------------------------------------------
*/

function packageUsageCount(mysqli $conn, int $packageId): ?int
{
    try {
        $stmt = $conn->prepare("
            SELECT COUNT(*) AS total
            FROM vouchers
            WHERE package_id = ?
        ");
    } catch (mysqli_sql_exception $exception) {
        return null;
    }

    if (!$stmt) {
        return null;
    }

    $stmt->bind_param('i', $packageId);

    if (!$stmt->execute()) {
        $stmt->close();
        return null;
    }

    $result = $stmt->get_result();
    if (!$result) {
        $stmt->close();
        return null;
    }

    $row = $result ? $result->fetch_assoc() : null;

    $stmt->close();

    if (!$row || !array_key_exists('total', $row)) {
        return null;
    }

    return (int)$row['total'];
}


/*
|--------------------------------------------------------------------------
| Check Whether Package Can Be Deleted
|--------------------------------------------------------------------------
*/

/* Count payment references, including pending payments not linked to a voucher. */
function packagePaymentUsageCount(mysqli $conn, int $packageId): ?int
{
    $stmt = null;
    try {
        $stmt = $conn->prepare('SELECT COUNT(*) AS total FROM payments WHERE package_id = ?');
        if (!$stmt) return null;
        $stmt->bind_param('i', $packageId);
        if (!$stmt->execute()) return null;
        $result = $stmt->get_result();
        if (!$result) return null;
        $row = $result->fetch_assoc();
        return $row && array_key_exists('total', $row) ? (int)$row['total'] : null;
    } catch (mysqli_sql_exception $exception) {
        return null;
    } finally {
        if ($stmt) $stmt->close();
    }
}

function packageCanBeDeleted(mysqli $conn, int $packageId): bool
{
    return packageUsageCount($conn, $packageId) === 0
        && packagePaymentUsageCount($conn, $packageId) === 0;
}


/*
|--------------------------------------------------------------------------
| Delete Package
|--------------------------------------------------------------------------
|
| Returns:
| true  = deleted
| false = could not be deleted / package is in use
|
*/

function deletePackage(mysqli $conn, int $packageId): bool
{
    if ($packageId <= 0) {
        return false;
    }

    /*
    |--------------------------------------------------------------------------
    | Never delete a package referenced by vouchers or payments
    |--------------------------------------------------------------------------
    */

    try {
        $stmt = $conn->prepare("
            DELETE FROM packages
            WHERE id = ?
              AND NOT EXISTS (
                  SELECT 1
                  FROM vouchers
                  WHERE vouchers.package_id = packages.id
              )
              AND NOT EXISTS (
                  SELECT 1
                  FROM payments
                  WHERE payments.package_id = packages.id
              )
            LIMIT 1
        ");
    } catch (mysqli_sql_exception $exception) {
        return false;
    }

    if (!$stmt) {
        return false;
    }

    $stmt->bind_param('i', $packageId);

    try {
        $success = $stmt->execute() && $stmt->affected_rows === 1;
    } catch (mysqli_sql_exception $exception) {
        $success = false;
    }

    $stmt->close();

    return $success;
}


/*
|--------------------------------------------------------------------------
| Package Status Badge
|--------------------------------------------------------------------------
*/

function packageStatusClass(string $status): string
{
    return match ($status) {

        'active' => 'package-status-active',

        'inactive' => 'package-status-inactive',

        default => 'package-status-inactive',
    };
}


/*
|--------------------------------------------------------------------------
| Validate Package Data
|--------------------------------------------------------------------------
*/

function validatePackageData(
    string $name,
    float $price,
    ?int $durationMinutes,
    ?string $speedLimit,
    bool $speedLimitEnabled,
    string $status
): array {

    $errors = [];

    /*
    |--------------------------------------------------------------------------
    | Name
    |--------------------------------------------------------------------------
    */

    $name = trim($name);

    if ($name === '') {

        $errors[] = 'Package name is required.';

    } elseif (mb_strlen($name) > 100) {

        $errors[] = 'Package name must not exceed 100 characters.';
    }


    /*
    |--------------------------------------------------------------------------
    | Price
    |--------------------------------------------------------------------------
    */

    if ($price < 0) {

        $errors[] = 'Package price cannot be negative.';
    }


    /*
    |--------------------------------------------------------------------------
    | Duration
    |--------------------------------------------------------------------------
    */

    if ($durationMinutes !== null && $durationMinutes < 1) {

        $errors[] = 'Duration must be at least 1 minute.';
    }


    /*
    |--------------------------------------------------------------------------
    | Speed Limit
    |--------------------------------------------------------------------------
    */

    if ($speedLimitEnabled) {

        $speedLimit = trim((string)$speedLimit);

        if ($speedLimit === '') {

            $errors[] = 'Enter a speed limit or turn the speed limit off.';

        } elseif (mb_strlen($speedLimit) > 30) {

            $errors[] = 'Speed limit must not exceed 30 characters.';
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Status
    |--------------------------------------------------------------------------
    */

    if (!array_key_exists($status, packageStatuses())) {

        $errors[] = 'Invalid package status.';
    }


    return $errors;
}
