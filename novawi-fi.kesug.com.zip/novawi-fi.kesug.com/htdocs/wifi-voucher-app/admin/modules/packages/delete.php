<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';

requireAdminLogin();

global $conn;

$error = '';
$success = '';
$package = null;
$voucherCount = null;
$paymentCount = null;
$lookupFailed = false;
$packageId = isPost()
    ? (postInt('package_id') ?? 0)
    : getInt('id', 0);

$loadPackage = static function (int $id) use ($conn, &$lookupFailed): ?array {
    $stmt = $conn->prepare("
        SELECT id, name, price, duration_minutes, speed_limit, status
        FROM packages
        WHERE id = ?
        LIMIT 1
    ");

    if (!$stmt) {
        $lookupFailed = true;
        return null;
    }

    $stmt->bind_param('i', $id);

    if (!$stmt->execute()) {
        $stmt->close();
        $lookupFailed = true;
        return null;
    }

    $result = $stmt->get_result();
    $row = $result ? $result->fetch_assoc() : null;
    $stmt->close();

    return $row ?: null;
};

if (isPost()) {
    requireAdminPost();
    requireCsrfToken();

    if ($packageId <= 0) {
        $error = 'The selected package is invalid.';
    } else {
        $package = $loadPackage($packageId);

        if ($lookupFailed) {
            $error = 'Could not load this package. Please try again.';
        } elseif (!$package) {
            $error = 'This package no longer exists.';
        } else {
            $voucherCount = packageUsageCount($conn, $packageId);
            $paymentCount = packagePaymentUsageCount($conn, $packageId);

            if ($voucherCount === null || $paymentCount === null) {
                $error = 'Could not check all voucher and payment references. No package was deleted.';
            } elseif ($voucherCount > 0) {
                $error = 'This package is assigned to ' . number_format($voucherCount) . ' voucher(s), so it cannot be deleted. Deactivate it from Edit to keep voucher history.';
            } elseif ($paymentCount > 0) {
                $error = 'This package has ' . number_format($paymentCount) . ' payment record(s), so it cannot be deleted. Deactivate it from Edit to preserve payment history and pending purchases.';
            } elseif (deletePackage($conn, $packageId)) {
                logAdminSecurityEvent(
                    'PACKAGE_DELETED',
                    'Deleted package ID #' . $packageId . ' (' . (string)$package['name'] . ').'
                );
                $success = 'Package “' . (string)$package['name'] . '” was deleted.';
                $package = null;
            } else {
                $error = 'The package could not be deleted. It may have become linked to a record; no linked voucher or payment data was removed.';
            }
        }
    }
} elseif ($packageId <= 0) {
    $error = 'The selected package is invalid.';
} else {
    $package = $loadPackage($packageId);

    if ($lookupFailed) {
        $error = 'Could not load this package. Please try again.';
    } elseif (!$package) {
        $error = 'This package no longer exists.';
    } else {
        $voucherCount = packageUsageCount($conn, $packageId);
        $paymentCount = packagePaymentUsageCount($conn, $packageId);

        if ($voucherCount === null || $paymentCount === null) {
            $error = 'Could not check all voucher and payment references. No package can be deleted until the checks succeed.';
        }
    }
}
?>

<div class="package-detail-page">
    <div class="package-page-heading">
        <div>
            <h1><i class="fa-solid fa-trash-can"></i> Delete package</h1>
            <p>Review the package and its voucher and payment references.</p>
        </div>
        <a class="package-back-link" href="<?= e(appUrl('admin/dashboard.php?page=packages')) ?>">
            <i class="fa-solid fa-arrow-left"></i> Back to packages
        </a>
    </div>

    <?php if ($error !== ''): ?>
        <div class="package-alert package-alert-error" role="alert">
            <i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?>
        </div>
    <?php endif; ?>

    <?php if ($success !== ''): ?>
        <div class="package-alert package-alert-success" role="status">
            <i class="fa-solid fa-circle-check"></i> <?= e($success) ?>
        </div>
        <a class="package-button package-button-primary" href="<?= e(appUrl('admin/dashboard.php?page=packages')) ?>">
            <i class="fa-solid fa-boxes-stacked"></i> Return to packages
        </a>
    <?php elseif ($package): ?>
        <section class="package-panel">
            <div class="package-panel-heading">
                <h2><?= e((string)$package['name']) ?></h2>
                <p>Package details and current voucher and payment references.</p>
            </div>

            <div class="package-detail-grid">
                <div class="package-detail-item">
                    <div class="package-detail-label">Price</div>
                    <div class="package-detail-value"><?= e(formatPackagePrice((float)$package['price'])) ?></div>
                </div>
                <div class="package-detail-item">
                    <div class="package-detail-label">Duration</div>
                    <div class="package-detail-value">
                        <?= e(formatPackageDuration($package['duration_minutes'] !== null ? (int)$package['duration_minutes'] : null)) ?>
                    </div>
                </div>
                <div class="package-detail-item">
                    <div class="package-detail-label">Speed</div>
                    <div class="package-detail-value"><?= e((string)($package['speed_limit'] ?: 'No speed limit')) ?></div>
                </div>
                <div class="package-detail-item">
                    <div class="package-detail-label">Status</div>
                    <div class="package-detail-value">
                        <span class="package-status <?= e(packageStatusClass((string)$package['status'])) ?>">
                            <?= e(packageStatusLabel((string)$package['status'])) ?>
                        </span>
                    </div>
                </div>
                <div class="package-detail-item">
                    <div class="package-detail-label">Vouchers using this package</div>
                    <div class="package-detail-value">
                        <?= $voucherCount === null ? 'Unable to verify' : number_format($voucherCount) ?>
                    </div>
                </div>
                <div class="package-detail-item">
                    <div class="package-detail-label">Payments using this package</div>
                    <div class="package-detail-value">
                        <?= $paymentCount === null ? 'Unable to verify' : number_format($paymentCount) ?>
                    </div>
                </div>
            </div>

            <?php if ($voucherCount === 0 && $paymentCount === 0 && $error === ''): ?>
                <div class="package-delete-notice">
                    This package has no voucher or payment references.
                </div>
                <form
                    class="package-inline-actions"
                    method="post"
                    action="<?= e(appUrl('admin/dashboard.php?page=packages&action=delete&id=' . $packageId)) ?>"
                    onsubmit="return confirm('Permanently delete this package? This cannot be undone.');"
                >
                    <?= csrfField() ?>
                    <input type="hidden" name="package_id" value="<?= $packageId ?>">
                    <a class="package-button package-button-secondary" href="<?= e(appUrl('admin/dashboard.php?page=packages')) ?>">Cancel</a>
                    <button class="package-button package-button-danger" type="submit">
                        <i class="fa-solid fa-trash-can"></i> Delete package
                    </button>
                </form>
            <?php elseif (($voucherCount !== null && $voucherCount > 0) || ($paymentCount !== null && $paymentCount > 0)): ?>
                <div class="package-delete-notice package-delete-notice-warning">
                    Keep this package so vouchers, payment history and pending purchases retain their package link. Deactivate it from Edit to stop new purchases and voucher creation.
                </div>
                <div class="package-inline-actions">
                    <a class="package-button package-button-primary" href="<?= e(appUrl('admin/dashboard.php?page=packages&action=edit&id=' . $packageId)) ?>">
                        <i class="fa-solid fa-pen"></i> Edit / deactivate package
                    </a>
                    <a class="package-button package-button-secondary" href="<?= e(appUrl('admin/dashboard.php?page=packages')) ?>">Cancel</a>
                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>
</div>
