<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';

requireAdminLogin();

global $conn;
require_once __DIR__ . '/../../../includes/package_data_limits.php';
if (!isset($conn) || !($conn instanceof mysqli) || !wifiPackageEnsureDataLimitColumn($conn)) {
    die('Unable to prepare package data limits.');
}
$packageCssUrl = appUrl('admin/modules/packages/packages.css?v=4');
echo '<link rel="stylesheet" href="' . e($packageCssUrl) . '">';

/*
|--------------------------------------------------------------------------
| ROUTING
|--------------------------------------------------------------------------
*/

$action = getString('action', '');

if ($action === 'create') {
    require __DIR__ . '/create.php';
    return;
}

if ($action === 'view') {
    require __DIR__ . '/view.php';
    return;
}

if ($action === 'edit') {
    require __DIR__ . '/edit.php';
    return;
}

if ($action === 'delete') {
    require __DIR__ . '/delete.php';
    return;
}


/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/

$search = trim(getString('search', ''));
$status = trim(getString('status', ''));

$allowedStatuses = ['active', 'inactive'];

if (!in_array($status, $allowedStatuses, true)) {
    $status = '';
}


/*
|--------------------------------------------------------------------------
| PAGINATION
|--------------------------------------------------------------------------
*/

$perPage = 20;

$currentPage = getInt('packages_page', 1);

if ($currentPage < 1) {
    $currentPage = 1;
}


/*
|--------------------------------------------------------------------------
| BUILD WHERE
|--------------------------------------------------------------------------
*/

$where = [];
$searchValue = '';

if ($search !== '') {

    $where[] = "
        (
            p.name LIKE ?
            OR p.speed_limit LIKE ?
        )
    ";

    $searchValue = '%' . $search . '%';
}

if ($status !== '') {
    $where[] = "p.status = ?";
}

$whereSql = '';

if (!empty($where)) {
    $whereSql = 'WHERE ' . implode(' AND ', $where);
}


/*
|--------------------------------------------------------------------------
| COUNT PACKAGES
|--------------------------------------------------------------------------
*/

$totalPackages = 0;

$countSql = "
    SELECT COUNT(*) AS total
    FROM packages p
    $whereSql
";

$countStmt = $conn->prepare($countSql);

if (!$countStmt) {
    die('Package count query failed.');
}

if ($search !== '' && $status !== '') {

    $countStmt->bind_param(
        'sss',
        $searchValue,
        $searchValue,
        $status
    );

} elseif ($search !== '') {

    $countStmt->bind_param(
        'ss',
        $searchValue,
        $searchValue
    );

} elseif ($status !== '') {

    $countStmt->bind_param(
        's',
        $status
    );
}

$countStmt->execute();

$countResult = $countStmt->get_result();

if ($countResult) {

    $countRow = $countResult->fetch_assoc();

    $totalPackages = (int)($countRow['total'] ?? 0);
}

$countStmt->close();


/*
|--------------------------------------------------------------------------
| CALCULATE PAGES
|--------------------------------------------------------------------------
*/

$totalPages = max(
    1,
    (int)ceil($totalPackages / $perPage)
);

if ($currentPage > $totalPages) {
    $currentPage = $totalPages;
}

$offset = (
    $currentPage - 1
) * $perPage;


/*
|--------------------------------------------------------------------------
| GET PACKAGES
|--------------------------------------------------------------------------
*/

$packages = [];

$listSql = "
    SELECT
        p.id,
        p.name,
        p.price,
        p.duration_minutes,
        p.speed_limit,
        p.data_limit_mb,
        p.status,
        p.created_at,
        COUNT(v.id) AS voucher_count

    FROM packages p

    LEFT JOIN vouchers v
        ON v.package_id = p.id

    $whereSql

    GROUP BY
        p.id,
        p.name,
        p.price,
        p.duration_minutes,
        p.speed_limit,
            p.data_limit_mb,
        p.status,
        p.created_at

    ORDER BY p.id DESC

    LIMIT ? OFFSET ?
";

$listStmt = $conn->prepare($listSql);

if (!$listStmt) {
    die('Package list query failed.');
}


/*
|--------------------------------------------------------------------------
| BIND LIST PARAMETERS
|--------------------------------------------------------------------------
*/

if ($search !== '' && $status !== '') {

    $listStmt->bind_param(
        'sssii',
        $searchValue,
        $searchValue,
        $status,
        $perPage,
        $offset
    );

} elseif ($search !== '') {

    $listStmt->bind_param(
        'ssii',
        $searchValue,
        $searchValue,
        $perPage,
        $offset
    );

} elseif ($status !== '') {

    $listStmt->bind_param(
        'sii',
        $status,
        $perPage,
        $offset
    );

} else {

    $listStmt->bind_param(
        'ii',
        $perPage,
        $offset
    );
}

$listStmt->execute();

$listResult = $listStmt->get_result();

if ($listResult) {

    while ($row = $listResult->fetch_assoc()) {
        $packages[] = $row;
    }
}

$listStmt->close();


/*
|--------------------------------------------------------------------------
| PACKAGE STATISTICS
|--------------------------------------------------------------------------
*/

$packageStats = [
    'total'    => 0,
    'active'   => 0,
    'inactive' => 0,
];

$statsResult = $conn->query("
    SELECT
        COUNT(*) AS total,
        SUM(status = 'active') AS active,
        SUM(status = 'inactive') AS inactive
    FROM packages
");

if ($statsResult) {

    $statsRow = $statsResult->fetch_assoc();

    $packageStats['total'] =
        (int)($statsRow['total'] ?? 0);

    $packageStats['active'] =
        (int)($statsRow['active'] ?? 0);

    $packageStats['inactive'] =
        (int)($statsRow['inactive'] ?? 0);
}

?>
<div class="packages-page">

    <div class="packages-header">

        <div class="packages-title">

            <h2>Packages</h2>

            <p>
                Manage WiFi service packages and pricing.
            </p>

        </div>

        <a
            href="dashboard.php?page=packages&action=create"
            class="package-primary-btn"
        >
            <i class="fa-solid fa-plus"></i>
            Create Package
        </a>

    </div>


    <div class="package-stats">

        <div class="package-stat">

            <div class="package-stat-label">
                Total Packages
            </div>

            <div class="package-stat-value">
                <?= number_format($packageStats['total']) ?>
            </div>

        </div>

        <div class="package-stat">

            <div class="package-stat-label">
                Active Packages
            </div>

            <div class="package-stat-value">
                <?= number_format($packageStats['active']) ?>
            </div>

        </div>

        <div class="package-stat">

            <div class="package-stat-label">
                Inactive Packages
            </div>

            <div class="package-stat-value">
                <?= number_format($packageStats['inactive']) ?>
            </div>

        </div>

    </div>


    <form
        method="get"
        action="dashboard.php"
        class="package-filter"
    >

        <input
            type="hidden"
            name="page"
            value="packages"
        >

        <input
            type="search"
            name="search"
            value="<?= e($search) ?>"
            placeholder="Search package..."
        >

        <select name="status">

            <option value="">
                All Status
            </option>

            <option
                value="active"
                <?= $status === 'active' ? 'selected' : '' ?>
            >
                Active
            </option>

            <option
                value="inactive"
                <?= $status === 'inactive' ? 'selected' : '' ?>
            >
                Inactive
            </option>

        </select>

        <button type="submit">
            <i class="fa-solid fa-filter"></i>
            Filter
        </button>

        <a
            href="dashboard.php?page=packages"
            class="package-reset"
        >
            Reset
        </a>

    </form>


    <div class="package-table-card">

        <?php if (empty($packages)): ?>

            <div class="package-empty">

                <div class="package-empty-icon">
                    <i class="fa-solid fa-box-open"></i>
                </div>

                <h3>No packages found</h3>

                <p>
                    There are currently no packages in the database.
                </p>

            </div>

        <?php else: ?>

            <div class="package-table-wrap">

                <table class="package-table">

                    <thead>
                        <tr>
                            <th>Package</th>
                            <th>Price</th>
                            <th>Duration</th>
                            <th>Speed</th>
                            <th>Vouchers</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php foreach ($packages as $package): ?>

                        <tr>

                            <td>
                                <div class="package-name">
                                    <?= e((string)$package['name']) ?>
                                </div>
                            </td>

                            <td>
                                <div class="package-price">
                                    <?= e(
                                        formatPackagePrice(
                                            (float)$package['price']
                                        )
                                    ) ?>
                                </div>
                            </td>

                            <td>
                                <?= e(
                                    formatPackageDuration(
                                        $package['duration_minutes'] !== null
                                            ? (int)$package['duration_minutes']
                                            : null
                                    )
                                ) ?>
                            </td>

                            <td>
                                <?= e(
                                    $package['speed_limit']
                                        ?: 'No speed limit'
                                ) ?>
                            </td>

                            <td>
                                <?= number_format(
                                    (int)$package['voucher_count']
                                ) ?>
                            </td>

                            <td>

                                <span class="package-status <?= e(
                                    packageStatusClass(
                                        (string)$package['status']
                                    )
                                ) ?>">

                                    <?= e(
                                        packageStatusLabel(
                                            (string)$package['status']
                                        )
                                    ) ?>

                                </span>

                            </td>

                            <td>

                                <div class="package-actions">

                                    <a
                                        class="package-action"
                                        href="dashboard.php?page=packages&action=view&id=<?= (int)$package['id'] ?>"
                                        title="View"
                                    >
                                        <i class="fa-solid fa-eye"></i>
                                    </a>

                                    <a
                                        class="package-action"
                                        href="dashboard.php?page=packages&action=edit&id=<?= (int)$package['id'] ?>"
                                        title="Edit"
                                    >
                                        <i class="fa-solid fa-pen"></i>
                                    </a>

                                    <a
                                        class="package-action package-action-delete"
                                        href="dashboard.php?page=packages&action=delete&id=<?= (int)$package['id'] ?>"
                                        title="Delete package"
                                        aria-label="Delete <?= e((string)$package['name']) ?>"
                                    >
                                        <i class="fa-solid fa-trash-can"></i>
                                    </a>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>


            <?php if ($totalPages > 1): ?>

                <div class="package-pagination">

                    <div class="package-page-info">
                        Page <?= number_format($currentPage) ?>
                        of <?= number_format($totalPages) ?>
                    </div>

                    <div class="package-page-links">

                        <?php if ($currentPage > 1): ?>

                            <a
                                class="package-page-link"
                                href="dashboard.php?page=packages&search=<?= urlencode($search) ?>&status=<?= urlencode($status) ?>&packages_page=<?= $currentPage - 1 ?>"
                            >
                                <i class="fa-solid fa-chevron-left"></i>
                            </a>

                        <?php endif; ?>


                        <?php

                        $startPage = max(
                            1,
                            $currentPage - 2
                        );

                        $endPage = min(
                            $totalPages,
                            $currentPage + 2
                        );

                        for (
                            $p = $startPage;
                            $p <= $endPage;
                            $p++
                        ):
                        ?>

                            <a
                                class="package-page-link <?= $p === $currentPage ? 'active' : '' ?>"
                                href="dashboard.php?page=packages&search=<?= urlencode($search) ?>&status=<?= urlencode($status) ?>&packages_page=<?= $p ?>"
                            >
                                <?= $p ?>
                            </a>

                        <?php endfor; ?>


                        <?php if ($currentPage < $totalPages): ?>

                            <a
                                class="package-page-link"
                                href="dashboard.php?page=packages&search=<?= urlencode($search) ?>&status=<?= urlencode($status) ?>&packages_page=<?= $currentPage + 1 ?>"
                            >
                                <i class="fa-solid fa-chevron-right"></i>
                            </a>

                        <?php endif; ?>

                    </div>

                </div>

            <?php endif; ?>

        <?php endif; ?>

    </div>

</div>
