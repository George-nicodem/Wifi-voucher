<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../config/app.php';
require_once __DIR__ . '/../../../config/security.php';
require_once __DIR__ . '/../../../includes/functions.php';
require_once __DIR__ . '/../../../includes/csrf.php';
require_once __DIR__ . '/../../includes/admin_auth.php';
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/functions.php';

requireAdminLogin();

if (!isset($conn) || !($conn instanceof mysqli)) {
    die('Database connection error.');
}

/*
|--------------------------------------------------------------------------
| GET PACKAGE ID
|--------------------------------------------------------------------------
*/

$packageId = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$packageId || $packageId <= 0) {
    echo '
        <div class="package-alert package-alert-error">
            <i class="fa-solid fa-triangle-exclamation"></i>
            Invalid package ID.
        </div>
    ';
    return;
}

/*
|--------------------------------------------------------------------------
| GET PACKAGE
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        id,
        name,
        price,
        duration_minutes,
        speed_limit,
        data_limit_mb,
        status,
        created_at
    FROM packages
    WHERE id = ?
    LIMIT 1
");

if (!$stmt) {
    echo '
        <div class="package-alert package-alert-error">
            Unable to prepare package request.
        </div>
    ';
    return;
}

$stmt->bind_param('i', $packageId);
$stmt->execute();

$result = $stmt->get_result();
$package = $result ? $result->fetch_assoc() : null;

$stmt->close();

/*
|--------------------------------------------------------------------------
| PACKAGE NOT FOUND
|--------------------------------------------------------------------------
*/

if (!$package) {

    echo '
        <div class="package-alert package-alert-error">
            <i class="fa-solid fa-circle-info"></i>
            Package not found.
        </div>

        <a
            href="' . e(appUrl('admin/dashboard.php?page=packages')) . '"
            class="btn btn-secondary"
        >
            <i class="bi bi-arrow-left me-1"></i>
            Back to Packages
        </a>
    ';

    return;
}

/*
|--------------------------------------------------------------------------
| VOUCHER USAGE
|--------------------------------------------------------------------------
*/

$voucherCount = packageUsageCount(
    $conn,
    (int)$package['id']
);

/*
|--------------------------------------------------------------------------
| FORMAT VALUES
|--------------------------------------------------------------------------
*/

$packagePrice = (float)$package['price'];

$duration = formatPackageDuration(
    (int)$package['duration_minutes']
);

$status = (string)$package['status'];

$statusLabel = packageStatusLabel($status);

$statusClass = packageStatusClass($status);

$createdAt = !empty($package['created_at'])
    ? date(
        'd M Y, H:i',
        strtotime((string)$package['created_at'])
    )
    : '-';

?>
<div class="package-detail-page">
    <header class="package-page-heading">
        <div><h1><i class="fa-solid fa-box"></i> Package details</h1><p>Review package settings and voucher usage.</p></div>
        <a class="package-back-link" href="<?= e(appUrl('admin/dashboard.php?page=packages')) ?>"><i class="fa-solid fa-arrow-left"></i> Packages</a>
    </header>
    <section class="package-panel">
        <div class="package-panel-heading"><h2><i class="fa-solid fa-circle-info"></i> Package information</h2><p>Package settings and current status.</p></div>
        <div class="package-detail-grid">
            <div class="package-detail-item"><div class="package-detail-label">Package name</div><div class="package-detail-value"><?= e((string)$package['name']) ?></div></div>
            <div class="package-detail-item"><div class="package-detail-label">Price</div><div class="package-detail-value"><?= e(formatPackagePrice($packagePrice)) ?></div></div>
            <div class="package-detail-item"><div class="package-detail-label">Duration</div><div class="package-detail-value"><?= e($duration) ?></div></div>
                <div class="package-detail-item"><div class="package-detail-label">Data allowance</div><div class="package-detail-value"><?= e(wifiPackageDataLimitLabel(isset($package['data_limit_mb']) && $package['data_limit_mb'] !== null ? (int)$package['data_limit_mb'] : null)) ?></div></div>
<div class="package-detail-item"><div class="package-detail-label">Speed limit</div><div class="package-detail-value"><?= !empty($package['speed_limit']) ? e((string)$package['speed_limit']) : 'No speed limit' ?></div></div>
            <div class="package-detail-item"><div class="package-detail-label">Status</div><div class="package-detail-value"><span class="package-status <?= e($statusClass) ?>"><?= e($statusLabel) ?></span></div></div>
            <div class="package-detail-item"><div class="package-detail-label">Created</div><div class="package-detail-value"><?= e($createdAt) ?></div></div>
            <div class="package-detail-item"><div class="package-detail-label">Vouchers using package</div><div class="package-detail-value"><?= number_format($voucherCount) ?></div></div>
        </div>
        <div class="package-inline-actions"><a class="package-button package-button-primary" href="<?= e(appUrl('admin/dashboard.php?page=packages&action=edit&id=' . (int)$package['id'])) ?>"><i class="fa-solid fa-pen"></i> Edit package</a><a class="package-button package-button-secondary" href="<?= e(appUrl('admin/dashboard.php?page=packages')) ?>">Back to packages</a></div>
    </section>
</div>
