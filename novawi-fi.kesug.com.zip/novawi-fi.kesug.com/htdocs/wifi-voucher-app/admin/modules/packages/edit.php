<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../config/app.php';
require_once __DIR__ . '/../../../config/security.php';
require_once __DIR__ . '/../../../includes/functions.php';
require_once __DIR__ . '/../../../includes/csrf.php';
require_once __DIR__ . '/../../includes/admin_auth.php';
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/functions.php';

requireAdminLogin();

if (!isset($conn) || !($conn instanceof mysqli)) {
    die('Database connection error.');
}

$packageId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$packageId || $packageId <= 0) {
    echo '<div class="package-alert package-alert-error" role="alert"><i class="fa-solid fa-triangle-exclamation"></i> Invalid package ID.</div>';
    return;
}

$stmt = $conn->prepare('SELECT id, name, price, duration_minutes, speed_limit, data_limit_mb, status FROM packages WHERE id = ? LIMIT 1');
if (!$stmt) {
    echo '<div class="package-alert package-alert-error" role="alert">Unable to prepare package request.</div>';
    return;
}
$stmt->bind_param('i', $packageId);
$stmt->execute();
$result = $stmt->get_result();
$package = $result ? $result->fetch_assoc() : null;
$stmt->close();

if (!$package) {
    echo '<div class="package-alert package-alert-error" role="alert">Package not found.</div>';
    echo '<a class="package-back-link" href="' . e(appUrl('admin/dashboard.php?page=packages')) . '"><i class="fa-solid fa-arrow-left"></i> Back to packages</a>';
    return;
}

$error = '';
$name = (string)$package['name'];
$price = (string)$package['price'];
$durationParts = packageMinutesToDuration($package['duration_minutes'] !== null ? (int)$package['duration_minutes'] : null);
$durationAmount = $durationParts['value'];
$durationUnit = $durationParts['unit'];
$speedLimit = (string)($package['speed_limit'] ?? '');
$speedLimitEnabled = trim($speedLimit) !== '';
$status = (string)$package['status'];
$dataLimitMb = isset($package['data_limit_mb']) && $package['data_limit_mb'] !== null ? (int)$package['data_limit_mb'] : null;
$dataLimitUnit = $dataLimitMb !== null && $dataLimitMb > 0 && $dataLimitMb % 1024 === 0 ? 'GB' : 'MB';
$dataLimitValue = $dataLimitMb === null ? '' : (string)($dataLimitUnit === 'GB' ? $dataLimitMb / 1024 : $dataLimitMb);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireAdminPostWithCsrf();

    $name = trim((string)($_POST['name'] ?? ''));
    $price = trim((string)($_POST['price'] ?? ''));
    $durationAmount = trim((string)($_POST['duration_value'] ?? $_POST['duration_hours'] ?? ''));
    $durationUnit = trim((string)($_POST['duration_unit'] ?? 'hours'));
    $speedLimitEnabled = isset($_POST['speed_limit_enabled'])
        && (string)$_POST['speed_limit_enabled'] === '1';
    $speedLimit = $speedLimitEnabled
        ? trim((string)($_POST['speed_limit'] ?? ''))
        : '';
    $status = trim((string)($_POST['status'] ?? ''));
$dataLimitValue = trim((string)($_POST['data_limit_value'] ?? ''));
$dataLimitUnit = strtoupper(trim((string)($_POST['data_limit_unit'] ?? 'MB')));
$dataLimitMb = wifiPackageDataLimitToMb($dataLimitValue, $dataLimitUnit);

    $priceValue = is_numeric($price) ? (float)$price : -1;
    $durationValue = packageDurationToMinutes($durationAmount, $durationUnit) ?? 0;

    $errors = validatePackageData(
        $name,
        $priceValue,
        $durationValue,
        $speedLimit,
        $speedLimitEnabled,
        $status
    );

    if ($dataLimitValue !== '' && $dataLimitMb === null) {
    $errors[] = 'Enter a valid data allowance amount and unit.';
}
if ($errors !== []) {
        $error = implode(' ', $errors);
    } else {
        $update = $conn->prepare("
            UPDATE packages
            SET name = ?, price = ?, duration_minutes = ?, speed_limit = NULLIF(?, ''), data_limit_mb = ?, status = ?
            WHERE id = ?
            LIMIT 1
        ");

        if (!$update) {
            $error = 'Unable to prepare package update request.';
        } else {
            $update->bind_param(
                'sdisisi',
                $name,
                $priceValue,
                $durationValue,
                $speedLimit, $dataLimitMb,
                $status,
                $packageId
            );

            if ($update->execute()) {
                if (function_exists('logAdminSecurityEvent')) {
                    logAdminSecurityEvent(
                        'package_updated',
                        'Updated package ID: ' . $packageId . ', name: ' . $name
                    );
                }
                $update->close();
                $redirectUrl = appUrl('admin/dashboard.php?page=packages&updated=1');
                echo '<script>window.location.href = ' . json_encode($redirectUrl, JSON_UNESCAPED_SLASHES) . ';</script>';
                exit;
            }

            $error = 'Failed to update package. Please try again.';
            $update->close();
        }
    }
}
?>

<div class="package-form-page">
    <header class="package-page-heading">
        <div>
            <h1><i class="fa-solid fa-pen-to-square"></i> Edit package</h1>
            <p>Update the package settings and availability.</p>
        </div>
        <a class="package-back-link" href="<?= e(appUrl('admin/dashboard.php?page=packages&action=view&id=' . (int)$package['id'])) ?>"><i class="fa-solid fa-arrow-left"></i> Package details</a>
    </header>

    <?php if ($error !== ''): ?>
        <div class="package-alert package-alert-error" role="alert"><i class="fa-solid fa-circle-exclamation"></i> <?= e($error) ?></div>
    <?php endif; ?>

    <section class="package-panel">
        <div class="package-panel-heading">
            <h2><i class="fa-solid fa-sliders"></i> Package information</h2>
            <p>Change the name, price, access duration, speed or status.</p>
        </div>
        <form class="package-form" method="post" action="<?= e(appUrl('admin/dashboard.php?page=packages&action=edit&id=' . (int)$package['id'])) ?>">
            <?= csrfField() ?>
            <div class="package-form-grid">
                <div class="package-field">
                    <label for="package-name">Package name</label>
                    <input id="package-name" name="name" type="text" required value="<?= e($name) ?>" placeholder="e.g. Daily 5 Mbps">
                </div>
                <div class="package-field">
                    <label for="package-price">Price</label>
                    <input id="package-price" name="price" type="number" min="0" step="0.01" required value="<?= e($price) ?>" placeholder="0.00">
                </div>
                <div class="package-field">
                    <label for="package-duration">Duration</label>
                    <div class="package-duration-input" style="display:grid;grid-template-columns:minmax(0,1fr) minmax(110px,1fr);gap:10px">
                        <input id="package-duration" name="duration_value" type="number" min="0.000001" step="any" required value="<?= e($durationAmount) ?>" placeholder="1">
                        <select id="package-duration-unit" name="duration_unit" required aria-label="Duration unit">
                            <?php foreach (packageDurationUnits() as $unitValue => $unit): ?>
                                <option value="<?= e($unitValue) ?>" <?= $durationUnit === $unitValue ? 'selected' : '' ?>><?= e($unit['label']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <span class="package-field-hint">Choose the amount and unit. One month equals 30 days.</span>
                </div>
                <div class="package-field package-field-full package-speed-option">
                    <label class="package-speed-toggle" for="package-speed-enabled">
                        <input id="package-speed-enabled" name="speed_limit_enabled" type="checkbox" value="1" <?= $speedLimitEnabled ? 'checked' : '' ?>>
                        <span><strong>Enable speed limit</strong><small>Turn this off to sell the package without a speed cap.</small></span>
                    </label>
                </div>
                <div class="package-field package-field-full package-speed-field" id="package-speed-field" <?= $speedLimitEnabled ? '' : 'hidden' ?>>
                    <label for="package-speed">Speed limit</label>
                    <input id="package-speed" name="speed_limit" type="text" value="<?= e($speedLimit) ?>" placeholder="e.g. 5M" <?= $speedLimitEnabled ? 'required' : 'disabled' ?>>
                    <span class="package-field-hint">Use the speed format expected by your router.</span>
                </div>
                    <div class="package-field package-field-full"><label for="package-data-limit">Optional data allowance</label><div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(110px,1fr);gap:10px"><input id="package-data-limit" name="data_limit_value" type="number" min="0.01" step="any" value="<?= e($dataLimitValue) ?>" placeholder="e.g. 500"><select name="data_limit_unit" aria-label="Data allowance unit"><option value="MB" <?= $dataLimitUnit === 'MB' ? 'selected' : '' ?>>MB</option><option value="GB" <?= $dataLimitUnit === 'GB' ? 'selected' : '' ?>>GB</option></select></div><span class="package-field-hint">Optional. Leave blank for no data allowance.</span></div>
<div class="package-field package-field-full">
                    <label for="package-status">Status</label>
                    <select id="package-status" name="status" required>
                        <?php foreach (packageStatuses() as $statusValue => $statusText): ?>
                            <option value="<?= e((string)$statusValue) ?>" <?= $status === (string)$statusValue ? 'selected' : '' ?>><?= e((string)$statusText) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="package-form-actions">
                <a class="package-button package-button-secondary" href="<?= e(appUrl('admin/dashboard.php?page=packages')) ?>">Cancel</a>
                <button class="package-button package-button-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save changes</button>
            </div>
        </form>
    </section>
</div>
<script>
(() => {
    const toggle = document.getElementById('package-speed-enabled');
    const field = document.getElementById('package-speed-field');
    const input = document.getElementById('package-speed');
    if (!toggle || !field || !input) return;
    const syncSpeedLimit = () => {
        field.hidden = !toggle.checked;
        input.disabled = !toggle.checked;
        input.required = toggle.checked;
    };
    toggle.addEventListener('change', syncSpeedLimit);
    syncSpeedLimit();
})();
</script>
