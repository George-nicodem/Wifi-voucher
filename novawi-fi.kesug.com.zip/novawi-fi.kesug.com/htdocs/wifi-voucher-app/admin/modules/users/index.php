<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/admin_auth.php';
requireAdminLogin();

global $conn;

$cssUrl = appUrl('admin/modules/users/users.css?v=5');
$errors = [];
$success = '';
$search = trim(getString('search', ''));
$search = function_exists('mb_substr') ? mb_substr($search, 0, 80) : substr($search, 0, 80);
$users = [];
$requests = [];
$stats = ['total' => 0, 'active' => 0, 'pending' => 0, 'disabled' => 0];
$adminSchema = $conn->query('SELECT id, username, email, password_hash, full_name, role, status FROM admin_users LIMIT 0');
$requestSchema = $conn->query('SELECT id, email, full_name, password_hash, status, created_at, reviewed_at, reviewed_by_admin_id FROM admin_account_requests LIMIT 0');
$schemaReady = $adminSchema !== false && $requestSchema !== false;
$activeStatus = 'active';

function wifiAllocateAdminUsername(mysqli $conn): ?string
{
    $lookup = $conn->prepare('SELECT id FROM admin_users WHERE username = ? LIMIT 1');
    if (!$lookup) {
        return null;
    }

    try {
        for ($attempt = 0; $attempt < 8; $attempt++) {
            $username = 'a' . bin2hex(random_bytes(6));
            $lookup->bind_param('s', $username);
            if (!$lookup->execute()) {
                $lookup->close();
                return null;
            }
            $result = $lookup->get_result();
            if (!$result || $result->num_rows === 0) {
                $lookup->close();
                return $username;
            }
        }
    } catch (Throwable $exception) {
        appLog('Could not generate a unique administrator username', ['error' => $exception->getMessage()]);
    }

    $lookup->close();
    return null;
}

function wifiSetAdminStatus(mysqli $conn, int $adminId, string $requestedStatus): ?string
{
    $candidates = $requestedStatus === 'active'
        ? ['active']
        : ['disabled', 'inactive', 'suspended', 'blocked'];

    foreach ($candidates as $candidate) {
        if (!$conn->begin_transaction()) {
            return null;
        }
        $firstAdminId = wifiFindFirstAdminId($conn, true);
        if ($firstAdminId === null || ($requestedStatus === 'disabled' && $adminId === $firstAdminId)) {
            $conn->rollback();
            return null;
        }
        $update = $conn->prepare('UPDATE admin_users SET status = ? WHERE id = ?');
        if (!$update) {
            $conn->rollback();
            return null;
        }
        $update->bind_param('si', $candidate, $adminId);
        $executed = $update->execute();
        $hasWarnings = $update->warning_count > 0;
        $update->close();
        if ($executed && !$hasWarnings) {
            $conn->commit();
            return $candidate;
        }
        $conn->rollback();
    }

    return null;
}

function wifiFindFirstAdminId(mysqli $conn, bool $lock = false): ?int
{
    try {
        $sql = 'SELECT id FROM admin_users ORDER BY id ASC LIMIT 1' . ($lock ? ' FOR UPDATE' : '');
        $result = $conn->query($sql);
        if (!$result) {
            return null;
        }
        $row = $result->fetch_assoc() ?: null;
        $result->free();
        return $row ? (int)$row['id'] : null;
    } catch (Throwable $exception) {
        appLog('Could not identify the permanent administrator account', ['error' => $exception->getMessage()]);
        return null;
    }
}

function wifiRemoveAdminAccount(mysqli $conn, int $adminId, int $currentAdminId): array
{
    if ($adminId <= 0 || $currentAdminId <= 0) {
        return ['ok' => false, 'message' => 'The administrator account is invalid.'];
    }
    if ($adminId === $currentAdminId) {
        return ['ok' => false, 'message' => 'You cannot remove the administrator account you are currently using.'];
    }

    try {
        if (!$conn->begin_transaction()) {
            throw new RuntimeException('Could not start administrator removal transaction.');
        }

        $firstAdminId = wifiFindFirstAdminId($conn, true);
        if ($firstAdminId === null) {
            throw new RuntimeException('Could not verify the permanent administrator account.');
        }
        if ($adminId === $firstAdminId) {
            $conn->rollback();
            return ['ok' => false, 'message' => 'The first administrator account is permanent and cannot be removed.'];
        }

        $lookup = $conn->prepare('SELECT id, role, status FROM admin_users WHERE id = ? FOR UPDATE');
        if (!$lookup) {
            throw new RuntimeException('Could not prepare administrator removal lookup.');
        }
        $lookup->bind_param('i', $adminId);
        if (!$lookup->execute()) {
            $lookup->close();
            throw new RuntimeException('Could not load the administrator account for removal.');
        }
        $result = $lookup->get_result();
        $target = $result ? ($result->fetch_assoc() ?: null) : null;
        $lookup->close();

        if (!$target) {
            $conn->rollback();
            return ['ok' => false, 'message' => 'The administrator account could not be found.'];
        }

        if (strtolower((string)$target['status']) === 'active') {
            $activeAdmins = $conn->prepare("SELECT id FROM admin_users WHERE role = ? AND status = 'active' FOR UPDATE");
            if (!$activeAdmins) {
                throw new RuntimeException('Could not prepare active administrator check.');
            }
            $role = (string)$target['role'];
            $activeAdmins->bind_param('s', $role);
            if (!$activeAdmins->execute()) {
                $activeAdmins->close();
                throw new RuntimeException('Could not check active administrators before removal.');
            }
            $activeResult = $activeAdmins->get_result();
            $activeCount = $activeResult ? $activeResult->num_rows : 0;
            $activeAdmins->close();

            if ($activeCount <= 1) {
                $conn->rollback();
                return ['ok' => false, 'message' => 'You cannot remove the only active administrator in this role.'];
            }
        }

        $removeCodes = $conn->prepare('DELETE FROM admin_login_codes WHERE admin_id = ?');
        if ($removeCodes) {
            $removeCodes->bind_param('i', $adminId);
            if (!$removeCodes->execute()) {
                $removeCodes->close();
                throw new RuntimeException('Could not remove administrator sign-in codes.');
            }
            $removeCodes->close();
        }

        $clearReviewer = $conn->prepare('UPDATE admin_account_requests SET reviewed_by_admin_id = NULL WHERE reviewed_by_admin_id = ?');
        if (!$clearReviewer) {
            throw new RuntimeException('Could not update reviewed administrator requests.');
        }
        $clearReviewer->bind_param('i', $adminId);
        if (!$clearReviewer->execute()) {
            $clearReviewer->close();
            throw new RuntimeException('Could not update reviewed administrator requests.');
        }
        $clearReviewer->close();

        $delete = $conn->prepare('DELETE FROM admin_users WHERE id = ?');
        if (!$delete) {
            throw new RuntimeException('Could not prepare administrator account removal.');
        }
        $delete->bind_param('i', $adminId);
        if (!$delete->execute() || $delete->affected_rows !== 1) {
            $delete->close();
            throw new RuntimeException('Could not remove the administrator account.');
        }
        $delete->close();

        if (!$conn->commit()) {
            throw new RuntimeException('Could not commit administrator account removal.');
        }

        logAdminSecurityEvent('ADMIN_USER_REMOVED', 'Removed admin user ID #' . $adminId . '.');
        return ['ok' => true, 'message' => 'The administrator account was removed.'];
    } catch (Throwable $exception) {
        $conn->rollback();
        appLog('Administrator account removal failed', ['error' => $exception->getMessage()]);
        return ['ok' => false, 'message' => 'The administrator account could not be removed right now. Please try again.'];
    }
}

function wifiApproveAdminAccountRequest(mysqli $conn, int $requestId, int $reviewerId, string $role): array
{
    try {
        if (!$conn->begin_transaction()) {
            throw new RuntimeException('Could not start account approval transaction.');
        }

        $requestLookup = $conn->prepare("SELECT id, email, full_name, password_hash, status
            FROM admin_account_requests WHERE id = ? FOR UPDATE");
        if (!$requestLookup) {
            throw new RuntimeException('Could not prepare account request lookup.');
        }
        $requestLookup->bind_param('i', $requestId);
        if (!$requestLookup->execute()) {
            $requestLookup->close();
            throw new RuntimeException('Could not load account request.');
        }
        $requestResult = $requestLookup->get_result();
        $request = $requestResult ? ($requestResult->fetch_assoc() ?: null) : null;
        $requestLookup->close();

        if (!$request || (string)$request['status'] !== 'pending') {
            $conn->rollback();
            return ['ok' => false, 'message' => 'This request does not exist or has already been handled.'];
        }

        $email = (string)$request['email'];
        $duplicate = $conn->prepare('SELECT id FROM admin_users WHERE email = ? OR username = ? LIMIT 1');
        if (!$duplicate) {
            throw new RuntimeException('Could not prepare duplicate administrator check.');
        }
        $duplicate->bind_param('ss', $email, $email);
        if (!$duplicate->execute()) {
            $duplicate->close();
            throw new RuntimeException('Could not check for an existing administrator.');
        }
        $duplicateResult = $duplicate->get_result();
        $alreadyExists = $duplicateResult && $duplicateResult->num_rows > 0;
        $duplicate->close();
        if ($alreadyExists) {
            $conn->rollback();
            return ['ok' => false, 'message' => 'This email address is already used by an administrator account.'];
        }

        $username = wifiAllocateAdminUsername($conn);
        if ($username === null) {
            throw new RuntimeException('Could not allocate a unique administrator username.');
        }
        $status = 'active';
        $insert = $conn->prepare('INSERT INTO admin_users (username, email, password_hash, full_name, role, status) VALUES (?, ?, ?, ?, ?, ?)');
        if (!$insert) {
            throw new RuntimeException('Could not prepare administrator account creation.');
        }
        $passwordHash = (string)$request['password_hash'];
        $fullName = (string)$request['full_name'];
        $insert->bind_param('ssssss', $username, $email, $passwordHash, $fullName, $role, $status);
        if (!$insert->execute()) {
            $insert->close();
            throw new RuntimeException('Could not create the approved administrator account.');
        }
        $adminId = (int)$insert->insert_id;
        $insert->close();

        $review = $conn->prepare("UPDATE admin_account_requests
            SET status = 'approved', password_hash = '', reviewed_at = CURRENT_TIMESTAMP, reviewed_by_admin_id = ?
            WHERE id = ? AND status = 'pending'");
        if (!$review) {
            throw new RuntimeException('Could not prepare account request approval.');
        }
        $review->bind_param('ii', $reviewerId, $requestId);
        if (!$review->execute() || $review->affected_rows !== 1) {
            $review->close();
            throw new RuntimeException('Could not mark the account request approved.');
        }
        $review->close();
        $conn->commit();

        logAdminSecurityEvent('ADMIN_USER_CREATED', 'Approved public admin account request #' . $requestId . ' as admin user #' . $adminId . '.');
        return ['ok' => true, 'message' => 'The request has been approved and the account is now active.'];
    } catch (Throwable $exception) {
        $conn->rollback();
        appLog('Administrator account approval failed', ['error' => $exception->getMessage()]);
        return ['ok' => false, 'message' => 'The account could not be approved right now. Please try again.'];
    }
}

$firstAdminId = $schemaReady ? wifiFindFirstAdminId($conn) : null;

if (isPost()) {
    requireAdminPost();
    requireCsrfToken();

    if (!$schemaReady) {
        $errors[] = 'The admin_users table is missing fields required for system sign-in.';
    } else {
        $formAction = postString('form_action', '');

        if ($formAction === 'create_admin') {
            $email = strtolower(trim(postString('email', '')));
            $fullName = trim(postString('full_name', ''));
            $password = $_POST['password'] ?? '';
            $passwordConfirm = $_POST['password_confirm'] ?? '';
            $password = is_string($password) ? $password : '';
            $passwordConfirm = is_string($passwordConfirm) ? $passwordConfirm : '';
            $newRole = currentAdminRole();

            if (strlen($email) > 190 || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
                $errors[] = 'Enter a valid administrator email address.';
            }
            $fullNameLength = function_exists('mb_strlen') ? mb_strlen($fullName) : strlen($fullName);
            if ($fullName === '' || $fullNameLength > 100) {
                $errors[] = 'Enter a full name with no more than 100 characters.';
            }
            $passwordLength = function_exists('mb_strlen') ? mb_strlen($password) : strlen($password);
            if ($passwordLength < 12 || strlen($password) > 1024) {
                $errors[] = 'The password must be at least 12 characters long.';
            }
            if (!hash_equals($password, $passwordConfirm)) {
                $errors[] = 'The passwords do not match.';
            }
            if (!$errors) {
                $usernameStmt = $conn->prepare('SELECT id FROM admin_users WHERE email = ? OR username = ? LIMIT 1');
                if (!$usernameStmt) {
                    logDatabaseError($conn, 'Preparing admin username check');
                    $errors[] = 'The username could not be checked right now.';
                } else {
                    $usernameStmt->bind_param('ss', $email, $email);
                    if (!$usernameStmt->execute()) {
                        logDatabaseError($conn, 'Checking admin username');
                        $errors[] = 'The username could not be checked right now.';
                    } else {
                        $usernameResult = $usernameStmt->get_result();
                        if ($usernameResult && $usernameResult->num_rows > 0) {
                            $errors[] = 'That username is already in use. Choose another.';
                        }
                    }
                    $usernameStmt->close();
                }
            }

            if (!$errors) {
                $username = wifiAllocateAdminUsername($conn);
                if ($username === null) {
                    $errors[] = 'The administrator username could not be created. Please try again.';
                }
            }

            if (!$errors) {
                $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                if (!is_string($passwordHash) || $passwordHash === '') {
                    $errors[] = 'The password could not be securely hashed.';
                } else {
                    $insertStmt = $conn->prepare('INSERT INTO admin_users (username, email, password_hash, full_name, role, status) VALUES (?, ?, ?, ?, ?, ?)');
                    if (!$insertStmt) {
                        logDatabaseError($conn, 'Preparing admin user creation');
                        $errors[] = 'The administrator account could not be added right now.';
                    } else {
                        $insertStmt->bind_param('ssssss', $username, $email, $passwordHash, $fullName, $newRole, $activeStatus);
                        if (!$insertStmt->execute()) {
                            logDatabaseError($conn, 'Creating admin user');
                            $errors[] = 'The administrator account could not be added. Make sure the username is not already in use.';
                        } else {
                            $createdId = (int)$insertStmt->insert_id;
                            $success = 'The administrator account was added.';
                            logAdminSecurityEvent('ADMIN_USER_CREATED', 'Created admin user ID #' . $createdId . '.');
                        }
                        $insertStmt->close();
                    }
                }
            }
        } elseif ($formAction === 'review_request') {
            $requestId = postInt('request_id', 0) ?? 0;
            $decision = postString('decision', '');
            $reviewerId = currentAdminId() ?? 0;

            if ($requestId <= 0 || !in_array($decision, ['approve', 'reject'], true)) {
                $errors[] = 'The administrator request is invalid.';
            } elseif ($decision === 'approve') {
                $review = wifiApproveAdminAccountRequest($conn, $requestId, $reviewerId, currentAdminRole());
                if (!empty($review['ok'])) {
                    $success = (string)$review['message'];
                } else {
                    $errors[] = (string)$review['message'];
                }
            } else {
                $reject = $conn->prepare("UPDATE admin_account_requests
                    SET status = 'rejected', password_hash = '', reviewed_at = CURRENT_TIMESTAMP, reviewed_by_admin_id = ?
                    WHERE id = ? AND status = 'pending'");
                if (!$reject) {
                    logDatabaseError($conn, 'Preparing admin request rejection');
                    $errors[] = 'The request could not be rejected right now.';
                } else {
                    $reject->bind_param('ii', $reviewerId, $requestId);
                    if (!$reject->execute()) {
                        logDatabaseError($conn, 'Rejecting admin account request');
                        $errors[] = 'The request could not be rejected right now.';
                    } elseif ($reject->affected_rows !== 1) {
                        $errors[] = 'This request does not exist or has already been handled.';
                    } else {
                        $success = 'The request was rejected.';
                        logAdminSecurityEvent('ADMIN_USER_REQUEST_REJECTED', 'Rejected public admin account request #' . $requestId . '.');
                    }
                    $reject->close();
                }
            }
        } elseif ($formAction === 'remove_admin') {
            $targetId = postInt('user_id', 0) ?? 0;
            $removal = wifiRemoveAdminAccount($conn, $targetId, currentAdminId() ?? 0);
            if (!empty($removal['ok'])) {
                $success = (string)$removal['message'];
            } else {
                $errors[] = (string)$removal['message'];
            }
        } elseif ($formAction === 'change_status') {
            $targetId = postInt('user_id', 0) ?? 0;
            $requestedStatus = postString('status', '');
            $currentAdmin = currentAdminId();

            if ($targetId <= 0 || !in_array($requestedStatus, ['active', 'disabled'], true)) {
                $errors[] = 'The administrator status change request is invalid.';
            } elseif ($currentAdmin !== null && $targetId === $currentAdmin) {
                $errors[] = 'You cannot disable the account you are currently using.';
            } else {
                $findStmt = $conn->prepare('SELECT id, role, status FROM admin_users WHERE id = ? LIMIT 1');
                if (!$findStmt) {
                    logDatabaseError($conn, 'Preparing admin user status lookup');
                    $errors[] = 'The administrator account could not be found right now.';
                } else {
                    $findStmt->bind_param('i', $targetId);
                    if (!$findStmt->execute()) {
                        logDatabaseError($conn, 'Loading admin user status');
                        $errors[] = 'The administrator account could not be found right now.';
                        $target = null;
                    } else {
                        $targetResult = $findStmt->get_result();
                        $target = $targetResult ? ($targetResult->fetch_assoc() ?: null) : null;
                    }
                    $findStmt->close();

                    if (!$errors && !$target) {
                        $errors[] = 'The administrator account could not be found.';
                    }
                    if (!$errors && $target && $requestedStatus === 'disabled' && $firstAdminId === null) {
                        $errors[] = 'The permanent administrator account could not be verified. Try again.';
                    } elseif (!$errors && $target && $requestedStatus === 'disabled' && $targetId === $firstAdminId) {
                        $errors[] = 'The first administrator account is permanent and cannot be disabled.';
                    }
                    if (!$errors && $target) {
                        $targetStatus = strtolower((string)$target['status']);
                        if ($requestedStatus === 'disabled' && $targetStatus === 'active') {
                            $countStmt = $conn->prepare("SELECT COUNT(*) AS active_count FROM admin_users WHERE role = ? AND status = 'active'");
                            if (!$countStmt) {
                                logDatabaseError($conn, 'Preparing active admin count');
                                $errors[] = 'The administrator status could not be checked. Please try again.';
                            } else {
                                $targetRole = (string)$target['role'];
                                $countStmt->bind_param('s', $targetRole);
                                if (!$countStmt->execute()) {
                                    logDatabaseError($conn, 'Counting active admins');
                                    $errors[] = 'The administrator status could not be checked. Please try again.';
                                } else {
                                    $countResult = $countStmt->get_result();
                                    $activeCount = $countResult ? (int)(($countResult->fetch_assoc()['active_count'] ?? 0)) : 0;
                                    if ($activeCount <= 1) {
                                        $errors[] = 'You cannot disable the only active administrator in this role.';
                                    }
                                }
                                $countStmt->close();
                            }
                        }
                    }

                    if (!$errors && $target) {
                        $newStatus = wifiSetAdminStatus($conn, $targetId, $requestedStatus);
                        if ($newStatus === null) {
                            $errors[] = 'The administrator status could not be changed. Make sure the database allows active or disabled statuses.';
                        } else {
                            $success = $newStatus === $activeStatus ? 'The administrator account was enabled.' : 'The administrator account was disabled.';
                            logAdminSecurityEvent('ADMIN_USER_STATUS_CHANGED', 'Changed admin user ID #' . $targetId . ' status to ' . $newStatus . '.');
                        }
                    }
                }
            }
        } else {
            $errors[] = 'The administrator users request was not recognized.';
        }
    }
}

$firstAdminId = $schemaReady ? wifiFindFirstAdminId($conn) : null;

if ($schemaReady) {
    $statsResult = $conn->query("SELECT COUNT(*) AS total,
        COALESCE(SUM(status = 'active'), 0) AS active,
        COALESCE(SUM(status IS NULL OR status <> 'active'), 0) AS disabled
        FROM admin_users");
    if ($statsResult) {
        $statsRow = $statsResult->fetch_assoc() ?: [];
        foreach (array_keys($stats) as $key) {
            $stats[$key] = (int)($statsRow[$key] ?? 0);
        }
    }
    $pendingResult = $conn->query("SELECT COUNT(*) AS pending FROM admin_account_requests WHERE status = 'pending'");
    if ($pendingResult) {
        $stats['pending'] = (int)(($pendingResult->fetch_assoc()['pending'] ?? 0));
    }

    $listStmt = $conn->prepare("SELECT id, username, email, full_name, role, status
        FROM admin_users
        WHERE (? = '' OR email LIKE ? OR username LIKE ? OR full_name LIKE ?)
        ORDER BY id DESC LIMIT 100");
    if (!$listStmt) {
        logDatabaseError($conn, 'Preparing admin users list');
        $errors[] = 'The administrator user list could not be loaded.';
    } else {
        $searchLike = '%' . $search . '%';
        $listStmt->bind_param('ssss', $search, $searchLike, $searchLike, $searchLike);
        if (!$listStmt->execute()) {
            logDatabaseError($conn, 'Loading admin users list');
            $errors[] = 'The administrator user list could not be loaded.';
        } else {
            $usersResult = $listStmt->get_result();
            if ($usersResult) {
                while ($user = $usersResult->fetch_assoc()) {
                    $users[] = $user;
                }
            }
        }
        $listStmt->close();
    }

    $requestStmt = $conn->prepare("SELECT id, email, full_name, created_at
        FROM admin_account_requests
        WHERE status = 'pending' AND (? = '' OR email LIKE ? OR full_name LIKE ?)
        ORDER BY created_at ASC, id ASC LIMIT 100");
    if (!$requestStmt) {
        logDatabaseError($conn, 'Preparing pending admin requests list');
        $errors[] = 'Administrator requests could not be loaded.';
    } else {
        $searchLike = '%' . $search . '%';
        $requestStmt->bind_param('sss', $search, $searchLike, $searchLike);
        if (!$requestStmt->execute()) {
            logDatabaseError($conn, 'Loading pending admin requests');
            $errors[] = 'Administrator requests could not be loaded.';
        } else {
            $requestResult = $requestStmt->get_result();
            if ($requestResult) {
                while ($request = $requestResult->fetch_assoc()) {
                    $requests[] = $request;
                }
            }
        }
        $requestStmt->close();
    }
}

$adminRoleForNewUser = currentAdminRole();
echo '<link rel="stylesheet" href="' . e($cssUrl) . '">';
?>

<div class="admin-users-page">
    <header class="admin-users-header"><div><div class="admin-users-eyebrow">Account Management</div><h1>Admin Users</h1><p>Approve new administrator requests and manage system sign-in accounts.</p></div><a class="admin-users-back" href="<?= e(appUrl('admin/dashboard.php?page=dashboard')) ?>"><i class="fa-solid fa-arrow-left"></i> Dashboard</a></header>

    <?php foreach (array_unique($errors) as $error): ?><div class="admin-users-alert" role="alert"><i class="fa-solid fa-circle-exclamation"></i><span><?= e($error) ?></span></div><?php endforeach; ?>
    <?php if ($success !== ''): ?><div class="admin-users-success" role="status"><i class="fa-solid fa-circle-check"></i><span><?= e($success) ?></span></div><?php endif; ?>
    <?php if ($schemaReady && $firstAdminId === null): ?><div class="admin-users-alert" role="alert"><i class="fa-solid fa-circle-exclamation"></i><span>The permanent administrator account could not be verified. Account removal and disabling are unavailable until it can be verified.</span></div><?php endif; ?>

    <?php if (!$schemaReady): ?>
        <section class="admin-users-setup"><i class="fa-solid fa-database"></i><h2>The administrator users schema is incomplete</h2><p>Run <code>admin/database/admin_accounts.sql</code> to create secure storage for sign-in codes and administrator requests.</p></section>
    <?php else: ?>
        <section class="admin-users-stats"><article><span class="admin-users-stat-icon"><i class="fa-solid fa-users"></i></span><div><small>Total accounts</small><strong><?= number_format($stats['total']) ?></strong></div></article><article><span class="admin-users-stat-icon is-pending"><i class="fa-solid fa-user-clock"></i></span><div><small>Pending approval</small><strong><?= number_format($stats['pending']) ?></strong></div></article><article><span class="admin-users-stat-icon is-active"><i class="fa-solid fa-user-check"></i></span><div><small>Active</small><strong><?= number_format($stats['active']) ?></strong></div></article><article><span class="admin-users-stat-icon is-disabled"><i class="fa-solid fa-user-lock"></i></span><div><small>Disabled</small><strong><?= number_format($stats['disabled']) ?></strong></div></article></section>

        <section class="admin-users-panel admin-users-requests">
            <div class="admin-users-directory-head"><div><h2>New Administrator Requests</h2><p>Approve accounts before users can sign in.</p></div><span class="admin-users-count"><?= number_format(count($requests)) ?> pending</span></div>
            <?php if ($requests): ?>
                <div class="admin-users-table-wrap"><table class="admin-users-table"><thead><tr><th>Name</th><th>Email</th><th>Request date</th><th>Actions</th></tr></thead><tbody>
                    <?php foreach ($requests as $request): ?>
                        <?php $requestedAt = strtotime((string)$request['created_at']); ?>
                        <tr>
                            <td><strong><?= e((string)$request['full_name']) ?></strong></td>
                            <td><?= e((string)$request['email']) ?></td>
                            <td><?= $requestedAt ? e(date('d M Y, H:i', $requestedAt)) : '—' ?></td>
                            <td class="admin-users-actions">
                                <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=users')) ?>" onsubmit="return confirm('Approve this administrator account?');"><?= csrfField() ?><input type="hidden" name="form_action" value="review_request"><input type="hidden" name="request_id" value="<?= (int)$request['id'] ?>"><input type="hidden" name="decision" value="approve"><button class="is-enable" type="submit">Approve</button></form>
                                <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=users')) ?>" onsubmit="return confirm('Reject this administrator request?');"><?= csrfField() ?><input type="hidden" name="form_action" value="review_request"><input type="hidden" name="request_id" value="<?= (int)$request['id'] ?>"><input type="hidden" name="decision" value="reject"><button class="is-disable" type="submit">Reject</button></form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody></table></div>
            <?php else: ?>
                <div class="admin-users-empty"><i class="fa-solid fa-user-check"></i><h3>No pending requests</h3><p>New requests will appear here.</p></div>
            <?php endif; ?>
        </section>

        <div class="admin-users-grid">
            <section class="admin-users-panel admin-users-create">
                <header><span><i class="fa-solid fa-user-plus"></i></span><div><h2>Add Administrator</h2><p>This account will be activated automatically with your role: <strong><?= e($adminRoleForNewUser) ?></strong>.</p></div></header>
                <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=users')) ?>" autocomplete="off">
                    <?= csrfField() ?><input type="hidden" name="form_action" value="create_admin">
                    <label><span>Administrator email</span><input name="email" type="email" maxlength="190" autocomplete="email" required placeholder="admin@example.com"></label>
                    <label><span>Full name</span><input name="full_name" maxlength="100" autocomplete="name" required placeholder="Administrator name"></label>
                    <label><span>Password</span><input name="password" type="password" minlength="12" maxlength="1024" autocomplete="new-password" required><small>At least 12 characters.</small></label>
                    <label><span>Confirm password</span><input name="password_confirm" type="password" minlength="12" maxlength="1024" autocomplete="new-password" required></label>
                    <button type="submit"><i class="fa-solid fa-user-plus"></i> Add Administrator user</button>
                </form>
                <p class="admin-users-security-note"><i class="fa-solid fa-shield-halved"></i> Passwords are stored as hashes and are never shown in this list.</p>
            </section>

            <section class="admin-users-panel admin-users-directory">
                <div class="admin-users-directory-head"><div><h2>Administrator Accounts</h2><p>The 100 most recent administrator accounts.</p></div><span class="admin-users-count"><?= number_format($stats['total']) ?> accounts</span></div>
                <form class="admin-users-search" method="get" action="<?= e(appUrl('admin/dashboard.php')) ?>"><input type="hidden" name="page" value="users"><label><i class="fa-solid fa-magnifying-glass"></i><input type="search" name="search" maxlength="80" value="<?= e($search) ?>" placeholder="Search email or name"></label><button type="submit">Search</button><?php if ($search !== ''): ?><a href="<?= e(appUrl('admin/dashboard.php?page=users')) ?>">Clear</a><?php endif; ?></form>
                <?php if ($users): ?>
                    <div class="admin-users-table-wrap"><table class="admin-users-table"><thead><tr><th>Admin</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead><tbody>
                        <?php foreach ($users as $user): ?>
                            <?php $status = strtolower((string)$user['status']); $isActive = $status === 'active'; $isPending = $status === 'pending'; $isSelf = currentAdminId() !== null && (int)$user['id'] === currentAdminId(); $isFirstAdmin = $firstAdminId !== null && (int)$user['id'] === $firstAdminId; $canManageAdmin = $firstAdminId !== null && !$isSelf && !$isFirstAdmin; ?>
                            <tr><td><strong><?= e((string)($user['full_name'] ?: $user['email'])) ?></strong><small><?= e((string)$user['email']) ?><?= $isSelf ? ' · You' : '' ?></small></td><td><span class="admin-users-role"><?= e((string)$user['role']) ?></span></td><td><span class="admin-users-status <?= $isPending ? 'is-pending' : ($isActive ? 'is-active' : 'is-disabled') ?>"><?= $isPending ? 'Pending' : ($isActive ? 'Active' : 'Disabled') ?></span></td><td class="admin-users-actions"><?php if ($isFirstAdmin): ?><span class="admin-users-permanent"><i class="fa-solid fa-shield-halved"></i> Permanent</span><?php if (!$isActive): ?><form method="post" action="<?= e(appUrl('admin/dashboard.php?page=users' . ($search !== '' ? '&search=' . rawurlencode($search) : ''))) ?>" onsubmit="return confirm('Enable the permanent administrator account?');"><?= csrfField() ?><input type="hidden" name="form_action" value="change_status"><input type="hidden" name="user_id" value="<?= (int)$user['id'] ?>"><input type="hidden" name="status" value="active"><button class="is-enable" type="submit">Enable</button></form><?php endif; ?><?php elseif ($canManageAdmin): ?><?php if ($isPending): ?><form method="post" action="<?= e(appUrl('admin/dashboard.php?page=users' . ($search !== '' ? '&search=' . rawurlencode($search) : ''))) ?>" onsubmit="return confirm('Approve this administrator account?');"><?= csrfField() ?><input type="hidden" name="form_action" value="change_status"><input type="hidden" name="user_id" value="<?= (int)$user['id'] ?>"><input type="hidden" name="status" value="active"><button class="is-enable" type="submit">Approve</button></form><form method="post" action="<?= e(appUrl('admin/dashboard.php?page=users' . ($search !== '' ? '&search=' . rawurlencode($search) : ''))) ?>" onsubmit="return confirm('Reject this administrator request?');"><?= csrfField() ?><input type="hidden" name="form_action" value="change_status"><input type="hidden" name="user_id" value="<?= (int)$user['id'] ?>"><input type="hidden" name="status" value="disabled"><button class="is-disable" type="submit">Reject</button></form><?php else: ?><form method="post" action="<?= e(appUrl('admin/dashboard.php?page=users' . ($search !== '' ? '&search=' . rawurlencode($search) : ''))) ?>" onsubmit="return confirm('<?= $isActive ? 'Disable' : 'Enable' ?> this administrator account?');"><?= csrfField() ?><input type="hidden" name="form_action" value="change_status"><input type="hidden" name="user_id" value="<?= (int)$user['id'] ?>"><input type="hidden" name="status" value="<?= $isActive ? 'disabled' : 'active' ?>"><button class="<?= $isActive ? 'is-disable' : 'is-enable' ?>" type="submit"><?= $isActive ? 'Disable' : 'Enable' ?></button></form><?php endif; ?><form method="post" action="<?= e(appUrl('admin/dashboard.php?page=users' . ($search !== '' ? '&search=' . rawurlencode($search) : ''))) ?>" onsubmit="return confirm('Remove this administrator account permanently? They will lose access immediately.');"><?= csrfField() ?><input type="hidden" name="form_action" value="remove_admin"><input type="hidden" name="user_id" value="<?= (int)$user['id'] ?>"><button class="is-remove" type="submit">Remove</button></form><?php else: ?><span class="admin-users-no-action">—</span><?php endif; ?></td></tr>
                        <?php endforeach; ?>
                    </tbody></table></div>
                <?php else: ?><div class="admin-users-empty"><i class="fa-solid fa-user-slash"></i><h3>No administrator accounts found</h3><p>Change your search or add a new account.</p></div><?php endif; ?>
            </section>
        </div>
    <?php endif; ?>
</div>
