<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| DATABASE BACKUP
|--------------------------------------------------------------------------
| Creates a complete SQL backup of the current application database.
|
| Location:
| admin/modules/backup/index.php
|
| Important:
| - Uses the existing central database connection.
| - Requires admin authentication.
| - Requires POST + CSRF for backup creation.
| - Backup files are stored in a private, web-denied application folder.
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/../../includes/admin_auth.php';

requireAdminLogin();

global $conn;

/*
|--------------------------------------------------------------------------
| CONFIGURATION
|--------------------------------------------------------------------------
*/

$backupDirectory = dirname(__DIR__, 3) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'backups';

$message = '';
$error = '';
if (isset($_SESSION['backup_flash']) && is_array($_SESSION['backup_flash'])) {
    $backupFlash = $_SESSION['backup_flash'];
    unset($_SESSION['backup_flash']);
    $backupFlashMessage = (string)($backupFlash['message'] ?? '');
    if (($backupFlash['type'] ?? '') === 'success') {
        $message = $backupFlashMessage;
    } else {
        $error = $backupFlashMessage;
    }
}

/*
|--------------------------------------------------------------------------
| CREATE BACKUP DIRECTORY
|--------------------------------------------------------------------------
*/

if (!is_dir($backupDirectory)) {
    if (!mkdir($backupDirectory, 0750, true) && !is_dir($backupDirectory)) {
        $error = 'Unable to create the database backup directory.';
    }
}

/*
|--------------------------------------------------------------------------
| DATABASE NAME
|--------------------------------------------------------------------------
*/

$dbName = '';

if ($conn instanceof mysqli) {
    $result = $conn->query("SELECT DATABASE() AS db_name");

    if ($result) {
        $row = $result->fetch_assoc();
        $dbName = (string)($row['db_name'] ?? '');
        $result->free();
    }
}

if ($dbName === '') {
    $error = 'Unable to determine the active database.';
}

/*
|--------------------------------------------------------------------------
| CREATE DATABASE BACKUP
|--------------------------------------------------------------------------
*/

if (
    ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST'
    && isset($_POST['create_backup'])
) {

    try {

        requireAdminPost();
        requireCsrfToken();

        if ($error !== '') {
            throw new RuntimeException($error);
        }

        if (!$conn instanceof mysqli) {
            throw new RuntimeException('Database connection is unavailable.');
        }

        if ($dbName === '') {
            throw new RuntimeException('Database name could not be determined.');
        }

        /*
        |--------------------------------------------------------------------------
        | SECURITY
        |--------------------------------------------------------------------------
        */

        logAdminSecurityEvent(
            'DATABASE_BACKUP_STARTED',
            'Administrator started a database backup.'
        );

        /*
        |--------------------------------------------------------------------------
        | FILE NAME
        |--------------------------------------------------------------------------
        */

        $timestamp = date('Y-m-d_H-i-s');

        $safeDbName = preg_replace(
            '/[^a-zA-Z0-9_-]/',
            '_',
            $dbName
        );

        $fileName =
            $safeDbName
            . '_backup_'
            . $timestamp
            . '.sql';

        $filePath =
            $backupDirectory
            . DIRECTORY_SEPARATOR
            . $fileName;

        /*
        |--------------------------------------------------------------------------
        | OPEN FILE
        |--------------------------------------------------------------------------
        */

        $handle = fopen($filePath, 'wb');

        if ($handle === false) {
            throw new RuntimeException(
                'Unable to create the backup file.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | BACKUP HEADER
        |--------------------------------------------------------------------------
        */

        fwrite(
            $handle,
            "-- WiFi Voucher Database Backup\n"
            . "-- Database: " . $dbName . "\n"
            . "-- Created: " . date('Y-m-d H:i:s') . "\n"
            . "-- Timezone: Africa/Dar_es_Salaam\n"
            . "-- --------------------------------------------------------\n\n"
        );

        /*
        |--------------------------------------------------------------------------
        | MYSQL SETTINGS
        |--------------------------------------------------------------------------
        */

        fwrite(
            $handle,
            "SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n"
            . "SET FOREIGN_KEY_CHECKS = 0;\n"
            . "SET AUTOCOMMIT = 0;\n"
            . "START TRANSACTION;\n\n"
        );

        /*
        |--------------------------------------------------------------------------
        | GET TABLES
        |--------------------------------------------------------------------------
        */

        $tablesResult = $conn->query("SHOW TABLES");

        if (!$tablesResult) {
            throw new RuntimeException(
                'Unable to read database tables: '
                . $conn->error
            );
        }

        /*
        |--------------------------------------------------------------------------
        | EXPORT TABLES
        |--------------------------------------------------------------------------
        */

        while ($tableRow = $tablesResult->fetch_row()) {

            $tableName = (string)($tableRow[0] ?? '');

            if ($tableName === '') {
                continue;
            }

            /*
            |--------------------------------------------------------------------------
            | Escape table identifier
            |--------------------------------------------------------------------------
            */

            $escapedTable =
                '`'
                . str_replace('`', '``', $tableName)
                . '`';

            /*
            |--------------------------------------------------------------------------
            | TABLE HEADER
            |--------------------------------------------------------------------------
            */

            fwrite(
                $handle,
                "\n-- --------------------------------------------------------\n"
                . "-- Table: {$tableName}\n"
                . "-- --------------------------------------------------------\n\n"
            );

            /*
            |--------------------------------------------------------------------------
            | DROP TABLE
            |--------------------------------------------------------------------------
            */

            fwrite(
                $handle,
                "DROP TABLE IF EXISTS {$escapedTable};\n\n"
            );

            /*
            |--------------------------------------------------------------------------
            | CREATE TABLE
            |--------------------------------------------------------------------------
            */

            $createResult = $conn->query(
                "SHOW CREATE TABLE {$escapedTable}"
            );

            if (!$createResult) {
                throw new RuntimeException(
                    'Unable to read structure of table '
                    . $tableName
                    . ': '
                    . $conn->error
                );
            }

            $createRow = $createResult->fetch_assoc();

            if ($createRow) {

                $createSql =
                    $createRow['Create Table']
                    ?? '';

                if ($createSql !== '') {
                    fwrite(
                        $handle,
                        $createSql . ";\n\n"
                    );
                }
            }

            $createResult->free();

            /*
            |--------------------------------------------------------------------------
            | TABLE DATA
            |--------------------------------------------------------------------------
            */

            $dataResult = $conn->query(
                "SELECT * FROM {$escapedTable}",
                MYSQLI_USE_RESULT
            );

            if (!$dataResult) {
                throw new RuntimeException(
                    'Unable to read data from table '
                    . $tableName
                    . ': '
                    . $conn->error
                );
            }

            $fieldCount = $dataResult->field_count;

            while ($dataRow = $dataResult->fetch_row()) {

                $values = [];

                for ($i = 0; $i < $fieldCount; $i++) {

                    $value = $dataRow[$i] ?? null;

                    if ($value === null) {
                        $values[] = 'NULL';
                    } else {
                        $values[] =
                            "'"
                            . $conn->real_escape_string(
                                (string)$value
                            )
                            . "'";
                    }
                }

                $insertSql =
                    "INSERT INTO "
                    . $escapedTable
                    . " VALUES ("
                    . implode(', ', $values)
                    . ");\n";

                fwrite(
                    $handle,
                    $insertSql
                );
            }

            $dataResult->free();

            fwrite(
                $handle,
                "\n"
            );
        }

        $tablesResult->free();

        /*
        |--------------------------------------------------------------------------
        | FINISH SQL
        |--------------------------------------------------------------------------
        */

        fwrite(
            $handle,
            "\nSET FOREIGN_KEY_CHECKS = 1;\n"
            . "COMMIT;\n"
            . "SET AUTOCOMMIT = 1;\n"
        );

        fclose($handle);

        /*
        |--------------------------------------------------------------------------
        | VERIFY FILE
        |--------------------------------------------------------------------------
        */

        if (!is_file($filePath)) {
            throw new RuntimeException(
                'Backup file was not created.'
            );
        }

        $fileSize = filesize($filePath);

        if ($fileSize === false || $fileSize <= 0) {

            @unlink($filePath);

            throw new RuntimeException(
                'Backup file is empty.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | SECURITY LOG
        |--------------------------------------------------------------------------
        */

        logAdminSecurityEvent(
            'DATABASE_BACKUP_CREATED',
            'Database backup created: ' . $fileName
        );

        $message =
            'Database backup created successfully: '
            . $fileName;

    } catch (Throwable $e) {

        if (
            isset($handle)
            && is_resource($handle)
        ) {
            fclose($handle);
        }

        if (
            isset($filePath)
            && is_file($filePath)
        ) {
            @unlink($filePath);
        }

        logException(
            $e,
            'Database backup'
        );

        $error =
            'Database backup failed. Please check the system logs.';
    }
}

/*
|--------------------------------------------------------------------------
| LIST BACKUPS
|--------------------------------------------------------------------------
*/

$backups = [];

if (is_dir($backupDirectory)) {

    $files = scandir($backupDirectory);

    if ($files !== false) {

        foreach ($files as $file) {

            if (
                $file === '.'
                || $file === '..'
            ) {
                continue;
            }

            $path =
                $backupDirectory
                . DIRECTORY_SEPARATOR
                . $file;

            if (
                is_file($path)
                && str_ends_with(
                    strtolower($file),
                    '.sql'
                )
            ) {

                $size = filesize($path);

                $backups[] = [
                    'name' => $file,
                    'size' => $size !== false
                        ? $size
                        : 0,
                    'time' => filemtime($path)
                        ?: 0,
                ];
            }
        }
    }
}

/*
|--------------------------------------------------------------------------
| SORT NEWEST FIRST
|--------------------------------------------------------------------------
*/

usort(
    $backups,
    static function (
        array $a,
        array $b
    ): int {
        return $b['time'] <=> $a['time'];
    }
);

/*
|--------------------------------------------------------------------------
| FORMAT FILE SIZE
|--------------------------------------------------------------------------
*/

function backupFormatBytes(int $bytes): string
{
    if ($bytes < 1024) {
        return $bytes . ' B';
    }

    if ($bytes < 1024 * 1024) {
        return number_format(
            $bytes / 1024,
            2
        ) . ' KB';
    }

    if ($bytes < 1024 * 1024 * 1024) {
        return number_format(
            $bytes / (1024 * 1024),
            2
        ) . ' MB';
    }

    return number_format(
        $bytes / (1024 * 1024 * 1024),
        2
    ) . ' GB';
}

?>
<section class="backup-page">
    <style>
        .backup-page{--backup-accent:#e87537;max-width:1320px;margin:0 auto;padding:12px;color:#172033}
        .backup-page *{box-sizing:border-box}
        .backup-page .backup-head{display:flex;align-items:center;justify-content:space-between;gap:18px;margin-bottom:18px}
        .backup-page .backup-kicker{display:block;margin-bottom:5px;color:#9a4c27;font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase}
        .backup-page h1{margin:0;color:#111827;font-size:24px;line-height:1.2}
        .backup-page .backup-lead{margin:7px 0 0;color:#64748b;font-size:13px}
        .backup-page .backup-back{display:inline-flex;align-items:center;gap:8px;min-height:38px;padding:0 13px;border:1px solid #f0d9cb;border-radius:11px;background:#fff8f3;color:#9a4c27;text-decoration:none;font-size:12px;font-weight:750}
        .backup-page .backup-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(260px,.75fr);gap:14px}
        .backup-page .backup-card{min-width:0;padding:18px;border:1px solid #e5eaf0;border-radius:14px;background:#fff;box-shadow:0 4px 15px rgba(15,23,42,.035)}
        .backup-page .backup-card h2{margin:0 0 12px;color:#111827;font-size:15px}
        .backup-page .backup-db{display:flex;align-items:center;gap:10px;margin-bottom:13px;padding:12px;border-radius:10px;background:#f8fafc;color:#475569;font-size:12px}
        .backup-page .backup-db i{color:var(--backup-accent);font-size:16px}.backup-page .backup-db strong{color:#172033}
        .backup-page .backup-note{margin:0 0 15px;padding:12px;border-radius:10px;background:#fff8e8;color:#805b13;font-size:11px;line-height:1.55}
        .backup-page .backup-button{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:39px;padding:0 14px;border:0;border-radius:10px;background:var(--backup-accent);color:#fff;text-decoration:none;font-size:11px;font-weight:750;cursor:pointer}
        .backup-page .backup-button:hover{background:#ce5b25}.backup-page .backup-download{background:#fff1e8;color:#9a4c27}.backup-page .backup-download:hover{background:#ffe4d3}.backup-page .backup-actions{display:flex;flex-wrap:wrap;align-items:center;gap:6px}.backup-page .backup-actions form{margin:0}.backup-page .backup-restore{background:#2563a8}.backup-page .backup-restore:hover{background:#1d4f87}.backup-page .backup-delete{background:#fff0f0;color:#a12626;border:1px solid #f4d0d0}.backup-page .backup-delete:hover{background:#ffe2e2}
        .backup-page .backup-alert{margin-bottom:13px;padding:12px 14px;border-radius:10px;font-size:12px}.backup-page .backup-success{background:#ecfdf5;color:#166534}.backup-page .backup-error{background:#fef2f2;color:#991b1b}
        .backup-page .backup-table-wrap{overflow:auto}.backup-page table{width:100%;min-width:560px;border-collapse:collapse}.backup-page th,.backup-page td{padding:11px 9px;border-bottom:1px solid #edf0f4;text-align:left}.backup-page th{background:#f8fafc;color:#64748b;font-size:10px;font-weight:750}.backup-page td{color:#475569;font-size:11px}.backup-page .backup-empty{padding:18px 0;color:#94a3b8;font-size:12px}
        .backup-page .backup-security{color:#64748b;font-size:11px;line-height:1.6}.backup-page .backup-security i{margin-right:6px;color:#0f9f83}
        @media(max-width:760px){.backup-page{padding:8px}.backup-page .backup-head{align-items:flex-start}.backup-page h1{font-size:21px}.backup-page .backup-grid{grid-template-columns:1fr}.backup-page .backup-card{padding:15px}}
    </style>

    <header class="backup-head">
        <div><span class="backup-kicker">System Administration</span><h1>Database Backup</h1><p class="backup-lead">Create and download a backup of your database.</p></div>
        <a class="backup-back" href="<?= e(appUrl('admin/dashboard.php?page=dashboard')) ?>"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i> Dashboard</a>
    </header>

    <?php if ($message !== ''): ?><div class="backup-alert backup-success" role="status"><i class="fa-solid fa-circle-check"></i> <?= e($message) ?></div><?php endif; ?>
    <?php if ($error !== ''): ?><div class="backup-alert backup-error" role="alert"><i class="fa-solid fa-triangle-exclamation"></i> <?= e($error) ?></div><?php endif; ?>

    <div class="backup-grid">
        <section class="backup-card">
            <h2><i class="fa-solid fa-database" aria-hidden="true"></i> Create Backup</h2>
            <div class="backup-db"><i class="fa-solid fa-server" aria-hidden="true"></i><span>Database inayotumika: <strong><?= e($dbName !== '' ? $dbName : 'Haijulikani') ?></strong></span></div>
            <p class="backup-note"><strong>Note:</strong> Creating a backup only reads the database and does not change records. Backup files are stored in a private folder and are available only through the signed-in admin panel. Download a copy and keep it in a safe place.</p>
            <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=backup')) ?>" onsubmit="return confirm('Create a new database backup now?');">
                <?= csrfField() ?>
                <input type="hidden" name="create_backup" value="1">
                <button type="submit" class="backup-button"><i class="fa-solid fa-cloud-arrow-down" aria-hidden="true"></i> Create Backup</button>
            </form>
        </section>

        <aside class="backup-card">
            <h2><i class="fa-solid fa-shield-halved" aria-hidden="true"></i> Security and Restore</h2>
            <p class="backup-security"><i class="fa-solid fa-lock" aria-hidden="true"></i> Creating a backup requires an administrator to be signed in and a CSRF token. Downloads also require administrator sign-in; files cannot be opened directly through a browser URL.</p>
            <p class="backup-note">Restoring replaces tables and data. The system creates a safety snapshot first, and you will be asked to type RESTORE. You can also delete older backups; the last backup cannot be deleted.</p>
        </aside>

        <section class="backup-card" style="grid-column:1/-1">
            <h2><i class="fa-solid fa-clock-rotate-left" aria-hidden="true"></i> Backup History</h2>
            <?php if (empty($backups)): ?>
                <div class="backup-empty">No backups have been created yet.</div>
            <?php else: ?>
                <div class="backup-table-wrap"><table>
                    <thead><tr><th>File</th><th>Size</th><th>Date</th><th>Action</th></tr></thead>
                    <tbody>
                    <?php foreach ($backups as $backup): ?>
                        <tr>
                            <td><?= e($backup['name']) ?></td>
                            <td><?= e(backupFormatBytes((int)$backup['size'])) ?></td>
                            <td><?= e(date('Y-m-d H:i:s', (int)$backup['time'])) ?></td>
                            <td>
    <div class="backup-actions">
        <a class="backup-button backup-download" href="<?= e(appUrl('admin/backup_download.php?file=' . rawurlencode($backup['name']))) ?>"><i class="fa-solid fa-download" aria-hidden="true"></i> Download</a>
        <form method="post" action="<?= e(appUrl('admin/backup_action.php')) ?>" onsubmit="const word=window.prompt('Restoring will replace database data. Type RESTORE to continue.'); if(word!=='RESTORE'){return false;} this.elements.confirmation.value=word;">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="restore">
            <input type="hidden" name="backup_file" value="<?= e($backup['name']) ?>">
            <input type="hidden" name="confirmation" value="">
            <button type="submit" class="backup-button backup-restore"><i class="fa-solid fa-rotate-left" aria-hidden="true"></i> Restore</button>
        </form>
        <form method="post" action="<?= e(appUrl('admin/backup_action.php')) ?>" onsubmit="const word=window.prompt('Deleting this backup does not delete database data. Type DELETE to continue.'); if(word!=='DELETE'){return false;} this.elements.confirmation.value=word;">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="backup_file" value="<?= e($backup['name']) ?>">
            <input type="hidden" name="confirmation" value="">
            <button type="submit" class="backup-button backup-delete"><i class="fa-solid fa-trash" aria-hidden="true"></i> Delete</button>
        </form>
    </div>
</td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table></div>
            <?php endif; ?>
        </section>
    </div>
</section>
