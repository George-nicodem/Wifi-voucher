<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../config/app.php';
require_once __DIR__ . '/../../../config/security.php';
require_once __DIR__ . '/../../../includes/functions.php';

function paymentRoutingNetworkCode(?string $code): string
{
    return strtoupper(trim((string)$code));
}

function paymentRoutingNetworkCodeIsUsable(?string $code): bool
{
    $code = trim((string)$code);
    return $code !== '' && strlen($code) <= 20 && strpos($code, "\0") === false;
}

function paymentRoutingMethodStatusLabel(?string $status): string
{
    return match (strtolower(trim((string)$status))) {
        'enabled' => 'Enabled customer choice',
        'disabled' => 'Disabled customer choice',
        default => 'Needs status review',
    };
}

function paymentRoutingChannelEnvironmentLabel(?string $environment): string
{
    return match (strtolower(trim((string)$environment))) {
        'live', 'production' => 'Live',
        'sandbox', 'test' => 'Test',
        default => 'Environment not set',
    };
}

function paymentRoutingChannelStatusLabel(array $channel): string
{
    if ((string)($channel['status'] ?? '') !== 'enabled') {
        return 'Channel disabled';
    }
    if ((int)($channel['configured'] ?? 0) !== 1) {
        return 'API setup pending';
    }

    return 'Configured';
}
