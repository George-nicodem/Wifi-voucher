<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';

requireAdminLogin();

global $conn;

// Load styles before processing or rendering so the module stays inside the dashboard layout.
$cssUrl = appUrl('admin/modules/payment_routing/payment-routing.css?v=1');
echo '<link rel="stylesheet" href="' . e($cssUrl) . '">';

$errors = [];
$success = '';

if (isPost()) {
    requireAdminPost();
    requireCsrfToken();

    if (postString('form_action', '') !== 'save_route') {
        $errors[] = 'The requested routing action is not valid.';
    } else {
        $methodId = postInt('payment_method_id', 0) ?? 0;
        $primaryChannelId = postInt('primary_channel_id', 0) ?? 0;
        $backupChannelId = postInt('backup_channel_id', 0) ?? 0;
        $method = null;

        if ($methodId <= 0 || $primaryChannelId < 0 || $backupChannelId < 0) {
            $errors[] = 'Choose a valid customer network and route.';
        }

        if (!$errors) {
            $methodStmt = $conn->prepare('SELECT id, name, display_name, provider_code FROM payment_methods WHERE id = ? LIMIT 1');
            if (!$methodStmt) {
                logDatabaseError($conn, 'Preparing payment routing network lookup');
                $errors[] = 'The selected customer network could not be checked.';
            } else {
                $methodStmt->bind_param('i', $methodId);
                if ($methodStmt->execute()) {
                    $method = $methodStmt->get_result()?->fetch_assoc() ?: null;
                } else {
                    logDatabaseError($conn, 'Loading customer network for payment routing');
                    $errors[] = 'The selected customer network could not be checked.';
                }
                $methodStmt->close();
            }
        }

        if (!$errors && !$method) {
            $errors[] = 'The selected customer network was not found.';
        }

        $networkCode = trim((string)($method['provider_code'] ?? ''));
        if (!$errors && !paymentRoutingNetworkCodeIsUsable($networkCode)) {
            $errors[] = 'This network needs a unique provider code of 1 to 20 characters before it can be routed.';
        }

        if (!$errors) {
            $codeCountStmt = $conn->prepare('SELECT COUNT(*) AS total FROM payment_methods WHERE provider_code = ?');
            if (!$codeCountStmt) {
                logDatabaseError($conn, 'Preparing payment network code uniqueness check');
                $errors[] = 'The network provider code could not be checked.';
            } else {
                $codeCountStmt->bind_param('s', $networkCode);
                if (!$codeCountStmt->execute()) {
                    logDatabaseError($conn, 'Checking payment network code uniqueness');
                    $errors[] = 'The network provider code could not be checked.';
                } else {
                    $codeCountResult = $codeCountStmt->get_result();
                    $codeCountRow = $codeCountResult ? $codeCountResult->fetch_assoc() : null;
                    $codeCount = (int)($codeCountRow['total'] ?? 0);
                    if ($codeCount !== 1) {
                        $errors[] = 'This provider code is used by more than one network. Give each network a unique provider code first.';
                    }
                }
                $codeCountStmt->close();
            }
        }

        if (!$errors && $primaryChannelId > 0 && $primaryChannelId === $backupChannelId) {
            $errors[] = 'Primary and backup must be different aggregator channels.';
        }
        if (!$errors && $primaryChannelId === 0 && $backupChannelId > 0) {
            $errors[] = 'Choose a primary aggregator before choosing a backup.';
        }

        $compatibleChannelIds = [];
        if (!$errors) {
            $compatibleStmt = $conn->prepare("SELECT pc.id
                FROM channel_payment_methods cpm
                INNER JOIN payment_channels pc ON pc.id = cpm.channel_id
                WHERE cpm.payment_method_id = ? AND cpm.status = 'enabled' AND pc.status = 'enabled'");
            if (!$compatibleStmt) {
                logDatabaseError($conn, 'Preparing compatible channel lookup for payment route');
                $errors[] = 'Supported aggregator channels could not be checked.';
            } else {
                $compatibleStmt->bind_param('i', $methodId);
                if (!$compatibleStmt->execute()) {
                    logDatabaseError($conn, 'Loading compatible aggregator channels for payment route');
                    $errors[] = 'Supported aggregator channels could not be checked.';
                } else {
                    $compatibleResult = $compatibleStmt->get_result();
                    if ($compatibleResult) {
                        while ($channelRow = $compatibleResult->fetch_assoc()) {
                            $compatibleChannelIds[(int)$channelRow['id']] = true;
                        }
                    }
                }
                $compatibleStmt->close();
            }
        }

        if (!$errors && $primaryChannelId > 0 && !isset($compatibleChannelIds[$primaryChannelId])) {
            $errors[] = 'The primary channel must be enabled and mapped to this customer network.';
        }
        if (!$errors && $backupChannelId > 0 && !isset($compatibleChannelIds[$backupChannelId])) {
            $errors[] = 'The backup channel must be enabled and mapped to this customer network.';
        }

        $routeIds = [];
        if (!$errors) {
            $routeLookup = $conn->prepare('SELECT id FROM payment_routing WHERE network_code = ? ORDER BY id ASC');
            if (!$routeLookup) {
                logDatabaseError($conn, 'Preparing existing payment route lookup');
                $errors[] = 'The existing route could not be checked.';
            } else {
                $routeLookup->bind_param('s', $networkCode);
                if (!$routeLookup->execute()) {
                    logDatabaseError($conn, 'Loading existing payment route');
                    $errors[] = 'The existing route could not be checked.';
                } else {
                    $routeResult = $routeLookup->get_result();
                    if ($routeResult) {
                        while ($routeRow = $routeResult->fetch_assoc()) {
                            $routeIds[] = (int)$routeRow['id'];
                        }
                    }
                    if (count($routeIds) > 1) {
                        $errors[] = 'More than one route exists for this network code. Resolve the duplicate route records before saving.';
                    }
                }
                $routeLookup->close();
            }
        }

        if (!$errors) {
            $primaryValue = $primaryChannelId > 0 ? $primaryChannelId : null;
            $backupValue = $backupChannelId > 0 ? $backupChannelId : null;
            $routeSaved = false;

            if ($routeIds) {
                $saveStmt = $conn->prepare('UPDATE payment_routing SET primary_channel_id = ?, backup_channel_id = ? WHERE id = ? LIMIT 1');
                if (!$saveStmt) {
                    logDatabaseError($conn, 'Preparing payment route update');
                    $errors[] = 'The route could not be saved right now.';
                } else {
                    $routeId = $routeIds[0];
                    $saveStmt->bind_param('iii', $primaryValue, $backupValue, $routeId);
                    if (!$saveStmt->execute()) {
                        logDatabaseError($conn, 'Saving payment route update');
                        $errors[] = 'The route could not be saved right now.';
                    } else {
                        $routeSaved = true;
                    }
                    $saveStmt->close();
                }
            } elseif ($primaryChannelId > 0) {
                $saveStmt = $conn->prepare('INSERT INTO payment_routing (network_code, primary_channel_id, backup_channel_id) VALUES (?, ?, ?)');
                if (!$saveStmt) {
                    logDatabaseError($conn, 'Preparing new payment route');
                    $errors[] = 'The route could not be saved right now.';
                } else {
                    $saveStmt->bind_param('sii', $networkCode, $primaryValue, $backupValue);
                    if (!$saveStmt->execute()) {
                        logDatabaseError($conn, 'Creating payment route');
                        $errors[] = 'The route could not be saved right now.';
                    } else {
                        $routeSaved = true;
                    }
                    $saveStmt->close();
                }
            } else {
                // No route exists and both selections are blank; leave the table unchanged.
                $success = 'No route is configured for ' . (string)$method['display_name'] . '.';
            }

            if (!$errors && $routeSaved) {
                $event = $primaryChannelId > 0 ? 'PAYMENT_ROUTE_SAVED' : 'PAYMENT_ROUTE_CLEARED';
                logAdminSecurityEvent($event, 'Updated payment routing for payment method ID #' . $methodId . '.');
                $success = $primaryChannelId > 0
                    ? 'Primary and backup routing saved for ' . (string)$method['display_name'] . '.'
                    : 'Routing cleared for ' . (string)$method['display_name'] . '.';
            }
        }
    }
}

$methods = [];
$methodResult = $conn->query('SELECT id, name, display_name, provider_code, payment_type, status, display_order FROM payment_methods ORDER BY COALESCE(display_order, 0) ASC, display_name ASC, id ASC');
if ($methodResult) {
    while ($row = $methodResult->fetch_assoc()) {
        $methods[] = $row;
    }
} else {
    logDatabaseError($conn, 'Loading customer networks for payment routing');
    $errors[] = 'Customer networks could not be loaded right now.';
}

$candidateChannels = [];
$candidateResult = $conn->query("SELECT cpm.payment_method_id, pc.id AS channel_id, pc.name, pc.type, pc.channel_type, pc.environment, pc.status, pc.configured
    FROM channel_payment_methods cpm
    INNER JOIN payment_channels pc ON pc.id = cpm.channel_id
    WHERE cpm.status = 'enabled' AND pc.status = 'enabled'
    ORDER BY pc.name ASC, pc.id ASC");
if ($candidateResult) {
    while ($row = $candidateResult->fetch_assoc()) {
        $candidateChannels[(int)$row['payment_method_id']][] = $row;
    }
} else {
    logDatabaseError($conn, 'Loading supported channels for payment routing');
    $errors[] = 'Supported aggregator channels could not be loaded right now.';
}

// Routing should offer only enabled customer networks with an enabled mapping
// on at least one enabled aggregator. Payment Methods remains the master list;
// this view uses the union of the per-aggregator network checkboxes.
$methods = array_values(array_filter($methods, static function (array $method) use ($candidateChannels): bool {
    return strtolower(trim((string)($method['status'] ?? ''))) === 'enabled'
        && !empty($candidateChannels[(int)($method['id'] ?? 0)]);
}));

$routesByCode = [];
$allRoutes = [];
$routeResult = $conn->query("SELECT pr.id, pr.network_code, pr.primary_channel_id, pr.backup_channel_id,
        primary_channel.name AS primary_channel_name,
        primary_channel.status AS primary_channel_status,
        primary_channel.configured AS primary_channel_configured,
        backup_channel.name AS backup_channel_name,
        backup_channel.status AS backup_channel_status,
        backup_channel.configured AS backup_channel_configured
    FROM payment_routing pr
    LEFT JOIN payment_channels primary_channel ON primary_channel.id = pr.primary_channel_id
    LEFT JOIN payment_channels backup_channel ON backup_channel.id = pr.backup_channel_id
    ORDER BY pr.network_code ASC, pr.id ASC");
if ($routeResult) {
    while ($row = $routeResult->fetch_assoc()) {
        $allRoutes[] = $row;
        $routeKey = paymentRoutingNetworkCode((string)($row['network_code'] ?? ''));
        $routesByCode[$routeKey][] = $row;
    }
} else {
    logDatabaseError($conn, 'Loading current payment routes');
    $errors[] = 'Current payment routes could not be loaded right now.';
}

$methodIdsByCode = [];
foreach ($methods as $method) {
    $code = trim((string)($method['provider_code'] ?? ''));
    if ($code !== '') {
        $methodIdsByCode[paymentRoutingNetworkCode($code)][] = (int)$method['id'];
    }
}

$routedCount = 0;
$readyRouteCount = 0;
$orphanRoutes = [];
foreach ($allRoutes as $route) {
    $key = paymentRoutingNetworkCode((string)($route['network_code'] ?? ''));
    if ($key === '' || !isset($methodIdsByCode[$key])) {
        $orphanRoutes[] = $route;
    }
}

foreach ($methods as $method) {
    $code = trim((string)($method['provider_code'] ?? ''));
    $key = paymentRoutingNetworkCode($code);
    $routeRows = $routesByCode[$key] ?? [];
    $currentRoute = count($routeRows) === 1 ? $routeRows[0] : null;
    $primaryId = (int)($currentRoute['primary_channel_id'] ?? 0);
    $primaryCandidates = [];
    foreach ($candidateChannels[(int)$method['id']] ?? [] as $channel) {
        $primaryCandidates[(int)$channel['channel_id']] = $channel;
    }

    if ($currentRoute && $primaryId > 0) {
        $routedCount++;
        if ((string)($method['status'] ?? '') === 'enabled' && isset($primaryCandidates[$primaryId]) && (int)$primaryCandidates[$primaryId]['configured'] === 1) {
            $readyRouteCount++;
        }
    }
}

$totalMethods = count($methods);
?>

<div class="payment-routing-page">
    <header class="payment-routing-header">
        <div class="payment-routing-heading">
            <div class="payment-routing-icon"><i class="fa-solid fa-shuffle"></i></div>
            <div>
                <div class="payment-routing-eyebrow">Payments / Aggregator selection</div>
                <h1>Payment Routing</h1>
                <p>Choose a primary and optional backup aggregator for each customer network.</p>
            </div>
        </div>
        <a class="payment-routing-secondary" href="<?= e(appUrl('admin/dashboard.php?page=payment_channels')) ?>"><i class="fa-solid fa-plug"></i> Payment Channels</a>
    </header>

    <div class="payment-routing-note"><i class="fa-solid fa-circle-info"></i><span>Customers choose their mobile network; the system routes to an aggregator that supports that network. Only enabled channels with an enabled network mapping appear here. A route can be prepared before API setup is complete, but checkout must wait until the selected channel is configured and payment processing is implemented.</span></div>

    <section class="payment-routing-stats" aria-label="Payment routing totals">
        <article><span>Networks supported by enabled aggregators</span><strong><?= number_format($totalMethods) ?></strong></article>
        <article><span>Routes with a primary</span><strong><?= number_format($routedCount) ?></strong></article>
        <article><span>Configured primaries on enabled networks</span><strong><?= number_format($readyRouteCount) ?></strong></article>
    </section>

    <?php foreach ($errors as $error): ?><div class="payment-routing-alert" role="alert"><i class="fa-solid fa-circle-exclamation"></i><span><?= e($error) ?></span></div><?php endforeach; ?>
    <?php if ($success !== ''): ?><div class="payment-routing-success" role="status"><i class="fa-solid fa-circle-check"></i><span><?= e($success) ?></span></div><?php endif; ?>

    <section class="payment-routing-list" aria-label="Routes by customer network">
        <?php if (!$methods): ?>
            <div class="payment-routing-empty"><span><i class="fa-solid fa-mobile-screen-button"></i></span><h2>No supported networks to route</h2><p>Enable a customer network in Payment Methods, then select it in at least one enabled aggregator under Payment Channels.</p></div>
        <?php else: ?>
            <?php foreach ($methods as $method): ?>
                <?php
                    $methodId = (int)$method['id'];
                    $networkCode = trim((string)($method['provider_code'] ?? ''));
                    $routeKey = paymentRoutingNetworkCode($networkCode);
                    $routeRows = $routeKey !== '' ? ($routesByCode[$routeKey] ?? []) : [];
                    $currentRoute = count($routeRows) === 1 ? $routeRows[0] : null;
                    $currentPrimaryId = (int)($currentRoute['primary_channel_id'] ?? 0);
                    $currentBackupId = (int)($currentRoute['backup_channel_id'] ?? 0);
                    $channels = $candidateChannels[$methodId] ?? [];
                    $channelMap = [];
                    foreach ($channels as $channel) {
                        $channelMap[(int)$channel['channel_id']] = $channel;
                    }
                    $methodCodeIsValid = paymentRoutingNetworkCodeIsUsable($networkCode);
                    $codeIsUnique = $routeKey !== '' && count($methodIdsByCode[$routeKey] ?? []) === 1;
                    $routeCanEdit = $methodCodeIsValid && $codeIsUnique && count($routeRows) <= 1;
                    $routeStatus = 'not-routed';
                    $routeStatusLabel = 'Not routed';
                    if (!$methodCodeIsValid) {
                        $routeStatus = 'needs-review';
                        $routeStatusLabel = 'Needs provider code';
                    } elseif (!$codeIsUnique || count($routeRows) > 1) {
                        $routeStatus = 'needs-review';
                        $routeStatusLabel = 'Resolve duplicate code/route';
                    } elseif ((string)($method['status'] ?? '') !== 'enabled') {
                        $routeStatus = 'needs-review';
                        $routeStatusLabel = 'Customer choice is not enabled';
                    } elseif ($currentPrimaryId > 0 && !isset($channelMap[$currentPrimaryId])) {
                        $routeStatus = 'needs-review';
                        $routeStatusLabel = 'Primary is not compatible';
                    } elseif ($currentPrimaryId > 0 && (int)$channelMap[$currentPrimaryId]['configured'] !== 1) {
                        $routeStatus = 'waiting';
                        $routeStatusLabel = 'API setup pending';
                    } elseif ($currentPrimaryId > 0) {
                        $routeStatus = 'ready';
                        $routeStatusLabel = 'Primary channel configured';
                    }
                ?>
                <article class="payment-routing-card">
                    <div class="payment-routing-card-heading">
                        <div class="payment-routing-method-icon"><i class="fa-solid fa-mobile-screen-button"></i></div>
                        <div class="payment-routing-method-title"><h2><?= e((string)$method['display_name']) ?></h2><p>Network code: <code><?= e($networkCode !== '' ? $networkCode : 'not set') ?></code> <span>·</span> <?= e(paymentRoutingMethodStatusLabel(isset($method['status']) ? (string)$method['status'] : null)) ?></p></div>
                        <span class="payment-routing-status is-<?= e($routeStatus) ?>"><i class="fa-solid <?= $routeStatus === 'ready' ? 'fa-circle-check' : ($routeStatus === 'waiting' ? 'fa-clock' : ($routeStatus === 'needs-review' ? 'fa-triangle-exclamation' : 'fa-circle-minus')) ?>"></i><?= e($routeStatusLabel) ?></span>
                    </div>

                    <?php if ($currentRoute): ?>
                        <?php
                            $primaryName = trim((string)($currentRoute['primary_channel_name'] ?? ''));
                            $backupName = trim((string)($currentRoute['backup_channel_name'] ?? ''));
                        ?>
                        <div class="payment-routing-current">
                            <span><small>Current primary</small><strong><?= e($primaryName !== '' ? $primaryName : ($currentPrimaryId > 0 ? 'Unavailable channel' : 'Not set')) ?></strong><?php if ($currentPrimaryId > 0): ?><em><?= e(isset($channelMap[$currentPrimaryId]) ? paymentRoutingChannelStatusLabel($channelMap[$currentPrimaryId]) : 'Disabled or no longer mapped') ?></em><?php endif; ?></span>
                            <i class="fa-solid fa-arrow-right-long" aria-hidden="true"></i>
                            <span><small>Current backup</small><strong><?= e($currentBackupId > 0 && $backupName !== '' ? $backupName : 'Not set') ?></strong><?php if ($currentBackupId > 0): ?><em><?= e(isset($channelMap[$currentBackupId]) ? paymentRoutingChannelStatusLabel($channelMap[$currentBackupId]) : 'Disabled or no longer mapped') ?></em><?php endif; ?></span>
                        </div>
                    <?php else: ?>
                        <div class="payment-routing-current is-empty"><i class="fa-solid fa-circle-info"></i><span><?= count($routeRows) > 1 ? 'Duplicate route records need review before this route can be edited.' : 'No primary/backup route is saved for this network yet.' ?></span></div>
                    <?php endif; ?>

                    <?php if (!$routeCanEdit): ?>
                        <div class="payment-routing-inline-alert"><i class="fa-solid fa-triangle-exclamation"></i><span><?php if (!$methodCodeIsValid): ?>Edit this network in Payment Methods and give it a provider code of 1–20 characters.<?php elseif (!$codeIsUnique): ?>This code is shared by multiple networks. Give every network a unique provider code.<?php else: ?>Multiple routing rows use this network code. Remove the duplicate row before editing its route.<?php endif; ?></span></div>
                    <?php else: ?>
                        <?php if (!$channels): ?><div class="payment-routing-inline-alert"><i class="fa-solid fa-triangle-exclamation"></i><span>No enabled aggregator is currently mapped to this network. Set its supported-network checkbox in Payment Channels first.</span></div><?php endif; ?>
                        <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=payment_routing')) ?>" class="payment-routing-form">
                            <?= csrfField() ?>
                            <input type="hidden" name="form_action" value="save_route">
                            <input type="hidden" name="payment_method_id" value="<?= $methodId ?>">
                            <label><span>Primary aggregator</span><select name="primary_channel_id"><option value="0" <?= $currentPrimaryId === 0 || !isset($channelMap[$currentPrimaryId]) ? 'selected' : '' ?>>— No primary route —</option><?php foreach ($channels as $channel): ?><?php $channelId = (int)$channel['channel_id']; ?><option value="<?= $channelId ?>" <?= $currentPrimaryId === $channelId ? 'selected' : '' ?>><?= e((string)$channel['name']) ?> · <?= e(paymentRoutingChannelStatusLabel($channel)) ?></option><?php endforeach; ?></select><small>Only enabled channels mapped to <?= e((string)$method['display_name']) ?> are listed.</small></label>
                            <label><span>Backup aggregator <em>Optional</em></span><select name="backup_channel_id"><option value="0" <?= $currentBackupId === 0 || !isset($channelMap[$currentBackupId]) ? 'selected' : '' ?>>— No backup route —</option><?php foreach ($channels as $channel): ?><?php $channelId = (int)$channel['channel_id']; ?><option value="<?= $channelId ?>" <?= $currentBackupId === $channelId ? 'selected' : '' ?>><?= e((string)$channel['name']) ?> · <?= e(paymentRoutingChannelStatusLabel($channel)) ?></option><?php endforeach; ?></select><small>Choose a different compatible aggregator as backup.</small></label>
                            <div class="payment-routing-form-footer"><p><i class="fa-solid fa-shield-halved"></i> Channels marked “API setup pending” can be assigned for later, but must not process customer payments until configured.</p><button class="payment-routing-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save route</button></div>
                        </form>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>

    <?php if ($orphanRoutes): ?>
        <section class="payment-routing-orphans">
            <div><h2><i class="fa-solid fa-triangle-exclamation"></i> Routes without an active support mapping</h2><p>These saved routes no longer match an enabled customer network supported by an enabled aggregator. Review them before using routing.</p></div>
            <ul><?php foreach ($orphanRoutes as $orphan): ?><li><code><?= e((string)($orphan['network_code'] ?? '')) ?></code> — route record #<?= (int)$orphan['id'] ?></li><?php endforeach; ?></ul>
        </section>
    <?php endif; ?>
</div>
