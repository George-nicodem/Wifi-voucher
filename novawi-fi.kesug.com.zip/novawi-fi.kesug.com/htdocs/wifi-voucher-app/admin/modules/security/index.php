<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/admin_auth.php';
requireAdminLogin();

global $conn;

$cssUrl = appUrl('admin/modules/security/security.css?v=1');
echo '<link rel="stylesheet" href="' . e($cssUrl) . '">';

$today = date('Y-m-d');
$defaultFrom = date('Y-m-d', strtotime('-29 days'));
$fromInput = trim(getString('from', $defaultFrom));
$toInput = trim(getString('to', $today));
$eventFilter = trim(getString('event', ''));
$search = trim(getString('search', ''));
$eventFilter = function_exists('mb_substr') ? mb_substr($eventFilter, 0, 100) : substr($eventFilter, 0, 100);
$search = function_exists('mb_substr') ? mb_substr($search, 0, 120) : substr($search, 0, 120);
$page = max(1, getInt('audit_page', 1) ?? 1);
$perPage = 50;
$errors = [];
$logs = [];
$actions = [];
$summary = ['total' => 0, 'recent' => 0, 'event_types' => 0];
$totalRows = 0;
$schemaReady = false;

$isValidDate = static function (string $value): bool {
    if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/D', $value, $parts)) {
        return false;
    }
    return checkdate((int)$parts[2], (int)$parts[3], (int)$parts[1]);
};

if (!$isValidDate($fromInput) || !$isValidDate($toInput) || $fromInput > $toInput) {
    $errors[] = 'Select a valid date range.';
    $fromInput = $defaultFrom;
    $toInput = $today;
}

$rangeStart = $fromInput . ' 00:00:00';
$rangeEnd = (new DateTimeImmutable($toInput))->modify('+1 day')->format('Y-m-d') . ' 00:00:00';
$searchLike = '%' . $search . '%';

$tableResult = $conn->query("SHOW TABLES LIKE 'security_logs'");
if ($tableResult && $tableResult->num_rows > 0) {
    $columnsResult = $conn->query('SHOW COLUMNS FROM security_logs');
    if ($columnsResult) {
        $columns = [];
        while ($column = $columnsResult->fetch_assoc()) {
            $columns[(string)$column['Field']] = true;
        }
        $schemaReady = count(array_diff(['id', 'user_id', 'action', 'details', 'ip_address', 'created_at'], array_keys($columns))) === 0;
    }
}

if ($tableResult && !$schemaReady) {
    $errors[] = 'The security_logs table is missing or does not have the required columns. If the table already exists, review its structure before running setup.';
}

if ($schemaReady) {
    $actionsResult = $conn->query('SELECT DISTINCT action FROM security_logs ORDER BY action ASC LIMIT 100');
    if ($actionsResult) {
        while ($actionRow = $actionsResult->fetch_assoc()) {
            $actions[] = (string)$actionRow['action'];
        }
    }

    $whereSql = "created_at >= ? AND created_at < ?
        AND (? = '' OR action = ?)
        AND (? = '' OR action LIKE ? OR details LIKE ? OR COALESCE(ip_address, '') LIKE ? OR CAST(COALESCE(user_id, 0) AS CHAR) LIKE ?)";

    $summaryStmt = $conn->prepare("SELECT COUNT(*) AS total,
        COALESCE(SUM(created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)), 0) AS recent,
        COUNT(DISTINCT action) AS event_types
        FROM security_logs WHERE $whereSql");
    if (!$summaryStmt) {
        logDatabaseError($conn, 'Preparing security log totals');
        $errors[] = 'The audit log summary could not be loaded.';
    } else {
        $summaryStmt->bind_param('sssssssss', $rangeStart, $rangeEnd, $eventFilter, $eventFilter, $search, $searchLike, $searchLike, $searchLike, $searchLike);
        if (!$summaryStmt->execute()) {
            logDatabaseError($conn, 'Loading security log totals');
            $errors[] = 'The audit log summary could not be loaded.';
        } else {
            $summaryResult = $summaryStmt->get_result();
            $summaryRow = $summaryResult ? ($summaryResult->fetch_assoc() ?: []) : [];
            $summary['total'] = (int)($summaryRow['total'] ?? 0);
            $summary['recent'] = (int)($summaryRow['recent'] ?? 0);
            $summary['event_types'] = (int)($summaryRow['event_types'] ?? 0);
            $totalRows = $summary['total'];
        }
        $summaryStmt->close();
    }

    $totalPages = max(1, (int)ceil($totalRows / $perPage));
    $page = min($page, $totalPages);
    $offset = ($page - 1) * $perPage;
    $listStmt = $conn->prepare("SELECT id, user_id, action, details, ip_address, created_at
        FROM security_logs WHERE $whereSql
        ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?");
    if (!$listStmt) {
        logDatabaseError($conn, 'Preparing security log list');
        $errors[] = 'The audit log could not be loaded.';
    } else {
        $listStmt->bind_param('sssssssssii', $rangeStart, $rangeEnd, $eventFilter, $eventFilter, $search, $searchLike, $searchLike, $searchLike, $searchLike, $perPage, $offset);
        if (!$listStmt->execute()) {
            logDatabaseError($conn, 'Loading security log list');
            $errors[] = 'The audit log could not be loaded.';
        } else {
            $listResult = $listStmt->get_result();
            if ($listResult) {
                while ($log = $listResult->fetch_assoc()) {
                    $logs[] = $log;
                }
            }
        }
        $listStmt->close();
    }
}

$totalPages = max(1, (int)ceil($totalRows / $perPage));
$baseUrl = 'admin/dashboard.php?page=security&from=' . rawurlencode($fromInput)
    . '&to=' . rawurlencode($toInput) . '&event=' . rawurlencode($eventFilter)
    . '&search=' . rawurlencode($search) . '&audit_page=';
?>

<div class="security-page">
    <header class="security-header">
        <div><div class="security-eyebrow">System Security</div><h1>Security &amp; Audit</h1><p>Review administrator events recorded by the system.</p></div>
        <a class="security-back" href="<?= e(appUrl('admin/dashboard.php?page=dashboard')) ?>"><i class="fa-solid fa-arrow-left"></i> Dashboard</a>
    </header>

    <?php foreach (array_unique($errors) as $error): ?><div class="security-alert" role="alert"><i class="fa-solid fa-circle-exclamation"></i><span><?= e($error) ?></span></div><?php endforeach; ?>

    <?php if (!$schemaReady): ?>
        <section class="security-setup"><span><i class="fa-solid fa-shield-halved"></i></span><h2>The audit log requires a security_logs table</h2><p>The administrator module records events in <code>security_logs</code>. If the table does not exist, run <code>admin/modules/security/install.sql</code> on the selected system database. If the table exists but has a different structure, create a backup and review the columns before changing it.</p></section>
    <?php else: ?>
        <section class="security-summary" aria-label="Security log summary"><article><span class="security-icon"><i class="fa-solid fa-list-check"></i></span><div><small>Matching Events</small><strong><?= number_format($summary['total']) ?></strong></div></article><article><span class="security-icon is-recent"><i class="fa-solid fa-clock-rotate-left"></i></span><div><small>In the last 24 hours</small><strong><?= number_format($summary['recent']) ?></strong></div></article><article><span class="security-icon is-actions"><i class="fa-solid fa-bolt"></i></span><div><small>Event types</small><strong><?= number_format($summary['event_types']) ?></strong></div></article></section>

        <form class="security-filter" method="get" action="<?= e(appUrl('admin/dashboard.php')) ?>">
            <input type="hidden" name="page" value="security">
            <label><span>From</span><input type="date" name="from" value="<?= e($fromInput) ?>" required></label>
            <label><span>To</span><input type="date" name="to" value="<?= e($toInput) ?>" required></label>
            <label><span>Event</span><select name="event"><option value="">All events</option><?php foreach ($actions as $action): ?><option value="<?= e($action) ?>" <?= $eventFilter === $action ? 'selected' : '' ?>><?= e($action) ?></option><?php endforeach; ?></select></label>
            <label class="security-search"><span>Search</span><input type="search" name="search" maxlength="120" value="<?= e($search) ?>" placeholder="Administrator ID, details, or IP address"></label>
            <button type="submit"><i class="fa-solid fa-filter"></i> Filter</button>
        </form>

        <section class="security-log-card">
            <div class="security-table-heading"><div><h2>Recent Events</h2><p>Shows up to 50 records per page. Details may show changes recorded by different modules.</p></div><span><?= number_format($totalRows) ?> records</span></div>
            <?php if ($logs): ?>
                <div class="security-table-wrap"><table class="security-table"><thead><tr><th>Date</th><th>Admin</th><th>Event</th><th>Details</th><th>IP address</th></tr></thead><tbody>
                    <?php foreach ($logs as $log): ?>
                        <?php $timestamp = strtotime((string)$log['created_at']); ?>
                        <tr><td><?= $timestamp ? e(date('d M Y, H:i:s', $timestamp)) : e((string)$log['created_at']) ?></td><td><?= !empty($log['user_id']) ? '#' . (int)$log['user_id'] : '—' ?></td><td><span class="security-event"><?= e((string)$log['action']) ?></span></td><td class="security-details"><?= e((string)($log['details'] ?? '')) ?></td><td><?= e((string)($log['ip_address'] ?? '—')) ?></td></tr>
                    <?php endforeach; ?>
                </tbody></table></div>
                <?php if ($totalPages > 1): ?><nav class="security-pagination" aria-label="Audit log pages"><?php if ($page > 1): ?><a href="<?= e(appUrl($baseUrl . ($page - 1))) ?>"><i class="fa-solid fa-arrow-left"></i> Previous</a><?php endif; ?><span>Page <?= number_format($page) ?> / <?= number_format($totalPages) ?></span><?php if ($page < $totalPages): ?><a href="<?= e(appUrl($baseUrl . ($page + 1))) ?>">Next <i class="fa-solid fa-arrow-right"></i></a><?php endif; ?></nav><?php endif; ?>
            <?php else: ?><div class="security-empty"><i class="fa-solid fa-shield"></i><h3>No events found</h3><p>New records will appear after an action is logged.</p></div><?php endif; ?>
        </section>
        <p class="security-footnote"><i class="fa-solid fa-circle-info"></i> This page displays events logged by <code>logAdminSecurityEvent()</code>. Not every system action is currently recorded in the audit log.</p>
    <?php endif; ?>
</div>
