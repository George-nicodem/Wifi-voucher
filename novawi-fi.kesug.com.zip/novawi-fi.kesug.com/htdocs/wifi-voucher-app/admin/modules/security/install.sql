-- Audit log used by the admin security module.
-- Select the application's database in phpMyAdmin before running this file.
-- CREATE TABLE IF NOT EXISTS leaves any existing security_logs table untouched.

CREATE TABLE IF NOT EXISTS security_logs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT(11) NULL DEFAULT NULL,
    action VARCHAR(100) NOT NULL,
    details TEXT NULL,
    ip_address VARCHAR(45) NULL DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_security_logs_created_at (created_at),
    KEY idx_security_logs_action (action),
    KEY idx_security_logs_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
