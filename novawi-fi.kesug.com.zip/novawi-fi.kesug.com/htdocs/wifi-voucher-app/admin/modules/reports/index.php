<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/admin_auth.php';
require_once __DIR__ . '/functions.php';
requireAdminLogin();

global $conn;

$cssUrl = appUrl('admin/modules/reports/reports.css?v=3');
echo '<link rel="stylesheet" href="' . e($cssUrl) . '">';

$errors = [];
$today = date('Y-m-d');
$defaultFrom = date('Y-m-01');
$fromInput = trim(getString('from', $defaultFrom));
$toInput = trim(getString('to', $today));

$isValidDate = static function (string $value): bool {
    if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/D', $value, $matches)) {
        return false;
    }
    return checkdate((int)$matches[2], (int)$matches[3], (int)$matches[1]);
};

if (!$isValidDate($fromInput) || !$isValidDate($toInput) || $fromInput > $toInput) {
    $errors[] = 'Select a valid start and end date.';
    $fromInput = $defaultFrom;
    $toInput = $today;
}

$rangeStart = $fromInput . ' 00:00:00';
$rangeEnd = (new DateTimeImmutable($toInput))->modify('+1 day')->format('Y-m-d') . ' 00:00:00';
$totals = [
    'automatic' => ['count' => 0, 'amount' => 0.0],
    'cash' => ['count' => 0, 'amount' => 0.0],
    'admin_activated' => ['count' => 0, 'amount' => 0.0],
];

$loadTotals = static function (string $sql, string $label) use ($conn, $rangeStart, $rangeEnd, &$errors): array {
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        logDatabaseError($conn, 'Preparing report totals: ' . $label);
        $errors[] = 'Sales data could not be loaded right now.';
        return ['count' => 0, 'amount' => 0.0];
    }

    $stmt->bind_param('ss', $rangeStart, $rangeEnd);
    if (!$stmt->execute()) {
        logDatabaseError($conn, 'Loading report totals: ' . $label);
        $errors[] = 'Sales data could not be loaded right now.';
        $stmt->close();
        return ['count' => 0, 'amount' => 0.0];
    }

    $result = $stmt->get_result();
    $row = $result ? ($result->fetch_assoc() ?: []) : [];
    $stmt->close();

    return [
        'count' => (int)($row['sale_count'] ?? 0),
        'amount' => (float)($row['sale_total'] ?? 0),
    ];
};

$totals['automatic'] = $loadTotals(
    "SELECT COUNT(*) AS sale_count, COALESCE(SUM(amount), 0) AS sale_total
     FROM payments
     WHERE UPPER(COALESCE(status, '')) = 'SUCCESS'
       AND COALESCE(paid_at, created_at) >= ? AND COALESCE(paid_at, created_at) < ?",
    'automatic payments'
);
$totals['cash'] = $loadTotals(
    "SELECT COUNT(*) AS sale_count, COALESCE(SUM(sold_price), 0) AS sale_total
     FROM vouchers
     WHERE source = 'manual' AND sold_at IS NOT NULL
       AND sold_at >= ? AND sold_at < ?",
    'manual cash sales'
);
$totals['admin_activated'] = $loadTotals(
    "SELECT COUNT(*) AS sale_count, COALESCE(SUM(COALESCE(v.sold_price, p.price, 0)), 0) AS sale_total
     FROM vouchers v
     LEFT JOIN packages p ON p.id = v.package_id
     WHERE v.source = 'manual' AND v.sold_at IS NULL
       AND v.activated_at IS NOT NULL
       AND v.activated_at >= ? AND v.activated_at < ?",
    'activated admin vouchers'
);

$sales = [];
$salesSql = reportsSalesSql(true);
$salesStmt = $conn->prepare($salesSql);
if (!$salesStmt) {
    logDatabaseError($conn, 'Preparing report sales list');
    $errors[] = 'The sales list could not be loaded right now.';
} else {
    $salesStmt->bind_param('ssssss', $rangeStart, $rangeEnd, $rangeStart, $rangeEnd, $rangeStart, $rangeEnd);
    if (!$salesStmt->execute()) {
        logDatabaseError($conn, 'Loading report sales list');
        $errors[] = 'The sales list could not be loaded right now.';
        $salesStmt->close();
    } else {
        $salesResult = $salesStmt->get_result();
        if ($salesResult) {
            while ($row = $salesResult->fetch_assoc()) {
                $sales[] = $row;
            }
        }
        $salesStmt->close();
    }
}

$totalCount = $totals['automatic']['count'] + $totals['cash']['count'] + $totals['admin_activated']['count'];
$totalAmount = $totals['automatic']['amount'] + $totals['cash']['amount'] + $totals['admin_activated']['amount'];
?>
<div class="reports-page">
    <header class="reports-header">
        <div>
            <div class="reports-eyebrow">Business Overview</div>
            <h1>Reports</h1>
            <p>Online sales, cash sales, and activated administrator vouchers.</p>
        </div>
        <a class="reports-back" href="<?= e(appUrl('admin/dashboard.php?page=dashboard')) ?>"><i class="fa-solid fa-arrow-left"></i> Dashboard</a>
    </header>

    <?php foreach (array_unique($errors) as $error): ?>
        <div class="reports-alert" role="alert"><i class="fa-solid fa-circle-exclamation"></i><?= e($error) ?></div>
    <?php endforeach; ?>

    <form class="reports-filter" method="get" action="<?= e(appUrl('admin/dashboard.php')) ?>">
        <input type="hidden" name="page" value="reports">
        <label><span>From</span><input type="date" name="from" value="<?= e($fromInput) ?>" required></label>
        <label><span>To</span><input type="date" name="to" value="<?= e($toInput) ?>" required></label>
        <button type="submit"><i class="fa-solid fa-filter"></i> Filter Reports</button>
        <a class="reports-export" href="<?= e(appUrl('admin/modules/reports/export.php') . '?' . http_build_query(['from' => $fromInput, 'to' => $toInput])) ?>"><i class="fa-solid fa-file-csv"></i> Download CSV</a>
    </form>

    <section class="reports-summary" aria-label="Total sales">
        <article class="reports-card reports-card-total"><span class="reports-icon"><i class="fa-solid fa-sack-dollar"></i></span><div><small>All sales · <?= number_format($totalCount) ?> records</small><strong><?= e(formatMoney($totalAmount)) ?></strong></div></article>
        <article class="reports-card"><span class="reports-icon is-online"><i class="fa-solid fa-mobile-screen-button"></i></span><div><small>Online · <?= number_format($totals['automatic']['count']) ?> payments</small><strong><?= e(formatMoney($totals['automatic']['amount'])) ?></strong></div></article>
        <article class="reports-card"><span class="reports-icon is-cash"><i class="fa-solid fa-cash-register"></i></span><div><small>Manual cash · <?= number_format($totals['cash']['count']) ?> sales</small><strong><?= e(formatMoney($totals['cash']['amount'])) ?></strong></div></article>
        <article class="reports-card"><span class="reports-icon is-admin"><i class="fa-solid fa-ticket"></i></span><div><small>Admin activated · <?= number_format($totals['admin_activated']['count']) ?> voucher</small><strong><?= e(formatMoney($totals['admin_activated']['amount'])) ?></strong></div></article>
    </section>

    <section class="reports-table-card">
        <div class="reports-table-heading"><div><h2>Sales Records</h2><p>The table shows up to 100 sales; the CSV download includes all records for this period. Records remain after a voucher expires.</p></div><span><?= e(date('d M Y', strtotime($fromInput))) ?> – <?= e(date('d M Y', strtotime($toInput))) ?></span></div>
        <?php if ($sales): ?>
            <div class="reports-table-wrap"><table class="reports-table"><thead><tr><th>Date</th><th>Type</th><th>Package</th><th>Reference</th><th>Status</th><th>Channel</th><th class="reports-amount">Amount</th></tr></thead><tbody>
                <?php foreach ($sales as $sale): ?>
                    <?php $statusKey = strtoupper((string)$sale['sale_status']); $statusClass = $statusKey === 'SUCCESS' || $statusKey === 'ACTIVE' ? 'is-good' : ($statusKey === 'EXPIRED' ? 'is-expired' : 'is-neutral'); ?>
                    <tr><td><?= e(date('d M Y, H:i', strtotime((string)$sale['sale_time']))) ?></td><td><?= e((string)$sale['sale_kind']) ?></td><td><?= e((string)$sale['package_name']) ?></td><td><?= e((string)$sale['reference']) ?></td><td><span class="reports-status <?= $statusClass ?>"><?= e(ucfirst(strtolower($statusKey))) ?></span></td><td><?= e((string)$sale['sale_channel']) ?></td><td class="reports-amount"><?= e(formatMoney((float)$sale['sale_amount'])) ?></td></tr>
                <?php endforeach; ?>
            </tbody></table></div>
        <?php else: ?>
            <div class="reports-empty"><i class="fa-solid fa-chart-line"></i><h3>No sales in this period</h3><p>Try selecting a different date.</p></div>
        <?php endif; ?>
    </section>
</div>
