<?php
declare(strict_types=1);

function reportsSalesSql(bool $limitDisplay = false): string
{
    $limit = $limitDisplay ? "\n    LIMIT 100" : '';
    return "SELECT sale_kind, package_name, reference, sale_status, sale_amount, sale_channel, sale_time
        FROM (
            SELECT 'Automatic' AS sale_kind,
                   COALESCE(NULLIF(p.name, ''), 'Wi-Fi voucher') AS package_name,
                   CONCAT('Payment #', pay.id) AS reference,
                   UPPER(COALESCE(pay.status, 'PENDING')) AS sale_status,
                   pay.amount AS sale_amount,
                   COALESCE(NULLIF(pay.payment_method, ''), 'Online payment') AS sale_channel,
                   COALESCE(pay.paid_at, pay.created_at) AS sale_time
            FROM payments pay
            LEFT JOIN packages p ON p.id = pay.package_id
            WHERE UPPER(COALESCE(pay.status, '')) = 'SUCCESS'
              AND COALESCE(pay.paid_at, pay.created_at) >= ?
              AND COALESCE(pay.paid_at, pay.created_at) < ?

            UNION ALL

            SELECT 'Manual cash' AS sale_kind,
                   COALESCE(NULLIF(p.name, ''), 'Wi-Fi voucher') AS package_name,
                   CONCAT('Voucher #', v.id) AS reference,
                   UPPER(COALESCE(v.status, 'UNUSED')) AS sale_status,
                   v.sold_price AS sale_amount,
                   'Cash sale' AS sale_channel,
                   v.sold_at AS sale_time
            FROM vouchers v
            LEFT JOIN packages p ON p.id = v.package_id
            WHERE v.source = 'manual' AND v.sold_at IS NOT NULL
              AND v.sold_at >= ? AND v.sold_at < ?

            UNION ALL

            SELECT 'Admin activated' AS sale_kind,
                   COALESCE(NULLIF(p.name, ''), 'Wi-Fi voucher') AS package_name,
                   CONCAT('Voucher #', v.id) AS reference,
                   UPPER(COALESCE(v.status, 'ACTIVE')) AS sale_status,
                   COALESCE(v.sold_price, p.price, 0) AS sale_amount,
                   'Admin activation' AS sale_channel,
                   v.activated_at AS sale_time
            FROM vouchers v
            LEFT JOIN packages p ON p.id = v.package_id
            WHERE v.source = 'manual' AND v.sold_at IS NULL
              AND v.activated_at IS NOT NULL
              AND v.activated_at >= ? AND v.activated_at < ?
        ) AS sales_rows
        ORDER BY sale_time DESC{$limit}";
}
