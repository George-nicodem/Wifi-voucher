<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/admin_auth.php';
require_once __DIR__ . '/functions.php';
requireAdminLogin();

global $conn;

$today = date('Y-m-d');
$defaultFrom = date('Y-m-01');
$from = trim((string)($_GET['from'] ?? $defaultFrom));
$to = trim((string)($_GET['to'] ?? $today));
$isValidDate = static function (string $value): bool {
    if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/D', $value, $parts)) return false;
    return checkdate((int)$parts[2], (int)$parts[3], (int)$parts[1]);
};

if (!$isValidDate($from) || !$isValidDate($to) || $from > $to) {
    http_response_code(400);
    header('Content-Type: text/plain; charset=utf-8');
    exit('Choose a valid report date range.');
}

$rangeStart = $from . ' 00:00:00';
$rangeEnd = (new DateTimeImmutable($to))->modify('+1 day')->format('Y-m-d') . ' 00:00:00';
$stmt = $conn->prepare(reportsSalesSql(false));
if (!$stmt) {
    logDatabaseError($conn, 'Preparing report CSV export');
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    exit('The sales export could not be prepared.');
}
$stmt->bind_param('ssssss', $rangeStart, $rangeEnd, $rangeStart, $rangeEnd, $rangeStart, $rangeEnd);
if (!$stmt->execute()) {
    logDatabaseError($conn, 'Executing report CSV export');
    $stmt->close();
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    exit('The sales export could not be generated.');
}

$saleKind = $packageName = $reference = $saleStatus = $saleChannel = $saleTime = '';
$saleAmount = '0.00';
$stmt->bind_result($saleKind, $packageName, $reference, $saleStatus, $saleAmount, $saleChannel, $saleTime);

$filename = 'wifi-voucher-sales-' . str_replace('-', '', $from) . '-' . str_replace('-', '', $to) . '.csv';
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('X-Content-Type-Options: nosniff');
$output = fopen('php://output', 'wb');
if ($output === false) {
    $stmt->close();
    http_response_code(500);
    exit;
}
fwrite($output, "\xEF\xBB\xBF");
fputcsv($output, ['Date', 'Sale type', 'Package', 'Reference', 'Status', 'Payment method', 'Amount (TZS)']);
$safeText = static function (string $value): string {
    return preg_match('/^[\s=+\-@]/u', $value) ? "'" . $value : $value;
};
while ($stmt->fetch()) {
    $formattedTime = strtotime((string)$saleTime);
    fputcsv($output, [
        $formattedTime === false ? (string)$saleTime : date('Y-m-d H:i:s', $formattedTime),
        $safeText((string)$saleKind),
        $safeText((string)$packageName),
        $safeText((string)$reference),
        $safeText((string)$saleStatus),
        $safeText((string)$saleChannel),
        number_format((float)$saleAmount, 2, '.', ''),
    ]);
}
fclose($output);
$stmt->close();
exit;
