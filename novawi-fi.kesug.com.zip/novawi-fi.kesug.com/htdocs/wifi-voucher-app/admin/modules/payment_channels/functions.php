<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../config/app.php';
require_once __DIR__ . '/../../../config/security.php';
require_once __DIR__ . '/../../../includes/functions.php';
require_once __DIR__ . '/../../../includes/payment_provider_catalog.php';

function paymentChannelProviderCatalog(): array
{
    return wifiPaymentProviderCatalog();
}

function paymentChannelProviderKey(array|string $provider): string
{
    if (is_array($provider)) {
        return wifiPaymentProviderKeyFromChannel($provider);
    }
    return wifiPaymentProviderKey($provider);
}

function paymentChannelProviderLabel(string $providerKey): string
{
    return wifiPaymentProviderLabel($providerKey);
}

function paymentChannelProviderAdapterReady(string $providerKey): bool
{
    return wifiPaymentProviderAdapterReady($providerKey);
}

function paymentChannelProviderApiTestReady(string $providerKey): bool
{
    return wifiPaymentProviderApiTestReady($providerKey);
}

function paymentChannelStatusLabel(?string $status): string
{
    return match (strtolower(trim((string)$status))) {
        'enabled' => 'Enabled',
        'disabled' => 'Disabled',
        default => 'Needs review',
    };
}

function paymentChannelEnvironmentLabel(?string $environment): string
{
    return match (strtolower(trim((string)$environment))) {
        'live', 'production' => 'Live',
        'test', 'sandbox' => 'Test',
        default => 'Not set',
    };
}

function paymentChannelMappingStatusLabel(?string $status): string
{
    return match (strtolower(trim((string)$status))) {
        'enabled' => 'Enabled',
        'disabled' => 'Disabled',
        default => 'Needs review',
    };
}

function paymentChannelLength(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
}

function paymentChannelIsClickPesa(array $channel): bool
{
    foreach (['name', 'type', 'channel_type'] as $field) {
        if (stripos((string)($channel[$field] ?? ''), 'clickpesa') !== false) {
            return true;
        }
    }

    return false;
}

/**
 * Confirm the app's encryption helpers can encrypt and decrypt a throwaway value.
 * The probe is never stored or logged and fails closed when APP_ENCRYPTION_KEY is
 * missing or invalid.
 */
function paymentChannelSecretEncryptionReady(): bool
{
    if (!function_exists('encryptData') || !function_exists('decryptData')) {
        return false;
    }

    try {
        $probe = bin2hex(random_bytes(24));
        $encryptedProbe = encryptData($probe);
        if (!is_string($encryptedProbe) || $encryptedProbe === '' || hash_equals($probe, $encryptedProbe)) {
            return false;
        }

        $decryptedProbe = decryptData($encryptedProbe);
        return is_string($decryptedProbe) && hash_equals($probe, $decryptedProbe);
    } catch (Throwable $exception) {
        return false;
    }
}
