<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../../includes/admin_auth.php';
require_once __DIR__ . '/../../../includes/payment_provider_adapters.php';

requireAdminLogin();

global $conn;

// Include styles before rendering this module inside the dashboard.
$cssUrl = appUrl('admin/modules/payment_channels/channels.css?v=4');
echo '<link rel="stylesheet" href="' . e($cssUrl) . '">';

$errors = [];
$success = '';
$selectedChannelId = max(0, getInt('channel_id', 0) ?? 0);
$secretEncryptionReady = paymentChannelSecretEncryptionReady();

if (isPost()) {
    requireAdminPost();
    requireCsrfToken();

    $formAction = postString('form_action', '');

    if ($formAction === 'create_channel') {
        $rawName = $_POST['channel_name'] ?? '';
        $rawProvider = $_POST['provider_name'] ?? '';
        $environment = strtolower(trim(postString('environment', 'sandbox')));
        $channelName = is_string($rawName) ? trim($rawName) : '';
        $providerName = is_string($rawProvider) ? trim($rawProvider) : '';

        if ($channelName === '' || paymentChannelLength($channelName) > 100 || strpos($channelName, "\0") !== false || preg_match('/[\x00-\x1F\x7F]/', $channelName)) {
            $errors[] = 'Enter an account name of 1–100 characters without control characters.';
        }
        if ($providerName === '' || paymentChannelLength($providerName) > 50 || strpos($providerName, "\0") !== false || preg_match('/[\x00-\x1F\x7F]/', $providerName)) {
            $errors[] = 'Choose an aggregator from the supported provider list.';
        } else {
            $providerKey = paymentChannelProviderKey($providerName);
            if ($providerKey === '') {
                $errors[] = 'Choose an aggregator from the supported provider list.';
            } else {
                $providerName = paymentChannelProviderLabel($providerKey);
            }
        }
        if (!in_array($environment, ['sandbox', 'live'], true)) {
            $errors[] = 'Choose either the Test or Live environment.';
        }

        if (!$errors) {
            // New channels are deliberately disabled and unconfigured until their API is set up.
            $initialStatus = 'disabled';
            $configured = 0;
            $createdBy = currentAdminId();
            $createStmt = $conn->prepare("INSERT INTO payment_channels
                (name, type, channel_type, environment, status, configured, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?)");
            if (!$createStmt) {
                logDatabaseError($conn, 'Preparing aggregator channel creation');
                $errors[] = 'The aggregator could not be added right now.';
            } else {
                $createStmt->bind_param('sssssii', $channelName, $providerName, $providerName, $environment, $initialStatus, $configured, $createdBy);
                if (!$createStmt->execute()) {
                    logDatabaseError($conn, 'Adding aggregator channel');
                    $errors[] = 'The aggregator could not be added right now.';
                } else {
                    $selectedChannelId = (int)$createStmt->insert_id;
                    logAdminSecurityEvent('PAYMENT_CHANNEL_CREATED', 'Added aggregator channel ID #' . $selectedChannelId . '.');
                    $success = 'Aggregator added as disabled. Save its credentials, run the read-only API verification, then enable it and select its supported networks.';
                }
                $createStmt->close();
            }
        }
    } elseif ($formAction === 'set_channel_status') {
        $channelId = postInt('channel_id', 0) ?? 0;
        $newStatus = strtolower(trim(postString('status', '')));
        $selectedChannelId = $channelId;
        if ($channelId <= 0 || !in_array($newStatus, ['enabled', 'disabled'], true)) {
            $errors[] = 'The selected aggregator status is invalid.';
        } elseif ($newStatus === 'enabled') {
            $providerLookup = $conn->prepare('SELECT name, type, channel_type, configured FROM payment_channels WHERE id = ? LIMIT 1');
            if (!$providerLookup) {
                logDatabaseError($conn, 'Preparing provider adapter readiness check');
                $errors[] = 'The aggregator cannot be checked right now.';
            } else {
                $providerLookup->bind_param('i', $channelId);
                $providerLookup->execute();
                $providerRow = $providerLookup->get_result()?->fetch_assoc() ?: [];
                $providerLookup->close();
                $providerKey = paymentChannelProviderKey($providerRow);
                if (!paymentChannelProviderAdapterReady($providerKey)) {
                    $errors[] = 'This provider is saved for setup, but its payment adapter is not installed yet. It cannot be enabled for customer payments.';
                } elseif ((int)($providerRow['configured'] ?? 0) !== 1) {
                    $errors[] = 'Save the API settings and complete API verification before enabling this aggregator.';
                }
            }
            if (!$errors) {
                $existsStmt = $conn->prepare('SELECT id FROM payment_channels WHERE id = ? LIMIT 1');
                if (!$existsStmt) {
                    logDatabaseError($conn, 'Preparing aggregator status lookup');
                    $errors[] = 'The aggregator could not be checked right now.';
                } else {
                    $existsStmt->bind_param('i', $channelId);
                    $channelExists = $existsStmt->execute() && $existsStmt->get_result()?->num_rows === 1;
                    $existsStmt->close();
                    if (!$channelExists) {
                        $errors[] = 'The selected aggregator was not found.';
                    } else {
                        $statusStmt = $conn->prepare('UPDATE payment_channels SET status = ?, updated_at = NOW() WHERE id = ? LIMIT 1');
                        if (!$statusStmt) {
                            logDatabaseError($conn, 'Preparing aggregator status update');
                            $errors[] = 'The aggregator status could not be changed right now.';
                        } else {
                            $statusStmt->bind_param('si', $newStatus, $channelId);
                            if (!$statusStmt->execute()) {
                                logDatabaseError($conn, 'Updating aggregator status');
                                $errors[] = 'The aggregator status could not be changed right now.';
                            } else {
                                logAdminSecurityEvent('PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #' . $channelId . ' to ' . $newStatus . '.');
                                $success = 'Aggregator enabled for use after its API and callback setup are completed.';
                            }
                            $statusStmt->close();
                        }
                    }
                }
            }
        } else {
            $existsStmt = $conn->prepare('SELECT id FROM payment_channels WHERE id = ? LIMIT 1');
            if (!$existsStmt) {
                logDatabaseError($conn, 'Preparing aggregator status lookup');
                $errors[] = 'The aggregator could not be checked right now.';
            } else {
                $existsStmt->bind_param('i', $channelId);
                $channelExists = $existsStmt->execute() && $existsStmt->get_result()?->num_rows === 1;
                $existsStmt->close();
                if (!$channelExists) {
                    $errors[] = 'The selected aggregator was not found.';
                } else {
                    $statusStmt = $conn->prepare('UPDATE payment_channels SET status = ?, updated_at = NOW() WHERE id = ? LIMIT 1');
                    if (!$statusStmt) {
                        logDatabaseError($conn, 'Preparing aggregator status update');
                        $errors[] = 'The aggregator status could not be changed right now.';
                    } else {
                        $statusStmt->bind_param('si', $newStatus, $channelId);
                        if (!$statusStmt->execute()) {
                            logDatabaseError($conn, 'Updating aggregator status');
                            $errors[] = 'The aggregator status could not be changed right now.';
                        } else {
                            logAdminSecurityEvent('PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #' . $channelId . ' to ' . $newStatus . '.');
                            $success = $newStatus === 'enabled'
                                ? 'Aggregator enabled. It can process real payments only after its API is configured and verified.'
                                : 'Aggregator disabled. It will no longer be offered for new routing choices.';
                        }
                        $statusStmt->close();
                    }
                }
            }
        }
    } elseif ($formAction === 'delete_channel') {
        $channelId = postInt('channel_id', 0) ?? 0;
        $selectedChannelId = 0;
        if ($channelId <= 0) {
            $errors[] = 'Choose a valid aggregator to remove.';
        } else {
            $transactionStarted = false;
            try {
                if (!$conn->begin_transaction()) {
                    throw new RuntimeException('Could not start aggregator removal transaction.');
                }
                $transactionStarted = true;

                $channelLock = $conn->prepare('SELECT id FROM payment_channels WHERE id = ? LIMIT 1 FOR UPDATE');
                if (!$channelLock) {
                    throw new RuntimeException('Could not lock aggregator for removal.');
                }
                $channelLock->bind_param('i', $channelId);
                if (!$channelLock->execute()) {
                    $channelLock->close();
                    throw new RuntimeException('Could not check aggregator for removal.');
                }
                $channelExists = $channelLock->get_result()?->num_rows === 1;
                $channelLock->close();
                if (!$channelExists) {
                    throw new RuntimeException('The selected aggregator was not found.');
                }

                $routeLock = $conn->prepare('SELECT id FROM payment_routing WHERE primary_channel_id = ? OR backup_channel_id = ? LIMIT 1 FOR UPDATE');
                if (!$routeLock) {
                    throw new RuntimeException('Could not check aggregator routing references.');
                }
                $routeLock->bind_param('ii', $channelId, $channelId);
                if (!$routeLock->execute()) {
                    $routeLock->close();
                    throw new RuntimeException('Could not check aggregator routing references.');
                }
                $isRouted = $routeLock->get_result()?->num_rows === 1;
                $routeLock->close();
                if ($isRouted) {
                    throw new DomainException('This aggregator is still selected in Payment Routing. Change or clear that route first, then remove it.');
                }

                $pendingPaymentLock = $conn->prepare("SELECT id FROM payments WHERE payment_channel_id = ? AND status IN ('PENDING', 'PROCESSING') LIMIT 1 FOR UPDATE");
                if (!$pendingPaymentLock) {
                    throw new RuntimeException('Could not check open payments for this aggregator.');
                }
                $pendingPaymentLock->bind_param('i', $channelId);
                if (!$pendingPaymentLock->execute()) {
                    $pendingPaymentLock->close();
                    throw new RuntimeException('Could not check open payments for this aggregator.');
                }
                $hasPendingPayment = $pendingPaymentLock->get_result()?->num_rows === 1;
                $pendingPaymentLock->close();
                if ($hasPendingPayment) {
                    throw new DomainException('This aggregator has an open payment request. Let it finish or fail, then remove it; you can disable it in the meantime.');
                }

                // These rows contain only network-support configuration for this channel.
                $deleteMappings = $conn->prepare('DELETE FROM channel_payment_methods WHERE channel_id = ?');
                if (!$deleteMappings) {
                    throw new RuntimeException('Could not prepare aggregator mapping cleanup.');
                }
                $deleteMappings->bind_param('i', $channelId);
                if (!$deleteMappings->execute()) {
                    $deleteMappings->close();
                    throw new RuntimeException('Could not remove aggregator network mappings.');
                }
                $deleteMappings->close();

                $deleteChannel = $conn->prepare('DELETE FROM payment_channels WHERE id = ? LIMIT 1');
                if (!$deleteChannel) {
                    throw new RuntimeException('Could not prepare aggregator removal.');
                }
                $deleteChannel->bind_param('i', $channelId);
                if (!$deleteChannel->execute() || $deleteChannel->affected_rows !== 1) {
                    $deleteChannel->close();
                    throw new RuntimeException('Could not remove aggregator.');
                }
                $deleteChannel->close();

                if (!$conn->commit()) {
                    throw new RuntimeException('Could not commit aggregator removal.');
                }
                $transactionStarted = false;
                logAdminSecurityEvent('PAYMENT_CHANNEL_REMOVED', 'Removed aggregator channel ID #' . $channelId . ' and its network mappings.');
                $success = 'Aggregator and its network mappings were removed.';
            } catch (DomainException $exception) {
                if ($transactionStarted) {
                    $conn->rollback();
                }
                $errors[] = $exception->getMessage();
            } catch (Throwable $exception) {
                if ($transactionStarted) {
                    $conn->rollback();
                }
                logDatabaseError($conn, 'Removing aggregator channel');
                $errors[] = 'The aggregator could not be removed. It may still be referenced by another payment record; disable it instead and check the database references.';
            }
        }
    } elseif ($formAction === 'save_channel_api_settings') {
        $channelId = postInt('channel_id', 0) ?? 0;
        $selectedChannelId = $channelId;
        $inputNames = ['api_base_url', 'callback_url', 'authentication_type', 'client_id', 'merchant_id', 'api_key', 'api_secret', 'checksum_key'];
        $apiSettings = [];
        foreach ($inputNames as $fieldName) {
            $rawValue = $_POST[$fieldName] ?? '';
            if (!is_string($rawValue)) {
                $errors[] = 'One or more API setting fields are invalid.';
                $apiSettings[$fieldName] = '';
                continue;
            }
            $apiSettings[$fieldName] = trim($rawValue);
        }

        $apiBaseUrl = $apiSettings['api_base_url'];
        $callbackUrl = $apiSettings['callback_url'];
        $authenticationType = $apiSettings['authentication_type'];
        $clientId = $apiSettings['client_id'];
        $merchantId = $apiSettings['merchant_id'];
        $apiKey = $apiSettings['api_key'];
        $apiSecret = $apiSettings['api_secret'];
        $checksumKey = $apiSettings['checksum_key'];
        if ($channelId <= 0) {
            $errors[] = 'Choose an aggregator account before saving its API settings.';
        }
        if ($apiBaseUrl === '' || strlen($apiBaseUrl) > 255 || strpos($apiBaseUrl, "\0") !== false || filter_var($apiBaseUrl, FILTER_VALIDATE_URL) === false) {
            $errors[] = 'Enter the full API Base URL supplied by the aggregator, including https://.';
        }
        foreach (['api_base_url' => $apiBaseUrl, 'callback_url' => $callbackUrl] as $urlField => $urlValue) {
            if ($urlValue === '') {
                continue;
            }
            $urlParts = parse_url($urlValue);
            if (strlen($urlValue) > 255 || filter_var($urlValue, FILTER_VALIDATE_URL) === false || !is_array($urlParts) || !in_array(strtolower((string)($urlParts['scheme'] ?? '')), ['http', 'https'], true) || isset($urlParts['user']) || isset($urlParts['pass'])) {
                $errors[] = $urlField === 'callback_url' ? 'Enter a valid Callback/Webhook URL of 255 characters or fewer.' : 'Enter a valid API Base URL of 255 characters or fewer.';
            }
        }
        if ($authenticationType === '' || strlen($authenticationType) > 50 || strpos($authenticationType, "\0") !== false || preg_match('/[\x00-\x1F\x7F]/', $authenticationType)) {
            $errors[] = 'Enter the authentication type shown in the aggregator API instructions (50 characters or fewer).';
        }
        if (strlen($clientId) > 255 || strlen($merchantId) > 255 || strlen($apiKey) > 4096 || strlen($apiSecret) > 4096 || strlen($checksumKey) > 4096 ||
            strpos($clientId, "\0") !== false || strpos($merchantId, "\0") !== false || strpos($apiKey, "\0") !== false || strpos($apiSecret, "\0") !== false || strpos($checksumKey, "\0") !== false) {
            $errors[] = 'An account ID or API credential is invalid or exceeds the allowed length.';
        }
        if (!$secretEncryptionReady && ($apiKey !== '' || $apiSecret !== '' || $checksumKey !== '')) {
            $errors[] = 'Encrypted credential storage is unavailable. Set a valid APP_ENCRYPTION_KEY in the app .env file before saving API secrets.';
        }

        $channelInfo = null;
        if (!$errors) {
            $channelStmt = $conn->prepare("SELECT id, environment,
                CASE WHEN NULLIF(client_id, '') IS NULL THEN 0 ELSE 1 END AS client_id_saved,
                CASE WHEN NULLIF(merchant_id, '') IS NULL THEN 0 ELSE 1 END AS merchant_id_saved,
                CASE WHEN NULLIF(api_key_enc, '') IS NULL THEN 0 ELSE 1 END AS api_key_saved,
                CASE WHEN NULLIF(api_secret_enc, '') IS NULL THEN 0 ELSE 1 END AS api_secret_saved,
                CASE WHEN NULLIF(checksum_secret, '') IS NULL THEN 0 ELSE 1 END AS checksum_saved
                FROM payment_channels WHERE id = ? LIMIT 1");
            if (!$channelStmt) {
                logDatabaseError($conn, 'Preparing aggregator API settings lookup');
                $errors[] = 'The selected aggregator could not be checked.';
            } else {
                $channelStmt->bind_param('i', $channelId);
                if ($channelStmt->execute()) {
                    $channelInfo = $channelStmt->get_result()?->fetch_assoc() ?: null;
                } else {
                    logDatabaseError($conn, 'Loading aggregator API settings state');
                    $errors[] = 'The selected aggregator could not be checked.';
                }
                $channelStmt->close();
            }
        }
        if (!$errors && !$channelInfo) {
            $errors[] = 'The selected aggregator was not found.';
        }
        if (!$errors && strtolower((string)($channelInfo['environment'] ?? '')) === 'live') {
            foreach ([$apiBaseUrl, $callbackUrl] as $liveUrl) {
                if ($liveUrl !== '' && strtolower((string)(parse_url($liveUrl, PHP_URL_SCHEME) ?: '')) !== 'https') {
                    $errors[] = 'Live API and callback URLs must use HTTPS.';
                    break;
                }
            }
        }

        if (!$errors) {
            try {
                $encryptedApiKey = $apiKey !== '' ? encryptData($apiKey) : '';
                $encryptedApiSecret = $apiSecret !== '' ? encryptData($apiSecret) : '';
                $encryptedChecksumKey = $checksumKey !== '' ? encryptData($checksumKey) : '';
                foreach ([[$apiKey, $encryptedApiKey], [$apiSecret, $encryptedApiSecret], [$checksumKey, $encryptedChecksumKey]] as [$plainValue, $encryptedValue]) {
                    if ($plainValue !== '' && (!is_string($encryptedValue) || $encryptedValue === '' || hash_equals($plainValue, $encryptedValue))) {
                        throw new RuntimeException('Credential encryption did not return ciphertext.');
                    }
                }

                $saveStmt = $conn->prepare("UPDATE payment_channels SET
                    api_base_url = ?, callback_url = ?, authentication_type = ?,
                    client_id = CASE WHEN ? <> '' THEN ? ELSE client_id END,
                    merchant_id = CASE WHEN ? <> '' THEN ? ELSE merchant_id END,
                    api_key_enc = CASE WHEN ? <> '' THEN ? ELSE api_key_enc END,
                    api_secret_enc = CASE WHEN ? <> '' THEN ? ELSE api_secret_enc END,
                    checksum_secret = CASE WHEN ? <> '' THEN ? ELSE checksum_secret END,
                    configured = 0,
                    updated_at = NOW()
                    WHERE id = ? LIMIT 1");
                if (!$saveStmt) {
                    logDatabaseError($conn, 'Preparing aggregator API settings update');
                    $errors[] = 'The aggregator API settings could not be saved right now.';
                } else {
                    $saveStmt->bind_param(str_repeat('s', 13) . 'i', $apiBaseUrl, $callbackUrl, $authenticationType, $clientId, $clientId, $merchantId, $merchantId, $encryptedApiKey, $encryptedApiKey, $encryptedApiSecret, $encryptedApiSecret, $encryptedChecksumKey, $encryptedChecksumKey, $channelId);
                    if (!$saveStmt->execute()) {
                        logDatabaseError($conn, 'Saving aggregator API settings');
                        $errors[] = 'The aggregator API settings could not be saved right now.';
                    } else {
                        logAdminSecurityEvent('PAYMENT_CHANNEL_API_SETTINGS_SAVED', 'Saved API settings for payment channel ID #' . $channelId . '.');
                        $success = 'API settings saved. This stores the details only; it does not test the connection, mark the channel configured, or start accepting payments.';
                    }
                    $saveStmt->close();
                }
            } catch (Throwable $exception) {
                // Never include provider credentials or crypto exception details in output or logs.
                $errors[] = 'The API secrets could not be encrypted. Check the app encryption-key configuration and try again.';
            }
        }
    } elseif ($formAction === 'verify_channel_api') {
        $channelId = postInt('channel_id', 0) ?? 0;
        $selectedChannelId = $channelId;
        if ($channelId <= 0) {
            $errors[] = 'Choose an aggregator channel before verifying its API.';
        } else {
            try {
                $verification = wifiPaymentVerifyAdapter($conn, $channelId);
                $configureStmt = $conn->prepare('UPDATE payment_channels SET configured = 1, updated_at = NOW() WHERE id = ? LIMIT 1');
                if (!$configureStmt) {
                    logDatabaseError($conn, 'Preparing payment channel configuration update');
                    $errors[] = 'The API responded, but its verified status could not be saved.';
                } else {
                    $configureStmt->bind_param('i', $channelId);
                    if (!$configureStmt->execute()) {
                        logDatabaseError($conn, 'Saving verified payment channel configuration');
                        $errors[] = 'The API responded, but its verified status could not be saved.';
                    } else {
                        logAdminSecurityEvent('PAYMENT_CHANNEL_API_VERIFIED', 'Verified API connectivity for payment channel ID #' . $channelId . '.');
                        $success = (string)($verification['message'] ?? 'Provider API verification succeeded.');
                    }
                    $configureStmt->close();
                }
            } catch (Throwable $exception) {
                // Keep credentials and raw provider replies out of the admin page/log.
                $errors[] = $exception->getMessage();
            }
        }
    } elseif ($formAction === 'save_networks') {
        $channelId = postInt('channel_id', 0) ?? 0;
        $selectedChannelId = $channelId;
        $rawNetworkIds = $_POST['payment_method_ids'] ?? [];
        $selectedNetworkIds = [];

        if ($channelId <= 0) {
            $errors[] = 'Choose an aggregator channel before saving its supported networks.';
        }
        if (!is_array($rawNetworkIds)) {
            $errors[] = 'The selected network list is invalid.';
        } else {
            foreach ($rawNetworkIds as $rawNetworkId) {
                if (!is_scalar($rawNetworkId)) {
                    $errors[] = 'The selected network list is invalid.';
                    break;
                }
                $networkId = filter_var((string)$rawNetworkId, FILTER_VALIDATE_INT);
                if ($networkId === false || $networkId <= 0) {
                    $errors[] = 'The selected network list is invalid.';
                    break;
                }
                $selectedNetworkIds[] = (int)$networkId;
            }
            $selectedNetworkIds = array_values(array_unique($selectedNetworkIds));
        }

        if (!$errors) {
            $channelCheck = $conn->prepare('SELECT id FROM payment_channels WHERE id = ? LIMIT 1');
            if (!$channelCheck) {
                logDatabaseError($conn, 'Preparing payment channel network lookup');
                $errors[] = 'The selected aggregator channel could not be checked.';
            } else {
                $channelCheck->bind_param('i', $channelId);
                $channelExists = $channelCheck->execute() && ($channelCheck->get_result()?->num_rows === 1);
                $channelCheck->close();
                if (!$channelExists) {
                    $errors[] = 'The selected aggregator channel was not found.';
                }
            }
        }

        if (!$errors && $selectedNetworkIds) {
            $methodCheck = $conn->prepare('SELECT id FROM payment_methods WHERE id = ? LIMIT 1');
            if (!$methodCheck) {
                logDatabaseError($conn, 'Preparing customer network validation');
                $errors[] = 'The selected networks could not be checked.';
            } else {
                foreach ($selectedNetworkIds as $networkId) {
                    $methodCheck->bind_param('i', $networkId);
                    if (!$methodCheck->execute() || !($methodCheck->get_result()?->num_rows === 1)) {
                        $errors[] = 'One or more selected networks were not found. Reload the page and try again.';
                        break;
                    }
                }
                $methodCheck->close();
            }
        }

        if (!$errors) {
            $existingNetworkIds = [];
            $existingStmt = $conn->prepare('SELECT payment_method_id FROM channel_payment_methods WHERE channel_id = ?');
            if (!$existingStmt) {
                logDatabaseError($conn, 'Preparing existing channel network lookup');
                $errors[] = 'The channel mappings could not be read right now.';
            } else {
                $existingStmt->bind_param('i', $channelId);
                if (!$existingStmt->execute()) {
                    logDatabaseError($conn, 'Loading existing channel network mappings');
                    $errors[] = 'The channel mappings could not be read right now.';
                } else {
                    $existingResult = $existingStmt->get_result();
                    if ($existingResult) {
                        while ($existingRow = $existingResult->fetch_assoc()) {
                            $existingNetworkIds[(int)$existingRow['payment_method_id']] = true;
                        }
                    }
                }
                $existingStmt->close();
            }
        }

        if (!$errors) {
            $transactionStarted = false;
            try {
                if (!$conn->begin_transaction()) {
                    throw new RuntimeException('Could not start network mapping transaction.');
                }
                $transactionStarted = true;

                $disableStmt = $conn->prepare("UPDATE channel_payment_methods SET status = 'disabled', updated_at = NOW() WHERE channel_id = ?");
                $enableStmt = $conn->prepare("UPDATE channel_payment_methods SET status = 'enabled', updated_at = NOW() WHERE channel_id = ? AND payment_method_id = ?");
                $insertStmt = $conn->prepare("INSERT INTO channel_payment_methods (channel_id, payment_method_id, status) VALUES (?, ?, 'enabled')");
                if (!$disableStmt || !$enableStmt || !$insertStmt) {
                    throw new RuntimeException('Could not prepare channel network mapping updates.');
                }

                $disableStmt->bind_param('i', $channelId);
                if (!$disableStmt->execute()) {
                    throw new RuntimeException('Could not disable previous network mappings.');
                }

                foreach ($selectedNetworkIds as $networkId) {
                    if (isset($existingNetworkIds[$networkId])) {
                        $enableStmt->bind_param('ii', $channelId, $networkId);
                        if (!$enableStmt->execute()) {
                            throw new RuntimeException('Could not enable a selected network mapping.');
                        }
                    } else {
                        $insertStmt->bind_param('ii', $channelId, $networkId);
                        if (!$insertStmt->execute()) {
                            throw new RuntimeException('Could not add a selected network mapping.');
                        }
                    }
                }

                $disableStmt->close();
                $enableStmt->close();
                $insertStmt->close();
                if (!$conn->commit()) {
                    throw new RuntimeException('Could not commit channel network mappings.');
                }
                $transactionStarted = false;
                logAdminSecurityEvent('PAYMENT_CHANNEL_NETWORKS_SAVED', 'Saved ' . count($selectedNetworkIds) . ' supported network(s) for payment channel ID #' . $channelId . '.');
                $success = 'Supported networks saved for this aggregator.';
            } catch (Throwable $exception) {
                if ($transactionStarted) {
                    $conn->rollback();
                }
                logDatabaseError($conn, 'Saving supported networks for payment channel');
                $errors[] = 'The supported networks could not be saved right now. Existing mappings were kept unchanged.';
            }
        }
    } elseif ($formAction === 'update_mapping') {
        $mappingId = postInt('mapping_id', 0) ?? 0;
        $channelId = postInt('channel_id', 0) ?? 0;
        $providerCode = trim(postString('provider_code', ''));
        $mappingStatus = strtolower(trim(postString('status', '')));
        $selectedChannelId = $channelId;

        if ($mappingId <= 0 || $channelId <= 0) {
            $errors[] = 'The selected network mapping is invalid.';
        }
        if (paymentChannelLength($providerCode) > 100) {
            $errors[] = 'The aggregator-specific network code must be 100 characters or fewer.';
        }
        if (!in_array($mappingStatus, ['enabled', 'disabled'], true)) {
            $errors[] = 'Choose a valid mapping status.';
        }

        if (!$errors) {
            $providerCodeValue = $providerCode !== '' ? $providerCode : null;
            $updateStmt = $conn->prepare('UPDATE channel_payment_methods SET provider_code = ?, status = ?, updated_at = NOW() WHERE id = ? AND channel_id = ? LIMIT 1');
            if (!$updateStmt) {
                logDatabaseError($conn, 'Preparing channel network mapping update');
                $errors[] = 'The network mapping could not be updated right now.';
            } else {
                $updateStmt->bind_param('ssii', $providerCodeValue, $mappingStatus, $mappingId, $channelId);
                if (!$updateStmt->execute()) {
                    logDatabaseError($conn, 'Updating channel network mapping');
                    $errors[] = 'The network mapping could not be updated right now.';
                } else {
                    logAdminSecurityEvent('PAYMENT_CHANNEL_NETWORK_UPDATED', 'Updated network mapping ID #' . $mappingId . ' for payment channel ID #' . $channelId . '.');
                    $success = 'Network mapping updated.';
                }
                $updateStmt->close();
            }
        }
    } else {
        $errors[] = 'The requested channel action is not valid.';
    }
}

$channels = [];
$channelResult = $conn->query("SELECT id, name, type, channel_type, environment, status, configured,
    api_base_url, callback_url, authentication_type,
    CASE WHEN NULLIF(client_id, '') IS NULL THEN 0 ELSE 1 END AS client_id_saved,
    CASE WHEN NULLIF(merchant_id, '') IS NULL THEN 0 ELSE 1 END AS merchant_id_saved,
    CASE WHEN NULLIF(api_key_enc, '') IS NULL THEN 0 ELSE 1 END AS api_key_saved,
    CASE WHEN NULLIF(api_secret_enc, '') IS NULL THEN 0 ELSE 1 END AS api_secret_saved,
    CASE WHEN NULLIF(checksum_secret, '') IS NULL THEN 0 ELSE 1 END AS checksum_saved
    FROM payment_channels ORDER BY name ASC, id ASC");
if ($channelResult) {
    while ($row = $channelResult->fetch_assoc()) {
        $channels[] = $row;
    }
} else {
    logDatabaseError($conn, 'Loading payment channels');
    $errors[] = 'Payment channels could not be loaded right now.';
}

$networks = [];
$networkResult = $conn->query('SELECT id, name, display_name, provider_code, payment_type, status, display_order FROM payment_methods ORDER BY COALESCE(display_order, 0) ASC, display_name ASC, id ASC');
if ($networkResult) {
    while ($row = $networkResult->fetch_assoc()) {
        $networks[] = $row;
    }
} else {
    logDatabaseError($conn, 'Loading payment networks for channel mapping');
    $errors[] = 'Customer networks could not be loaded right now.';
}

$totalChannels = count($channels);
$readyChannels = 0;
foreach ($channels as $channel) {
    $providerKey = paymentChannelProviderKey($channel);
    if (($channel['status'] ?? '') === 'enabled'
        && (int)($channel['configured'] ?? 0) === 1
        && paymentChannelProviderAdapterReady($providerKey)) {
        $readyChannels++;
    }
}

$mappingSql = '
    SELECT
        cpm.id,
        cpm.channel_id,
        cpm.payment_method_id,
        cpm.provider_code,
        cpm.status AS mapping_status,
        pc.name AS channel_name,
        pc.type AS channel_type,
        pc.environment,
        pc.status AS channel_status,
        pc.configured,
        pm.name AS network_key,
        pm.display_name AS network_name,
        pm.provider_code AS network_code,
        pm.status AS network_status
    FROM channel_payment_methods cpm
    INNER JOIN payment_channels pc ON pc.id = cpm.channel_id
    INNER JOIN payment_methods pm ON pm.id = cpm.payment_method_id
';
$mappingStmt = null;
if ($selectedChannelId > 0) {
    $mappingStmt = $conn->prepare($mappingSql . ' WHERE cpm.channel_id = ? ORDER BY pc.name ASC, pm.display_order ASC, pm.display_name ASC');
    if ($mappingStmt) {
        $mappingStmt->bind_param('i', $selectedChannelId);
    }
} else {
    $mappingStmt = $conn->prepare($mappingSql . ' ORDER BY pc.name ASC, cpm.channel_id ASC, pm.display_order ASC, pm.display_name ASC');
}

$mappings = [];
if (!$mappingStmt) {
    logDatabaseError($conn, 'Preparing payment channel network mapping list');
    $errors[] = 'Network support mappings could not be loaded right now.';
} elseif (!$mappingStmt->execute()) {
    logDatabaseError($conn, 'Loading payment channel network mappings');
    $errors[] = 'Network support mappings could not be loaded right now.';
    $mappingStmt->close();
} else {
    $mappingResult = $mappingStmt->get_result();
    if ($mappingResult) {
        while ($row = $mappingResult->fetch_assoc()) {
            $mappings[] = $row;
        }
    }
    $mappingStmt->close();
}

$enabledMappingCount = 0;
$checkedNetworkIds = [];
foreach ($mappings as $mapping) {
    if (($mapping['mapping_status'] ?? '') === 'enabled') {
        $enabledMappingCount++;
        if ($selectedChannelId > 0 && (int)$mapping['channel_id'] === $selectedChannelId) {
            $checkedNetworkIds[(int)$mapping['payment_method_id']] = true;
        }
    }
}
$selectedChannel = null;
foreach ($channels as $channel) {
    if ((int)$channel['id'] === $selectedChannelId) {
        $selectedChannel = $channel;
        break;
    }
}

$selectedProviderKey = $selectedChannel ? paymentChannelProviderKey($selectedChannel) : '';
$defaultWebhookUrl = '';
if ($selectedChannel && paymentChannelProviderAdapterReady($selectedProviderKey)) {
    try {
        $defaultWebhookUrl = wifiPaymentDefaultWebhookUrl($selectedProviderKey, (int)$selectedChannel['id']);
    } catch (Throwable $exception) {
        $defaultWebhookUrl = '';
    }
}
?>

<div class="payment-channels-page">
    <header class="payment-channels-header">
        <div class="payment-channels-title-wrap">
            <div class="payment-channels-title-icon"><i class="fa-solid fa-plug"></i></div>
            <div>
                <div class="payment-channels-eyebrow">Payments / Aggregator setup</div>
                <h1>Payment Channels</h1>
                <p>Choose which mobile networks each aggregator supports.</p>
            </div>
        </div>
        <div class="payment-channels-header-actions">
            <a class="payment-channels-primary" href="#add-aggregator"><i class="fa-solid fa-plus"></i> Add aggregator</a>
            <a class="payment-channels-secondary" href="<?= e(appUrl('admin/dashboard.php?page=payment_methods')) ?>"><i class="fa-solid fa-mobile-screen-button"></i> Customer networks</a>
        </div>
    </header>

    <div class="payment-channels-note"><i class="fa-solid fa-circle-info"></i><span>Customers choose only their mobile network; Payment Routing chooses the aggregator. ClickPesa, Snippe, ZenoPay, Selcom and AzamPay have direct mobile-money adapters. Pesapal can be API-verified here, but its hosted checkout is not part of the direct USSD routing flow.</span></div>

    <section class="payment-channels-card payment-channels-create-card" id="add-aggregator">
        <div class="payment-channels-card-heading"><div><h2>Add an aggregator</h2><p>Create an account entry for one of the six supported provider brands.</p></div><span class="payment-channels-step"><i class="fa-solid fa-plus"></i></span></div>
        <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=payment_channels')) ?>" class="payment-channels-create-form">
            <?= csrfField() ?>
            <input type="hidden" name="form_action" value="create_channel">
            <label class="payment-channels-field"><span>Aggregator <b>*</b></span><select name="provider_name" required><option value="">Choose provider</option><?php foreach (paymentChannelProviderCatalog() as $providerKey => $provider): ?><option value="<?= e($provider['name']) ?>"><?= e($provider['name']) ?><?= $provider['adapter_ready'] ? ' · connected' : ' · setup only' ?></option><?php endforeach; ?></select><small>Each account starts disabled. You can add another account for the same provider if needed.</small></label>
            <label class="payment-channels-field"><span>Account name <b>*</b></span><input type="text" name="channel_name" maxlength="100" required placeholder="e.g. ClickPesa Main"><small>This label appears in routing and channel lists.</small></label>
            <label class="payment-channels-field"><span>Environment <b>*</b></span><select name="environment" required><option value="sandbox" selected>Test / Sandbox</option><option value="live">Live</option></select><small>New aggregators start disabled and unconfigured.</small></label>
            <div class="payment-channels-create-footer"><p><i class="fa-solid fa-shield-halved"></i> This creates a disabled entry only. It cannot accept payments by itself.</p><button class="payment-channels-primary" type="submit"><i class="fa-solid fa-plus"></i> Add aggregator</button></div>
        </form>
    </section>

    <section class="payment-channels-stats" aria-label="Payment channel totals">
        <article><span>Aggregator channels</span><strong><?= number_format($totalChannels) ?></strong></article>
        <article><span>Connected payment adapters</span><strong><?= number_format($readyChannels) ?></strong></article>
        <article><span>Enabled network mappings<?= $selectedChannelId > 0 ? ' in view' : '' ?></span><strong><?= number_format($enabledMappingCount) ?></strong></article>
    </section>

    <?php foreach ($errors as $error): ?><div class="payment-channels-alert" role="alert"><i class="fa-solid fa-circle-exclamation"></i><?= e($error) ?></div><?php endforeach; ?>
    <?php if ($success !== ''): ?><div class="payment-channels-success" role="status"><i class="fa-solid fa-circle-check"></i><?= e($success) ?></div><?php endif; ?>
    <?php if (!$secretEncryptionReady): ?><div class="payment-channels-alert" role="alert"><i class="fa-solid fa-lock"></i><span>Encrypted credential storage is unavailable. Add a valid <code>APP_ENCRYPTION_KEY</code> with 64 hexadecimal characters to the app’s <code>.env</code> file, then reload this page before saving API secrets.</span></div><?php endif; ?>

    <?php if (!$channels): ?>
        <section class="payment-channels-empty"><span><i class="fa-solid fa-plug-circle-xmark"></i></span><h2>No aggregator channels found</h2><p>Create or configure an aggregator channel before assigning supported networks.</p></section>
    <?php else: ?>
        <section class="payment-channels-card">
            <div class="payment-channels-card-heading"><div><h2>Aggregator channels</h2><p>Use the channel entry that represents the API account you plan to connect.</p></div><span class="payment-channels-count"><i class="fa-solid fa-shield-halved"></i> Credentials hidden</span></div>
            <div class="payment-channels-grid">
                    <?php foreach ($channels as $channel): ?>
                    <?php
                        $channelEnabled = (string)($channel['status'] ?? '') === 'enabled';
                        $channelConfigured = (int)($channel['configured'] ?? 0) === 1;
                        $providerKey = paymentChannelProviderKey($channel);
                        $providerAdapterReady = paymentChannelProviderAdapterReady($providerKey);
                    ?>
                    <article class="payment-channel-card <?= $selectedChannelId === (int)$channel['id'] ? 'is-selected' : '' ?>">
                        <div class="payment-channel-card-top"><span class="payment-channel-card-icon"><i class="fa-solid fa-building-columns"></i></span><span class="channel-state <?= $channelEnabled ? 'is-enabled' : 'is-disabled' ?>"><?= e(paymentChannelStatusLabel((string)($channel['status'] ?? ''))) ?></span></div>
                        <h3><?= e((string)$channel['name']) ?></h3>
                        <p><?= e(paymentChannelProviderLabel($providerKey)) ?> <span>·</span> Channel #<?= (int)$channel['id'] ?></p>
                        <div class="payment-channel-meta"><span><i class="fa-regular fa-clock"></i> <?= e(paymentChannelEnvironmentLabel((string)($channel['environment'] ?? ''))) ?></span><span class="<?= $providerAdapterReady ? 'is-configured' : 'is-unconfigured' ?>"><i class="fa-solid <?= $providerAdapterReady ? 'fa-circle-check' : 'fa-triangle-exclamation' ?>"></i> <?= $providerAdapterReady ? 'Adapter connected' : 'Adapter not installed' ?></span></div>
                        <a class="payment-channels-manage" href="<?= e(appUrl('admin/dashboard.php?page=payment_channels&channel_id=' . (int)$channel['id'])) ?>"><i class="fa-solid fa-list-check"></i> Networks &amp; API settings</a>
                        <div class="payment-channel-actions">
                            <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=payment_channels&channel_id=' . (int)$channel['id'])) ?>">
                                <?= csrfField() ?><input type="hidden" name="form_action" value="set_channel_status"><input type="hidden" name="channel_id" value="<?= (int)$channel['id'] ?>"><input type="hidden" name="status" value="<?= $channelEnabled ? 'disabled' : 'enabled' ?>">
                                <button class="payment-channel-action-button <?= $channelEnabled ? 'is-disable' : 'is-enable' ?>" type="submit" <?= !$channelEnabled && !$providerAdapterReady ? 'disabled title="Adapter not installed"' : '' ?>><i class="fa-solid <?= $channelEnabled ? 'fa-pause' : 'fa-play' ?>"></i> <?= $channelEnabled ? 'Disable' : ($providerAdapterReady ? 'Enable' : 'Setup only') ?></button>
                            </form>
                            <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=payment_channels')) ?>" onsubmit="return confirm('Remove this aggregator and its network mappings? This cannot be undone.');">
                                <?= csrfField() ?><input type="hidden" name="form_action" value="delete_channel"><input type="hidden" name="channel_id" value="<?= (int)$channel['id'] ?>">
                                <button class="payment-channel-action-button is-remove" type="submit"><i class="fa-solid fa-trash-can"></i> Remove</button>
                            </form>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="payment-channels-card payment-channel-credentials-card">
            <div class="payment-channels-card-heading">
                <div><h2>Aggregator API settings</h2><p>Save the endpoint and connection details provided for this aggregator account.</p></div>
                <span class="payment-channels-count"><i class="fa-solid fa-lock"></i> API secrets encrypted</span>
            </div>
            <?php if ($selectedChannelId <= 0 || !$selectedChannel): ?>
                <div class="payment-channels-inline-empty">Select any aggregator above using “Manage supported networks” to enter its API URL and credentials.</div>
            <?php else: ?>
                <div class="payment-channel-credential-statuses" aria-label="API settings status">
                    <span class="<?= trim((string)($selectedChannel['api_base_url'] ?? '')) !== '' ? 'is-saved' : 'is-missing' ?>"><i class="fa-solid <?= trim((string)($selectedChannel['api_base_url'] ?? '')) !== '' ? 'fa-circle-check' : 'fa-circle-minus' ?>"></i> API URL <?= trim((string)($selectedChannel['api_base_url'] ?? '')) !== '' ? 'saved' : 'missing' ?></span>
                    <span class="<?= (int)$selectedChannel['client_id_saved'] === 1 ? 'is-saved' : 'is-missing' ?>"><i class="fa-solid <?= (int)$selectedChannel['client_id_saved'] === 1 ? 'fa-circle-check' : 'fa-circle-minus' ?>"></i> Client ID <?= (int)$selectedChannel['client_id_saved'] === 1 ? 'saved' : 'not saved' ?></span>
                    <span class="<?= (int)$selectedChannel['merchant_id_saved'] === 1 ? 'is-saved' : 'is-missing' ?>"><i class="fa-solid <?= (int)$selectedChannel['merchant_id_saved'] === 1 ? 'fa-circle-check' : 'fa-circle-minus' ?>"></i> Merchant ID <?= (int)$selectedChannel['merchant_id_saved'] === 1 ? 'saved' : 'not saved' ?></span>
                    <span class="<?= (int)$selectedChannel['api_key_saved'] === 1 ? 'is-saved' : 'is-missing' ?>"><i class="fa-solid <?= (int)$selectedChannel['api_key_saved'] === 1 ? 'fa-circle-check' : 'fa-circle-minus' ?>"></i> API Key <?= (int)$selectedChannel['api_key_saved'] === 1 ? 'saved' : 'not saved' ?></span>
                    <span class="<?= (int)$selectedChannel['api_secret_saved'] === 1 ? 'is-saved' : 'is-missing' ?>"><i class="fa-solid <?= (int)$selectedChannel['api_secret_saved'] === 1 ? 'fa-circle-check' : 'fa-circle-minus' ?>"></i> API Secret <?= (int)$selectedChannel['api_secret_saved'] === 1 ? 'saved' : 'not saved' ?></span>
                    <span class="<?= (int)$selectedChannel['checksum_saved'] === 1 ? 'is-saved' : 'is-missing' ?>"><i class="fa-solid <?= (int)$selectedChannel['checksum_saved'] === 1 ? 'fa-circle-check' : 'fa-circle-minus' ?>"></i> Checksum <?= (int)$selectedChannel['checksum_saved'] === 1 ? 'saved' : 'not saved' ?></span>
                    <span class="is-pending"><i class="fa-solid fa-clock"></i> API verification pending</span>
                </div>
                <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=payment_channels&channel_id=' . (int)$selectedChannel['id'])) ?>" class="payment-channel-credentials-form" autocomplete="off">
                    <?= csrfField() ?>
                    <input type="hidden" name="channel_id" value="<?= (int)$selectedChannel['id'] ?>">
                    <div class="payment-channel-credentials-grid">
                        <label class="payment-channel-credential-field"><span>API Base URL <b>*</b></span><input name="api_base_url" type="url" maxlength="255" required value="<?= e((string)($selectedChannel['api_base_url'] ?? '')) ?>" placeholder="https://api.example.com"><small>Copy the full base URL from the aggregator’s API documentation. Use HTTPS for Live.</small></label>
                        <label class="payment-channel-credential-field"><span>Authentication type <b>*</b></span><input name="authentication_type" type="text" maxlength="50" required list="aggregator-auth-types" value="<?= e((string)($selectedChannel['authentication_type'] ?? '')) ?>" placeholder="e.g. Client ID + API Key + Checksum"><datalist id="aggregator-auth-types"><option value="API Key"><option value="Client ID + API Key"><option value="Client ID + API Secret (OAuth2)"><option value="Username + Password (Basic)"><option value="API Key + Checksum"><option value="Other"></datalist><small>Use the method named in the provider’s API instructions.</small></label>
                        <label class="payment-channel-credential-field"><span>Callback / Webhook URL</span><input name="callback_url" type="url" maxlength="255" value="<?= e((string)($selectedChannel['callback_url'] ?? '')) ?>" placeholder="https://your-domain.example/..." autocomplete="url"><small><?php if ($defaultWebhookUrl !== ''): ?>Default URL: <code><?= e($defaultWebhookUrl) ?></code>. Leave blank to use this generated URL. For AzamPay, register it in the provider dashboard.<?php else: ?>Enter the public HTTPS endpoint for provider notifications.<?php endif; ?></small></label>
                        <label class="payment-channel-credential-field"><span>Client ID</span><input name="client_id" type="text" maxlength="255" value="" autocomplete="off" spellcheck="false" placeholder="Enter Client ID"><small><?= (int)$selectedChannel['client_id_saved'] === 1 ? 'A value is saved. Enter a new one only to replace it.' : 'Fill this only if the provider issued a Client ID.' ?></small></label>
                        <label class="payment-channel-credential-field"><span>Merchant ID</span><input name="merchant_id" type="text" maxlength="255" value="" autocomplete="off" spellcheck="false" placeholder="Enter Merchant ID"><small><?= (int)$selectedChannel['merchant_id_saved'] === 1 ? 'A value is saved. Enter a new one only to replace it.' : 'Optional; fill it if the provider issued one.' ?></small></label>
                        <label class="payment-channel-credential-field"><span>API Key</span><input name="api_key" type="password" maxlength="4096" autocomplete="new-password" spellcheck="false" placeholder="Enter API Key"><small><?= (int)$selectedChannel['api_key_saved'] === 1 ? 'Saved key is hidden. Leave blank to keep it.' : 'Enter only if required by the provider.' ?></small></label>
                        <label class="payment-channel-credential-field"><span>API Secret</span><input name="api_secret" type="password" maxlength="4096" autocomplete="new-password" spellcheck="false" placeholder="Enter API Secret"><small><?= (int)$selectedChannel['api_secret_saved'] === 1 ? 'Saved secret is hidden. Leave blank to keep it.' : 'Enter only if required by the provider.' ?></small></label>
                        <label class="payment-channel-credential-field"><span>Checksum Security Key</span><input name="checksum_key" type="password" maxlength="4096" autocomplete="new-password" spellcheck="false" placeholder="Enter Checksum Security Key"><small><?= (int)$selectedChannel['checksum_saved'] === 1 ? 'Saved key is hidden. Leave blank to keep it.' : 'Enter only if required by the provider.' ?></small></label>
                    </div>
                    <div class="payment-channel-credential-footer"><p><i class="fa-solid fa-shield-halved"></i> Fill only the credentials the provider requires. API Key, API Secret and Checksum are encrypted; saved secrets are never shown again. API verification is read-only and does not create a payment.</p><div class="payment-channel-credential-actions"><button class="payment-channels-secondary" type="submit" name="form_action" value="save_channel_api_settings"><i class="fa-solid fa-floppy-disk"></i> Save API settings</button><?php if (paymentChannelProviderApiTestReady(paymentChannelProviderKey($selectedChannel))): ?><button class="payment-channels-primary" type="submit" name="form_action" value="verify_channel_api"><i class="fa-solid fa-plug-circle-check"></i> Verify API</button><?php else: ?><button class="payment-channels-primary" type="button" disabled title="API verification is not supported yet"><i class="fa-solid fa-hourglass-half"></i> API verification not ready</button><?php endif; ?></div></div>
                </form>
            <?php endif; ?>
        </section>

        <div class="payment-channels-workspace">
            <section class="payment-channels-card payment-channels-add-card">
                <div class="payment-channels-card-heading"><div><h2>Networks this channel supports</h2><p>Select every network the selected aggregator can process.</p></div><span class="payment-channels-step">1</span></div>
                <?php if ($selectedChannelId <= 0 || !$selectedChannel): ?>
                    <div class="payment-channels-inline-empty">Choose an aggregator by clicking “Manage supported networks” on its card above.</div>
                <?php elseif (!$networks): ?>
                    <div class="payment-channels-inline-empty">Add customer networks in Payment Methods first.</div>
                <?php else: ?>
                    <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=payment_channels&channel_id=' . (int)$selectedChannel['id'])) ?>" class="payment-channels-form">
                        <?= csrfField() ?>
                        <input type="hidden" name="form_action" value="save_networks">
                        <input type="hidden" name="channel_id" value="<?= (int)$selectedChannel['id'] ?>">
                        <div class="payment-channels-selected-channel"><i class="fa-solid fa-plug"></i><span><strong><?= e((string)$selectedChannel['name']) ?></strong><small>Channel #<?= (int)$selectedChannel['id'] ?> · <?= e(paymentChannelEnvironmentLabel((string)($selectedChannel['environment'] ?? ''))) ?></small></span></div>
                        <fieldset class="payment-channels-network-list">
                            <legend>Tick all supported mobile networks</legend>
                            <?php foreach ($networks as $network): ?>
                                <?php $networkId = (int)$network['id']; ?>
                                <label class="payment-channel-network-option">
                                    <input type="checkbox" name="payment_method_ids[]" value="<?= $networkId ?>" <?= isset($checkedNetworkIds[$networkId]) ? 'checked' : '' ?>>
                                    <span><strong><?= e((string)$network['display_name']) ?></strong><small><?= e((string)$network['name']) ?><?php if (!empty($network['provider_code'])): ?> · <?= e((string)$network['provider_code']) ?><?php endif; ?></small></span>
                                    <i class="fa-solid fa-check" aria-hidden="true"></i>
                                </label>
                            <?php endforeach; ?>
                        </fieldset>
                        <p class="payment-channels-checkbox-help">Only check networks this specific account supports. Unchecked mappings will be disabled, not deleted. A mapping appears in customer checkout only after its provider adapter is available and its account is enabled and configured.</p>
                        <button class="payment-channels-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save supported networks</button>
                    </form>
                <?php endif; ?>
            </section>

            <section class="payment-channels-card payment-channels-mappings-card">
                <div class="payment-channels-card-heading">
                    <div><h2>Network support mappings</h2><p><?= number_format(count($mappings)) ?> mapping<?= count($mappings) === 1 ? '' : 's' ?><?= $selectedChannelId > 0 ? ' for selected channel' : ' across all channels' ?></p></div>
                    <form method="get" action="<?= e(appUrl('admin/dashboard.php')) ?>" class="payment-channels-filter"><input type="hidden" name="page" value="payment_channels"><select name="channel_id" aria-label="Filter mappings by channel"><option value="0">All channels</option><?php foreach ($channels as $channel): ?><option value="<?= (int)$channel['id'] ?>" <?= $selectedChannelId === (int)$channel['id'] ? 'selected' : '' ?>><?= e((string)$channel['name']) ?> · #<?= (int)$channel['id'] ?></option><?php endforeach; ?></select><button type="submit" aria-label="Filter"><i class="fa-solid fa-filter"></i></button></form>
                </div>
                <?php if ($mappings): ?>
                    <div class="payment-channels-table-wrap"><table class="payment-channels-table"><thead><tr><th>Aggregator</th><th>Customer network</th><th>API network code</th><th>Channel readiness</th><th>Mapping</th><th>Save</th></tr></thead><tbody>
                        <?php foreach ($mappings as $mapping): ?>
                            <?php
                                $mappingProviderKey = paymentChannelProviderKey([
                                    'name' => (string)$mapping['channel_name'],
                                    'type' => (string)$mapping['channel_type'],
                                ]);
                                $isReady = (string)$mapping['channel_status'] === 'enabled'
                                    && (int)$mapping['configured'] === 1
                                    && paymentChannelProviderAdapterReady($mappingProviderKey);
                            ?>
                            <tr>
                                <td><strong><?= e((string)$mapping['channel_name']) ?></strong><small>Channel #<?= (int)$mapping['channel_id'] ?> · <?= e(paymentChannelEnvironmentLabel((string)($mapping['environment'] ?? ''))) ?></small></td>
                                <td><strong><?= e((string)$mapping['network_name']) ?></strong><small><?= e((string)$mapping['network_key']) ?><?php if (!empty($mapping['network_code'])): ?> · <?= e((string)$mapping['network_code']) ?><?php endif; ?></small></td>
                                <td>
                                    <form id="payment-channel-mapping-<?= (int)$mapping['id'] ?>" method="post" action="<?= e(appUrl('admin/dashboard.php?page=payment_channels')) ?>" class="payment-channels-inline-form">
                                        <?= csrfField() ?><input type="hidden" name="form_action" value="update_mapping"><input type="hidden" name="mapping_id" value="<?= (int)$mapping['id'] ?>"><input type="hidden" name="channel_id" value="<?= (int)$mapping['channel_id'] ?>">
                                        <input name="provider_code" maxlength="100" value="<?= e((string)($mapping['provider_code'] ?? '')) ?>" placeholder="Use shared code">
                                    </form>
                                </td>
                                <td><span class="channel-readiness <?= $isReady ? 'is-ready' : 'is-pending' ?>"><i class="fa-solid <?= $isReady ? 'fa-circle-check' : 'fa-clock' ?>"></i> <?= $isReady ? 'Configured' : 'API not ready' ?></span></td>
                                <td><select name="status" form="payment-channel-mapping-<?= (int)$mapping['id'] ?>" aria-label="Mapping status"><option value="enabled" <?= $mapping['mapping_status'] === 'enabled' ? 'selected' : '' ?>>Enabled</option><option value="disabled" <?= $mapping['mapping_status'] === 'disabled' ? 'selected' : '' ?>>Disabled</option></select></td>
                                <td><button class="payment-channels-save-icon" type="submit" form="payment-channel-mapping-<?= (int)$mapping['id'] ?>" title="Save mapping"><i class="fa-solid fa-floppy-disk"></i></button></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody></table></div>
                <?php else: ?>
                    <div class="payment-channels-empty-inline"><span><i class="fa-solid fa-link-slash"></i></span><h3>No network mappings yet</h3><p>Select a channel and add the networks its API supports. For example, do not map M‑Pesa to ClickPesa if that account does not support it.</p></div>
                <?php endif; ?>
            </section>
        </div>
    <?php endif; ?>
</div>
