<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/admin_auth.php';

$destination = isAdminLoggedIn()
    ? 'admin/dashboard.php'
    : 'admin/login.php';

header('Location: ' . appUrl($destination), true, 302);
exit;
