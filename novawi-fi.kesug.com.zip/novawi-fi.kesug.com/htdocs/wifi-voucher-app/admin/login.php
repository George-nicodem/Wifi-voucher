<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/admin_email_auth.php';
startAdminSession();

if (isAdminLoggedIn()) {
    header('Location: ' . appUrl('admin/dashboard.php'), true, 302);
    exit;
}

$error = '';
$notice = isset($_GET['first_admin'])
    ? 'The first administrator account is ready. Sign in with your email and password, then enter the code sent to your email.'
    : (isset($_GET['password_reset']) ? 'The administrator password has been changed. Sign in with your new password.' : '');
$email = '';
$schemaReady = adminEmailAuthSchemaReady();
if (isset($_GET['timeout']) && $notice === '') {
    $notice = 'Your session has expired. Sign in again to continue.';
}

if (isPost()) {
    requireCsrfToken();
    $action = postString('form_action', 'request_code');
    $loginIpAddress = (string)($_SERVER['REMOTE_ADDR'] ?? '');

    if (!$schemaReady) {
        $error = 'Administrator email sign-in is not configured. Run admin/database/admin_accounts.sql and make sure the existing administrator has an email in admin_users.';
    } elseif ($action === 'request_code') {
        $email = adminAccountEmail(postString('email'));
        $password = $_POST['password'] ?? '';
        $password = is_string($password) ? $password : '';
        $throttle = $email !== '' ? adminLoginThrottleStatus($email, $loginIpAddress) : ['locked' => false, 'minutes_left' => 0];

        if (!empty($throttle['locked'])) {
            $error = 'Too many sign-in attempts. Wait ' . (int)$throttle['minutes_left'] . ' minutes, then try again.';
        } elseif (filter_var($email, FILTER_VALIDATE_EMAIL) === false || strlen($email) > 190 || $password === '' || strlen($password) > 1024) {
            $error = 'The email or password is incorrect.';
        } else {
            $stmt = $conn->prepare('SELECT id, username, email, password_hash, full_name, role, status FROM admin_users WHERE email = ? LIMIT 1');
            if (!$stmt) {
                logDatabaseError($conn, 'Preparing administrator email login lookup');
                $error = 'Unable to sign in right now. Please try again later.';
            } else {
                $stmt->bind_param('s', $email);
                if (!$stmt->execute()) {
                    logDatabaseError($conn, 'Loading administrator for email login');
                    $error = 'Unable to sign in right now. Please try again later.';
                    $admin = null;
                } else {
                    $result = $stmt->get_result();
                    $admin = $result ? $result->fetch_assoc() : null;
                }
                $stmt->close();

                if ($error === '') {
                    if (!$admin || empty($admin['password_hash']) || !password_verify($password, (string)$admin['password_hash'])) {
                        recordFailedAdminLogin($email, $loginIpAddress);
                        $afterFailure = adminLoginThrottleStatus($email, $loginIpAddress);
                        $error = !empty($afterFailure['locked'])
                            ? 'Too many sign-in attempts. Wait ' . (int)$afterFailure['minutes_left'] . ' minutes, then try again.'
                            : 'The email or password is incorrect.';
                    } elseif ((string)$admin['status'] === 'pending') {
                        $error = 'Your administrator account request is awaiting approval.';
                    } elseif ((string)$admin['status'] !== 'active') {
                        $error = 'This administrator account is disabled. Contact the system administrator.';
                    } else {
                        $issue = adminIssueEmailCode($admin);
                        if (!empty($issue['sent']) || !empty($issue['cooldown'])) {
                            $_SESSION['admin_login_pending_id'] = (int)$admin['id'];
                            $_SESSION['admin_login_pending_email'] = (string)$admin['email'];
                            $notice = (string)$issue['message'];
                        } else {
                            $error = (string)$issue['message'];
                        }
                    }
                }
            }
        }
    } elseif ($action === 'verify_code') {
        $pendingId = (int)($_SESSION['admin_login_pending_id'] ?? 0);
        $code = postString('email_code');
        if ($pendingId <= 0) {
            adminClearPendingEmailLogin();
            $error = 'Start again with your email and password.';
        } else {
            $lookup = $conn->prepare('SELECT id, username, email, full_name, role, status FROM admin_users WHERE id = ? LIMIT 1');
            $admin = null;
            if ($lookup) {
                $lookup->bind_param('i', $pendingId);
                if ($lookup->execute()) {
                    $result = $lookup->get_result();
                    $admin = $result ? $result->fetch_assoc() : null;
                }
                $lookup->close();
            }
            if (!$admin || (string)$admin['status'] !== 'active') {
                adminClearPendingEmailLogin();
                $error = 'The account is unavailable or disabled. Contact the system administrator.';
            } else {
                $verification = adminVerifyEmailCode($pendingId, $code);
                if (!empty($verification['ok'])) {
                    adminClearPendingEmailLogin();
                    clearAdminLoginThrottle((string)$admin['email'], $loginIpAddress);
                    loginAdmin((int)$admin['id'], (string)($admin['full_name'] ?: $admin['username']), (string)$admin['role']);
                    logAdminSecurityEvent('ADMIN_LOGIN', 'Administrator email and one-time code login successful.');
                    header('Location: ' . appUrl('admin/dashboard.php'), true, 303);
                    exit;
                }
                $error = (string)$verification['message'];
            }
        }
    } elseif ($action === 'resend_code') {
        $pendingId = (int)($_SESSION['admin_login_pending_id'] ?? 0);
        $lookup = $pendingId > 0
            ? $conn->prepare("SELECT id, username, email, full_name, role, status FROM admin_users WHERE id = ? AND status = 'active' LIMIT 1")
            : false;
        $admin = null;
        if ($lookup) {
            $lookup->bind_param('i', $pendingId);
            if ($lookup->execute()) {
                $result = $lookup->get_result();
                $admin = $result ? $result->fetch_assoc() : null;
            }
            $lookup->close();
        }
        if (!$admin) {
            adminClearPendingEmailLogin();
            $error = 'Start again with your email and password.';
        } else {
            $issue = adminIssueEmailCode($admin);
            if (!empty($issue['sent']) || !empty($issue['cooldown'])) {
                $_SESSION['admin_login_pending_email'] = (string)$admin['email'];
                $notice = (string)$issue['message'];
            } else {
                $error = (string)$issue['message'];
            }
        }
    } elseif ($action === 'cancel_code') {
        adminClearPendingEmailLogin();
        $notice = 'Email verification was cancelled. Sign in again to continue.';
    } else {
        $error = 'Unrecognized sign-in request.';
    }
}

$pendingId = (int)($_SESSION['admin_login_pending_id'] ?? 0);
$pendingEmail = (string)($_SESSION['admin_login_pending_email'] ?? '');
$showCodeForm = $pendingId > 0;
$maskedEmail = $pendingEmail;
if (str_contains($pendingEmail, '@')) {
    [$emailName, $emailDomain] = explode('@', $pendingEmail, 2);
    $maskedEmail = substr($emailName, 0, 1) . str_repeat('*', max(2, min(8, strlen($emailName) - 1))) . '@' . $emailDomain;
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Admin login | <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= e(appUrl('admin/assets/auth-theme.css?v=6')) ?>">
</head>
<body class="auth-page">
<main class="login-container">
    <section class="login-card">
        <div class="auth-brand"><span class="auth-brand-mark" aria-hidden="true">Wi-Fi</span><span><strong>WiFi Voucher</strong><small>System Administration</small></span></div>
        <header class="login-title"><h1><?= $showCodeForm ? 'Verify your email' : 'Sign in to the system' ?></h1><p><?= $showCodeForm ? 'Enter the code we sent to ' . e($maskedEmail) . '.' : e(APP_NAME) ?></p></header>
        <?php if ($notice !== ''): ?><div class="message success" role="status"><?= e($notice) ?></div><?php endif; ?>
        <?php if (isset($_GET['timeout'])): ?><div class="timeout" role="status">Your session has expired. Sign in again to continue.</div><?php endif; ?>
        <?php if (!$schemaReady): ?><div class="error" role="alert">Administrator email sign-in is not set up. Run <code>admin/database/admin_accounts.sql</code> and make sure <code>admin_users</code> has an email address for the existing administrator.</div><?php endif; ?>
        <?php if ($error !== ''): ?><div class="error" role="alert"><?= e($error) ?></div><?php endif; ?>
        <?php if ($showCodeForm): ?>
            <form method="post" action="<?= e(appUrl('admin/login.php')) ?>" autocomplete="one-time-code">
                <?= csrfField() ?><input type="hidden" name="form_action" value="verify_code">
                <div class="form-group"><label for="email_code">Email code</label><input id="email_code" name="email_code" type="text" inputmode="numeric" pattern="[0-9]{6}" minlength="6" maxlength="6" autocomplete="one-time-code" required autofocus></div>
                <small class="password-change-note">The code can be used once, expires in 5 minutes, and allows 5 attempts.</small>
                <button type="submit" <?= !$schemaReady ? 'disabled' : '' ?>>Verify and sign in</button>
            </form>
            <div class="auth-links">
                <form method="post" action="<?= e(appUrl('admin/login.php')) ?>"><?= csrfField() ?><input type="hidden" name="form_action" value="resend_code"><button class="auth-text-button" type="submit">Resend code</button></form>
                <form method="post" action="<?= e(appUrl('admin/login.php')) ?>"><?= csrfField() ?><input type="hidden" name="form_action" value="cancel_code"><button class="auth-text-button" type="submit">Switch account</button></form>
            </div>
        <?php else: ?>
            <div class="auth-links"><a href="<?= e(appUrl('admin/forgot_password.php')) ?>">Forgot your password?</a></div>
            <form method="post" action="<?= e(appUrl('admin/login.php')) ?>" autocomplete="on">
                <?= csrfField() ?><input type="hidden" name="form_action" value="request_code">
                <div class="form-group"><label for="email">Email</label><input id="email" name="email" type="email" maxlength="190" autocomplete="email" value="<?= e($email) ?>" required></div>
                <div class="form-group"><label for="password">Password</label><input id="password" name="password" type="password" maxlength="1024" autocomplete="current-password" required><label class="password-visibility"><input id="showPassword" type="checkbox" aria-controls="password"> <span>Show password</span></label></div>
                <button type="submit" <?= !$schemaReady ? 'disabled' : '' ?>>Send sign-in code</button>
            </form>
            <div class="auth-links"><a href="<?= e(appUrl('admin/register.php')) ?>">Request a new administrator account</a><a href="<?= e(appUrl('admin/change_password.php')) ?>">Change password</a><small>Sign-in requires your password and an email code.</small></div>
        <?php endif; ?>
        <footer class="footer"><?= e(APP_NAME) ?> · Admin Panel</footer>
    </section>
</main>
<script>
(() => {
    const password = document.getElementById('password');
    const showPassword = document.getElementById('showPassword');
    if (!password || !showPassword) return;
    showPassword.addEventListener('change', () => {
        password.type = showPassword.checked ? 'text' : 'password';
    });
})();
</script>
<script src="<?= e(appUrl('admin/assets/admin-password.js?v=1')) ?>" defer></script>
</body>
</html>
