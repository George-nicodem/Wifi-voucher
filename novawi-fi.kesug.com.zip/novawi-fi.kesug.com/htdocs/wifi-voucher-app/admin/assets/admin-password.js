(() => {
  const style = document.createElement('style');
  style.textContent = ".admin-password-wrap{position:relative;display:block;width:100%}.admin-password-wrap>input{box-sizing:border-box;width:100%;padding-right:3rem!important}.admin-password-toggle{position:absolute;top:50%;right:.7rem;transform:translateY(-50%);display:grid;place-items:center;width:2rem;height:2rem;padding:0;border:0;background:transparent;color:#64748b;cursor:pointer}.admin-password-toggle:hover{color:#0f766e}.admin-password-toggle:focus-visible{outline:2px solid #0f766e;outline-offset:2px;border-radius:.35rem}.admin-password-toggle svg{width:1.2rem;height:1.2rem;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}";
  document.head.append(style);

  const eye = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>';
  const eyeOff = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 3 18 18M10.6 10.6a2 2 0 0 0 2.8 2.8"/><path d="M9.9 5.2A10.7 10.7 0 0 1 12 5c6.4 0 10 7 10 7a15.8 15.8 0 0 1-3 3.8M6.2 6.2C3.5 8 2 12 2 12s3.6 7 10 7c1.1 0 2.1-.2 3-.5"/></svg>';

  document.querySelectorAll('.password-visibility').forEach((oldControl) => oldControl.remove());
  document.querySelectorAll('input[type="password"]').forEach((input) => {
    if (input.dataset.adminPasswordToggle === 'ready') return;
    input.dataset.adminPasswordToggle = 'ready';
    const wrapper = document.createElement('span');
    wrapper.className = 'admin-password-wrap';
    input.parentNode.insertBefore(wrapper, input);
    wrapper.append(input);

    const button = document.createElement('button');
    button.className = 'admin-password-toggle';
    button.type = 'button';
    button.innerHTML = eye;
    button.setAttribute('aria-label', 'Show password');
    button.title = 'Show password';
    button.setAttribute('aria-pressed', 'false');
    button.addEventListener('click', () => {
      const reveal = input.type === 'password';
      input.type = reveal ? 'text' : 'password';
      button.innerHTML = reveal ? eyeOff : eye;
      button.setAttribute('aria-label', reveal ? 'Hide password' : 'Show password');
      button.title = reveal ? 'Hide password' : 'Show password';
      button.setAttribute('aria-pressed', String(reveal));
      input.focus();
    });
    wrapper.append(button);
  });
})();