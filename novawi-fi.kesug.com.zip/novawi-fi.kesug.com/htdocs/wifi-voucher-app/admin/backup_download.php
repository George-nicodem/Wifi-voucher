<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/admin_auth.php';
requireAdminLogin();

$backupDirectory = dirname(__DIR__)
    . DIRECTORY_SEPARATOR . 'storage'
    . DIRECTORY_SEPARATOR . 'backups';
$fileName = $_GET['file'] ?? '';
$pattern = '/^[A-Za-z0-9_-]+_backup_[0-9]{4}-[0-9]{2}-[0-9]{2}_[0-9]{2}-[0-9]{2}-[0-9]{2}(?:_before_restore_[a-f0-9]{8})?\.sql$/D';

if (!is_string($fileName) || !preg_match($pattern, $fileName)) {
    http_response_code(404);
    exit('Backup file not found.');
}

$directoryRealPath = realpath($backupDirectory);
$fileRealPath = realpath($backupDirectory . DIRECTORY_SEPARATOR . $fileName);
if (
    $directoryRealPath === false
    || $fileRealPath === false
    || dirname($fileRealPath) !== $directoryRealPath
    || !is_file($fileRealPath)
    || !is_readable($fileRealPath)
) {
    http_response_code(404);
    exit('Backup file not found.');
}

$fileSize = filesize($fileRealPath);
if ($fileSize === false || $fileSize < 1) {
    http_response_code(404);
    exit('Backup file not found.');
}

logAdminSecurityEvent(
    'DATABASE_BACKUP_DOWNLOADED',
    'Administrator downloaded database backup: ' . $fileName
);

header('Content-Type: application/sql; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $fileName . '"');
header('Content-Length: ' . (string)$fileSize);
header('Cache-Control: private, no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
readfile($fileRealPath);
exit;
