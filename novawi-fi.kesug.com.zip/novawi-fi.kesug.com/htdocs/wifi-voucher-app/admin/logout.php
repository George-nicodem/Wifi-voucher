<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/admin_auth.php';

if (isAdminLoggedIn()) {
    logAdminSecurityEvent(
        'ADMIN_LOGOUT',
        'Administrator logged out.'
    );
}

logoutAdmin();

header('Location: ' . appUrl('admin/login.php?logout=1'), true, 302);
exit;
