<?php
declare(strict_types=1);

/** Separate, non-sale Wi-Fi trial flow. Router provisioning is not included yet. */
require_once dirname(__DIR__) . '/config/app.php';
require_once dirname(__DIR__) . '/config/database.php';

function wifiTrialAppKey(): string
{
    $key = (string)($_ENV['APP_ENCRYPTION_KEY'] ?? getenv('APP_ENCRYPTION_KEY') ?: '');
    if (defined('APP_ENCRYPTION_KEY')) {
        $key = (string)constant('APP_ENCRYPTION_KEY');
    }
    if (strlen($key) < 32) {
        throw new RuntimeException('Weka APP_ENCRYPTION_KEY yenye angalau herufi 32 kwenye .env kabla ya kutumia trial.');
    }
    return $key;
}

function wifiTrialFingerprint(string $type, string $value): string
{
    return hash_hmac('sha256', $type . ':' . $value, wifiTrialAppKey());
}

function wifiTrialNormalizeMac(string $value): ?string
{
    $compact = strtoupper((string)preg_replace('/[^0-9a-f]/i', '', trim($value)));
    if (!preg_match('/^[0-9A-F]{12}$/D', $compact)) {
        return null;
    }
    return implode(':', str_split($compact, 2));
}

function wifiTrialEncryptCode(string $code): string
{
    if (!function_exists('openssl_encrypt')) {
        throw new RuntimeException('PHP OpenSSL haijawashwa; haiwezekani kuhifadhi code kwa usalama.');
    }
    $key = hash('sha256', wifiTrialAppKey(), true);
    $iv = random_bytes(12);
    $tag = '';
    $ciphertext = openssl_encrypt($code, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
    if ($ciphertext === false) {
        throw new RuntimeException('Imeshindikana kuficha code ya trial.');
    }
    return base64_encode($iv . $tag . $ciphertext);
}

function wifiTrialIssue(mysqli $db, string $deviceToken, ?string $mac): array
{
    if (!preg_match('/^[a-f0-9]{64}$/iD', $deviceToken)) {
        throw new RuntimeException('Kifaa hakikutuma kitambulisho chake. Washa JavaScript au tumia browser nyingine.');
    }
    $tokenHash = wifiTrialFingerprint('browser', strtolower($deviceToken));
    $macHash = $mac !== null ? wifiTrialFingerprint('mac', $mac) : null;
    $now = new DateTimeImmutable('now');

    $db->begin_transaction();
    try {
        // The singleton settings row serializes trial requests and prevents a double-click race.
        $settingsResult = $db->query('SELECT enabled, duration_minutes, cooldown_days FROM trial_settings WHERE id = 1 FOR UPDATE');
        $settings = $settingsResult ? $settingsResult->fetch_assoc() : null;
        if (!$settings) {
            throw new RuntimeException('Mipangilio ya trial haipo. Endesha admin/database/trial_voucher.sql kwanza.');
        }
        if ((int)$settings['enabled'] !== 1) {
            throw new RuntimeException('Jaribio la Wi-Fi limezimwa kwa sasa.');
        }

        $nowSql = $now->format('Y-m-d H:i:s');
        $expire = $db->prepare("UPDATE trial_vouchers SET status = 'expired' WHERE expires_at <= ? AND status IN ('pending_router', 'provisioned', 'active')");
        if ($expire) {
            $expire->bind_param('s', $nowSql);
            $expire->execute();
            $expire->close();
        }
        $check = $db->prepare('SELECT cooldown_until FROM trial_vouchers WHERE cooldown_until > ? AND (device_token_hash = ? OR (? IS NOT NULL AND mac_hash = ?)) ORDER BY issued_at DESC LIMIT 1');
        if (!$check) {
            throw new RuntimeException('Imeshindikana kukagua kama kifaa hiki kilijaribu hivi karibuni.');
        }
        $check->bind_param('ssss', $nowSql, $tokenHash, $macHash, $macHash);
        $check->execute();
        $previous = $check->get_result()->fetch_assoc();
        $check->close();
        if ($previous) {
            $until = new DateTimeImmutable((string)$previous['cooldown_until']);
            $remaining = max(1, (int)ceil(($until->getTimestamp() - $now->getTimestamp()) / 86400));
            throw new RuntimeException('Kifaa hiki kimeshatumia trial. Jaribu tena baada ya takribani siku ' . $remaining . '.');
        }

        $minutes = max(1, min(60, (int)$settings['duration_minutes']));
        $days = max(1, min(365, (int)$settings['cooldown_days']));
        $issuedSql = $now->format('Y-m-d H:i:s');
        $expiresSql = $now->modify('+' . $minutes . ' minutes')->format('Y-m-d H:i:s');
        $cooldownSql = $now->modify('+' . $days . ' days')->format('Y-m-d H:i:s');
        $code = 'TR-' . strtoupper(bin2hex(random_bytes(6)));
        $codeHash = hash('sha256', $code);
        $codeEncrypted = wifiTrialEncryptCode($code);

        $insert = $db->prepare("INSERT INTO trial_vouchers (code_hash, code_encrypted, device_token_hash, mac_hash, issued_at, expires_at, cooldown_until, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending_router')");
        if (!$insert) {
            throw new RuntimeException('Imeshindikana kuandaa rekodi ya trial.');
        }
        $insert->bind_param('sssssss', $codeHash, $codeEncrypted, $tokenHash, $macHash, $issuedSql, $expiresSql, $cooldownSql);
        if (!$insert->execute()) {
            throw new RuntimeException('Imeshindikana kuhifadhi trial kwenye database.');
        }
        $insert->close();
        $db->commit();
        return ['code' => $code, 'expires_at' => $expiresSql, 'minutes' => $minutes, 'status' => 'pending_router'];
    } catch (Throwable $exception) {
        $db->rollback();
        throw $exception;
    }
}
