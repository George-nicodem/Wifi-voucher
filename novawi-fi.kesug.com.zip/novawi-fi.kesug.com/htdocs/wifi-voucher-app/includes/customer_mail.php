<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';

/** Send a UTF-8 text email through configured SMTP or PHP's mail transport. */
function wifiSendEmail(string $recipient, string $subject, string $body): bool
{
    $recipient = trim($recipient);
    $fromAddress = trim((string)($_ENV['MAIL_FROM_ADDRESS'] ?? ''));
    $fromName = trim((string)($_ENV['MAIL_FROM_NAME'] ?? APP_NAME));
    $host = trim((string)($_ENV['SMTP_HOST'] ?? ''));
    $port = (int)($_ENV['SMTP_PORT'] ?? 587);
    $encryption = strtolower(trim((string)($_ENV['SMTP_ENCRYPTION'] ?? 'tls')));
    $username = (string)($_ENV['SMTP_USERNAME'] ?? '');
    $password = (string)($_ENV['SMTP_PASSWORD'] ?? '');

    if (
        filter_var($recipient, FILTER_VALIDATE_EMAIL) === false ||
        filter_var($fromAddress, FILTER_VALIDATE_EMAIL) === false ||
        preg_match('/[\r\n]/', $fromName) ||
        preg_match('/[\r\n]/', $subject)
    ) {
        return false;
    }

    $encodedSubject = function_exists('mb_encode_mimeheader')
        ? mb_encode_mimeheader($subject, 'UTF-8', 'B', "\r\n")
        : '=?UTF-8?B?' . base64_encode($subject) . '?=';
    $encodedFromName = function_exists('mb_encode_mimeheader')
        ? mb_encode_mimeheader($fromName, 'UTF-8', 'B', "\r\n")
        : '=?UTF-8?B?' . base64_encode($fromName) . '?=';

    $headers = [
        'From: ' . $encodedFromName . ' <' . $fromAddress . '>',
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
        'Content-Transfer-Encoding: 8bit',
    ];

    if ($host === '') {
        return function_exists('mail') && @mail($recipient, $encodedSubject, $body, implode("\r\n", $headers));
    }

    if ($port < 1 || $port > 65535 || !in_array($encryption, ['tls', 'ssl', 'none'], true)) {
        return false;
    }
    if (($username !== '' || $password !== '') && $encryption === 'none') {
        return false;
    }

    $scheme = $encryption === 'ssl' ? 'ssl://' : 'tcp://';
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
            'peer_name' => $host,
            'SNI_enabled' => true,
        ],
    ]);

    try {
        $socket = @stream_socket_client(
            $scheme . $host . ':' . $port,
            $errorNumber,
            $errorMessage,
            12,
            STREAM_CLIENT_CONNECT,
            $context
        );
        if (!is_resource($socket)) {
            return false;
        }
        stream_set_timeout($socket, 12);

        $read = static function () use ($socket): array {
            $response = '';
            $code = 0;
            do {
                $line = fgets($socket, 1024);
                if ($line === false) {
                    throw new RuntimeException('SMTP server did not return a response.');
                }
                $response .= $line;
                if (preg_match('/^(\d{3})([ -])/', $line, $matches)) {
                    $code = (int)$matches[1];
                    $more = $matches[2] === '-';
                } else {
                    $more = false;
                }
            } while ($more);
            return [$code, $response];
        };

        $command = static function (string $line, array $expected) use ($socket, $read): array {
            if (str_contains($line, "\r") || str_contains($line, "\n")) {
                throw new RuntimeException('Invalid SMTP command.');
            }
            if (fwrite($socket, $line . "\r\n") === false) {
                throw new RuntimeException('SMTP command could not be written.');
            }
            [$code, $response] = $read();
            if (!in_array($code, $expected, true)) {
                throw new RuntimeException('SMTP server rejected a message command (' . $code . ').');
            }
            return [$code, $response];
        };

        [$greeting] = $read();
        if ($greeting !== 220) {
            throw new RuntimeException('SMTP server is not ready.');
        }
        $helloHost = (string)(parse_url(APP_URL, PHP_URL_HOST) ?: 'localhost');
        if (!preg_match('/^[A-Za-z0-9.-]{1,253}$/', $helloHost)) {
            $helloHost = 'localhost';
        }
        $command('EHLO ' . $helloHost, [250]);

        if ($encryption === 'tls') {
            $command('STARTTLS', [220]);
            $cryptoEnabled = stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            if ($cryptoEnabled !== true) {
                throw new RuntimeException('SMTP TLS could not be enabled.');
            }
            $command('EHLO ' . $helloHost, [250]);
        }

        if ($username !== '' || $password !== '') {
            if ($username === '' || $password === '') {
                throw new RuntimeException('SMTP credentials are incomplete.');
            }
            $command('AUTH LOGIN', [334]);
            $command(base64_encode($username), [334]);
            $command(base64_encode($password), [235]);
        }

        $command('MAIL FROM:<' . $fromAddress . '>', [250]);
        $command('RCPT TO:<' . $recipient . '>', [250, 251]);
        $command('DATA', [354]);

        $normalizedBody = str_replace(["\r\n", "\r"], "\n", $body);
        $normalizedBody = str_replace("\n.", "\n..", $normalizedBody);
        $message = implode("\r\n", [
            'From: ' . $encodedFromName . ' <' . $fromAddress . '>',
            'To: <' . $recipient . '>',
            'Subject: ' . $encodedSubject,
            'Date: ' . date(DATE_RFC2822),
            'MIME-Version: 1.0',
            'Content-Type: text/plain; charset=UTF-8',
            'Content-Transfer-Encoding: 8bit',
            '',
            str_replace("\n", "\r\n", $normalizedBody),
            '.',
            '',
        ]);
        if (fwrite($socket, $message) === false) {
            throw new RuntimeException('SMTP message could not be written.');
        }
        [$accepted] = $read();
        if ($accepted !== 250) {
            throw new RuntimeException('SMTP server did not accept the message.');
        }
        $command('QUIT', [221]);
        fclose($socket);
        return true;
    } catch (Throwable $exception) {
        if (isset($socket) && is_resource($socket)) {
            fclose($socket);
        }
        if (function_exists('appLog')) {
            appLog('Authentication email could not be sent', [
                'error' => substr($exception->getMessage(), 0, 180),
            ]);
        }
        return false;
    }
}

/** Backward-compatible name for older customer-auth code in existing installs. */
function wifiCustomerSendEmail(string $recipient, string $subject, string $body): bool
{
    return wifiSendEmail($recipient, $subject, $body);
}
