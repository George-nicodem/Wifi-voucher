<?php
declare(strict_types=1);

/** Server-side adapters for the Tanzania mobile-money providers in this app. */
require_once __DIR__ . '/payment_provider_catalog.php';

function wifiPaymentHttpJson(string $url, string $method, ?array $payload = null, array $headers = []): array
{
    if (!function_exists('curl_init')) throw new RuntimeException('PHP cURL haijawashwa kwenye server.');
    $parts = parse_url($url);
    if (!is_array($parts) || strtolower((string)($parts['scheme'] ?? '')) !== 'https'
        || empty($parts['host']) || isset($parts['user']) || isset($parts['pass'])) {
        throw new RuntimeException('API URL lazima iwe HTTPS na iwe sahihi.');
    }
    $headers = array_merge(['Accept: application/json'], $headers);
    $options = [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 25,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_CUSTOMREQUEST => strtoupper($method),
        CURLOPT_HTTPHEADER => $headers,
    ];
    if ($payload !== null) {
        $options[CURLOPT_POSTFIELDS] = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $options[CURLOPT_HTTPHEADER][] = 'Content-Type: application/json';
    }
    $ch = curl_init();
    curl_setopt_array($ch, $options);
    $raw = curl_exec($ch);
    $error = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($raw === false) throw new RuntimeException('Could not reach the payment provider API. Check the server connection and SSL configuration.');
    if ($code === 401 || $code === 403) {
        throw new RuntimeException('The provider rejected the API credentials or this account lacks access (HTTP ' . $code . '). Check the active account/workspace, API credentials, environment, and payout permissions in Payment Channels.');
    }
    if ($code === 429) {
        throw new RuntimeException('The provider is rate-limiting API requests (HTTP 429). Wait briefly and retry.');
    }
    if (in_array($code, [502, 503, 504], true)) {
        throw new RuntimeException('The provider API is temporarily unavailable (HTTP ' . $code . '). Wait briefly and retry.');
    }
    if ($code >= 500) {
        throw new RuntimeException('The provider API returned a server error (HTTP ' . $code . '). Retry later.');
    }
    $json = json_decode((string)$raw, true);
    if (!is_array($json)) throw new RuntimeException('API imerudisha jibu lisilosomeka (HTTP ' . $code . ').');
    if ($code < 200 || $code >= 300) throw new RuntimeException('The provider rejected the API request (HTTP ' . $code . '). Check the API URL and request settings.');
    return ['http_code' => $code, 'json' => $json, 'raw' => (string)$raw];
}

function wifiPaymentAppendQuery(string $url, array $query): string
{
    if (!$query) return $url;
    $parts = parse_url($url);
    if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) throw new RuntimeException('Webhook URL si sahihi.');
    parse_str((string)($parts['query'] ?? ''), $existing);
    $merged = array_merge(is_array($existing) ? $existing : [], $query);
    $rebuilt = strtolower((string)$parts['scheme']) . '://' . $parts['host'];
    if (isset($parts['port'])) $rebuilt .= ':' . (int)$parts['port'];
    $rebuilt .= (string)($parts['path'] ?? '/');
    if ($merged) $rebuilt .= '?' . http_build_query($merged, '', '&', PHP_QUERY_RFC3986);
    if (isset($parts['fragment'])) $rebuilt .= '#' . $parts['fragment'];
    return $rebuilt;
}

function wifiPaymentProviderHostAllowed(string $provider, string $host): bool
{
    $host = strtolower(rtrim($host, '.'));
    $domains = match ($provider) {
        'clickpesa' => ['clickpesa.com'],
        'snippe' => ['snippe.sh'],
        'zenopay' => ['zenopaymobile.com', 'zenoapi.com'],
        'pesapal' => ['pesapal.com'],
        'selcom' => ['selcommobile.com'],
        'azampay' => ['azampay.co.tz'],
        default => [],
    };
    foreach ($domains as $domain) {
        if ($host === $domain || str_ends_with($host, '.' . $domain)) return true;
    }
    return false;
}

function wifiPaymentLoadChannelConfig(mysqli $db, int $channelId, bool $requireEnabled = true, bool $requirePaymentAdapter = true): array
{
    if ($channelId <= 0) throw new RuntimeException('Akaunti ya malipo haipo.');
    $stmt = $db->prepare('SELECT id, name, type, channel_type, environment, status, configured,
        api_base_url, callback_url, client_id, merchant_id, api_key_enc, api_secret_enc, checksum_secret
        FROM payment_channels WHERE id = ? LIMIT 1');
    if (!$stmt) throw new RuntimeException('Imeshindikana kusoma akaunti ya malipo.');
    $stmt->bind_param('i', $channelId);
    if (!$stmt->execute()) { $stmt->close(); throw new RuntimeException('Imeshindikana kusoma akaunti ya malipo.'); }
    $row = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    if (!$row) throw new RuntimeException('Akaunti ya malipo haipatikani.');
    $key = wifiPaymentProviderKeyFromChannel($row);
    if ($requirePaymentAdapter && !wifiPaymentProviderAdapterReady($key)) throw new RuntimeException('Payment adapter ya provider hii haijakamilika kwa checkout hii.');
    if ($requireEnabled && (strtolower((string)$row['status']) !== 'enabled' || (int)$row['configured'] !== 1)) {
        throw new RuntimeException('Akaunti ya aggregator haijawezeshwa na kuhakikiwa.');
    }
    $decrypt = static function (string $field) use ($row): string {
        $value = trim((string)($row[$field] ?? ''));
        if ($value === '') return '';
        try { return trim((string)decryptData($value)); }
        catch (Throwable $e) { throw new RuntimeException('Credentials haziwezi kufunguliwa. Kagua APP_ENCRYPTION_KEY.'); }
    };
    $config = [
        'channel_id' => (int)$row['id'],
        'channel_name' => trim((string)$row['name']) ?: wifiPaymentProviderLabel($key),
        'provider_key' => $key,
        'environment' => strtolower(trim((string)$row['environment'])) ?: 'live',
        'api_base_url' => rtrim(trim((string)$row['api_base_url']), '/'),
        'callback_url' => trim((string)($row['callback_url'] ?? '')),
        'client_id' => trim((string)($row['client_id'] ?? '')),
        'merchant_id' => trim((string)($row['merchant_id'] ?? '')),
        'api_key' => $decrypt('api_key_enc'),
        'api_secret' => $decrypt('api_secret_enc'),
        'checksum_key' => $decrypt('checksum_secret'),
    ];
    if ($config['api_base_url'] === '') throw new RuntimeException('Weka API Base URL kwenye Payment Channels.');
    $urlParts = parse_url($config['api_base_url']);
    if (!is_array($urlParts) || strtolower((string)($urlParts['scheme'] ?? '')) !== 'https'
        || empty($urlParts['host']) || isset($urlParts['user']) || isset($urlParts['pass'])
        || !wifiPaymentProviderHostAllowed($key, (string)$urlParts['host'])) {
        throw new RuntimeException('API Base URL lazima iwe HTTPS na domain rasmi ya provider husika.');
    }
    foreach (['client_id', 'merchant_id', 'api_key', 'api_secret', 'checksum_key'] as $field) {
        if (preg_match('/[\r\n]/', (string)$config[$field])) throw new RuntimeException('Taarifa za API zina alama zisizokubalika.');
    }
    return $config;
}

function wifiPaymentDefaultWebhookUrl(string $providerKey, int $channelId): string
{
    $slug = match ($providerKey) {
        'snippe' => 'snippe', 'zenopay' => 'zenopay', 'selcom' => 'selcom', 'azampay' => 'azampay',
        'pesapal' => 'pesapal', default => 'clickpesa',
    };
    $url = appUrl('webhooks/' . $slug . '.php');
    $query = ['channel_id' => $channelId];
    if (in_array($providerKey, ['zenopay', 'azampay'], true)) {
        $appKey = (string)($_ENV['APP_ENCRYPTION_KEY'] ?? '');
        if (strlen($appKey) !== 64 || !ctype_xdigit($appKey)) throw new RuntimeException('Weka APP_ENCRYPTION_KEY halali kabla ya kuandaa webhook.');
        $query['token'] = hash_hmac('sha256', 'wifi-voucher-' . $providerKey . '-webhook:' . $channelId, hex2bin($appKey));
    }
    return wifiPaymentAppendQuery($url, $query);
}

function wifiPaymentCallbackForConfig(array $config, string $providerKey): string
{
    $configured = trim((string)($config['callback_url'] ?? ''));
    $channelId = (int)$config['channel_id'];
    if ($configured === '') $configured = wifiPaymentDefaultWebhookUrl($providerKey, $channelId);
    $query = ['channel_id' => $channelId];
    if (in_array($providerKey, ['zenopay', 'azampay'], true)) {
        $appKey = (string)($_ENV['APP_ENCRYPTION_KEY'] ?? '');
        if (strlen($appKey) !== 64 || !ctype_xdigit($appKey)) throw new RuntimeException('APP_ENCRYPTION_KEY haijawekwa vizuri kwa webhook.');
        $query['token'] = hash_hmac('sha256', 'wifi-voucher-' . $providerKey . '-webhook:' . $channelId, hex2bin($appKey));
    }
    $callback = wifiPaymentAppendQuery($configured, $query);
    if (strtolower((string)($config['environment'] ?? 'live')) === 'live'
        && strtolower((string)parse_url($callback, PHP_URL_SCHEME)) !== 'https') {
        throw new RuntimeException('Webhook ya malipo ya live lazima itumie HTTPS.');
    }
    return $callback;
}

function wifiPaymentBaseUrl(array $config): string
{
    $provider = (string)$config['provider_key'];
    if ($provider === 'clickpesa') return rtrim($config['api_base_url'] ?: 'https://api.clickpesa.com/third-parties', '/');
    if ($provider === 'snippe') return rtrim($config['api_base_url'] ?: 'https://api.snippe.sh', '/');
    if ($provider === 'zenopay') return rtrim($config['api_base_url'] ?: 'https://zenopaymobile.com/api', '/');
    if ($provider === 'pesapal') return rtrim($config['api_base_url'] ?: ($config['environment'] === 'test' ? 'https://cybqa.pesapal.com/pesapalv3' : 'https://pay.pesapal.com/v3'), '/');
    if ($provider === 'azampay') return rtrim($config['api_base_url'] ?: ($config['environment'] === 'test' ? 'https://sandbox.azampay.co.tz' : 'https://checkout.azampay.co.tz'), '/');
    return rtrim($config['api_base_url'], '/'); // Selcom supplies an account-specific API base URL.
}

function wifiPaymentAzamToken(array $config): string
{
    $sandbox = in_array($config['environment'], ['test', 'sandbox'], true);
    $authBase = $sandbox ? 'https://authenticator-sandbox.azampay.co.tz' : 'https://authenticator.azampay.co.tz';
    $result = wifiPaymentHttpJson($authBase . '/AppRegistration/GenerateToken', 'POST', [
        'appName' => $config['merchant_id'],
        'clientId' => $config['client_id'],
        'clientSecret' => $config['api_secret'],
    ], ['X-API-KEY: ' . $config['api_key']]);
    $data = $result['json'];
    $token = trim((string)($data['data']['accessToken'] ?? ''));
    if ((int)($data['statusCode'] ?? 0) !== 200 || $token === '') throw new RuntimeException('AzamPay credentials hazikuthibitishwa.');
    return $token;
}

function wifiPaymentPesapalToken(array $config): string
{
    $base = wifiPaymentBaseUrl($config);
    $result = wifiPaymentHttpJson($base . '/api/Auth/RequestToken', 'POST', [
        'consumer_key' => $config['client_id'],
        'consumer_secret' => $config['api_secret'],
    ], ['Accept: application/json', 'Content-Type: application/json']);
    $token = trim((string)($result['json']['token'] ?? ''));
    if ($token === '') throw new RuntimeException('Pesapal haikurudisha token ya uthibitisho.');
    return $token;
}

function wifiSelcomHeaders(array $config, array $fields): array
{
    if ($config['api_key'] === '' || $config['api_secret'] === '') throw new RuntimeException('Weka Selcom API Key na API Secret.');
    $timestamp = (new DateTimeImmutable('now', new DateTimeZone('Africa/Dar_es_Salaam')))->format('Y-m-d\TH:i:sP');
    $names = array_keys($fields);
    $parts = ['timestamp=' . $timestamp];
    foreach ($fields as $name => $value) $parts[] = $name . '=' . (is_scalar($value) ? (string)$value : json_encode($value, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
    $digest = base64_encode(hash_hmac('sha256', implode('&', $parts), $config['api_secret'], true));
    return [
        'Authorization: SELCOM ' . base64_encode($config['api_key']),
        'Digest-Method: HS256', 'Digest: ' . $digest,
        'Timestamp: ' . $timestamp, 'Signed-Fields: ' . implode(',', $names),
    ];
}

function wifiSelcomRequest(array $config, string $path, string $method, array $fields): array
{
    $headers = wifiSelcomHeaders($config, $fields);
    $url = wifiPaymentBaseUrl($config) . $path;
    if (strtoupper($method) === 'GET' || strtoupper($method) === 'DELETE') {
        $url = wifiPaymentAppendQuery($url, $fields);
        return wifiPaymentHttpJson($url, $method, null, $headers)['json'];
    }
    return wifiPaymentHttpJson($url, $method, $fields, $headers)['json'];
}

function wifiPaymentVerifyAdapter(mysqli $db, int $channelId): array
{
    $config = wifiPaymentLoadChannelConfig($db, $channelId, false);
    $provider = (string)$config['provider_key'];
    switch ($provider) {
        case 'clickpesa':
            if ($config['client_id'] === '' || $config['api_key'] === '' || $config['checksum_key'] === '') throw new RuntimeException('Weka Client ID, API Key na Checksum Security Key za ClickPesa.');
            $r = wifiPaymentHttpJson(wifiPaymentBaseUrl($config) . '/generate-token', 'POST', null, [
                'client-id: ' . $config['client_id'], 'api-key: ' . $config['api_key'],
            ]);
            if (trim((string)($r['json']['token'] ?? '')) === '') throw new RuntimeException('ClickPesa haikuthibitisha credentials.');
            break;
        case 'snippe':
            if ($config['api_key'] === '' || $config['checksum_key'] === '') throw new RuntimeException('Weka Snippe API Key na Webhook Signing Key.');
            $snippeAuth = ['Authorization: Bearer ' . $config['api_key']];
            wifiPaymentHttpJson(wifiPaymentBaseUrl($config) . '/v1/payments/balance', 'GET', null, $snippeAuth);
            // Checkout verification does not require permission to make payouts.
            break;
        case 'zenopay':
            if ($config['api_key'] === '') throw new RuntimeException('Weka ZenoPay API Key.');
            $appKey = (string)($_ENV['APP_ENCRYPTION_KEY'] ?? '');
            if (strlen($appKey) !== 64 || !ctype_xdigit($appKey)) throw new RuntimeException('APP_ENCRYPTION_KEY halali inahitajika kwa webhook ya ZenoPay.');
            $probe = wifiPaymentHttpJson(wifiPaymentBaseUrl($config) . '/payments/order-status?order_id=CONNECTION-CHECK', 'GET', null, ['x-api-key: ' . $config['api_key']]);
            if (str_contains(strtolower(json_encode($probe['json'])), 'invalid api key')) throw new RuntimeException('ZenoPay haikubali API Key.');
            break;
        case 'pesapal':
            if ($config['client_id'] === '' || $config['api_secret'] === '') throw new RuntimeException('Weka Pesapal Consumer Key na Consumer Secret.');
            $token = wifiPaymentPesapalToken($config);
            wifiPaymentHttpJson(wifiPaymentBaseUrl($config) . '/api/URLSetup/GetIpnList', 'GET', null, ['Authorization: Bearer ' . $token]);
            break;
        case 'selcom':
            if ($config['merchant_id'] === '' || $config['api_key'] === '' || $config['api_secret'] === '') throw new RuntimeException('Weka Selcom Vendor ID, API Key na API Secret.');
            $probe = wifiSelcomRequest($config, '/v1/checkout/order-status', 'GET', ['order_id' => 'CONNECTION-CHECK']);
            if (in_array((string)($probe['resultcode'] ?? ''), ['401', '403'], true)) throw new RuntimeException('Selcom haikukubali API credentials.');
            break;
        case 'azampay':
            if ($config['client_id'] === '' || $config['api_secret'] === '' || $config['api_key'] === '' || $config['merchant_id'] === '') {
                throw new RuntimeException('AzamPay inahitaji App Name, Client ID, Client Secret na Client Token (API Key).');
            }
            $appKey = (string)($_ENV['APP_ENCRYPTION_KEY'] ?? '');
            if (strlen($appKey) !== 64 || !ctype_xdigit($appKey)) throw new RuntimeException('APP_ENCRYPTION_KEY halali inahitajika kwa webhook ya AzamPay.');
            $token = wifiPaymentAzamToken($config);
            wifiPaymentHttpJson(wifiPaymentBaseUrl($config) . '/api/v1/Partner/GetPaymentPartners', 'GET', null, ['Authorization: Bearer ' . $token]);
            break;
        default:
            throw new RuntimeException('API test ya provider hii haijaandaliwa.');
    }
    $message = wifiPaymentProviderLabel($provider) . ' API credentials zimejibu ombi la uthibitisho lisilotoza mteja.';
    if ($provider === 'snippe') {
        $message .= ' Salio limefikiwa; hakuna fedha iliyotumwa.';
    }
    return ['provider' => $provider, 'message' => $message];
}

function wifiPaymentPersistProviderReference(mysqli $db, string $localReference, string $providerReference): void
{
    $providerReference = substr(trim($providerReference), 0, 100);
    if ($providerReference === '') return;
    $stmt = $db->prepare("UPDATE payments SET transaction_reference = ? WHERE order_reference = ? AND status IN ('PENDING','PROCESSING') LIMIT 1");
    if (!$stmt) throw new RuntimeException('Imeshindikana kuhifadhi reference ya API.');
    $stmt->bind_param('ss', $providerReference, $localReference);
    if (!$stmt->execute()) { $stmt->close(); throw new RuntimeException('Imeshindikana kuhifadhi reference ya API.'); }
    $stmt->close();
}

function wifiPaymentAdapterInitiate(array $config, string $localReference, string $phone, float $amount, string $networkCode, string $buyerName = '', string $buyerEmail = ''): array
{
    $provider = (string)$config['provider_key'];
    $callback = wifiPaymentCallbackForConfig($config, $provider);
    $amountWhole = (int)round($amount);
    if (abs($amount - $amountWhole) > 0.00001) throw new RuntimeException('Kifurushi hiki kina senti. Provider hii inahitaji kiasi kizima cha TZS.');
    switch ($provider) {
        case 'snippe':
            if ($buyerEmail === '' || $buyerName === '') throw new RuntimeException('Weka jina na email ili kutumia Snippe.');
            $nameParts = preg_split('/\s+/', trim($buyerName), 2) ?: [];
            $first = (string)($nameParts[0] ?? ''); $last = (string)($nameParts[1] ?? '');
            if ($first === '' || $last === '' || filter_var($buyerEmail, FILTER_VALIDATE_EMAIL) === false) throw new RuntimeException('Jaza jina kamili na email halali.');
            $payload = [
                'payment_type' => 'mobile',
                'details' => ['amount' => $amountWhole, 'currency' => 'TZS'],
                'phone_number' => $phone,
                'customer' => ['firstname' => $first, 'lastname' => $last, 'email' => $buyerEmail],
                'webhook_url' => $callback,
                'metadata' => ['order_id' => $localReference],
            ];
            $idempotency = substr(preg_replace('/[^A-Za-z0-9_-]/', '', $localReference) ?? '', 0, 30);
            $r = wifiPaymentHttpJson(wifiPaymentBaseUrl($config) . '/v1/payments', 'POST', $payload, [
                'Authorization: Bearer ' . $config['api_key'], 'Idempotency-Key: ' . $idempotency,
            ])['json'];
            $data = $r['data'] ?? [];
            if (!is_array($data) || (string)($data['status'] ?? '') === '' || empty($data['reference'])) throw new RuntimeException('Snippe haikurudishia reference ya malipo.');
            return ['status' => 'PENDING', 'provider_reference' => (string)$data['reference'], 'redirect_url' => ''];

        case 'zenopay':
            if ($buyerEmail === '' || $buyerName === '' || filter_var($buyerEmail, FILTER_VALIDATE_EMAIL) === false) throw new RuntimeException('Weka jina kamili na email halali ili kutumia ZenoPay.');
            $payload = [
                'order_id' => $localReference,
                'buyer_email' => $buyerEmail,
                'buyer_name' => $buyerName,
                'buyer_phone' => preg_replace('/^255/', '0', $phone),
                'amount' => $amountWhole,
                'webhook_url' => $callback,
            ];
            $r = wifiPaymentHttpJson(wifiPaymentBaseUrl($config) . '/payments/mobile_money_tanzania', 'POST', $payload, ['x-api-key: ' . $config['api_key']])['json'];
            if (strtolower((string)($r['status'] ?? '')) !== 'success' || (string)($r['resultcode'] ?? '') !== '000') throw new RuntimeException('ZenoPay haikukubali ombi la malipo.');
            return ['status' => 'PENDING', 'provider_reference' => $localReference, 'redirect_url' => ''];

        case 'selcom':
            if ($config['merchant_id'] === '' || $config['api_key'] === '' || $config['api_secret'] === '') throw new RuntimeException('Weka Selcom inahitaji Vendor ID, API Key na API Secret.');
            if ($buyerEmail === '' || $buyerName === '' || filter_var($buyerEmail, FILTER_VALIDATE_EMAIL) === false) throw new RuntimeException('Weka jina kamili na email halali ili kutumia Selcom.');
            $hook = base64_encode($callback);
            $created = wifiSelcomRequest($config, '/v1/checkout/create-order-minimal', 'POST', [
                'vendor' => $config['merchant_id'], 'order_id' => $localReference,
                'buyer_email' => $buyerEmail, 'buyer_name' => $buyerName, 'buyer_phone' => $phone,
                'amount' => $amountWhole, 'currency' => 'TZS', 'payment_methods' => 'MOBILEMONEYPULL',
                'webhook' => $hook, 'buyer_remarks' => 'Wi-Fi voucher ' . $localReference,
                'merchant_remarks' => 'Wi-Fi voucher', 'no_of_items' => 1,
            ]);
            if (strtoupper((string)($created['result'] ?? '')) !== 'SUCCESS') throw new RuntimeException('Selcom haikuweza kutengeneza order ya malipo.');
            $push = wifiSelcomRequest($config, '/v1/checkout/wallet-payment', 'POST', [
                'transid' => $localReference, 'order_id' => $localReference, 'msisdn' => $phone,
            ]);
            $status = strtoupper((string)($push['result'] ?? ''));
            if (!in_array($status, ['SUCCESS', 'PENDING', 'INPROGRESS', 'AMBIGUOUS'], true)) throw new RuntimeException('Selcom haikukubali ombi la USSD.');
            return ['status' => $status === 'SUCCESS' ? 'PENDING' : 'PROCESSING', 'provider_reference' => (string)($push['reference'] ?? $localReference), 'redirect_url' => ''];

        case 'azampay':
            $token = wifiPaymentAzamToken($config);
            $network = match (wifiCpCanonicalNetwork($networkCode)) {
                'airtel' => 'Airtel', 'mpesa' => 'Mpesa', 'mixx_yas' => 'Tigopesa', 'halotel' => 'HaloPesa',
                'zantel' => 'Azampesa', default => '',
            };
            if ($network === '') throw new RuntimeException('AzamPay haijawekewa provider code ya mtandao huu.');
            $payload = [
                'provider' => $network, 'accountNumber' => preg_replace('/^255/', '0', $phone),
                'amount' => (string)$amountWhole, 'currency' => 'TZS', 'externalId' => $localReference,
                'additionalProperties' => ['order_reference' => $localReference],
            ];
            $r = wifiPaymentHttpJson(wifiPaymentBaseUrl($config) . '/azampay/mno/checkout', 'POST', $payload, ['Authorization: Bearer ' . $token])['json'];
            if (empty($r['success']) || empty($r['transactionId'])) throw new RuntimeException('AzamPay haikukubali ombi la malipo.');
            return ['status' => 'PENDING', 'provider_reference' => (string)$r['transactionId'], 'redirect_url' => ''];
    }
    throw new RuntimeException('Payment adapter haipo kwa provider hii.');
}

function wifiPaymentProviderStatus(mysqli $db, array $payment): ?array
{
    $channelId = (int)($payment['payment_channel_id'] ?? 0);
    if ($channelId <= 0) return null;
    $config = wifiCpConfigForPayment($db, $payment);
    $provider = (string)($config['provider_key'] ?? 'clickpesa');
    $localReference = (string)$payment['order_reference'];
    $providerReference = trim((string)($payment['transaction_reference'] ?? ''));
    $r = [];
    switch ($provider) {
        case 'clickpesa':
            return wifiCpProviderPayment($localReference, $config);
        case 'snippe':
            if ($providerReference === '') return null;
            $r = wifiPaymentHttpJson(wifiPaymentBaseUrl($config) . '/v1/payments/' . rawurlencode($providerReference), 'GET', null, ['Authorization: Bearer ' . $config['api_key']])['json'];
            $d = is_array($r['data'] ?? null) ? $r['data'] : $r;
            $amount = $d['amount']['value'] ?? $d['amount'] ?? null;
            $currency = $d['amount']['currency'] ?? 'TZS';
            return ['status' => wifiPaymentNormalizeStatus((string)($d['status'] ?? '')), 'orderReference' => $localReference, 'collectedAmount' => $amount, 'collectedCurrency' => $currency, 'paymentReference' => $providerReference, 'channel' => (string)($d['channel']['provider'] ?? '')];
        case 'zenopay':
            $r = wifiPaymentHttpJson(wifiPaymentBaseUrl($config) . '/payments/order-status?order_id=' . rawurlencode($localReference), 'GET', null, ['x-api-key: ' . $config['api_key']])['json'];
            $d = is_array($r['data'][0] ?? null) ? $r['data'][0] : (is_array($r['data'] ?? null) ? $r['data'] : $r);
            return ['status' => wifiPaymentNormalizeStatus((string)($d['payment_status'] ?? $d['status'] ?? '')), 'orderReference' => $localReference, 'collectedAmount' => $d['amount'] ?? null, 'collectedCurrency' => 'TZS', 'paymentReference' => (string)($d['transid'] ?? $d['reference'] ?? $providerReference), 'channel' => (string)($d['channel'] ?? '')];
        case 'selcom':
            $r = wifiSelcomRequest($config, '/v1/checkout/order-status', 'GET', ['order_id' => $localReference]);
            $d = is_array($r['data'][0] ?? null) ? $r['data'][0] : [];
            return ['status' => wifiPaymentNormalizeStatus((string)($d['payment_status'] ?? $r['result'] ?? '')), 'orderReference' => $localReference, 'collectedAmount' => $d['amount'] ?? null, 'collectedCurrency' => 'TZS', 'paymentReference' => (string)($d['reference'] ?? $d['transid'] ?? $providerReference), 'channel' => (string)($d['channel'] ?? '')];
        case 'azampay':
        case 'pesapal':
            return null;
    }
    return null;
}

function wifiPaymentNormalizeStatus(string $status): string
{
    return match (strtoupper(trim($status))) {
        'SUCCESS', 'SETTLED', 'COMPLETED', 'COMPLETE', 'PAID' => 'SUCCESS',
        'FAILED', 'FAIL', 'REJECTED', 'INVALID' => 'FAILED',
        'CANCELLED', 'CANCELED', 'USERCANCELLED', 'USERCANCELED', 'VOIDED' => 'CANCELLED',
        'EXPIRED' => 'FAILED',
        'INPROGRESS', 'PROCESSING', 'AMBIGUOUS' => 'PROCESSING',
        'PENDING', 'WAITING', 'CREATED' => 'PENDING',
        default => '',
    };
}

function wifiPaymentFindRowByReference(mysqli $db, string $reference): ?array
{
    $stmt = $db->prepare('SELECT id, order_reference, transaction_reference, payment_channel_id, amount, status, voucher_id FROM payments WHERE order_reference = ? LIMIT 1');
    if (!$stmt) return null;
    $stmt->bind_param('s', $reference); $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc() ?: null; $stmt->close();
    return $row;
}

function wifiPaymentFindRowByTransactionReference(mysqli $db, string $reference): ?array
{
    $stmt = $db->prepare('SELECT id, order_reference, transaction_reference, payment_channel_id, amount, status, voucher_id FROM payments WHERE transaction_reference = ? LIMIT 1');
    if (!$stmt) return null;
    $stmt->bind_param('s', $reference); $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc() ?: null; $stmt->close();
    return $row;
}

function wifiPaymentVerifySelcomWebhook(array $payload, array $headers, array $config): bool
{
    $authorization = trim((string)($headers['authorization'] ?? ''));
    $timestamp = trim((string)($headers['timestamp'] ?? ''));
    $method = strtoupper(trim((string)($headers['digest-method'] ?? '')));
    $digest = trim((string)($headers['digest'] ?? ''));
    $signedFields = trim((string)($headers['signed-fields'] ?? ''));
    if ($method !== 'HS256' || $digest === '' || $timestamp === '' || $config['api_secret'] === '') return false;
    if (!hash_equals('SELCOM ' . base64_encode($config['api_key']), $authorization)) return false;
    $when = strtotime($timestamp);
    if ($when === false || abs(time() - $when) > 300) return false;
    $names = array_values(array_filter(array_map('trim', explode(',', $signedFields)), static fn($v) => $v !== ''));
    if (!$names) return false;
    $parts = ['timestamp=' . $timestamp];
    foreach ($names as $name) {
        if (!array_key_exists($name, $payload)) return false;
        $value = $payload[$name];
        $parts[] = $name . '=' . (is_scalar($value) ? (string)$value : json_encode($value, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
    }
    $expected = base64_encode(hash_hmac('sha256', implode('&', $parts), $config['api_secret'], true));
    return hash_equals($expected, $digest);
}

function wifiPaymentConfirmNormalized(mysqli $db, string $localReference, array $normalized): void
{
    $payment = wifiCpPaymentRow($db, $localReference);
    if (!$payment) throw new RuntimeException('Payment haipo.');
    $normalized['orderReference'] = $localReference;
    if (!in_array(strtoupper((string)($normalized['status'] ?? '')), ['SUCCESS', 'SETTLED'], true)) {
        wifiCpMarkPendingStatus($db, $localReference, (string)($normalized['status'] ?? 'PENDING'));
        return;
    }
    $config = wifiCpConfigForPayment($db, $payment);
    wifiCpIssueVerifiedVoucher($db, $localReference, $normalized, $config);
}

function wifiPaymentWebhookKeyMatches(string $provided, int $channelId, string $providerKey): bool
{
    $key = (string)($_ENV['APP_ENCRYPTION_KEY'] ?? '');
    if ($channelId <= 0 || strlen($key) !== 64 || !ctype_xdigit($key)) return false;
    $expected = hash_hmac('sha256', 'wifi-voucher-' . $providerKey . '-webhook:' . $channelId, hex2bin($key));
    return $provided !== '' && hash_equals($expected, $provided);
}

function wifiPaymentHandleWebhook(mysqli $db, string $providerKey, int $channelId, array $payload, array $headers = [], array $query = []): string
{
    $config = wifiPaymentLoadChannelConfig($db, $channelId, false);
    if ($config['provider_key'] !== $providerKey) throw new RuntimeException('Provider channel mismatch.');
    $reference = '';
    $referenceCandidates = [];
    $providerTransactionReference = '';
    switch ($providerKey) {
        case 'snippe':
            $raw = (string)($headers['_raw_body'] ?? '');
            $timestamp = trim((string)($headers['x-webhook-timestamp'] ?? ''));
            $signature = trim((string)($headers['x-webhook-signature'] ?? ''));
            $when = ctype_digit($timestamp) ? (int)$timestamp : 0;
            if ($config['checksum_key'] === '' || $raw === '' || $signature === '' || $when <= 0 || abs(time() - $when) > 300) throw new RuntimeException('Snippe webhook haijathibitishwa.');
            $expected = hash_hmac('sha256', $timestamp . '.' . $raw, $config['checksum_key']);
            if (!hash_equals($expected, strtolower($signature))) throw new RuntimeException('Snippe webhook signature si sahihi.');
            $data = is_array($payload['data'] ?? null) ? $payload['data'] : $payload;
            $metadata = is_array($data['metadata'] ?? null) ? $data['metadata'] : [];
            $referenceCandidates = array_values(array_unique(array_filter([
                trim((string)($metadata['order_id'] ?? '')),
                trim((string)($data['external_reference'] ?? '')),
            ], static fn(string $candidate): bool => $candidate !== '')));
            $reference = $referenceCandidates[0] ?? '';
            $providerTransactionReference = trim((string)($data['reference'] ?? ''));
            break;
        case 'zenopay':
            if (!wifiPaymentWebhookKeyMatches((string)($query['token'] ?? ''), $channelId, 'zenopay')) throw new RuntimeException('Webhook token si sahihi.');
            $reference = (string)($payload['order_id'] ?? $payload['externalId'] ?? '');
            break;
        case 'selcom':
            if (!wifiPaymentVerifySelcomWebhook($payload, $headers, $config)) throw new RuntimeException('Selcom webhook signature si sahihi.');
            $reference = (string)($payload['order_id'] ?? '');
            break;
        case 'azampay':
            if (!wifiPaymentWebhookKeyMatches((string)($query['token'] ?? ''), $channelId, 'azampay')) throw new RuntimeException('Webhook token si sahihi.');
            $reference = (string)($payload['additionalProperties']['order_reference'] ?? $payload['externalId'] ?? $payload['reference'] ?? $payload['utilityref'] ?? '');
            break;
        default:
            throw new RuntimeException('Webhook ya provider hii haitumiki.');
    }
    $reference = trim($reference);
    if ($providerKey === 'snippe') {
        $payment = null;
        foreach ($referenceCandidates as $candidate) {
            if (strlen($candidate) > 100) continue;
            $candidatePayment = wifiPaymentFindRowByReference($db, $candidate);
            if ($candidatePayment && (int)$candidatePayment['payment_channel_id'] === $channelId) {
                $payment = $candidatePayment;
                break;
            }
        }
        // Snippe's webhook reference is its own payment ID. The checkout stores
        // that ID in transaction_reference, so it is a reliable fallback when
        // the provider omits or changes our order ID in the webhook metadata.
        if (!$payment && $providerTransactionReference !== '' && strlen($providerTransactionReference) <= 100) {
            $candidatePayment = wifiPaymentFindRowByTransactionReference($db, $providerTransactionReference);
            if ($candidatePayment && (int)$candidatePayment['payment_channel_id'] === $channelId) $payment = $candidatePayment;
        }
    } else {
        if ($reference === '' || strlen($reference) > 100) throw new RuntimeException('Reference ya malipo si sahihi.');
        $payment = wifiPaymentFindRowByReference($db, $reference);
        if (!$payment && $providerKey === 'azampay') $payment = wifiPaymentFindRowByTransactionReference($db, $reference);
    }
    if (!$payment || (int)$payment['payment_channel_id'] !== $channelId) throw new RuntimeException('Malipo hayalingani na account ya webhook.');
    $reference = (string)$payment['order_reference'];

    if ($providerKey === 'snippe') {
        $data = is_array($payload['data'] ?? null) ? $payload['data'] : $payload;
        $snippeReference = trim((string)($data['reference'] ?? ''));
        if ($snippeReference !== '') {
            wifiPaymentPersistProviderReference($db, $reference, $snippeReference);
            $payment = wifiPaymentFindRowByReference($db, $reference) ?? $payment;
        }
    }

    if ($providerKey === 'azampay') {
        if (strtolower((string)($payload['transactionstatus'] ?? '')) !== 'success') {
            wifiCpMarkPendingStatus($db, $reference, wifiPaymentNormalizeStatus((string)($payload['transactionstatus'] ?? '')) ?: 'PENDING');
            return 'AzamPay notification received';
        }
        $normalized = [
            'status' => 'SUCCESS', 'orderReference' => $reference,
            'collectedAmount' => $payload['amount'] ?? null, 'collectedCurrency' => 'TZS',
            'paymentReference' => (string)($payload['reference'] ?? $payload['utilityref'] ?? $payload['externalId'] ?? $reference),
            'channel' => (string)($payload['operator'] ?? ''),
        ];
        wifiPaymentConfirmNormalized($db, $reference, $normalized);
        return 'AzamPay payment verified and voucher issued';
    }

    // For providers with a status endpoint, webhook is only a wake-up call. The
    // authenticated server-to-server status response is the source of truth.
    $verified = wifiPaymentProviderStatus($db, $payment);
    if (!is_array($verified) || trim((string)($verified['status'] ?? '')) === '') throw new RuntimeException('Provider status bado haijathibitisha malipo.');
    wifiPaymentConfirmNormalized($db, $reference, $verified);
    return 'Payment status checked and processed';
}
