<?php
declare(strict_types=1);

function wifiPackageEnsureDataLimitColumn(mysqli $db): bool
{
    static $checked = null;
    if ($checked !== null) {
        return $checked;
    }

    try {
        $result = $db->query("SHOW COLUMNS FROM `packages` LIKE 'data_limit_mb'");
        if ($result instanceof mysqli_result) {
            $exists = $result->num_rows > 0;
            $result->free();
            if ($exists) {
                return $checked = true;
            }
        }

        $checked = $db->query(
            "ALTER TABLE `packages` ADD COLUMN `data_limit_mb` BIGINT UNSIGNED NULL DEFAULT NULL AFTER `speed_limit`"
        ) === true;
    } catch (Throwable $exception) {
        error_log('Package data limit schema check failed: ' . $exception->getMessage());
        $checked = false;
    }

    return $checked;
}

function wifiPackageDataLimitToMb(string $value, string $unit): ?int
{
    $value = trim($value);
    $unit = strtoupper(trim($unit));
    if ($value === '') {
        return null;
    }
    if (!is_numeric($value) || !in_array($unit, ['MB', 'GB'], true)) {
        return null;
    }

    $amount = (float)$value;
    if (!is_finite($amount) || $amount <= 0) {
        return null;
    }

    $megabytes = (int)round($amount * ($unit === 'GB' ? 1024 : 1));
    if ($megabytes < 1 || $megabytes > 4294967295) {
        return null;
    }
    return $megabytes;
}

function wifiPackageDataLimitLabel(?int $limitMb): string
{
    if ($limitMb === null || $limitMb <= 0) {
        return 'No data limit';
    }
    if ($limitMb % 1024 === 0) {
        $gigabytes = number_format($limitMb / 1024, 2, '.', '');
        return rtrim(rtrim($gigabytes, '0'), '.') . ' GB';
    }
    return number_format($limitMb) . ' MB';
}
