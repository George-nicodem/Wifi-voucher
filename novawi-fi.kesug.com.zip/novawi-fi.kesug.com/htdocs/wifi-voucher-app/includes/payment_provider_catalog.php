<?php
declare(strict_types=1);

/**
 * Aggregator capabilities. `adapter_ready` means the customer checkout can
 * safely use the provider in the selected MNO/phone flow. Pesapal is kept in
 * the catalogue for credentials and a read-only API check, but its documented
 * product is a hosted payment page where the customer picks a payment method.
 */
function wifiPaymentProviderCatalog(): array
{
    return [
        'clickpesa' => ['name' => 'ClickPesa', 'adapter_ready' => true, 'api_test_ready' => true, 'contact_fields' => false],
        'snippe' => ['name' => 'Snippe', 'adapter_ready' => true, 'api_test_ready' => true, 'contact_fields' => true],
        'pesapal' => ['name' => 'Pesapal', 'adapter_ready' => false, 'api_test_ready' => true, 'contact_fields' => true, 'mode' => 'hosted'],
        'zenopay' => ['name' => 'ZenoPay', 'adapter_ready' => true, 'api_test_ready' => true, 'contact_fields' => true],
        'selcom' => ['name' => 'Selcom', 'adapter_ready' => true, 'api_test_ready' => true, 'contact_fields' => true],
        'azampay' => ['name' => 'AzamPay', 'adapter_ready' => true, 'api_test_ready' => true, 'contact_fields' => false],
    ];
}

function wifiPaymentProviderKey(string ...$values): string
{
    $catalog = wifiPaymentProviderCatalog();
    foreach ($values as $value) {
        $candidate = strtolower((string)(preg_replace('/[^a-z0-9]+/i', '', trim($value)) ?? ''));
        if ($candidate === '') continue;
        if (isset($catalog[$candidate])) return $candidate;
        foreach (array_keys($catalog) as $providerKey) {
            if (str_contains($candidate, $providerKey)) return $providerKey;
        }
    }
    return '';
}

function wifiPaymentProviderKeyFromChannel(array $channel): string
{
    return wifiPaymentProviderKey(
        (string)($channel['type'] ?? ''),
        (string)($channel['channel_type'] ?? ''),
        (string)($channel['provider_code'] ?? ''),
        (string)($channel['name'] ?? '')
    );
}

function wifiPaymentProviderLabel(string $providerKey): string
{
    return (string)(wifiPaymentProviderCatalog()[$providerKey]['name'] ?? 'Aggregator nyingine');
}

function wifiPaymentProviderAdapterReady(string $providerKey): bool
{
    return (bool)(wifiPaymentProviderCatalog()[$providerKey]['adapter_ready'] ?? false);
}

function wifiPaymentProviderApiTestReady(string $providerKey): bool
{
    return (bool)(wifiPaymentProviderCatalog()[$providerKey]['api_test_ready'] ?? false);
}

function wifiPaymentProviderNeedsContact(string $providerKey): bool
{
    return (bool)(wifiPaymentProviderCatalog()[$providerKey]['contact_fields'] ?? false);
}

/** Networks supported by the documented direct mobile-money push adapters. */
function wifiPaymentProviderSupportsNetwork(string $providerKey, string $network): bool
{
    $network = strtolower(trim($network));
    return match ($providerKey) {
        'clickpesa' => true, // Availability is checked against ClickPesa preview before charging.
        'snippe', 'zenopay', 'selcom' => in_array($network, ['mpesa', 'airtel', 'mixx_yas', 'halotel'], true),
        // AzamPay's current checkout lists M-Pesa, Airtel, Mixx by Yas,
        // HaloPesa, and AzamPesa (Zantel).
        'azampay' => in_array($network, ['mpesa', 'airtel', 'halotel', 'mixx_yas', 'zantel'], true),
        default => false,
    };
}
