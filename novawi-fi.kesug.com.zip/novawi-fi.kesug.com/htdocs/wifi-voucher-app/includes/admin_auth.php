<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/csrf.php';

/*
|--------------------------------------------------------------------------
| ADMIN SESSION
|--------------------------------------------------------------------------
*/

function startAdminSession(): void
{
    startSecureSession();
}

/*
|--------------------------------------------------------------------------
| CHECK LOGIN
|--------------------------------------------------------------------------
*/

function isAdminLoggedIn(): bool
{
    startAdminSession();

    return isset($_SESSION['admin_id'])
        && is_numeric($_SESSION['admin_id'])
        && (int)$_SESSION['admin_id'] > 0;
}

/*
|--------------------------------------------------------------------------
| REQUIRE ADMIN LOGIN
|--------------------------------------------------------------------------
*/

function requireAdminLogin(): void
{
    if (!isAdminLoggedIn()) {
        redirect('admin/login.php');
    }

    checkAdminSessionTimeout();
}

/*
|--------------------------------------------------------------------------
| CURRENT ADMIN ID
|--------------------------------------------------------------------------
*/

function currentAdminId(): ?int
{
    if (!isAdminLoggedIn()) {
        return null;
    }

    return (int)$_SESSION['admin_id'];
}

/*
|--------------------------------------------------------------------------
| CURRENT ADMIN NAME
|--------------------------------------------------------------------------
*/

function currentAdminName(): string
{
    startAdminSession();

    if (
        isset($_SESSION['admin_name']) &&
        is_string($_SESSION['admin_name']) &&
        $_SESSION['admin_name'] !== ''
    ) {
        return $_SESSION['admin_name'];
    }

    return 'Administrator';
}

/*
|--------------------------------------------------------------------------
| LOGIN ADMIN
|--------------------------------------------------------------------------
*/

function loginAdmin(
    int $adminId,
    string $adminName
): void {

    startAdminSession();

    /*
     * Prevent session fixation.
     */
    session_regenerate_id(true);

    $_SESSION['admin_id'] = $adminId;
    $_SESSION['admin_name'] = $adminName;
    $_SESSION['admin_login_time'] = time();
    $_SESSION['admin_last_activity'] = time();

    /*
     * Extra marker to identify an authenticated admin session.
     */
    $_SESSION['admin_authenticated'] = true;
}

/*
|--------------------------------------------------------------------------
| SESSION TIMEOUT
|--------------------------------------------------------------------------
*/

function checkAdminSessionTimeout(
    int $timeout = 1800
): void {

    if (!isAdminLoggedIn()) {
        return;
    }

    startAdminSession();

    $lastActivity =
        $_SESSION['admin_last_activity'] ?? null;

    if (
        !is_numeric($lastActivity) ||
        (time() - (int)$lastActivity) > $timeout
    ) {
        logoutAdmin();

        redirect(
            'admin/login.php?timeout=1'
        );
    }

    $_SESSION['admin_last_activity'] = time();
}

/*
|--------------------------------------------------------------------------
| LOGOUT
|--------------------------------------------------------------------------
*/

function logoutAdmin(): void
{
    startAdminSession();

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {

        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            [
                'expires' => time() - 42000,
                'path' => $params['path'] ?? '/',
                'domain' => $params['domain'] ?? '',
                'secure' => (bool)($params['secure'] ?? false),
                'httponly' => (bool)($params['httponly'] ?? true),
                'samesite' => $params['samesite'] ?? 'Lax'
            ]
        );
    }

    session_destroy();
}

/*
|--------------------------------------------------------------------------
| REQUIRE POST REQUEST
|--------------------------------------------------------------------------
*/

function requireAdminPost(): void
{
    if (
        ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST'
    ) {
        http_response_code(405);

        header('Allow: POST');

        exit('Method not allowed.');
    }
}

/*
|--------------------------------------------------------------------------
| REQUIRE ADMIN + POST + CSRF
|--------------------------------------------------------------------------
*/

function requireAdminPostWithCsrf(): void
{
    requireAdminLogin();
    requireAdminPost();
    requireCsrfToken();
}
