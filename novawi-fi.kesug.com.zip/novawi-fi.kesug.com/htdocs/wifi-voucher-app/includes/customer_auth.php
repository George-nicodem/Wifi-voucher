<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/customer_mail.php';

function startCustomerAccountSession(): void
{
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Pragma: no-cache');
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    $secure = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_name('WIFI_VOUCHER_CUSTOMER');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function customerAccountSchemaReady(): bool
{
    global $conn;

    $accounts = $conn->query('SELECT id, full_name, email, password_hash, status, failed_login_count, failed_login_window_start, locked_until FROM customer_accounts LIMIT 0');
    $codes = $conn->query('SELECT account_id, code_hash, expires_at, attempt_count, consumed_at, created_at FROM customer_login_codes LIMIT 0');
    return $accounts !== false && $codes !== false;
}

function customerAccountEmail(string $email): string
{
    return strtolower(trim($email));
}

function customerAccountLockedUntil(array $account): int
{
    $lockedUntil = trim((string)($account['locked_until'] ?? ''));
    $timestamp = $lockedUntil !== '' ? strtotime($lockedUntil) : false;
    return $timestamp !== false && $timestamp > time() ? $timestamp : 0;
}

function customerAccountRecordFailedLogin(int $accountId): int
{
    global $conn;

    $select = $conn->prepare('SELECT failed_login_count, failed_login_window_start, locked_until FROM customer_accounts WHERE id = ? LIMIT 1');
    if (!$select) {
        return 0;
    }
    $select->bind_param('i', $accountId);
    if (!$select->execute()) {
        $select->close();
        return 0;
    }
    $result = $select->get_result();
    $account = $result ? $result->fetch_assoc() : null;
    $select->close();
    if (!$account) {
        return 0;
    }

    $lockedUntil = customerAccountLockedUntil($account);
    if ($lockedUntil > 0) {
        return $lockedUntil;
    }

    $windowStart = trim((string)($account['failed_login_window_start'] ?? ''));
    $windowTimestamp = $windowStart !== '' ? strtotime($windowStart) : false;
    $insideWindow = $windowTimestamp !== false && time() - $windowTimestamp < 900;
    $failures = $insideWindow ? (int)$account['failed_login_count'] + 1 : 1;
    $newWindowStart = $insideWindow ? $windowStart : date('Y-m-d H:i:s');
    $lock = $failures >= 8;

    if ($lock) {
        $update = $conn->prepare('UPDATE customer_accounts SET failed_login_count = ?, failed_login_window_start = ?, locked_until = DATE_ADD(CURRENT_TIMESTAMP, INTERVAL 15 MINUTE) WHERE id = ?');
    } else {
        $update = $conn->prepare('UPDATE customer_accounts SET failed_login_count = ?, failed_login_window_start = ?, locked_until = NULL WHERE id = ?');
    }
    if ($update) {
        $update->bind_param('isi', $failures, $newWindowStart, $accountId);
        $update->execute();
        $update->close();
    }

    return $lock ? time() + 900 : 0;
}

function customerAccountClearFailedLogins(int $accountId): void
{
    global $conn;
    $reset = $conn->prepare('UPDATE customer_accounts SET failed_login_count = 0, failed_login_window_start = NULL, locked_until = NULL WHERE id = ?');
    if ($reset) {
        $reset->bind_param('i', $accountId);
        $reset->execute();
        $reset->close();
    }
}

function customerAccountLoggedIn(): bool
{
    startCustomerAccountSession();
    $loggedIn = !empty($_SESSION['customer_account_authenticated'])
        && isset($_SESSION['customer_account_id'])
        && (int)$_SESSION['customer_account_id'] > 0;
    if (!$loggedIn) {
        return false;
    }

    $lastActivity = (int)($_SESSION['customer_account_last_activity'] ?? 0);
    if ($lastActivity > 0 && time() - $lastActivity > 1800) {
        customerAccountLogout();
        return false;
    }
    $_SESSION['customer_account_last_activity'] = time();
    return true;
}

function customerAccountLogin(int $accountId, string $fullName, string $email): void
{
    startCustomerAccountSession();
    session_regenerate_id(true);
    $_SESSION['customer_account_id'] = $accountId;
    $_SESSION['customer_account_name'] = $fullName;
    $_SESSION['customer_account_email'] = $email;
    $_SESSION['customer_account_authenticated'] = true;
    $_SESSION['customer_account_login_time'] = time();
    $_SESSION['customer_account_last_activity'] = time();
    unset($_SESSION['customer_login_pending_id'], $_SESSION['customer_login_pending_email']);
}

function customerAccountLogout(): void
{
    startCustomerAccountSession();
    unset(
        $_SESSION['customer_account_id'],
        $_SESSION['customer_account_name'],
        $_SESSION['customer_account_email'],
        $_SESSION['customer_account_authenticated'],
        $_SESSION['customer_account_login_time'],
        $_SESSION['customer_account_last_activity'],
        $_SESSION['customer_login_pending_id'],
        $_SESSION['customer_login_pending_email']
    );
    session_regenerate_id(true);
}

function requireCustomerAccount(): void
{
    global $conn;

    if (!customerAccountLoggedIn()) {
        header('Location: ' . appUrl('customer/login.php'), true, 302);
        exit;
    }

    $accountId = (int)$_SESSION['customer_account_id'];
    $stmt = $conn->prepare("SELECT status FROM customer_accounts WHERE id = ? LIMIT 1");
    if (!$stmt) {
        customerAccountLogout();
        header('Location: ' . appUrl('customer/login.php?unavailable=1'), true, 302);
        exit;
    }
    $stmt->bind_param('i', $accountId);
    $active = false;
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $account = $result ? $result->fetch_assoc() : null;
        $active = $account && (string)$account['status'] === 'active';
    }
    $stmt->close();

    if (!$active) {
        customerAccountLogout();
        header('Location: ' . appUrl('customer/login.php?unavailable=1'), true, 302);
        exit;
    }
}

/** Create or refresh a six-digit, ten-minute login code. */
function customerAccountIssueLoginCode(array $account): array
{
    global $conn;

    $accountId = (int)($account['id'] ?? 0);
    $email = (string)($account['email'] ?? '');
    $name = trim((string)($account['full_name'] ?? ''));
    if ($accountId <= 0 || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
        return ['sent' => false, 'cooldown' => false, 'message' => 'Akaunti haikuweza kuthibitishwa.'];
    }

    $previous = $conn->prepare('SELECT created_at, expires_at, attempt_count, consumed_at FROM customer_login_codes WHERE account_id = ? LIMIT 1');
    if ($previous) {
        $previous->bind_param('i', $accountId);
        if ($previous->execute()) {
            $result = $previous->get_result();
            $row = $result ? $result->fetch_assoc() : null;
            $createdAt = $row ? strtotime((string)$row['created_at']) : false;
            $expiresAt = $row ? strtotime((string)$row['expires_at']) : false;
            $codeStillUsable = $row
                && empty($row['consumed_at'])
                && (int)$row['attempt_count'] < 5
                && $expiresAt !== false
                && $expiresAt > time();
            if ($codeStillUsable && $createdAt !== false && time() - $createdAt < 60) {
                $previous->close();
                return ['sent' => false, 'cooldown' => true, 'message' => 'Code imetumwa hivi karibuni. Ingiza code iliyotumwa kwenye email yako.'];
            }
        }
        $previous->close();
    }

    $code = (string)random_int(100000, 999999);
    $codeHash = password_hash($code, PASSWORD_DEFAULT);
    if (!is_string($codeHash) || $codeHash === '') {
        return ['sent' => false, 'cooldown' => false, 'message' => 'Imeshindikana kutengeneza code ya kuingia.'];
    }

    $save = $conn->prepare("INSERT INTO customer_login_codes (account_id, code_hash, expires_at, attempt_count, consumed_at, created_at)
        VALUES (?, ?, DATE_ADD(CURRENT_TIMESTAMP, INTERVAL 5 MINUTE), 0, NULL, CURRENT_TIMESTAMP)
        ON DUPLICATE KEY UPDATE code_hash = VALUES(code_hash), expires_at = VALUES(expires_at), attempt_count = 0, consumed_at = NULL, created_at = CURRENT_TIMESTAMP");
    if (!$save) {
        appLog('Could not prepare customer login code storage', ['error' => $conn->error]);
        return ['sent' => false, 'cooldown' => false, 'message' => 'Email code haikuweza kutengenezwa. Jaribu tena.'];
    }
    $save->bind_param('is', $accountId, $codeHash);
    if (!$save->execute()) {
        appLog('Could not store customer login code', ['error' => $save->error]);
        $save->close();
        return ['sent' => false, 'cooldown' => false, 'message' => 'Email code haikuweza kutengenezwa. Jaribu tena.'];
    }
    $save->close();

    $greeting = $name !== '' ? $name : 'Mteja';
    $body = "Habari {$greeting},\n\nCode yako ya kuingia kwenye akaunti ya Wi-Fi Voucher ni: {$code}\n\nCode hii itatumika mara moja na itaisha baada ya dakika 5. Kama hukuomba kuingia, puuza email hii.\n";
    $sent = wifiCustomerSendEmail($email, APP_NAME . ' login code', $body);
    if (!$sent) {
        $delete = $conn->prepare('DELETE FROM customer_login_codes WHERE account_id = ?');
        if ($delete) {
            $delete->bind_param('i', $accountId);
            $delete->execute();
            $delete->close();
        }
        return ['sent' => false, 'cooldown' => false, 'message' => 'Imeshindikana kutuma code ya email. Hakikisha email ya mfumo imewekwa vizuri kisha ujaribu tena.'];
    }

    return ['sent' => true, 'cooldown' => false, 'message' => 'Tumetuma code ya kuingia kwenye email yako.'];
}

/** Consume a login code once; invalid attempts are counted up to five. */
function customerAccountVerifyLoginCode(int $accountId, string $code): array
{
    global $conn;

    if ($accountId <= 0 || !preg_match('/^\d{6}$/D', $code)) {
        return ['ok' => false, 'message' => 'Weka code ya tarakimu 6 iliyotumwa kwenye email yako.'];
    }

    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare('SELECT code_hash, expires_at, attempt_count, consumed_at, created_at FROM customer_login_codes WHERE account_id = ? FOR UPDATE');
        if (!$stmt) {
            throw new RuntimeException('Could not prepare customer code lookup.');
        }
        $stmt->bind_param('i', $accountId);
        if (!$stmt->execute()) {
            $stmt->close();
            throw new RuntimeException('Could not execute customer code lookup.');
        }
        $result = $stmt->get_result();
        $record = $result ? $result->fetch_assoc() : null;
        $stmt->close();

        $createdAt = $record ? strtotime((string)$record['created_at']) : false;
        $available = $record
            && empty($record['consumed_at'])
            && (int)$record['attempt_count'] < 5
            && $createdAt !== false
            && $createdAt > time() - 300
            && strtotime((string)$record['expires_at']) > time();
        $matches = $available && password_verify($code, (string)$record['code_hash']);

        if (!$matches) {
            if ($record && empty($record['consumed_at']) && (int)$record['attempt_count'] < 5) {
                $attempts = (int)$record['attempt_count'] + 1;
                $consume = $attempts >= 5 ? ', consumed_at = CURRENT_TIMESTAMP' : '';
                $update = $conn->prepare('UPDATE customer_login_codes SET attempt_count = ?' . $consume . ' WHERE account_id = ?');
                if ($update) {
                    $update->bind_param('ii', $attempts, $accountId);
                    $update->execute();
                    $update->close();
                }
            }
            $conn->commit();
            return ['ok' => false, 'message' => 'Code si sahihi, imeisha muda, au tayari imetumika. Omba code nyingine ujaribu tena.'];
        }

        $consume = $conn->prepare('UPDATE customer_login_codes SET consumed_at = CURRENT_TIMESTAMP WHERE account_id = ? AND consumed_at IS NULL');
        if (!$consume) {
            throw new RuntimeException('Could not prepare customer code consumption.');
        }
        $consume->bind_param('i', $accountId);
        if (!$consume->execute() || $consume->affected_rows !== 1) {
            $consume->close();
            throw new RuntimeException('Could not consume customer login code.');
        }
        $consume->close();
        $conn->commit();
        return ['ok' => true, 'message' => 'Code imethibitishwa.'];
    } catch (Throwable $exception) {
        $conn->rollback();
        appLog('Customer login code verification failed', ['error' => substr($exception->getMessage(), 0, 180)]);
        return ['ok' => false, 'message' => 'Imeshindikana kuthibitisha code kwa sasa. Jaribu tena.'];
    }
}
