<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| COMMON APPLICATION FUNCTIONS
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/../config/app.php';

/*
|--------------------------------------------------------------------------
| HTML ESCAPE
|--------------------------------------------------------------------------
*/

function e(mixed $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| REDIRECT
|--------------------------------------------------------------------------
*/

function redirect(string $path): never
{
    header('Location: ' . appUrl($path));
    exit;
}

/*
|--------------------------------------------------------------------------
| JSON RESPONSE
|--------------------------------------------------------------------------
*/

function jsonResponse(
    bool $success,
    string $message = '',
    array $data = [],
    int $statusCode = 200
): never {

    http_response_code($statusCode);

    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Pragma: no-cache');

    echo json_encode(
        [
            'success' => $success,
            'message' => $message,
            'data' => $data
        ],
        JSON_UNESCAPED_UNICODE |
        JSON_UNESCAPED_SLASHES
    );

    exit;
}

/*
|--------------------------------------------------------------------------
| REQUEST METHOD
|--------------------------------------------------------------------------
*/

function isPost(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
}

function isGet(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? '') === 'GET';
}

/*
|--------------------------------------------------------------------------
| POST VALUE
|--------------------------------------------------------------------------
*/

function postString(
    string $key,
    string $default = ''
): string {

    $value = $_POST[$key] ?? $default;

    if (is_array($value)) {
        return $default;
    }

    return trim((string)$value);
}

/*
|--------------------------------------------------------------------------
| GET VALUE
|--------------------------------------------------------------------------
*/

function getString(
    string $key,
    string $default = ''
): string {

    $value = $_GET[$key] ?? $default;

    if (is_array($value)) {
        return $default;
    }

    return trim((string)$value);
}

/*
|--------------------------------------------------------------------------
| INTEGER INPUT
|--------------------------------------------------------------------------
*/

function postInt(
    string $key,
    ?int $default = null
): ?int {

    $value = $_POST[$key] ?? null;

    if ($value === null || is_array($value)) {
        return $default;
    }

    if (
        filter_var(
            $value,
            FILTER_VALIDATE_INT
        ) === false
    ) {
        return $default;
    }

    return (int)$value;
}

function getInt(
    string $key,
    ?int $default = null
): ?int {

    $value = $_GET[$key] ?? null;

    if ($value === null || is_array($value)) {
        return $default;
    }

    if (
        filter_var(
            $value,
            FILTER_VALIDATE_INT
        ) === false
    ) {
        return $default;
    }

    return (int)$value;
}

/*
|--------------------------------------------------------------------------
| TANZANIA PHONE NORMALIZATION
|--------------------------------------------------------------------------
|
| Accepted examples:
|
| 0675409835
| +255675409835
| 255675409835
|
| Result:
|
| 255675409835
|--------------------------------------------------------------------------
*/

function normalizeTanzaniaPhone(string $phone): ?string
{
    $phone = trim($phone);

    /*
     * Remove spaces, dashes and brackets.
     */
    $phone = preg_replace(
        '/[\s\-\(\)]/',
        '',
        $phone
    );

    if ($phone === null || $phone === '') {
        return null;
    }

    /*
     * +255XXXXXXXXX
     */
    if (str_starts_with($phone, '+255')) {

        $phone = substr($phone, 1);
    }

    /*
     * 0XXXXXXXXX
     */
    if (
        strlen($phone) === 10 &&
        $phone[0] === '0'
    ) {

        $phone = '255' . substr($phone, 1);
    }

    /*
     * Validate final format.
     *
     * Tanzania mobile numbers:
     * 255 + 9 digits
     */
    if (
        !preg_match(
            '/^255[67]\d{8}$/',
            $phone
        )
    ) {
        return null;
    }

    return $phone;
}

/*
|--------------------------------------------------------------------------
| PHONE DISPLAY FORMAT
|--------------------------------------------------------------------------
*/

function formatTanzaniaPhone(string $phone): string
{
    $normalized = normalizeTanzaniaPhone($phone);

    if ($normalized === null) {
        return $phone;
    }

    return '0' . substr($normalized, 3);
}

/*
|--------------------------------------------------------------------------
| MONEY FORMAT
|--------------------------------------------------------------------------
*/

function formatMoney(
    float|int|string $amount
): string {

    return number_format(
        (float)$amount,
        0,
        '.',
        ','
    ) . ' ' . APP_CURRENCY;
}

/*
|--------------------------------------------------------------------------
| ORDER REFERENCE
|--------------------------------------------------------------------------
|
| Example:
| WIFI-20260928123945-A7F3C2
|--------------------------------------------------------------------------
*/

function generateOrderReference(): string
{
    return 'WIFI-' .
        date('YmdHis') .
        '-' .
        strtoupper(
            bin2hex(
                random_bytes(3)
            )
        );
}

/*
|--------------------------------------------------------------------------
| SECURE RANDOM STRING
|--------------------------------------------------------------------------
*/

function randomString(int $length = 32): string
{
    if ($length < 1) {
        $length = 1;
    }

    return substr(
        bin2hex(random_bytes(
            (int)ceil($length / 2)
        )),
        0,
        $length
    );
}

/*
|--------------------------------------------------------------------------
| VOUCHER STATUS
|--------------------------------------------------------------------------
*/

function isVoucherExpired(
    ?string $expiresAt
): bool {

    if (!$expiresAt) {
        return false;
    }

    $expiry = strtotime($expiresAt);

    if ($expiry === false) {
        return false;
    }

    return $expiry <= time();
}

/*
|--------------------------------------------------------------------------
| PAYMENT STATUS
|--------------------------------------------------------------------------
*/

function isSuccessfulPayment(string $status): bool
{
    return strtoupper(trim($status)) === 'SUCCESS';
}

function isPendingPayment(string $status): bool
{
    return strtoupper(trim($status)) === 'PENDING';
}

function isFailedPayment(string $status): bool
{
    return in_array(
        strtoupper(trim($status)),
        [
            'FAILED',
            'CANCELLED',
            'CANCELED',
            'EXPIRED'
        ],
        true
    );
}

/*
|--------------------------------------------------------------------------
| SAFE DATABASE ERROR LOGGING
|--------------------------------------------------------------------------
|
| Never show database errors to customers.
|--------------------------------------------------------------------------
*/

function logDatabaseError(
    mysqli $conn,
    string $context = ''
): void {

    appLog(
        'Database error',
        [
            'context' => $context,
            'error' => $conn->error
        ]
    );
}

/*
|--------------------------------------------------------------------------
| SAFE EXCEPTION LOGGING
|--------------------------------------------------------------------------
*/

function logException(
    Throwable $exception,
    string $context = ''
): void {

    appLog(
        'Application exception',
        [
            'context' => $context,
            'type' => get_class($exception),
            'message' => $exception->getMessage(),
            'file' => $exception->getFile(),
            'line' => $exception->getLine()
        ]
    );
}

/*
|--------------------------------------------------------------------------
| PUBLIC ERROR MESSAGE
|--------------------------------------------------------------------------
*/

function publicErrorMessage(
    string $default = 'Something went wrong. Please try again.'
): string {

    if (defined('APP_DEBUG') && APP_DEBUG) {
        return $default;
    }

    return 'Something went wrong. Please try again later.';
}

/*
|--------------------------------------------------------------------------
| REQUEST ID
|--------------------------------------------------------------------------
|
| Useful for matching customer errors with server logs
| without exposing sensitive information.
|--------------------------------------------------------------------------
*/

function requestId(): string
{
    static $id = null;

    if ($id === null) {
        $id = strtoupper(
            bin2hex(random_bytes(8))
        );
    }

    return $id;
}

/*
|--------------------------------------------------------------------------
| CLIENT IP
|--------------------------------------------------------------------------
|
| Do not blindly trust X-Forwarded-For.
| We use REMOTE_ADDR by default.
|--------------------------------------------------------------------------
*/

function clientIp(): string
{
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

/*
|--------------------------------------------------------------------------
| USER AGENT
|--------------------------------------------------------------------------
*/

function userAgent(): string
{
    return substr(
        $_SERVER['HTTP_USER_AGENT'] ?? '',
        0,
        500
    );
}

/*
|--------------------------------------------------------------------------
| CHECK POSITIVE AMOUNT
|--------------------------------------------------------------------------
*/

function validAmount(
    mixed $amount
): bool {

    if (!is_numeric($amount)) {
        return false;
    }

    return (float)$amount > 0;
}

/*
|--------------------------------------------------------------------------
| NORMALIZE PAYMENT STATUS
|--------------------------------------------------------------------------
*/

function normalizePaymentStatus(string $status): string
{
    return strtoupper(
        trim($status)
    );
}

/*
|--------------------------------------------------------------------------
| NORMALIZE VOUCHER SOURCE
|--------------------------------------------------------------------------
*/

function normalizeVoucherSource(string $source): string
{
    $source = strtolower(
        trim($source)
    );

    return match ($source) {
        'payment',
        'auto',
        'automatic',
        'online' => 'automatic',

        'manual',
        'admin' => 'manual',

        default => $source
    };
}