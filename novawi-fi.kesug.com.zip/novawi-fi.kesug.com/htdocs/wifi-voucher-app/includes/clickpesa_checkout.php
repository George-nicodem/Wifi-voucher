<?php
declare(strict_types=1);

/* ClickPesa adapter used by the customer checkout, status page and webhook. */
require_once dirname(__DIR__) . '/config/app.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/config/security.php';
require_once __DIR__ . '/payment_provider_catalog.php';
require_once __DIR__ . '/payment_provider_adapters.php';
require_once __DIR__ . '/package_data_limits.php';

const WIFI_CP_API_BASE = 'https://api.clickpesa.com/third-parties';

/** An HTTP rejection, distinct from an unknown network or response outcome. */
final class WiFiClickPesaHttpException extends RuntimeException
{
    public function __construct(string $message, private int $httpStatus)
    {
        parent::__construct($message, $httpStatus);
    }

    public function getHttpStatus(): int
    {
        return $this->httpStatus;
    }
}

/** Use only around the initiate request, before any accepted-response processing. */
function wifiCpIsDefinitiveInitiationRejection(Throwable $error): bool
{
    return $error instanceof WiFiClickPesaHttpException
        && in_array($error->getHttpStatus(), [400, 401, 403, 404, 405, 410, 422], true);
}

function wifiCpIsClickPesaChannel(array $channel): bool
{
    return wifiPaymentProviderKeyFromChannel($channel) === 'clickpesa';
}

function wifiCpBuildChannelConfig(array $channel): array
{
    if (!wifiCpIsClickPesaChannel($channel)) {
        throw new RuntimeException('Channel hii haina adapter ya malipo iliyounganishwa bado.');
    }

    if (strtolower(trim((string)($channel['status'] ?? ''))) !== 'enabled'
        || (int)($channel['configured'] ?? 0) !== 1) {
        throw new RuntimeException('Akaunti ya ClickPesa haijawezeshwa au haijathibitishwa.');
    }

    $clientId = trim((string)($channel['client_id'] ?? ''));
    $encryptedApiKey = trim((string)($channel['api_key_enc'] ?? ''));
    $encryptedChecksum = trim((string)($channel['checksum_secret'] ?? ''));
    $baseUrl = trim((string)($channel['api_base_url'] ?? ''));

    if ($clientId === '' || $encryptedApiKey === '' || $encryptedChecksum === '') {
        throw new RuntimeException('Taarifa za API za akaunti ya ClickPesa hazijakamilika.');
    }

    try {
        $apiKey = decryptData($encryptedApiKey);
        $checksumKey = decryptData($encryptedChecksum);
    } catch (Throwable $exception) {
        throw new RuntimeException('Credentials za ClickPesa haziwezi kufunguliwa. Hakiki APP_ENCRYPTION_KEY kwenye .env.');
    }

    if ($apiKey === '' || $checksumKey === '') {
        throw new RuntimeException('Credentials za ClickPesa hazijakamilika.');
    }
    foreach ([$clientId, $apiKey, $checksumKey] as $credentialValue) {
        if (preg_match('/[\r\n]/', (string)$credentialValue)) {
            throw new RuntimeException('Credentials za ClickPesa zina alama zisizokubalika.');
        }
    }

    if ($baseUrl === '') {
        $baseUrl = WIFI_CP_API_BASE;
    }
    $parts = parse_url($baseUrl);
    $scheme = strtolower((string)($parts['scheme'] ?? ''));
    if (!is_array($parts) || !isset($parts['host']) || $scheme !== 'https'
        || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])
        || !wifiPaymentProviderHostAllowed('clickpesa', (string)$parts['host'])) {
        throw new RuntimeException('ClickPesa API Base URL lazima itumie HTTPS kwenye domain rasmi ya ClickPesa.');
    }

    return [
        'channel_id' => (int)($channel['id'] ?? 0),
        'channel_name' => trim((string)($channel['name'] ?? 'ClickPesa')) ?: 'ClickPesa',
        'provider_key' => 'clickpesa',
        'client_id' => $clientId,
        'api_key' => $apiKey,
        'checksum_key' => $checksumKey,
        'api_base_url' => rtrim($baseUrl, '/'),
        'environment' => trim((string)($channel['environment'] ?? 'live')),
    ];
}

function wifiCpChannelConfig(mysqli $db, int $channelId, bool $requireEnabled = true): array
{
    if ($channelId <= 0) {
        throw new RuntimeException('Akaunti ya malipo haipo.');
    }
    $stmt = $db->prepare('SELECT id, name, type, channel_type, environment, status, configured, api_base_url, client_id, api_key_enc, checksum_secret FROM payment_channels WHERE id = ? LIMIT 1');
    if (!$stmt) {
        throw new RuntimeException('Imeshindikana kusoma akaunti ya malipo.');
    }
    $stmt->bind_param('i', $channelId);
    if (!$stmt->execute()) {
        $stmt->close();
        throw new RuntimeException('Imeshindikana kusoma akaunti ya malipo.');
    }
    $channel = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    if (!$channel) {
        throw new RuntimeException('Akaunti ya malipo iliyohifadhiwa haipatikani.');
    }
    if (!$requireEnabled) {
        // A callback for an in-flight payment must still be verified if an admin
        // disabled the channel after the customer started the payment.
        $channel['status'] = 'enabled';
        $channel['configured'] = 1;
    }
    return wifiCpBuildChannelConfig($channel);
}

function wifiCpConfigForPayment(mysqli $db, array $payment): array
{
    $channelId = (int)($payment['payment_channel_id'] ?? 0);
    if ($channelId <= 0) {
        throw new RuntimeException('This payment has no saved aggregator channel. Legacy credentials from .env are no longer supported.');
    }
    $stmt = $db->prepare('SELECT id, name, type, channel_type FROM payment_channels WHERE id = ? LIMIT 1');
    if (!$stmt) throw new RuntimeException('Imeshindikana kutambua akaunti ya malipo.');
    $stmt->bind_param('i', $channelId);
    if (!$stmt->execute()) { $stmt->close(); throw new RuntimeException('Imeshindikana kusoma akaunti ya malipo.'); }
    $channel = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    if (!$channel) throw new RuntimeException('Akaunti ya malipo haipatikani.');
    $providerKey = wifiPaymentProviderKeyFromChannel($channel);
    return $providerKey === 'clickpesa'
        ? wifiCpChannelConfig($db, $channelId, false)
        : wifiPaymentLoadChannelConfig($db, $channelId, false);
}

function wifiCpRequest(string $path, string $method, ?array $payload = null, array $extraHeaders = [], string $baseUrl = WIFI_CP_API_BASE): array
{
    if (!function_exists('curl_init')) {
        throw new RuntimeException('PHP cURL haijawashwa kwenye server. Washa cURL kwenye usanidi wa PHP wa hosting yako.');
    }
    $baseUrl = rtrim(trim($baseUrl) !== '' ? trim($baseUrl) : WIFI_CP_API_BASE, '/');
    $url = $baseUrl . '/' . ltrim($path, '/');
    $headers = array_merge(['Accept: application/json'], $extraHeaders);
    $options = [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 25,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_CUSTOMREQUEST => strtoupper($method),
        CURLOPT_HTTPHEADER => $headers,
    ];
    if ($payload !== null) {
        $options[CURLOPT_POSTFIELDS] = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $options[CURLOPT_HTTPHEADER][] = 'Content-Type: application/json';
    }
    $curl = curl_init();
    curl_setopt_array($curl, $options);
    $raw = curl_exec($curl);
    $httpCode = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $curlError = curl_error($curl);
    curl_close($curl);
    if ($raw === false) {
        throw new RuntimeException('Imeshindikana kuwasiliana na ClickPesa: ' . ($curlError ?: 'hitilafu ya mtandao.'));
    }
    $decoded = json_decode((string)$raw, true);
    $providerMessage = '';
    if ($httpCode < 200 || $httpCode >= 300) {
        $candidateMessage = ''; if (is_array($decoded)) { $findMessage = static function (array $value, int $depth = 0) use (&$findMessage): string { if ($depth > 5) return ''; foreach (['message', 'error', 'detail', 'description', 'reason'] as $key) { if (isset($value[$key]) && is_scalar($value[$key])) return (string)$value[$key]; } foreach ($value as $nested) { if (is_array($nested)) { $found = $findMessage($nested, $depth + 1); if ($found !== '') return $found; } } return ''; }; $candidateMessage = $findMessage($decoded); } elseif (is_string($decoded) && $decoded !== '') { $candidateMessage = $decoded; } else { $candidateMessage = (string)$raw; }
        if (is_scalar($candidateMessage)) {
            $providerMessage = trim(strip_tags((string)$candidateMessage));
            $providerMessage = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $providerMessage) ?? '';
            $providerMessage = preg_replace('/\s+/u', ' ', $providerMessage) ?? '';
            $providerMessage = preg_replace('/(?<!\d)(?:\+?255|0)?[67][0-9]{8}(?!\d)/', '[namba imefichwa]', $providerMessage) ?? $providerMessage;
            $providerMessage = preg_replace('/\bBearer\s+[A-Za-z0-9._~+\/=-]+/i', '[token redacted]', $providerMessage) ?? $providerMessage; $providerMessage = preg_replace('/\b[A-Za-z0-9_-]{32,}\b/', '[token redacted]', $providerMessage) ?? $providerMessage; $providerMessage = function_exists('mb_substr') ? mb_substr($providerMessage, 0, 200) : substr($providerMessage, 0, 200);
        }
        if (function_exists('appLog')) {
            appLog('ClickPesa API request rejected', [
                'method' => strtoupper($method), 'api_path' => $path,
                'http_status' => $httpCode,
                'provider_message' => $providerMessage,
            ]);
        }
        if ($httpCode === 401 || $httpCode === 403) {
            throw new WiFiClickPesaHttpException('ClickPesa rejected the API credentials or this account lacks access (HTTP ' . $httpCode . '). Check the active merchant workspace, Client ID, API Key, and environment.', $httpCode);
        }
        if (in_array($httpCode, [502, 503, 504], true)) {
            $message = 'ClickPesa is temporarily unavailable (HTTP ' . $httpCode . '). Wait briefly and retry.';
            if (strtoupper($method) === 'GET' && rtrim($path, '/') === '/list/banks') {
                $message .= ' This was a read-only bank-list request; no payout was submitted.';
            }
            throw new WiFiClickPesaHttpException($message, $httpCode);
        }
        if ($httpCode === 429) {
            $message = 'ClickPesa is rate-limiting requests (HTTP 429). Wait briefly before retrying.';
            if (strtoupper($method) === 'GET' && rtrim($path, '/') === '/list/banks') {
                $message .= ' This was a read-only bank-list request; no payout was submitted.';
            }
            throw new WiFiClickPesaHttpException($message, $httpCode);
        }
        $message = 'ClickPesa rejected the API request (HTTP ' . $httpCode . ').';
        if ($providerMessage !== '') {
            $message .= ' ClickPesa says: ' . $providerMessage;
        } else {
            $message .= ' Check the API URL and request settings.';
        }
        throw new WiFiClickPesaHttpException($message, $httpCode);
    }
    if (!is_array($decoded)) {
        throw new RuntimeException('ClickPesa returned an unreadable response (HTTP ' . $httpCode . ').');
    }
    return $decoded;
}

function wifiCpCanonicalNetwork(string ...$values): string
{
    foreach ($values as $value) {
        $key = preg_replace('/[^A-Z0-9]+/', '', strtoupper($value)) ?? '';
        if ($key === '') {
            continue;
        }
        if (str_contains($key, 'MPESA') || str_contains($key, 'VODACOM')) return 'mpesa';
        if (str_contains($key, 'AIRTEL')) return 'airtel';
        if (str_contains($key, 'MIXX') || str_contains($key, 'YAS') || str_contains($key, 'TIGOPESA')) return 'mixx_yas';
        if (str_contains($key, 'HALO') || str_contains($key, 'HALOTEL')) return 'halotel';
        if (str_contains($key, 'TTCL')) return 'ttcl';
        if (str_contains($key, 'EZPESA') || str_contains($key, 'ZANTEL')) return 'zantel';
    }
    return '';
}

function wifiCpMethodMatchesNetwork(string $methodName, string $networkId): bool
{
    $methodNetwork = wifiCpCanonicalNetwork($methodName);
    $selectedNetwork = wifiCpCanonicalNetwork($networkId);
    return $methodNetwork !== '' && $methodNetwork === $selectedNetwork;
}

function wifiCpResolveRoute(mysqli $db, int $paymentMethodId, ?int $requestedChannelId = null): array
{
    $methodStmt = $db->prepare("SELECT id, name, display_name, provider_code FROM payment_methods WHERE id = ? AND LOWER(status) = 'enabled' LIMIT 1");
    if (!$methodStmt) {
        throw new RuntimeException('Imeshindikana kuthibitisha mtandao uliochaguliwa.');
    }
    $methodStmt->bind_param('i', $paymentMethodId);
    $methodStmt->execute();
    $method = $methodStmt->get_result()->fetch_assoc() ?: null;
    $methodStmt->close();
    if (!$method) {
        throw new RuntimeException('Mtandao huu haupatikani kwa malipo kwa sasa.');
    }

    $networkCode = trim((string)($method['provider_code'] ?? ''));
    if ($networkCode === '') {
        throw new RuntimeException('Mtandao huu haujawekewa provider code. Wasiliana na msimamizi.');
    }
    $routeStmt = $db->prepare('SELECT primary_channel_id, backup_channel_id FROM payment_routing WHERE UPPER(TRIM(network_code)) = UPPER(?) ORDER BY id ASC LIMIT 1');
    if (!$routeStmt) {
        throw new RuntimeException('Payment Routing haipatikani kwa sasa.');
    }
    $routeStmt->bind_param('s', $networkCode);
    $routeStmt->execute();
    $route = $routeStmt->get_result()->fetch_assoc() ?: null;
    $routeStmt->close();
    if (!$route && ($requestedChannelId ?? 0) <= 0) {
        throw new RuntimeException('Hakuna aggregator iliyopangiwa mtandao huu. Wasiliana na msimamizi.');
    }

    // Checkout passes no requested channel: the administrator's primary and
    // fallback route control provider selection on the server. The optional ID
    // remains for internal compatibility, but it is never taken from checkout.
    $candidateIds = ($requestedChannelId ?? 0) > 0
        ? [(int)$requestedChannelId]
        : array_values(array_unique(array_filter([
            (int)($route['primary_channel_id'] ?? 0),
            (int)($route['backup_channel_id'] ?? 0),
        ], static fn(int $id): bool => $id > 0)));
    $sawUnsupported = false;

    foreach ($candidateIds as $channelId) {
        $channelStmt = $db->prepare("SELECT pc.id, pc.name, pc.type, pc.channel_type, pc.environment, pc.status, pc.configured,
                pc.api_base_url, pc.callback_url, pc.client_id, pc.merchant_id, pc.api_key_enc, pc.api_secret_enc,
                pc.checksum_secret, cpm.provider_code AS channel_network_code, cpm.status AS mapping_status
            FROM payment_channels pc
            INNER JOIN channel_payment_methods cpm ON cpm.channel_id = pc.id
            WHERE pc.id = ? AND cpm.payment_method_id = ? LIMIT 1");
        if (!$channelStmt) {
            throw new RuntimeException('Imeshindikana kukagua aggregator ya mtandao huu.');
        }
        $channelStmt->bind_param('ii', $channelId, $paymentMethodId);
        $channelStmt->execute();
        $channel = $channelStmt->get_result()->fetch_assoc() ?: null;
        $channelStmt->close();
        if (!$channel || strtolower((string)$channel['status']) !== 'enabled'
            || strtolower((string)$channel['mapping_status']) !== 'enabled'
            || (int)$channel['configured'] !== 1) {
            continue;
        }
        try {
            $providerKey = wifiPaymentProviderKeyFromChannel($channel);
            $canonicalNetwork = wifiCpCanonicalNetwork(
                (string)($method['provider_code'] ?? ''),
                (string)($method['name'] ?? ''),
                (string)($method['display_name'] ?? '')
            );
            if (!wifiPaymentProviderAdapterReady($providerKey)
                || !wifiPaymentProviderSupportsNetwork($providerKey, $canonicalNetwork)) {
                $sawUnsupported = true;
                continue;
            }
            $config = $providerKey === 'clickpesa'
                ? wifiCpBuildChannelConfig($channel)
                : wifiPaymentLoadChannelConfig($db, $channelId, true);
            return ['method' => $method, 'channel' => $channel, 'config' => $config, 'provider_key' => $providerKey];
        } catch (Throwable $exception) {
            // An unusable primary is skipped so a configured backup can be used.
            continue;
        }
    }

    if ($sawUnsupported) throw new RuntimeException('Aggregator iliyopangiwa mtandao huu haijaunganishwa kwa mtandao huo au taarifa zake hazijakamilika. Kagua Payment Channels na Routing.');
    throw new RuntimeException('Hakuna aggregator iliyo enabled na kuthibitishwa kwa mtandao huu.');
}

function wifiCpCustomerChannelsForMethod(mysqli $db, int $paymentMethodId): array
{
    $stmt = $db->prepare("SELECT pc.id, pc.name, pc.type, pc.channel_type, pc.environment,
            pc.status, pc.configured, pc.api_base_url, pc.client_id, pc.api_key_enc,
            pc.checksum_secret, cpm.status AS mapping_status
        FROM channel_payment_methods cpm
        INNER JOIN payment_channels pc ON pc.id = cpm.channel_id
        WHERE cpm.payment_method_id = ?
          AND LOWER(TRIM(cpm.status)) = 'enabled'
          AND LOWER(TRIM(pc.status)) = 'enabled'
          AND pc.configured = 1
        ORDER BY pc.name ASC, pc.id ASC");
    if (!$stmt) {
        throw new RuntimeException('Imeshindikana kusoma akaunti zinazounga mkono mtandao huu.');
    }
    $stmt->bind_param('i', $paymentMethodId);
    if (!$stmt->execute()) {
        $stmt->close();
        throw new RuntimeException('Imeshindikana kusoma akaunti zinazounga mkono mtandao huu.');
    }
    $result = $stmt->get_result();
    $channels = [];
    while ($channel = $result->fetch_assoc()) {
        $channelId = (int)$channel['id'];
        try {
            $route = wifiCpResolveRoute($db, $paymentMethodId, $channelId);
            $providerKey = wifiPaymentProviderKeyFromChannel($route['channel']);
            if (!wifiPaymentProviderAdapterReady($providerKey)) {
                continue;
            }
            $channels[] = [
                'id' => $channelId,
                'name' => trim((string)$channel['name']) ?: wifiPaymentProviderLabel($providerKey),
                'provider_key' => $providerKey,
                'provider_name' => wifiPaymentProviderLabel($providerKey),
            ];
        } catch (Throwable $exception) {
            // An invalid mapping or incomplete provider account is hidden from
            // checkout; it remains available for admin setup.
            continue;
        }
    }
    $stmt->close();
    return $channels;
}

function wifiCpCustomerNetworks(mysqli $db): array
{
    $definitions = [
        'mpesa' => ['name' => 'M-Pesa', 'logo' => 'M-pesa.svg', 'fallback' => 'M', 'tone' => 'mpesa'],
        'airtel' => ['name' => 'Airtel Money', 'logo' => 'airtel-money.svg', 'fallback' => 'A', 'tone' => 'airtel'],
        'mixx_yas' => ['name' => 'Mixx by Yas', 'logo' => 'mixx-by-yas.svg', 'fallback' => 'MY', 'tone' => 'mixx'],
        'halotel' => ['name' => 'HaloPesa', 'logo' => 'halopesa.svg', 'fallback' => 'H', 'tone' => 'halotel'],
        'ttcl' => ['name' => 'TTCL', 'logo' => 'TTCL.svg', 'fallback' => 'T', 'tone' => 'ttcl'],
        'zantel' => ['name' => 'Zantel eZPesa', 'logo' => '', 'fallback' => 'eZ', 'tone' => 'zantel'],
    ];

    $channelCount = $db->query('SELECT COUNT(*) AS total FROM payment_channels');
    $hasAnyChannel = (int)($channelCount?->fetch_assoc()['total'] ?? 0) > 0;
    if (!$hasAnyChannel) {
        return [];
    }

    $result = $db->query("SELECT id, name, display_name, provider_code, icon FROM payment_methods WHERE LOWER(status) = 'enabled' ORDER BY COALESCE(display_order, 0) ASC, display_name ASC, id ASC");
    if (!$result) {
        throw new RuntimeException('Mitandao ya malipo haikuweza kusomwa.');
    }
    $options = [];
    while ($method = $result->fetch_assoc()) {
        $canonical = wifiCpCanonicalNetwork(
            (string)($method['provider_code'] ?? ''),
            (string)($method['name'] ?? ''),
            (string)($method['display_name'] ?? '')
        );
        if ($canonical === '' || !isset($definitions[$canonical])) {
            continue;
        }
        try {
            $defaultRoute = wifiCpResolveRoute($db, (int)$method['id']);
        } catch (Throwable $exception) {
            // Do not show a network unless the administrator's primary/fallback
            // routing resolves to a configured payment adapter.
            continue;
        }
        $choice = 'method:' . (int)$method['id'];
        $networkDefinition = $definitions[$canonical];
        $customLogo = trim((string)($method['icon'] ?? ''));
        if (preg_match('~^custom/network-[1-9][0-9]*-[a-f0-9]{16}\.(?:png|jpg|webp)$~D', $customLogo) === 1) {
            $networkDefinition['logo'] = $customLogo;
        }
        $options[$choice] = $networkDefinition + [
            'choice' => $choice,
            'canonical' => $canonical,
            'method_id' => (int)$method['id'],
            'network_code' => (string)$method['provider_code'],
            'network_name' => trim((string)($method['display_name'] ?? '')) ?: $definitions[$canonical]['name'],
            'requires_contact' => wifiPaymentProviderNeedsContact((string)($defaultRoute['provider_key'] ?? '')),
        ];
    }
    return $options;
}

function wifiCpNewReference(): string
{
    return 'W' . strtoupper(date('ymdHis')) . strtoupper(substr(strtr(base64_encode(random_bytes(8)), '+/', 'AZ'), 0, 7));
}

function wifiCpAmountCents(mixed $amount): ?int
{
    $text = trim((string)$amount);
    if (!preg_match('/^\d+(?:\.\d{1,2})?$/', $text)) {
        return null;
    }
    [$whole, $fraction] = array_pad(explode('.', $text, 2), 2, '');
    return ((int)$whole * 100) + (int)str_pad($fraction, 2, '0');
}

function wifiCpActivePackages(mysqli $db): array
{
    if (!wifiPackageEnsureDataLimitColumn($db)) {
        throw new RuntimeException('Imeshindikana kuandaa kikomo cha data ya package.');
    }
$result = $db->query("SELECT id, name, price, duration_minutes, speed_limit, data_limit_mb FROM packages WHERE LOWER(status) IN ('active', 'enabled', '1') ORDER BY price ASC, id ASC");
    if (!$result) {
        throw new RuntimeException('Imeshindikana kusoma vifurushi active kutoka database.');
    }
    return $result->fetch_all(MYSQLI_ASSOC);
}

function wifiCpCreatePendingPayment(mysqli $db, string $phone, int $packageId, float $amount, string $reference, int $channelId, string $channelName): void
{
    $methodLabel = function_exists('mb_substr') ? mb_substr($channelName, 0, 50) : substr($channelName, 0, 50);
    if ($channelId > 0) {
        $stmt = $db->prepare("INSERT INTO payments (phone, package_id, amount, order_reference, payment_method, payment_channel_id, status)
            VALUES (?, ?, ?, ?, ?, ?, 'PENDING')");
        if (!$stmt) {
            throw new RuntimeException('Imeshindikana kuandaa rekodi ya malipo. Hakiki kuwa database migration imewekwa.');
        }
        $stmt->bind_param('sidssi', $phone, $packageId, $amount, $reference, $methodLabel, $channelId);
    } else {
        $stmt = $db->prepare("INSERT INTO payments (phone, package_id, amount, order_reference, payment_method, payment_channel_id, status)
            VALUES (?, ?, ?, ?, ?, NULL, 'PENDING')");
        if (!$stmt) {
            throw new RuntimeException('Imeshindikana kuandaa rekodi ya malipo. Hakiki kuwa database migration imewekwa.');
        }
        $stmt->bind_param('sidss', $phone, $packageId, $amount, $reference, $methodLabel);
    }
    if (!$stmt->execute()) {
        $stmt->close();
        throw new RuntimeException('Imeshindikana kuhifadhi ombi la malipo.');
    }
    $stmt->close();
}

function wifiCpProviderPayment(string $reference, array $config): array
{
    $response = wifiCpRequest('/payments/' . rawurlencode($reference), 'GET', null, [
        'Authorization: ' . wifiCpToken($config),
    ], (string)$config['api_base_url']);
    if (array_is_list($response) && isset($response[0]) && is_array($response[0])) {
        return $response[0];
    }
    if (isset($response['data']) && is_array($response['data']) && isset($response['data']['status'])) {
        return $response['data'];
    }
    return $response;
}

function wifiCpCanonicalize(mixed $value): mixed
{
    if (!is_array($value)) return $value;
    if (array_is_list($value)) return array_map('wifiCpCanonicalize', $value);
    ksort($value, SORT_STRING);
    foreach ($value as $key => $item) $value[$key] = wifiCpCanonicalize($item);
    return $value;
}

function wifiCpChecksum(array $payload, string $key): string
{
    unset($payload['checksum'], $payload['checksumMethod']);
    $serialized = json_encode(wifiCpCanonicalize($payload), JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    return hash_hmac('sha256', $serialized, $key);
}

function wifiCpSignPayload(array $payload, string $key): array
{
    if ($key !== '') $payload['checksum'] = wifiCpChecksum($payload, $key);
    return $payload;
}

function wifiCpVerifyWebhook(array $payload, string $key): bool
{
    $provided = trim((string)($payload['checksum'] ?? ''));
    return $key !== '' && $provided !== '' && hash_equals(wifiCpChecksum($payload, $key), strtolower($provided));
}

function wifiCpToken(array $config): string
{
    // Shared across PHP sessions/requests on this server. The credentials are
    // hashed for the filename; the cache file itself contains the bearer token.
    $cacheKey = hash(
        'sha256',
        (string)$config['client_id'] . "\0" .
        (string)$config['api_key'] . "\0" .
        (string)$config['api_base_url']
    );
    $cacheFile = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
        . DIRECTORY_SEPARATOR . 'nova_wifi_cp_' . $cacheKey . '.json';

    $handle = @fopen($cacheFile, 'c+');
    if ($handle === false) {
        throw new RuntimeException('Imeshindikana kufungua ClickPesa token cache.');
    }

    try {
        @chmod($cacheFile, 0600);
        if (!flock($handle, LOCK_EX)) {
            throw new RuntimeException('Imeshindikana kufunga ClickPesa token cache.');
        }

        rewind($handle);
        $raw = stream_get_contents($handle);
        $cache = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($cache)) {
            $cache = [];
        }

        $now = time();
        $cachedToken = (string)($cache['token'] ?? '');
        $expiresAt = (int)($cache['expires_at'] ?? 0);

        // Reuse a valid token across independent requests and PHP sessions.
        if ($cachedToken !== '' && $expiresAt > $now + 45) {
            return $cachedToken;
        }

        // Avoid hammering ClickPesa after its explicit 429 / three-minute limit.
        $retryAfter = (int)($cache['retry_after'] ?? 0);
        if ($retryAfter > $now) {
            throw new RuntimeException(
                'ClickPesa token requests are temporarily paused. Try again in '
                . ($retryAfter - $now) . ' seconds.'
            );
        }

        try {
            $response = wifiCpRequest('/generate-token', 'POST', null, [
                'client-id: ' . $config['client_id'],
                'api-key: ' . $config['api_key'],
            ], (string)$config['api_base_url']);
        } catch (Throwable $exception) {
            if (strpos($exception->getMessage(), 'HTTP 429') !== false) {
                $cache = [
                    'token' => '',
                    'expires_at' => 0,
                    'retry_after' => time() + 180,
                ];
                rewind($handle);
                ftruncate($handle, 0);
                fwrite($handle, json_encode($cache, JSON_THROW_ON_ERROR));
                fflush($handle);
            }
            throw $exception;
        }

        $token = trim((string)($response['token'] ?? ''));
        if ($token === '') {
            throw new RuntimeException('ClickPesa haikurudisha token ya API.');
        }
        if (!str_starts_with($token, 'Bearer ')) {
            $token = 'Bearer ' . $token;
        }

        $cache = [
            'token' => $token,
            'expires_at' => time() + 3500,
            'retry_after' => 0,
        ];
        rewind($handle);
        ftruncate($handle, 0);
        fwrite($handle, json_encode($cache, JSON_THROW_ON_ERROR));
        fflush($handle);

        return $token;
    } finally {
        // flock() is harmless here even if acquisition failed; close releases it too.
        @flock($handle, LOCK_UN);
        fclose($handle);
    }
}
function wifiCpNormalizePhone(string $input): ?string
{
    $digits = preg_replace('/\D+/', '', $input) ?? '';
    if (str_starts_with($digits, '00')) $digits = substr($digits, 2);
    elseif (str_starts_with($digits, '0')) $digits = '255' . substr($digits, 1);
    return preg_match('/^255[67][0-9]{8}$/', $digits) ? $digits : null;
}

function wifiCpPaymentRow(mysqli $db, string $reference): ?array
{
    $stmt = $db->prepare("SELECT p.id, p.phone, p.package_id, p.amount, p.order_reference,
            p.transaction_reference, p.payment_method, p.payment_channel_id, p.status, p.voucher_id, p.created_at, p.paid_at,
            pk.name AS package_name,
            v.code AS voucher_code, v.status AS voucher_status,
            v.activated_at AS voucher_activated_at, v.expires_at AS voucher_expires_at
        FROM payments p
        LEFT JOIN packages pk ON pk.id = p.package_id
        LEFT JOIN vouchers v ON v.id = p.voucher_id
        WHERE p.order_reference = ? LIMIT 1");
    if (!$stmt) throw new RuntimeException('Imeshindikana kusoma malipo kutoka database.');
    $stmt->bind_param('s', $reference);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    return $row;
}

function wifiCpMarkPendingStatus(mysqli $db, string $reference, string $status): void
{
    $allowed = ['PENDING', 'PROCESSING', 'FAILED', 'CANCELLED', 'CANCELED'];
    if (!in_array($status, $allowed, true)) return;
    if ($status === 'CANCELED') $status = 'CANCELLED';
    $stmt = $db->prepare("UPDATE payments SET status = ? WHERE order_reference = ? AND voucher_id IS NULL AND status IN ('PENDING', 'PROCESSING')");
    if (!$stmt) throw new RuntimeException('Imeshindikana kusasisha hali ya malipo.');
    $stmt->bind_param('ss', $status, $reference);
    if (!$stmt->execute()) {
        $stmt->close();
        throw new RuntimeException('Imeshindikana kusasisha hali ya malipo.');
    }
    $stmt->close();
}

function wifiCpUniqueVoucherCode(mysqli $db): string
{
    $check = $db->prepare('SELECT id FROM vouchers WHERE code = ? LIMIT 1');
    if (!$check) throw new RuntimeException('Imeshindikana kuangalia code ya voucher.');
    for ($attempt = 0; $attempt < 16; $attempt++) {
        $code = generateVoucherCode(VOUCHER_CODE_LENGTH);
        $check->bind_param('s', $code);
        $check->execute();
        if (!$check->get_result()->fetch_assoc()) {
            $check->close();
            return $code;
        }
    }
    $check->close();
    throw new RuntimeException('Imeshindikana kutengeneza code ya kipekee ya voucher.');
}

function wifiCpIssueVerifiedVoucher(mysqli $db, string $reference, array $providerPayment, ?array $config = null): array
{
    $config ??= wifiCpConfigForPayment($db, wifiCpPaymentRow($db, $reference) ?? []);
    $providerStatus = strtoupper(trim((string)($providerPayment['status'] ?? '')));
    $providerReference = trim((string)($providerPayment['orderReference'] ?? ''));
    if (!in_array($providerStatus, ['SUCCESS', 'SETTLED'], true) || $providerReference === '' || !hash_equals($reference, $providerReference)) {
        throw new RuntimeException('ClickPesa bado haijathibitisha malipo haya.');
    }
    $collectedCents = wifiCpAmountCents($providerPayment['collectedAmount'] ?? null);
    $currency = strtoupper(trim((string)($providerPayment['collectedCurrency'] ?? '')));
    if ($collectedCents === null || $currency !== 'TZS') throw new RuntimeException('Uthibitisho wa ClickPesa hauna kiasi au sarafu inayotarajiwa.');

    $providerMethod = trim((string)($providerPayment['channel'] ?? ''));
    $channelLabel = trim((string)($config['channel_name'] ?? 'ClickPesa'));
    $paymentMethod = substr($channelLabel . ($providerMethod !== '' ? ' - ' . $providerMethod : ''), 0, 50);
    $transactionReference = substr(trim((string)($providerPayment['paymentReference'] ?? $providerPayment['id'] ?? $reference)), 0, 100);

    $db->begin_transaction();
    try {
        $lock = $db->prepare('SELECT id, phone, package_id, amount, status, voucher_id FROM payments WHERE order_reference = ? LIMIT 1 FOR UPDATE');
        if (!$lock) throw new RuntimeException('Imeshindikana kufungua rekodi ya malipo.');
        $lock->bind_param('s', $reference);
        $lock->execute();
        $payment = $lock->get_result()->fetch_assoc();
        $lock->close();
        if (!$payment) throw new RuntimeException('Ombi hili la malipo halipo kwenye mfumo.');
        $expectedCents = wifiCpAmountCents($payment['amount']);
        if ($expectedCents === null || $expectedCents !== $collectedCents) throw new RuntimeException('Kiasi kilicholipwa hakilingani na ombi la kifurushi.');

        $voucherId = (int)($payment['voucher_id'] ?? 0);
        $voucherCode = '';
        if ($voucherId > 0) {
            $find = $db->prepare('SELECT code, status FROM vouchers WHERE id = ? LIMIT 1 FOR UPDATE');
            $find->bind_param('i', $voucherId);
            $find->execute();
            $existingVoucher = $find->get_result()->fetch_assoc() ?: null;
            $voucherCode = (string)($existingVoucher['code'] ?? '');
            $find->close();
            if ($voucherCode === '') throw new RuntimeException('Malipo yameunganishwa na voucher isiyopatikana.');

            // Idempotent recovery for a voucher created by an earlier callback:
            // start its timer once, and never reactivate expired/disabled vouchers.
            if ((string)($existingVoucher['status'] ?? '') === 'unused') {
                $activate = $db->prepare("UPDATE vouchers AS v
                    LEFT JOIN packages AS pk ON pk.id = v.package_id
                    SET v.status = 'active',
                        v.activated_at = COALESCE(v.activated_at, NOW()),
                        v.expires_at = CASE
                            WHEN v.expires_at IS NULL AND pk.duration_minutes > 0
                                THEN DATE_ADD(NOW(), INTERVAL pk.duration_minutes MINUTE)
                            ELSE v.expires_at
                        END
                    WHERE v.id = ? AND v.status = 'unused'");
                if (!$activate) throw new RuntimeException('Imeshindikana kuandaa activation ya voucher.');
                $activate->bind_param('i', $voucherId);
                if (!$activate->execute()) throw new RuntimeException('Imeshindikana kuwezesha voucher iliyopo.');
                $activate->close();
            }
        } else {
            $voucherCode = wifiCpUniqueVoucherCode($db);
            $packageId = (int)$payment['package_id'];
            $soldPrice = (float)$payment['amount'];
            $insert = $db->prepare("INSERT INTO vouchers
                (code, package_id, status, source, activated_at, expires_at, sold_at, sold_price)
                SELECT ?, pk.id, 'active', 'auto', NOW(),
                    CASE WHEN pk.duration_minutes > 0
                        THEN DATE_ADD(NOW(), INTERVAL pk.duration_minutes MINUTE)
                        ELSE NULL
                    END,
                    NOW(), ?
                FROM packages AS pk
                WHERE pk.id = ?");
            if (!$insert) throw new RuntimeException('Imeshindikana kuandaa voucher.');
            $insert->bind_param('sdi', $voucherCode, $soldPrice, $packageId);
            if (!$insert->execute() || $insert->affected_rows !== 1) throw new RuntimeException('Imeshindikana kuhifadhi voucher ya kifurushi hiki.');
            $voucherId = (int)$db->insert_id;
            $insert->close();
        }

        $update = $db->prepare("UPDATE payments SET status = 'SUCCESS', transaction_reference = ?, payment_method = ?, voucher_id = ?, paid_at = COALESCE(paid_at, NOW()) WHERE id = ?");
        if (!$update) throw new RuntimeException('Imeshindikana kuunganisha malipo na voucher.');
        $paymentId = (int)$payment['id'];
        $update->bind_param('ssii', $transactionReference, $paymentMethod, $voucherId, $paymentId);
        if (!$update->execute()) throw new RuntimeException('Imeshindikana kuthibitisha malipo kwenye database.');
        $update->close();
        $db->commit();
        return ['id' => $voucherId, 'code' => $voucherCode];
    } catch (Throwable $error) {
        $db->rollback();
        throw $error;
    }
}
