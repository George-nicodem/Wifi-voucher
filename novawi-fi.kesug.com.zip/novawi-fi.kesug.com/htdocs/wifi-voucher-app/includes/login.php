<?php
declare(strict_types=1);

/*
 * The old login implementation in this file was incomplete and caused a PHP
 * parse error. Keep this legacy URL working by forwarding to the canonical,
 * CSRF-protected administrator login page.
 */
header('Location: ../admin/login.php', true, 302);
exit;
