<?php
declare(strict_types=1);

/**
 * Read customer-facing settings without requiring the optional maintenance
 * columns to exist before the matching SQL migration has been applied.
 */
function wifiPortalSettings(mysqli $db, array $defaults = []): array
{
    $settings = array_merge([
        'brand_name' => defined('APP_NAME') ? (string)APP_NAME : 'Wi-Fi',
        'welcome_message' => 'Lipa kwa simu yako na upokee voucher baada ya malipo kuthibitishwa.',
        'call_phone' => '',
        'whatsapp_phone' => '',
        'logo_path' => '',
        'theme_key' => 'ocean',
        'theme_accent_color' => '#08aebe',
        'theme_background_color' => '#f3f7fb',
        'theme_surface_color' => '#ffffff',
        'theme_text_color' => '#14283d',
        'theme_border_color' => '#e1e9f1',
        'theme_button_color' => '#e87537',
        'maintenance_enabled' => 0,
        'maintenance_message' => 'Manunuzi mapya yamesitishwa kwa muda kwa ajili ya matengenezo. Tafadhali jaribu tena baadaye.',
        'customer_payments_enabled' => 1,
    ], $defaults);

    try {
        $columnsResult = $db->query('SHOW COLUMNS FROM portal_settings');
        if (!$columnsResult instanceof mysqli_result) {
            return $settings;
        }

        $available = [];
        while ($column = $columnsResult->fetch_assoc()) {
            $available[(string)($column['Field'] ?? '')] = true;
        }
        $columnsResult->free();

        $knownColumns = [
            'brand_name', 'welcome_message', 'call_phone', 'whatsapp_phone',
            'maintenance_enabled', 'maintenance_message', 'logo_path', 'theme_key',
            'customer_payments_enabled',
            'theme_accent_color', 'theme_background_color', 'theme_surface_color',
            'theme_text_color', 'theme_border_color', 'theme_button_color',
        ];
        $selectColumns = array_values(array_filter(
            $knownColumns,
            static fn(string $column): bool => isset($available[$column])
        ));
        if ($selectColumns === [] || !isset($available['id'])) {
            return $settings;
        }

        $result = $db->query(
            'SELECT ' . implode(', ', $selectColumns) . ' FROM portal_settings WHERE id = 1 LIMIT 1'
        );
        if (!$result instanceof mysqli_result) {
            return $settings;
        }

        $row = $result->fetch_assoc();
        $result->free();
        if (is_array($row)) {
            foreach ($selectColumns as $column) {
                if (array_key_exists($column, $row)) {
                    $settings[$column] = $row[$column];
                }
            }
        }
    } catch (Throwable $exception) {
        error_log('Customer portal settings: ' . $exception->getMessage());
    }

    $settings['maintenance_enabled'] = (int)($settings['maintenance_enabled'] ?? 0) === 1 ? 1 : 0;
    $settings['customer_payments_enabled'] = (int)($settings['customer_payments_enabled'] ?? 1) === 0 ? 0 : 1;
    $settings['maintenance_message'] = trim((string)($settings['maintenance_message'] ?? ''))
        ?: 'Manunuzi mapya yamesitishwa kwa muda kwa ajili ya matengenezo. Tafadhali jaribu tena baadaye.';
    $settings['theme_key'] = wifiPortalThemeKey($settings['theme_key'] ?? 'ocean');
    foreach (wifiPortalThemeColorCatalog() as $key => $definition) {
        $value = $settings[$key] ?? $definition['default'];
        $settings[$key] = is_string($value) && preg_match('/^#[0-9a-f]{6}$/iD', $value) === 1
            ? strtolower($value)
            : $definition['default'];
    }

    return $settings;
}

function wifiPortalThemeCatalog(): array
{
    return [
        'ocean' => ['name' => 'Ocean', 'description' => 'Light blue and teal, clean and familiar.', 'swatches' => ['#f2f7fb', '#06aebe', '#14283d']],
        'midnight' => ['name' => 'Midnight', 'description' => 'Deep navy with bright cyan details.', 'swatches' => ['#071827', '#22c7d5', '#eaf4fb']],
        'sunset' => ['name' => 'Sunset', 'description' => 'Warm cream with coral and amber details.', 'swatches' => ['#fff7f0', '#e87537', '#3f2630']],
        'forest' => ['name' => 'Forest', 'description' => 'Soft ivory with fresh green details.', 'swatches' => ['#f2f8f2', '#2d9b66', '#193b31']],
    ];
}

function wifiPortalThemeKey(mixed $value): string
{
    if (!is_string($value)) {
        return 'ocean';
    }
    $theme = strtolower(trim($value));
    return array_key_exists($theme, wifiPortalThemeCatalog()) ? $theme : 'ocean';
}

function wifiPortalThemeColorCatalog(): array
{
    return [
        'theme_accent_color' => ['name' => 'Accent color', 'default' => '#08aebe', 'css' => '--portal-custom-accent'],
        'theme_background_color' => ['name' => 'Page background', 'default' => '#f3f7fb', 'css' => '--portal-custom-background'],
        'theme_surface_color' => ['name' => 'Cards and fields', 'default' => '#ffffff', 'css' => '--portal-custom-surface'],
        'theme_text_color' => ['name' => 'Main text', 'default' => '#14283d', 'css' => '--portal-custom-text'],
        'theme_border_color' => ['name' => 'Borders', 'default' => '#e1e9f1', 'css' => '--portal-custom-border'],
        'theme_button_color' => ['name' => 'Button color', 'default' => '#e87537', 'css' => '--portal-custom-button'],
    ];
}

function wifiPortalThemeStyle(array $settings): string
{
    $properties = [];
    $palette = [];
    foreach (wifiPortalThemeColorCatalog() as $key => $definition) {
        $value = $settings[$key] ?? $definition['default'];
        $safeColor = is_string($value) && preg_match('/^#[0-9a-f]{6}$/iD', $value) === 1
            ? strtolower($value)
            : $definition['default'];
        $properties[] = $definition['css'] . ':' . $safeColor;
        $palette[$key] = $safeColor;
    }
    // Choose readable text for any administrator-selected button color.
    $button = $palette['theme_button_color'];
    $linear = [];
    foreach ([1, 3, 5] as $offset) {
        $channel = hexdec(substr($button, $offset, 2)) / 255;
        $linear[] = $channel <= 0.04045 ? $channel / 12.92 : (($channel + 0.055) / 1.055) ** 2.4;
    }
    $luminance = 0.2126 * $linear[0] + 0.7152 * $linear[1] + 0.0722 * $linear[2];
    $properties[] = '--portal-button-ink:' . ($luminance > 0.179 ? '#000000' : '#ffffff');
    return implode(';', $properties);
}

function wifiPortalLogoPath(array $settings): string
{
    $path = trim((string)($settings['logo_path'] ?? ''));
    return preg_match('/^customer\/uploads\/portal-logo-[a-f0-9]{16}\.(?:png|jpe?g|webp)$/iD', $path) === 1
        ? $path
        : '';
}
