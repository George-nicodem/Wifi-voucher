<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/clickpesa_checkout.php';

function providerWebhookRespond(int $status, string $message): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    echo json_encode(['received' => $status >= 200 && $status < 300, 'message' => $message], JSON_UNESCAPED_SLASHES);
    exit;
}

function providerWebhookRun(string $providerKey): never
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') providerWebhookRespond(405, 'POST required');
    $raw = file_get_contents('php://input');
    if (!is_string($raw) || $raw === '' || strlen($raw) > 32768) providerWebhookRespond(400, 'Invalid payload');
    $payload = json_decode($raw, true);
    if (!is_array($payload)) providerWebhookRespond(400, 'Invalid JSON');
    $channelId = filter_var((string)($_GET['channel_id'] ?? ''), FILTER_VALIDATE_INT);
    if ($channelId === false || (int)$channelId <= 0) providerWebhookRespond(400, 'Missing channel ID');

    $headers = [];
    if (function_exists('getallheaders')) {
        foreach ((array)getallheaders() as $name => $value) $headers[strtolower((string)$name)] = (string)$value;
    }
    foreach ($_SERVER as $name => $value) {
        if (str_starts_with($name, 'HTTP_')) $headers[strtolower(str_replace('_', '-', substr($name, 5)))] = (string)$value;
    }
    $headers['_raw_body'] = $raw;

    try {
        global $conn;
        $message = wifiPaymentHandleWebhook($conn, $providerKey, (int)$channelId, $payload, $headers, $_GET);
        providerWebhookRespond(200, $message);
    } catch (Throwable $exception) {
        error_log($providerKey . ' webhook rejected/failed: ' . $exception->getMessage());
        providerWebhookRespond(503, 'Webhook could not be verified or processed');
    }
}
