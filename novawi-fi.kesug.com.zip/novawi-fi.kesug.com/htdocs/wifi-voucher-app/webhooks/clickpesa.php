<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/clickpesa_checkout.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

function clickPesaWebhookRespond(int $status, string $message): never
{
    http_response_code($status);
    echo json_encode(['received' => $status >= 200 && $status < 300, 'message' => $message], JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    clickPesaWebhookRespond(405, 'POST required');
}

$rawBody = file_get_contents('php://input');
if (!is_string($rawBody) || $rawBody === '' || strlen($rawBody) > 32768) {
    clickPesaWebhookRespond(400, 'Invalid payload');
}
$payload = json_decode($rawBody, true);
if (!is_array($payload)) {
    clickPesaWebhookRespond(400, 'Invalid JSON');
}

try {
    $event = strtoupper(trim((string)($payload['event'] ?? '')));
    $data = $payload['data'] ?? null;
    if (!is_array($data)) {
        clickPesaWebhookRespond(400, 'Missing event data');
    }
    $reference = trim((string)($data['orderReference'] ?? ''));
    if ($reference === '' || strlen($reference) > 100) {
        clickPesaWebhookRespond(400, 'Invalid order reference');
    }

    global $conn;
    $db = $conn;
    $payment = wifiCpPaymentRow($db, $reference);
    if (!$payment) {
        clickPesaWebhookRespond(404, 'Payment not found');
    }
    // Each configured aggregator account can use its own checksum key.
    $config = wifiCpConfigForPayment($db, $payment);
    if (!wifiCpVerifyWebhook($payload, $config['checksum_key'])) {
        clickPesaWebhookRespond(401, 'Invalid webhook signature');
    }

    if ($event === 'PAYMENT FAILED') {
        wifiCpMarkPendingStatus($db, $reference, 'FAILED');
        clickPesaWebhookRespond(200, 'Payment failure recorded');
    }
    if ($event !== 'PAYMENT RECEIVED') {
        clickPesaWebhookRespond(200, 'Event ignored');
    }

    // The signed callback wakes this handler; the authenticated status API is the final source used to issue a voucher.
    $providerPayment = wifiCpProviderPayment($reference, $config);
    $providerStatus = strtoupper(trim((string)($providerPayment['status'] ?? '')));
    if (!in_array($providerStatus, ['SUCCESS', 'SETTLED'], true)) {
        if (in_array($providerStatus, ['PENDING', 'PROCESSING'], true)) {
            wifiCpMarkPendingStatus($db, $reference, $providerStatus);
        }
        throw new RuntimeException('Payment notification arrived before the provider status was final.');
    }
    wifiCpIssueVerifiedVoucher($db, $reference, $providerPayment, $config);
    clickPesaWebhookRespond(200, 'Payment confirmed and voucher issued');
} catch (Throwable $exception) {
    error_log('ClickPesa webhook processing failed: ' . $exception->getMessage());
    clickPesaWebhookRespond(503, 'Temporary processing error');
}
