<?php
declare(strict_types=1);
require_once __DIR__ . '/provider_webhook_handler.php';
providerWebhookRun('zenopay');
