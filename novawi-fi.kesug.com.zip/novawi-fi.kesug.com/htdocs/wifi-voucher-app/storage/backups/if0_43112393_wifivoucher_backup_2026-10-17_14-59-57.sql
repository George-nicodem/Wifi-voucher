-- WiFi Voucher Database Backup
-- Database: if0_43112393_wifivoucher
-- Created: 2026-10-17 14:59:57
-- Timezone: Africa/Dar_es_Salaam
-- --------------------------------------------------------

SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET FOREIGN_KEY_CHECKS = 0;
SET AUTOCOMMIT = 0;
START TRANSACTION;


-- --------------------------------------------------------
-- Table: admin_account_requests
-- --------------------------------------------------------

DROP TABLE IF EXISTS `admin_account_requests`;

CREATE TABLE `admin_account_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(190) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `reviewed_at` datetime DEFAULT NULL,
  `reviewed_by_admin_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admin_account_requests_email` (`email`),
  KEY `idx_admin_account_requests_status_created` (`status`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_account_requests` VALUES ('1', 'bonifaskabuta@gmail.com', 'Bonifas John Kabuta', '', 'approved', '2026-10-15 15:11:42', '2026-10-15 15:13:02', '2');
INSERT INTO `admin_account_requests` VALUES ('2', 'georgenicodemus56@gmail.com', 'GEORGE NDUNGURU', '', 'rejected', '2026-10-15 15:52:57', '2026-10-17 14:55:45', '2');


-- --------------------------------------------------------
-- Table: admin_login_codes
-- --------------------------------------------------------

DROP TABLE IF EXISTS `admin_login_codes`;

CREATE TABLE `admin_login_codes` (
  `admin_id` bigint(20) unsigned NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `attempt_count` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `consumed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`admin_id`),
  KEY `idx_admin_login_codes_expiry` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_login_codes` VALUES ('2', '$2y$12$gNMLoQQ14jhz7SmAysd/C.DGVj8z3EldN3L74Gv2IL1Jh.rNcEv6m', '2026-10-17 14:50:32', '0', '2026-10-17 14:46:28', '2026-10-17 14:45:32');


-- --------------------------------------------------------
-- Table: admin_login_throttle
-- --------------------------------------------------------

DROP TABLE IF EXISTS `admin_login_throttle`;

CREATE TABLE `admin_login_throttle` (
  `identity_hash` char(64) NOT NULL,
  `failed_attempts` smallint(5) unsigned NOT NULL DEFAULT 0,
  `window_started_at` datetime NOT NULL,
  `locked_until` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`identity_hash`),
  KEY `idx_admin_login_throttle_updated` (`updated_at`),
  KEY `idx_admin_login_throttle_locked` (`locked_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------
-- Table: admin_security_policy
-- --------------------------------------------------------

DROP TABLE IF EXISTS `admin_security_policy`;

CREATE TABLE `admin_security_policy` (
  `id` tinyint(3) unsigned NOT NULL,
  `session_timeout_minutes` smallint(5) unsigned NOT NULL DEFAULT 30,
  `max_login_attempts` smallint(5) unsigned NOT NULL DEFAULT 5,
  `lockout_minutes` smallint(5) unsigned NOT NULL DEFAULT 15,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_security_policy` VALUES ('1', '30', '5', '15', '2026-10-13 23:16:27');


-- --------------------------------------------------------
-- Table: admin_users
-- --------------------------------------------------------

DROP TABLE IF EXISTS `admin_users`;

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `role` varchar(30) NOT NULL DEFAULT 'admin',
  `status` enum('active','disabled') NOT NULL DEFAULT 'active',
  `last_login_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admin_username` (`username`),
  UNIQUE KEY `uq_admin_email` (`email`),
  KEY `idx_admin_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_users` VALUES ('2', 'a94fa1f3aa93fba07', 'georgenicodemus2003@gmail.com', '$2y$12$U/H7d0/FSoJnLpsW8oI7Z.Go1O04nvEFZfQNBb86tcZag7po2BmZq', 'GEORGE NDUNGURU', 'admin', 'active', NULL, '2026-10-15 15:01:16', '2026-10-15 15:01:16');


-- --------------------------------------------------------
-- Table: admin_wallet_security
-- --------------------------------------------------------

DROP TABLE IF EXISTS `admin_wallet_security`;

CREATE TABLE `admin_wallet_security` (
  `admin_id` int(11) NOT NULL,
  `withdrawal_password_hash` varchar(255) NOT NULL,
  `failed_attempts` smallint(5) unsigned NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_wallet_security` VALUES ('2', '$2y$12$v3nciQpNBuOO.OFLmfi7LO9ChkJABD6qpZ0FXyvzybzmh2F8J7JiS', '0', NULL, '2026-10-15 23:34:05');


-- --------------------------------------------------------
-- Table: admin_wallet_selcom_settings
-- --------------------------------------------------------

DROP TABLE IF EXISTS `admin_wallet_selcom_settings`;

CREATE TABLE `admin_wallet_selcom_settings` (
  `payment_channel_id` int(11) NOT NULL,
  `provider_key` varchar(40) NOT NULL DEFAULT 'selcom',
  `vendor_enc` mediumtext NOT NULL,
  `pin_enc` mediumtext NOT NULL,
  `sender_account_enc` mediumtext NOT NULL,
  `sender_name_enc` mediumtext NOT NULL,
  `sender_msisdn_enc` mediumtext NOT NULL,
  `purpose_enc` mediumtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`payment_channel_id`),
  KEY `idx_admin_wallet_selcom_provider` (`provider_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- --------------------------------------------------------
-- Table: admin_wallet_withdrawals
-- --------------------------------------------------------

DROP TABLE IF EXISTS `admin_wallet_withdrawals`;

CREATE TABLE `admin_wallet_withdrawals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `provider_key` varchar(40) NOT NULL DEFAULT 'clickpesa',
  `payment_channel_id` int(11) NOT NULL,
  `channel_name` varchar(120) NOT NULL,
  `order_reference` varchar(80) NOT NULL,
  `destination_type` varchar(20) NOT NULL DEFAULT 'mobile_money',
  `destination_bank` varchar(40) DEFAULT NULL,
  `recipient_account` varchar(64) DEFAULT NULL,
  `recipient_name` varchar(120) DEFAULT NULL,
  `phone_number` varchar(20) NOT NULL,
  `payout_amount` decimal(12,2) NOT NULL,
  `fee_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `debit_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `currency` char(3) NOT NULL DEFAULT 'TZS',
  `status` varchar(24) NOT NULL DEFAULT 'PROCESSING',
  `provider_payout_id` varchar(100) DEFAULT NULL,
  `requested_by` int(11) DEFAULT NULL,
  `requested_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admin_wallet_order_reference` (`order_reference`),
  KEY `idx_admin_wallet_requested_at` (`requested_at`),
  KEY `idx_admin_wallet_status` (`status`),
  KEY `idx_admin_wallet_channel` (`payment_channel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- --------------------------------------------------------
-- Table: backup_policy
-- --------------------------------------------------------

DROP TABLE IF EXISTS `backup_policy`;

CREATE TABLE `backup_policy` (
  `id` tinyint(3) unsigned NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `frequency` enum('daily','weekly') NOT NULL DEFAULT 'daily',
  `run_time` time NOT NULL DEFAULT '02:00:00',
  `run_day` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `retention_count` tinyint(3) unsigned NOT NULL DEFAULT 7,
  `last_run_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `backup_policy` VALUES ('1', '0', 'daily', '02:00:00', '1', '7', NULL, '2026-10-15 14:53:40');


-- --------------------------------------------------------
-- Table: channel_payment_methods
-- --------------------------------------------------------

DROP TABLE IF EXISTS `channel_payment_methods`;

CREATE TABLE `channel_payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `provider_code` varchar(100) DEFAULT NULL,
  `status` enum('enabled','disabled') DEFAULT 'enabled',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_channel_method` (`channel_id`,`payment_method_id`),
  KEY `payment_method_id` (`payment_method_id`),
  CONSTRAINT `channel_payment_methods_ibfk_1` FOREIGN KEY (`channel_id`) REFERENCES `payment_channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `channel_payment_methods_ibfk_2` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `channel_payment_methods` VALUES ('14', '11', '4', NULL, 'enabled', '2026-10-01 09:35:21', '2026-10-01 09:45:57');
INSERT INTO `channel_payment_methods` VALUES ('15', '11', '2', NULL, 'enabled', '2026-10-01 09:35:21', '2026-10-01 09:45:57');
INSERT INTO `channel_payment_methods` VALUES ('16', '11', '3', NULL, 'enabled', '2026-10-01 09:35:21', '2026-10-01 09:45:57');
INSERT INTO `channel_payment_methods` VALUES ('17', '11', '1', NULL, 'enabled', '2026-10-01 09:35:21', '2026-10-01 09:45:57');


-- --------------------------------------------------------
-- Table: customer_accounts
-- --------------------------------------------------------

DROP TABLE IF EXISTS `customer_accounts`;

CREATE TABLE `customer_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `status` enum('pending','active','rejected','disabled') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `approved_at` datetime DEFAULT NULL,
  `approved_by_admin_id` int(10) unsigned DEFAULT NULL,
  `failed_login_count` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `failed_login_window_start` datetime DEFAULT NULL,
  `locked_until` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_customer_accounts_email` (`email`),
  KEY `idx_customer_accounts_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------
-- Table: customer_login_codes
-- --------------------------------------------------------

DROP TABLE IF EXISTS `customer_login_codes`;

CREATE TABLE `customer_login_codes` (
  `account_id` int(10) unsigned NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `attempt_count` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `consumed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`account_id`),
  KEY `idx_customer_login_codes_expiry` (`expires_at`),
  CONSTRAINT `fk_customer_login_codes_account` FOREIGN KEY (`account_id`) REFERENCES `customer_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------
-- Table: network_controllers
-- --------------------------------------------------------

DROP TABLE IF EXISTS `network_controllers`;

CREATE TABLE `network_controllers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `controller_type` enum('software','hardware','cloud') NOT NULL DEFAULT 'software',
  `base_url` varchar(500) DEFAULT NULL,
  `site_id` varchar(120) DEFAULT NULL,
  `api_client_key_enc` text DEFAULT NULL,
  `api_client_secret_enc` text DEFAULT NULL,
  `status` enum('draft','enabled','disabled') NOT NULL DEFAULT 'draft',
  `connection_status` enum('not_connected','connected','failed') NOT NULL DEFAULT 'not_connected',
  `last_connected_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_network_controllers_status` (`status`,`connection_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------
-- Table: network_deployments
-- --------------------------------------------------------

DROP TABLE IF EXISTS `network_deployments`;

CREATE TABLE `network_deployments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `controller_id` bigint(20) unsigned DEFAULT NULL,
  `profile_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('draft','queued','applied','failed') NOT NULL DEFAULT 'draft',
  `summary` varchar(500) NOT NULL DEFAULT 'Waiting for network hardware and controller connection.',
  `attempted_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_network_deployments_status_created` (`status`,`created_at`),
  KEY `idx_network_deployments_profile` (`profile_id`),
  KEY `fk_network_deployment_controller` (`controller_id`),
  CONSTRAINT `fk_network_deployment_controller` FOREIGN KEY (`controller_id`) REFERENCES `network_controllers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_network_deployment_profile` FOREIGN KEY (`profile_id`) REFERENCES `wifi_network_profiles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------
-- Table: network_devices
-- --------------------------------------------------------

DROP TABLE IF EXISTS `network_devices`;

CREATE TABLE `network_devices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `controller_id` bigint(20) unsigned DEFAULT NULL,
  `site_id` bigint(20) unsigned DEFAULT NULL,
  `platform` enum('tp_link','omada','mikrotik') NOT NULL,
  `role` enum('access_point','gateway','router','other') NOT NULL DEFAULT 'access_point',
  `device_family` varchar(60) NOT NULL,
  `device_model` varchar(100) NOT NULL,
  `hardware_version` varchar(50) DEFAULT NULL,
  `firmware_version` varchar(80) DEFAULT NULL,
  `management_ip` varchar(45) DEFAULT NULL,
  `status` enum('planned','online','offline','disabled') NOT NULL DEFAULT 'planned',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `serial_number` varchar(100) DEFAULT NULL,
  `mac_address` varchar(17) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_network_devices_status` (`status`),
  KEY `idx_network_devices_controller` (`controller_id`),
  KEY `idx_network_devices_site` (`site_id`),
  CONSTRAINT `fk_network_device_controller` FOREIGN KEY (`controller_id`) REFERENCES `network_controllers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_network_devices_site` FOREIGN KEY (`site_id`) REFERENCES `network_sites` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------
-- Table: network_gateway_settings
-- --------------------------------------------------------

DROP TABLE IF EXISTS `network_gateway_settings`;

CREATE TABLE `network_gateway_settings` (
  `id` tinyint(3) unsigned NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT 'Main MikroTik Gateway',
  `management_host` varchar(253) NOT NULL,
  `api_port` smallint(5) unsigned NOT NULL DEFAULT 8729,
  `api_tls` tinyint(1) NOT NULL DEFAULT 1,
  `api_username_enc` text NOT NULL,
  `api_password_enc` text NOT NULL,
  `config_status` enum('draft','enabled','disabled') NOT NULL DEFAULT 'draft',
  `connection_status` enum('not_connected','connected','failed') NOT NULL DEFAULT 'not_connected',
  `last_connected_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------
-- Table: network_sites
-- --------------------------------------------------------

DROP TABLE IF EXISTS `network_sites`;

CREATE TABLE `network_sites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `location_detail` varchar(255) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_network_sites_status_name` (`status`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `network_sites` VALUES ('2', 'segerea', NULL, '-6.8358070', '39.1851302', 'active', '2026-10-04 20:38:39', '2026-10-04 20:38:39');


-- --------------------------------------------------------
-- Table: packages
-- --------------------------------------------------------

DROP TABLE IF EXISTS `packages`;

CREATE TABLE `packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `duration_minutes` int(11) DEFAULT 60,
  `speed_limit` varchar(30) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `packages` VALUES ('26', 'ClickPesa', '500.00', '1', '2', 'active', '2026-09-28 21:37:01');
INSERT INTO `packages` VALUES ('27', 'ClickPesa', '500.00', '2', '2', 'active', '2026-09-29 15:49:33');
INSERT INTO `packages` VALUES ('28', '6 hours', '500.00', '360', '2', 'active', '2026-09-29 15:53:02');
INSERT INTO `packages` VALUES ('29', 'Daily', '1500.00', '1440', '4', 'active', '2026-10-04 00:06:49');
INSERT INTO `packages` VALUES ('30', 'weekly', '5500.00', '10080', '4', 'active', '2026-10-08 13:16:21');
INSERT INTO `packages` VALUES ('31', '2 weeks', '8000.00', '20340', '', 'inactive', '2026-10-08 13:22:28');


-- --------------------------------------------------------
-- Table: payment_channels
-- --------------------------------------------------------

DROP TABLE IF EXISTS `payment_channels`;

CREATE TABLE `payment_channels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(50) DEFAULT 'gateway',
  `api_key_enc` text DEFAULT NULL,
  `api_secret_enc` text DEFAULT NULL,
  `api_base_url` varchar(255) DEFAULT NULL,
  `authentication_type` varchar(50) DEFAULT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `merchant_id` varchar(255) DEFAULT NULL,
  `supported_networks` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`supported_networks`)),
  `api_key` varchar(255) DEFAULT NULL,
  `api_secret` varchar(255) DEFAULT NULL,
  `environment` enum('sandbox','live') DEFAULT 'live',
  `callback_url` varchar(255) DEFAULT NULL,
  `status` enum('enabled','disabled') DEFAULT 'enabled',
  `created_by` int(11) DEFAULT NULL,
  `configured` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `checksum_secret` text DEFAULT NULL,
  `base_url` varchar(255) DEFAULT NULL,
  `config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config`)),
  `channel_type` varchar(50) DEFAULT 'generic',
  `checksum_key` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payment_channels` VALUES ('11', 'Clickpesa', 'ClickPesa', 'y3e2bLJKBDjAjUnaLxqux145xDW+Ls7CBNEMg4T/ErbtOz3EddWM7jyRnovvMJ8EoJj5Si5o+pOfvWb8XLiNalbCPU37Tw==', NULL, 'https://api.clickpesa.com/third-parties', 'Client ID +APA Key + Checksum security key', 'ID4dzsqwJ2G78RgQA6VvEHWghlQtTBve', NULL, NULL, NULL, NULL, 'live', '', 'enabled', '1', '1', '2026-10-01 09:25:43', '2026-10-01 10:23:54', 'akicYwMgaoELd+QC6uTAXnMgqUOp89ZlsunjsUyw4T+TsoPh4rRINdPA7qkPbrMPWuUQBdQX3cCDG5x9u0va', NULL, NULL, 'ClickPesa', NULL);


-- --------------------------------------------------------
-- Table: payment_methods
-- --------------------------------------------------------

DROP TABLE IF EXISTS `payment_methods`;

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `provider_code` varchar(100) DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT 'mobile_money',
  `icon` varchar(255) DEFAULT NULL,
  `status` enum('enabled','disabled') DEFAULT 'enabled',
  `display_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payment_methods` VALUES ('1', 'tigopesa', 'Mixx by Yas', 'TIGOPESA', 'mobile_money', '', 'enabled', '1', '2026-09-26 21:45:39', '2026-10-17 01:32:06');
INSERT INTO `payment_methods` VALUES ('2', 'halotel', 'Halotel', 'HALOTEL', 'mobile_money', 'custom/network-2-b730f5e649521fe4.jpg', 'enabled', '0', '2026-09-27 09:15:32', '2026-10-17 01:34:34');
INSERT INTO `payment_methods` VALUES ('3', 'ttcl', 'TTCL', 'TTCL', 'mobile_money', '', 'enabled', '0', '2026-09-27 09:16:49', '2026-10-17 01:32:08');
INSERT INTO `payment_methods` VALUES ('4', 'airtel', 'Airtel Money', 'AIRTEL', 'mobile_money', 'custom/network-4-e70c1ce053c6c4e4.jpg', 'enabled', '0', '2026-09-27 09:17:49', '2026-10-17 01:32:28');
INSERT INTO `payment_methods` VALUES ('5', 'mpesa', 'M-Pesa', 'M-PESA', 'mobile_money', '', 'enabled', '0', '2026-09-27 09:19:24', '2026-10-17 01:32:04');


-- --------------------------------------------------------
-- Table: payment_networks
-- --------------------------------------------------------

DROP TABLE IF EXISTS `payment_networks`;

CREATE TABLE `payment_networks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(20) NOT NULL,
  `ussd_code` varchar(20) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- --------------------------------------------------------
-- Table: payment_routing
-- --------------------------------------------------------

DROP TABLE IF EXISTS `payment_routing`;

CREATE TABLE `payment_routing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `network_code` varchar(20) DEFAULT NULL,
  `primary_channel_id` int(11) DEFAULT NULL,
  `backup_channel_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payment_routing` VALUES ('1', 'AIRTEL', '11', NULL, '2026-10-01 10:05:44');
INSERT INTO `payment_routing` VALUES ('2', 'HALOTEL', '11', NULL, '2026-10-04 11:13:42');
INSERT INTO `payment_routing` VALUES ('3', 'TIGOPESA', '11', NULL, '2026-10-04 11:13:54');
INSERT INTO `payment_routing` VALUES ('4', 'TTCL', '11', NULL, '2026-10-04 11:17:12');


-- --------------------------------------------------------
-- Table: payments
-- --------------------------------------------------------

DROP TABLE IF EXISTS `payments`;

CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(20) NOT NULL,
  `package_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `order_reference` varchar(100) NOT NULL,
  `transaction_reference` varchar(100) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_channel_id` int(11) DEFAULT NULL,
  `channel_id` int(11) DEFAULT NULL,
  `status` enum('PENDING','PROCESSING','SUCCESS','FAILED','CANCELLED') DEFAULT 'PENDING',
  `voucher_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `paid_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_reference` (`order_reference`),
  KEY `payments_ibfk_2` (`voucher_id`),
  KEY `payments_ibfk_1` (`package_id`),
  KEY `idx_payments_channel_id` (`channel_id`),
  KEY `idx_payments_payment_channel_id` (`payment_channel_id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`voucher_id`) REFERENCES `vouchers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payments` VALUES ('44', '255692855239', '27', '500.00', 'W2610011025184B3E23', 'MP261001.1025.P70323', 'Airtel Money', NULL, '11', 'SUCCESS', '53', '2026-10-01 10:25:22', '2026-10-01 10:26:07');
INSERT INTO `payments` VALUES ('45', '255692855239', '27', '500.00', 'W261001145545E884FC', 'MP261001.1456.Q09964', 'Airtel Money', NULL, '11', 'SUCCESS', '54', '2026-10-01 14:55:47', '2026-10-01 14:56:17');
INSERT INTO `payments` VALUES ('46', '255692855239', '27', '500.00', 'W26100115284773DA92', NULL, 'Airtel Money', NULL, '11', 'FAILED', NULL, '2026-10-01 15:28:53', NULL);
INSERT INTO `payments` VALUES ('47', '255692855239', '26', '500.00', 'W261003233154FD2117', NULL, 'ClickPesa', NULL, NULL, 'FAILED', NULL, '2026-10-03 23:31:56', NULL);
INSERT INTO `payments` VALUES ('48', '255675409835', '26', '500.00', 'W261004022503BB95B1', NULL, 'ClickPesa', NULL, NULL, 'PROCESSING', NULL, '2026-10-04 02:25:04', NULL);
INSERT INTO `payments` VALUES ('49', '255675409835', '26', '500.00', 'W261004112241A09241', NULL, 'Clickpesa', '11', NULL, 'FAILED', NULL, '2026-10-04 11:22:41', NULL);
INSERT INTO `payments` VALUES ('50', '255692855239', '27', '500.00', 'W261004113202B3A235', 'MP261004.1132.S53645', 'Clickpesa - AIRTEL-MONEY', '11', NULL, 'SUCCESS', '57', '2026-10-04 11:32:03', '2026-10-04 11:32:21');
INSERT INTO `payments` VALUES ('51', '255692855239', '28', '500.00', 'W2610041142346E2EB7', 'MP261004.1142.U01366', 'Clickpesa - AIRTEL-MONEY', '11', NULL, 'SUCCESS', '58', '2026-10-04 11:42:35', '2026-10-04 11:42:52');
INSERT INTO `payments` VALUES ('52', '255774408340', '27', '500.00', 'W261007153555555746', NULL, 'Clickpesa', '11', NULL, 'PROCESSING', NULL, '2026-10-07 15:36:16', NULL);


-- --------------------------------------------------------
-- Table: portal_settings
-- --------------------------------------------------------

DROP TABLE IF EXISTS `portal_settings`;

CREATE TABLE `portal_settings` (
  `id` int(10) unsigned NOT NULL DEFAULT 1,
  `brand_name` varchar(100) NOT NULL,
  `welcome_message` varchar(255) NOT NULL,
  `call_phone` varchar(30) NOT NULL DEFAULT '',
  `whatsapp_phone` varchar(30) NOT NULL DEFAULT '',
  `maintenance_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `maintenance_message` varchar(250) NOT NULL DEFAULT 'Manunuzi mapya yamesitishwa kwa muda kwa ajili ya matengenezo. Tafadhali jaribu tena baadaye.',
  `logo_path` varchar(255) NOT NULL DEFAULT '',
  `theme_key` varchar(20) NOT NULL DEFAULT 'ocean',
  `theme_accent_color` char(7) NOT NULL DEFAULT '#08aebe',
  `theme_background_color` char(7) NOT NULL DEFAULT '#f3f7fb',
  `theme_surface_color` char(7) NOT NULL DEFAULT '#ffffff',
  `theme_text_color` char(7) NOT NULL DEFAULT '#14283d',
  `theme_border_color` char(7) NOT NULL DEFAULT '#e1e9f1',
  `theme_button_color` char(7) NOT NULL DEFAULT '#e87537',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `portal_settings` VALUES ('1', 'WIFI SYSTEM', 'TUNAKUPA NETWORK  YENYE KASI WEWE AMUA IKUFIKISHE WAPI.', '0675409835', '0749509813', '0', 'Manunuzi mapya yamesitishwa kwa muda kwa ajili ya matengenezo. Tafadhali jaribu tena baadaye.', '', 'sunset', '#000000', '#7d7391', '#173d38', '#bf0000', '#5b82a9', '#5c5c4d');


-- --------------------------------------------------------
-- Table: security_logs
-- --------------------------------------------------------

DROP TABLE IF EXISTS `security_logs`;

CREATE TABLE `security_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=257 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `security_logs` VALUES ('1', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-28 14:02:38');
INSERT INTO `security_logs` VALUES ('2', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-28 14:09:40');
INSERT INTO `security_logs` VALUES ('3', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-28 14:13:55');
INSERT INTO `security_logs` VALUES ('4', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-28 14:57:37');
INSERT INTO `security_logs` VALUES ('5', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-28 15:45:55');
INSERT INTO `security_logs` VALUES ('6', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 3', '::1', '2026-09-28 16:34:04');
INSERT INTO `security_logs` VALUES ('7', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 3', '::1', '2026-09-28 16:46:04');
INSERT INTO `security_logs` VALUES ('8', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 3', '::1', '2026-09-28 16:47:06');
INSERT INTO `security_logs` VALUES ('9', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 14', '::1', '2026-09-28 16:51:55');
INSERT INTO `security_logs` VALUES ('10', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-28 18:07:40');
INSERT INTO `security_logs` VALUES ('11', '1', 'package_created', 'Created package ID: 20, name: daily', '::1', '2026-09-28 18:24:35');
INSERT INTO `security_logs` VALUES ('12', '1', 'package_created', 'Created package ID: 21, name: daily', '::1', '2026-09-28 18:26:01');
INSERT INTO `security_logs` VALUES ('13', '1', 'package_created', 'Created package ID: 22, name: daily', '::1', '2026-09-28 18:28:24');
INSERT INTO `security_logs` VALUES ('14', '1', 'package_created', 'Created package ID: 23, name: 3', '::1', '2026-09-28 18:28:49');
INSERT INTO `security_logs` VALUES ('15', '1', 'package_created', 'Created package ID: 24, name: 2', '::1', '2026-09-28 19:10:02');
INSERT INTO `security_logs` VALUES ('16', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-28 20:05:30');
INSERT INTO `security_logs` VALUES ('17', '1', 'VOUCHERS_BULK_CREATED', 'Created 7 manual vouchers for package ID 2.', '::1', '2026-09-28 20:34:12');
INSERT INTO `security_logs` VALUES ('18', '1', 'VOUCHER_TEST_ACTIVATED', 'Test-activated voucher ID #45 using the admin voucher test tool.', '::1', '2026-09-28 21:03:01');
INSERT INTO `security_logs` VALUES ('19', '1', 'VOUCHER_UPDATED', 'Voucher ID #45 updated. Package ID #2, status changed from active to disabled.', '::1', '2026-09-28 21:04:14');
INSERT INTO `security_logs` VALUES ('20', '1', 'VOUCHER_TEST_ACTIVATED', 'Test-activated voucher ID #44 using the admin voucher test tool.', '::1', '2026-09-28 21:05:17');
INSERT INTO `security_logs` VALUES ('21', '1', 'PACKAGE_DELETED', 'Deleted package ID #24 (2).', '::1', '2026-09-28 21:15:32');
INSERT INTO `security_logs` VALUES ('22', '1', 'PACKAGE_DELETED', 'Deleted package ID #23 (3).', '::1', '2026-09-28 21:16:07');
INSERT INTO `security_logs` VALUES ('23', '1', 'PACKAGE_DELETED', 'Deleted package ID #20 (daily).', '::1', '2026-09-28 21:16:22');
INSERT INTO `security_logs` VALUES ('24', '1', 'PACKAGE_DELETED', 'Deleted package ID #12 (3 Masaa).', '::1', '2026-09-28 21:19:50');
INSERT INTO `security_logs` VALUES ('25', '1', 'PACKAGE_DELETED', 'Deleted package ID #22 (daily).', '::1', '2026-09-28 21:22:10');
INSERT INTO `security_logs` VALUES ('26', '1', 'PACKAGE_DELETED', 'Deleted package ID #21 (daily).', '::1', '2026-09-28 21:22:19');
INSERT INTO `security_logs` VALUES ('27', '1', 'PACKAGE_DELETED', 'Deleted package ID #19 (urtrxfcg).', '::1', '2026-09-28 21:33:56');
INSERT INTO `security_logs` VALUES ('28', '1', 'PACKAGE_DELETED', 'Deleted package ID #16 (Siku 1).', '::1', '2026-09-28 21:34:06');
INSERT INTO `security_logs` VALUES ('29', '1', 'PACKAGE_DELETED', 'Deleted package ID #1 (1 Hour).', '::1', '2026-09-28 21:34:17');
INSERT INTO `security_logs` VALUES ('30', '1', 'PACKAGE_DELETED', 'Deleted package ID #2 (3 Hours).', '::1', '2026-09-28 21:34:26');
INSERT INTO `security_logs` VALUES ('31', '1', 'PACKAGE_DELETED', 'Deleted package ID #14 (1 Saa).', '::1', '2026-09-28 21:34:41');
INSERT INTO `security_logs` VALUES ('32', '1', 'PACKAGE_DELETED', 'Deleted package ID #7 (testbn 333).', '::1', '2026-09-28 21:34:53');
INSERT INTO `security_logs` VALUES ('33', '1', 'PACKAGE_DELETED', 'Deleted package ID #3 (1 Day).', '::1', '2026-09-28 21:35:03');
INSERT INTO `security_logs` VALUES ('34', '1', 'package_created', 'Created package ID: 25, name: 50 minuts', '::1', '2026-09-28 21:36:06');
INSERT INTO `security_logs` VALUES ('35', '1', 'PACKAGE_DELETED', 'Deleted package ID #25 (50 minuts).', '::1', '2026-09-28 21:36:30');
INSERT INTO `security_logs` VALUES ('36', '1', 'package_created', 'Created package ID: 26, name: ClickPesa', '::1', '2026-09-28 21:37:01');
INSERT INTO `security_logs` VALUES ('37', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 26', '::1', '2026-09-28 21:37:18');
INSERT INTO `security_logs` VALUES ('38', '1', 'VOUCHER_TEST_ACTIVATED', 'Test-activated voucher ID #46 using the admin voucher test tool.', '::1', '2026-09-28 21:37:44');
INSERT INTO `security_logs` VALUES ('39', '1', 'PAYMENT_METHOD_UPDATED', 'Updated payment method ID #1 (Mixx by Yas).', '::1', '2026-09-28 22:53:06');
INSERT INTO `security_logs` VALUES ('40', '1', 'PAYMENT_METHOD_UPDATED', 'Updated payment method ID #1 (Mixx by Yas).', '::1', '2026-09-28 22:53:34');
INSERT INTO `security_logs` VALUES ('41', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #1 status to disabled.', '::1', '2026-09-28 23:08:39');
INSERT INTO `security_logs` VALUES ('42', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #1 status to enabled.', '::1', '2026-09-28 23:08:47');
INSERT INTO `security_logs` VALUES ('43', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #4 status to enabled.', '::1', '2026-09-28 23:09:06');
INSERT INTO `security_logs` VALUES ('44', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #5 status to enabled.', '::1', '2026-09-28 23:09:21');
INSERT INTO `security_logs` VALUES ('45', '1', 'PAYMENT_CHANNEL_NETWORKS_SAVED', 'Saved 3 supported network(s) for payment channel ID #5.', '::1', '2026-09-28 23:13:58');
INSERT INTO `security_logs` VALUES ('46', '1', 'PAYMENT_CHANNEL_NETWORKS_SAVED', 'Saved 3 supported network(s) for payment channel ID #5.', '::1', '2026-09-28 23:14:25');
INSERT INTO `security_logs` VALUES ('47', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #2 status to enabled.', '::1', '2026-09-29 00:16:50');
INSERT INTO `security_logs` VALUES ('48', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #3 status to enabled.', '::1', '2026-09-29 00:16:57');
INSERT INTO `security_logs` VALUES ('49', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #4 status to disabled.', '::1', '2026-09-29 00:48:16');
INSERT INTO `security_logs` VALUES ('50', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #4 status to enabled.', '::1', '2026-09-29 00:48:28');
INSERT INTO `security_logs` VALUES ('51', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #5 status to disabled.', '::1', '2026-09-29 00:48:42');
INSERT INTO `security_logs` VALUES ('52', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #3 status to disabled.', '::1', '2026-09-29 00:48:54');
INSERT INTO `security_logs` VALUES ('53', '1', 'PAYMENT_CHANNEL_CREATED', 'Added aggregator channel ID #7.', '::1', '2026-09-29 00:51:27');
INSERT INTO `security_logs` VALUES ('54', '1', 'PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #7 to enabled.', '::1', '2026-09-29 00:51:38');
INSERT INTO `security_logs` VALUES ('55', '1', 'CLICKPESA_CREDENTIALS_SAVED', 'Saved encrypted credentials for payment channel ID #7.', '::1', '2026-09-29 00:53:23');
INSERT INTO `security_logs` VALUES ('56', '1', 'PAYMENT_CHANNEL_NETWORKS_SAVED', 'Saved 3 supported network(s) for payment channel ID #7.', '::1', '2026-09-29 00:55:48');
INSERT INTO `security_logs` VALUES ('57', '1', 'PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #7 to disabled.', '::1', '2026-09-29 00:56:43');
INSERT INTO `security_logs` VALUES ('58', '1', 'PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #7 to enabled.', '::1', '2026-09-29 00:56:47');
INSERT INTO `security_logs` VALUES ('59', '1', 'PAYMENT_CHANNEL_NETWORK_UPDATED', 'Updated network mapping ID #8 for payment channel ID #7.', '::1', '2026-09-29 00:57:10');
INSERT INTO `security_logs` VALUES ('60', '1', 'PAYMENT_CHANNEL_NETWORKS_SAVED', 'Saved 3 supported network(s) for payment channel ID #7.', '::1', '2026-09-29 00:57:22');
INSERT INTO `security_logs` VALUES ('61', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-29 09:09:10');
INSERT INTO `security_logs` VALUES ('62', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 26', '::1', '2026-09-29 09:09:45');
INSERT INTO `security_logs` VALUES ('63', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-29 09:42:03');
INSERT INTO `security_logs` VALUES ('64', '1', 'PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #7 to disabled.', '::1', '2026-09-29 09:42:25');
INSERT INTO `security_logs` VALUES ('65', '1', 'PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #7 to enabled.', '::1', '2026-09-29 09:42:29');
INSERT INTO `security_logs` VALUES ('66', '1', 'PAYMENT_CHANNEL_REMOVED', 'Removed aggregator channel ID #7 and its network mappings.', '::1', '2026-09-29 09:42:53');
INSERT INTO `security_logs` VALUES ('67', '1', 'PAYMENT_CHANNEL_CREATED', 'Added aggregator channel ID #8.', '::1', '2026-09-29 09:43:07');
INSERT INTO `security_logs` VALUES ('68', '1', 'PAYMENT_CHANNEL_REMOVED', 'Removed aggregator channel ID #8 and its network mappings.', '::1', '2026-09-29 09:43:21');
INSERT INTO `security_logs` VALUES ('69', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #5 status to enabled.', '::1', '2026-09-29 09:49:12');
INSERT INTO `security_logs` VALUES ('70', '1', 'PAYMENT_CHANNEL_CREATED', 'Added aggregator channel ID #9.', '::1', '2026-09-29 09:51:18');
INSERT INTO `security_logs` VALUES ('71', '1', 'PAYMENT_CHANNEL_CREATED', 'Added aggregator channel ID #10.', '::1', '2026-09-29 09:58:06');
INSERT INTO `security_logs` VALUES ('72', '1', 'PAYMENT_CHANNEL_REMOVED', 'Removed aggregator channel ID #9 and its network mappings.', '::1', '2026-09-29 09:58:16');
INSERT INTO `security_logs` VALUES ('73', '1', 'PAYMENT_CHANNEL_NETWORKS_SAVED', 'Saved 3 supported network(s) for payment channel ID #10.', '::1', '2026-09-29 10:14:10');
INSERT INTO `security_logs` VALUES ('74', '1', 'PAYMENT_CHANNEL_API_SETTINGS_SAVED', 'Saved API settings for payment channel ID #10.', '::1', '2026-09-29 10:18:42');
INSERT INTO `security_logs` VALUES ('75', '1', 'PAYMENT_CHANNEL_API_SETTINGS_SAVED', 'Saved API settings for payment channel ID #10.', '::1', '2026-09-29 10:19:40');
INSERT INTO `security_logs` VALUES ('76', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-29 14:58:54');
INSERT INTO `security_logs` VALUES ('77', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-29 15:49:07');
INSERT INTO `security_logs` VALUES ('78', '1', 'package_created', 'Created package ID: 27, name: ClickPesa', '::1', '2026-09-29 15:49:33');
INSERT INTO `security_logs` VALUES ('79', '1', 'package_created', 'Created package ID: 28, name: ClickPesa', '::1', '2026-09-29 15:53:02');
INSERT INTO `security_logs` VALUES ('80', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-29 16:46:05');
INSERT INTO `security_logs` VALUES ('81', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-29 17:36:28');
INSERT INTO `security_logs` VALUES ('82', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-30 06:45:42');
INSERT INTO `security_logs` VALUES ('83', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 27', '::1', '2026-09-30 06:47:59');
INSERT INTO `security_logs` VALUES ('84', '1', 'VOUCHER_TEST_ACTIVATED', 'Test-activated voucher ID #48 using the admin voucher test tool.', '::1', '2026-09-30 06:48:19');
INSERT INTO `security_logs` VALUES ('85', '1', 'VOUCHER_TEST_ACTIVATED', 'Test-activated voucher ID #47 using the admin voucher test tool.', '::1', '2026-09-30 06:54:33');
INSERT INTO `security_logs` VALUES ('86', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 28', '::1', '2026-09-30 07:07:39');
INSERT INTO `security_logs` VALUES ('87', '1', 'VOUCHER_TEST_ACTIVATED', 'Test-activated voucher ID #49 using the admin voucher test tool.', '::1', '2026-09-30 07:07:58');
INSERT INTO `security_logs` VALUES ('88', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 28', '::1', '2026-09-30 07:16:16');
INSERT INTO `security_logs` VALUES ('89', '1', 'VOUCHER_TEST_ACTIVATED', 'Test-activated voucher ID #50 using the admin voucher test tool.', '::1', '2026-09-30 07:16:39');
INSERT INTO `security_logs` VALUES ('90', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-30 17:25:10');
INSERT INTO `security_logs` VALUES ('91', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-30 19:44:03');
INSERT INTO `security_logs` VALUES ('92', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 27', '::1', '2026-09-30 19:47:55');
INSERT INTO `security_logs` VALUES ('93', '1', 'VOUCHER_TEST_ACTIVATED', 'Test-activated voucher ID #51 using the admin voucher test tool.', '::1', '2026-09-30 19:48:34');
INSERT INTO `security_logs` VALUES ('94', '1', 'package_updated', 'Updated package ID: 28, name: 6 hours', '::1', '2026-09-30 20:08:39');
INSERT INTO `security_logs` VALUES ('95', '1', 'package_updated', 'Updated package ID: 28, name: 6 hours', '::1', '2026-09-30 20:09:04');
INSERT INTO `security_logs` VALUES ('96', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-09-30 23:25:05');
INSERT INTO `security_logs` VALUES ('97', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-01 08:16:12');
INSERT INTO `security_logs` VALUES ('98', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 26', '::1', '2026-10-01 08:22:20');
INSERT INTO `security_logs` VALUES ('99', '1', 'VOUCHER_TEST_ACTIVATED', 'Test-activated voucher ID #52 using the admin voucher test tool.', '::1', '2026-10-01 08:22:55');
INSERT INTO `security_logs` VALUES ('100', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-01 09:20:33');
INSERT INTO `security_logs` VALUES ('101', '1', 'PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #10 to enabled.', '::1', '2026-10-01 09:23:12');
INSERT INTO `security_logs` VALUES ('102', '1', 'PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #10 to disabled.', '::1', '2026-10-01 09:23:40');
INSERT INTO `security_logs` VALUES ('103', '1', 'PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #10 to enabled.', '::1', '2026-10-01 09:23:43');
INSERT INTO `security_logs` VALUES ('104', '1', 'PAYMENT_CHANNEL_REMOVED', 'Removed aggregator channel ID #10 and its network mappings.', '::1', '2026-10-01 09:25:22');
INSERT INTO `security_logs` VALUES ('105', '1', 'PAYMENT_CHANNEL_CREATED', 'Added aggregator channel ID #11.', '::1', '2026-10-01 09:25:43');
INSERT INTO `security_logs` VALUES ('106', '1', 'PAYMENT_CHANNEL_NETWORKS_SAVED', 'Saved 4 supported network(s) for payment channel ID #11.', '::1', '2026-10-01 09:35:21');
INSERT INTO `security_logs` VALUES ('107', '1', 'PAYMENT_CHANNEL_API_SETTINGS_SAVED', 'Saved API settings for payment channel ID #11.', '::1', '2026-10-01 09:38:57');
INSERT INTO `security_logs` VALUES ('108', '1', 'PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #11 to enabled.', '::1', '2026-10-01 09:39:32');
INSERT INTO `security_logs` VALUES ('109', '1', 'PAYMENT_CHANNEL_API_SETTINGS_SAVED', 'Saved API settings for payment channel ID #11.', '::1', '2026-10-01 09:43:39');
INSERT INTO `security_logs` VALUES ('110', '1', 'PAYMENT_CHANNEL_NETWORKS_SAVED', 'Saved 4 supported network(s) for payment channel ID #11.', '::1', '2026-10-01 09:44:44');
INSERT INTO `security_logs` VALUES ('111', '1', 'PAYMENT_CHANNEL_NETWORKS_SAVED', 'Saved 4 supported network(s) for payment channel ID #11.', '::1', '2026-10-01 09:45:57');
INSERT INTO `security_logs` VALUES ('112', '1', 'PAYMENT_ROUTE_SAVED', 'Updated payment routing for payment method ID #4.', '::1', '2026-10-01 10:05:44');
INSERT INTO `security_logs` VALUES ('113', '1', 'PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #11 to disabled.', '::1', '2026-10-01 10:20:52');
INSERT INTO `security_logs` VALUES ('114', '1', 'PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #11 to enabled.', '::1', '2026-10-01 10:20:59');
INSERT INTO `security_logs` VALUES ('115', '1', 'PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #11 to disabled.', '::1', '2026-10-01 10:21:03');
INSERT INTO `security_logs` VALUES ('116', '1', 'PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #11 to enabled.', '::1', '2026-10-01 10:21:15');
INSERT INTO `security_logs` VALUES ('117', '1', 'PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #11 to disabled.', '::1', '2026-10-01 10:21:27');
INSERT INTO `security_logs` VALUES ('118', '1', 'PAYMENT_CHANNEL_STATUS_CHANGED', 'Changed aggregator channel ID #11 to enabled.', '::1', '2026-10-01 10:21:29');
INSERT INTO `security_logs` VALUES ('119', '1', 'PAYMENT_CHANNEL_API_VERIFIED', 'Verified API connectivity for payment channel ID #11.', '::1', '2026-10-01 10:22:50');
INSERT INTO `security_logs` VALUES ('120', '1', 'PAYMENT_CHANNEL_API_SETTINGS_SAVED', 'Saved API settings for payment channel ID #11.', '::1', '2026-10-01 10:23:54');
INSERT INTO `security_logs` VALUES ('121', '1', 'VOUCHER_TEST_ACTIVATED', 'Test-activated voucher ID #53 using the admin voucher test tool.', '::1', '2026-10-01 10:27:47');
INSERT INTO `security_logs` VALUES ('122', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-01 14:57:16');
INSERT INTO `security_logs` VALUES ('123', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 26', '::1', '2026-10-01 15:15:15');
INSERT INTO `security_logs` VALUES ('124', '1', 'VOUCHER_TEST_ACTIVATED', 'Test-activated voucher ID #55 using the admin voucher test tool.', '::1', '2026-10-01 15:15:33');
INSERT INTO `security_logs` VALUES ('125', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-01 18:31:33');
INSERT INTO `security_logs` VALUES ('126', '1', 'VOUCHER_TEST_ACTIVATED', 'Test-activated voucher ID #54 using the admin voucher test tool.', '::1', '2026-10-01 18:31:58');
INSERT INTO `security_logs` VALUES ('127', '1', 'ADMIN_LOGOUT', 'Administrator logged out.', '::1', '2026-10-01 19:21:48');
INSERT INTO `security_logs` VALUES ('128', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-01 19:22:56');
INSERT INTO `security_logs` VALUES ('129', '1', 'ADMIN_LOGOUT', 'Administrator logged out.', '::1', '2026-10-01 19:23:04');
INSERT INTO `security_logs` VALUES ('130', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-01 19:23:07');
INSERT INTO `security_logs` VALUES ('131', '1', 'ADMIN_LOGOUT', 'Administrator logged out.', '::1', '2026-10-01 19:23:10');
INSERT INTO `security_logs` VALUES ('132', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-01 19:35:53');
INSERT INTO `security_logs` VALUES ('133', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-03 21:15:08');
INSERT INTO `security_logs` VALUES ('134', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 27', '::1', '2026-10-03 21:19:18');
INSERT INTO `security_logs` VALUES ('135', '1', 'VOUCHER_TEST_ACTIVATED', 'Test-activated voucher ID #56 using the admin voucher test tool.', '::1', '2026-10-03 21:19:36');
INSERT INTO `security_logs` VALUES ('136', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-03 22:18:02');
INSERT INTO `security_logs` VALUES ('137', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-03 23:26:13');
INSERT INTO `security_logs` VALUES ('138', '1', 'package_created', 'Created package ID: 29, name: 7 days', '::1', '2026-10-04 00:06:49');
INSERT INTO `security_logs` VALUES ('139', '1', 'package_updated', 'Updated package ID: 28, name: 6 hours', '::1', '2026-10-04 00:07:32');
INSERT INTO `security_logs` VALUES ('140', '1', 'package_updated', 'Updated package ID: 29, name: 7 days', '::1', '2026-10-04 00:08:21');
INSERT INTO `security_logs` VALUES ('141', '1', 'package_updated', 'Updated package ID: 29, name: 7 days', '::1', '2026-10-04 00:09:03');
INSERT INTO `security_logs` VALUES ('142', '1', 'package_updated', 'Updated package ID: 29, name: 7 days', '::1', '2026-10-04 00:10:37');
INSERT INTO `security_logs` VALUES ('143', '1', 'package_updated', 'Updated package ID: 29, name: daily', '::1', '2026-10-04 00:12:08');
INSERT INTO `security_logs` VALUES ('144', '1', 'package_updated', 'Updated package ID: 29, name: weeky', '::1', '2026-10-04 00:12:35');
INSERT INTO `security_logs` VALUES ('145', '1', 'NETWORK_SITE_CREATED', 'Created a network site.', '::1', '2026-10-04 00:53:22');
INSERT INTO `security_logs` VALUES ('146', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '192.168.1.112', '2026-10-04 02:08:57');
INSERT INTO `security_logs` VALUES ('147', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-04 10:34:37');
INSERT INTO `security_logs` VALUES ('148', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-04 11:12:37');
INSERT INTO `security_logs` VALUES ('149', '1', 'PAYMENT_ROUTE_SAVED', 'Updated payment routing for payment method ID #2.', '::1', '2026-10-04 11:13:42');
INSERT INTO `security_logs` VALUES ('150', '1', 'PAYMENT_ROUTE_SAVED', 'Updated payment routing for payment method ID #1.', '::1', '2026-10-04 11:13:54');
INSERT INTO `security_logs` VALUES ('151', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #1 status to disabled.', '::1', '2026-10-04 11:15:22');
INSERT INTO `security_logs` VALUES ('152', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #5 status to disabled.', '::1', '2026-10-04 11:15:28');
INSERT INTO `security_logs` VALUES ('153', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #2 status to disabled.', '::1', '2026-10-04 11:15:33');
INSERT INTO `security_logs` VALUES ('154', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #4 status to disabled.', '::1', '2026-10-04 11:15:39');
INSERT INTO `security_logs` VALUES ('155', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #4 status to enabled.', '::1', '2026-10-04 11:15:51');
INSERT INTO `security_logs` VALUES ('156', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #2 status to enabled.', '::1', '2026-10-04 11:15:59');
INSERT INTO `security_logs` VALUES ('157', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #5 status to enabled.', '::1', '2026-10-04 11:16:03');
INSERT INTO `security_logs` VALUES ('158', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #3 status to enabled.', '::1', '2026-10-04 11:16:09');
INSERT INTO `security_logs` VALUES ('159', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #3 status to enabled.', '::1', '2026-10-04 11:16:15');
INSERT INTO `security_logs` VALUES ('160', '1', 'PAYMENT_METHOD_STATUS_CHANGED', 'Changed payment method ID #1 status to enabled.', '::1', '2026-10-04 11:16:19');
INSERT INTO `security_logs` VALUES ('161', '1', 'PAYMENT_ROUTE_SAVED', 'Updated payment routing for payment method ID #1.', '::1', '2026-10-04 11:16:34');
INSERT INTO `security_logs` VALUES ('162', '1', 'PAYMENT_ROUTE_SAVED', 'Updated payment routing for payment method ID #3.', '::1', '2026-10-04 11:17:12');
INSERT INTO `security_logs` VALUES ('163', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-04 14:55:32');
INSERT INTO `security_logs` VALUES ('164', '1', 'DATABASE_BACKUP_STARTED', 'Administrator started a database backup.', '::1', '2026-10-04 15:05:05');
INSERT INTO `security_logs` VALUES ('165', '1', 'DATABASE_BACKUP_CREATED', 'Database backup created: wifi_voucher_backup_2026-10-04_15-05-05.sql', '::1', '2026-10-04 15:05:05');
INSERT INTO `security_logs` VALUES ('166', '1', 'DATABASE_BACKUP_DOWNLOADED', 'Administrator downloaded database backup: wifi_voucher_backup_2026-10-04_15-05-05.sql', '::1', '2026-10-04 15:05:11');
INSERT INTO `security_logs` VALUES ('167', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-04 15:40:31');
INSERT INTO `security_logs` VALUES ('168', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 29', '::1', '2026-10-04 15:49:23');
INSERT INTO `security_logs` VALUES ('169', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 27', '::1', '2026-10-04 15:50:55');
INSERT INTO `security_logs` VALUES ('170', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-04 17:00:58');
INSERT INTO `security_logs` VALUES ('171', '1', 'DATABASE_BACKUP_DOWNLOADED', 'Administrator downloaded database backup: wifi_voucher_backup_2026-10-04_15-05-05.sql', '::1', '2026-10-04 17:06:31');
INSERT INTO `security_logs` VALUES ('172', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-04 18:18:52');
INSERT INTO `security_logs` VALUES ('173', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-04 19:57:26');
INSERT INTO `security_logs` VALUES ('174', '1', 'WIFI_PROFILE_DRAFT_SAVED', 'Saved Wi-Fi profile draft #1.', '::1', '2026-10-04 20:25:37');
INSERT INTO `security_logs` VALUES ('175', '1', 'NETWORK_SITE_CREATED', 'Created a network site.', '::1', '2026-10-04 20:38:39');
INSERT INTO `security_logs` VALUES ('176', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-06 11:07:37');
INSERT INTO `security_logs` VALUES ('177', '1', 'DATABASE_BACKUP_DOWNLOADED', 'Administrator downloaded database backup: wifi_voucher_backup_2026-10-04_15-05-05.sql', '::1', '2026-10-06 11:07:45');
INSERT INTO `security_logs` VALUES ('178', '1', 'DATABASE_BACKUP_STARTED', 'Administrator started a database backup.', '::1', '2026-10-06 11:07:49');
INSERT INTO `security_logs` VALUES ('179', '1', 'DATABASE_BACKUP_STARTED', 'Administrator started a database backup.', '::1', '2026-10-06 11:07:51');
INSERT INTO `security_logs` VALUES ('180', '1', 'DATABASE_BACKUP_STARTED', 'Administrator started a database backup.', '::1', '2026-10-06 11:07:57');
INSERT INTO `security_logs` VALUES ('181', '1', 'DATABASE_BACKUP_STARTED', 'Administrator started a database backup.', '::1', '2026-10-06 11:08:14');
INSERT INTO `security_logs` VALUES ('182', '1', 'DATABASE_BACKUP_STARTED', 'Administrator started a database backup.', '::1', '2026-10-06 11:09:00');
INSERT INTO `security_logs` VALUES ('183', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-07 10:48:57');
INSERT INTO `security_logs` VALUES ('184', '1', 'VOUCHER_TEST_ACTIVATED', 'Test-activated voucher ID #57 using the admin voucher test tool.', '::1', '2026-10-07 10:50:16');
INSERT INTO `security_logs` VALUES ('185', '1', 'package_updated', 'Updated package ID: 29, name: weeky', '::1', '2026-10-07 10:51:51');
INSERT INTO `security_logs` VALUES ('186', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-07 15:33:45');
INSERT INTO `security_logs` VALUES ('187', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 27', '::1', '2026-10-07 15:34:26');
INSERT INTO `security_logs` VALUES ('188', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-07 20:40:48');
INSERT INTO `security_logs` VALUES ('189', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-07 21:40:34');
INSERT INTO `security_logs` VALUES ('190', '1', 'PORTAL_SETTINGS_UPDATED', 'Administrator updated customer portal settings.', '::1', '2026-10-07 22:01:32');
INSERT INTO `security_logs` VALUES ('191', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-08 09:04:41');
INSERT INTO `security_logs` VALUES ('192', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-08 10:24:26');
INSERT INTO `security_logs` VALUES ('193', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-08 13:15:12');
INSERT INTO `security_logs` VALUES ('194', '1', 'package_created', 'Created package ID: 30, name: weekly', '::1', '2026-10-08 13:16:21');
INSERT INTO `security_logs` VALUES ('195', '1', 'package_updated', 'Updated package ID: 29, name: Daily', '::1', '2026-10-08 13:20:54');
INSERT INTO `security_logs` VALUES ('196', '1', 'package_created', 'Created package ID: 31, name: 2 weeks', '::1', '2026-10-08 13:22:28');
INSERT INTO `security_logs` VALUES ('197', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-08 18:15:42');
INSERT INTO `security_logs` VALUES ('198', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-08 19:57:36');
INSERT INTO `security_logs` VALUES ('199', '1', 'PAYMENT_NETWORK_LOGO_UPDATED', 'Administrator updated a payment network logo. Network ID: 4', '::1', '2026-10-08 20:26:20');
INSERT INTO `security_logs` VALUES ('200', '1', 'PAYMENT_NETWORK_LOGO_UPDATED', 'Administrator updated a payment network logo. Network ID: 3', '::1', '2026-10-08 20:27:20');
INSERT INTO `security_logs` VALUES ('201', '1', 'PAYMENT_NETWORK_LOGO_UPDATED', 'Administrator updated a payment network logo. Network ID: 2', '::1', '2026-10-08 20:27:38');
INSERT INTO `security_logs` VALUES ('202', '1', 'PAYMENT_NETWORK_LOGO_UPDATED', 'Administrator updated a payment network logo. Network ID: 5', '::1', '2026-10-08 20:27:56');
INSERT INTO `security_logs` VALUES ('203', '1', 'PAYMENT_NETWORK_LOGO_UPDATED', 'Administrator updated a payment network logo. Network ID: 1', '::1', '2026-10-08 20:28:18');
INSERT INTO `security_logs` VALUES ('204', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-11 11:08:38');
INSERT INTO `security_logs` VALUES ('205', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-11 12:18:36');
INSERT INTO `security_logs` VALUES ('206', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '::1', '2026-10-11 14:17:54');
INSERT INTO `security_logs` VALUES ('207', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '197.186.72.234', '2026-10-13 23:07:52');
INSERT INTO `security_logs` VALUES ('208', '1', 'VOUCHER_TEST_ACTIVATED', 'Test-activated voucher ID #61 using the admin voucher test tool.', '197.186.72.234', '2026-10-13 23:23:29');
INSERT INTO `security_logs` VALUES ('209', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '197.186.72.234', '2026-10-14 15:06:38');
INSERT INTO `security_logs` VALUES ('210', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '197.186.72.234', '2026-10-14 15:34:37');
INSERT INTO `security_logs` VALUES ('211', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '197.186.72.234', '2026-10-14 15:38:26');
INSERT INTO `security_logs` VALUES ('212', '1', 'package_updated', 'Updated package ID: 31, name: 2 weeks', '197.186.72.234', '2026-10-14 15:39:43');
INSERT INTO `security_logs` VALUES ('213', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '197.186.72.234', '2026-10-14 15:47:28');
INSERT INTO `security_logs` VALUES ('214', '1', 'ADMIN_LOGIN', 'Administrator login successful.', '197.186.72.234', '2026-10-14 18:14:34');
INSERT INTO `security_logs` VALUES ('215', '1', 'VOUCHER_CREATED', 'Created a manual voucher for package ID 26', '197.186.72.234', '2026-10-14 18:14:58');
INSERT INTO `security_logs` VALUES ('216', '2', 'ADMIN_LOGIN', 'Administrator email and one-time code login successful.', '197.186.66.249', '2026-10-15 15:05:03');
INSERT INTO `security_logs` VALUES ('217', '2', 'ADMIN_LOGIN', 'Administrator email and one-time code login successful.', '197.186.66.249', '2026-10-15 15:11:53');
INSERT INTO `security_logs` VALUES ('218', '2', 'ADMIN_USER_CREATED', 'Approved public admin account request #1 as admin user #3.', '197.186.66.249', '2026-10-15 15:13:02');
INSERT INTO `security_logs` VALUES ('219', '3', 'ADMIN_LOGIN', 'Administrator email and one-time code login successful.', '197.186.66.249', '2026-10-15 15:16:04');
INSERT INTO `security_logs` VALUES ('220', '2', 'ADMIN_USER_STATUS_CHANGED', 'Changed admin user ID #3 status to disabled.', '197.186.66.249', '2026-10-15 15:16:49');
INSERT INTO `security_logs` VALUES ('221', '3', 'ADMIN_LOGOUT', 'Administrator logged out.', '197.186.66.249', '2026-10-15 15:17:06');
INSERT INTO `security_logs` VALUES ('222', '2', 'ADMIN_USER_STATUS_CHANGED', 'Changed admin user ID #3 status to active.', '197.186.66.249', '2026-10-15 15:17:59');
INSERT INTO `security_logs` VALUES ('223', '2', 'ADMIN_USER_REMOVED', 'Removed admin user ID #3.', '197.186.66.249', '2026-10-15 15:18:04');
INSERT INTO `security_logs` VALUES ('224', '2', 'ADMIN_LOGIN', 'Administrator email and one-time code login successful.', '197.186.66.249', '2026-10-15 15:52:17');
INSERT INTO `security_logs` VALUES ('225', '2', 'ADMIN_LOGOUT', 'Administrator logged out.', '197.186.66.249', '2026-10-15 15:52:36');
INSERT INTO `security_logs` VALUES ('226', '2', 'ADMIN_LOGIN', 'Administrator email and one-time code login successful.', '197.186.66.249', '2026-10-15 15:54:20');
INSERT INTO `security_logs` VALUES ('227', '2', 'ADMIN_LOGIN', 'Administrator email and one-time code login successful.', '197.186.68.181', '2026-10-15 22:36:00');
INSERT INTO `security_logs` VALUES ('228', '2', 'ADMIN_LOGOUT', 'Administrator logged out.', '197.186.68.181', '2026-10-15 22:44:36');
INSERT INTO `security_logs` VALUES ('229', '2', 'ADMIN_LOGIN', 'Administrator email and one-time code login successful.', '197.186.68.181', '2026-10-15 22:46:15');
INSERT INTO `security_logs` VALUES ('230', '2', 'ADMIN_LOGIN', 'Administrator email and one-time code login successful.', '197.186.68.181', '2026-10-15 23:31:22');
INSERT INTO `security_logs` VALUES ('231', '2', 'ADMIN_WALLET_PIN_SET', 'Set or changed the withdrawal PIN.', '197.186.68.181', '2026-10-15 23:34:05');
INSERT INTO `security_logs` VALUES ('232', '2', 'ADMIN_LOGIN', 'Administrator email and one-time code login successful.', '197.250.230.25', '2026-10-16 09:27:20');
INSERT INTO `security_logs` VALUES ('233', '2', 'ADMIN_LOGIN', 'Administrator email and one-time code login successful.', '197.186.75.229', '2026-10-17 01:21:37');
INSERT INTO `security_logs` VALUES ('234', '2', 'PORTAL_SETTINGS_UPDATED', 'Administrator updated customer portal settings.', '197.186.75.229', '2026-10-17 01:22:25');
INSERT INTO `security_logs` VALUES ('235', '2', 'ADMIN_LOGIN', 'Administrator email and one-time code login successful.', '197.186.75.229', '2026-10-17 01:30:17');
INSERT INTO `security_logs` VALUES ('236', '2', 'PAYMENT_NETWORK_LOGO_RESET', 'Administrator reset a payment network logo. Network ID: 2', '197.186.75.229', '2026-10-17 01:32:00');
INSERT INTO `security_logs` VALUES ('237', '2', 'PAYMENT_NETWORK_LOGO_RESET', 'Administrator reset a payment network logo. Network ID: 4', '197.186.75.229', '2026-10-17 01:32:02');
INSERT INTO `security_logs` VALUES ('238', '2', 'PAYMENT_NETWORK_LOGO_RESET', 'Administrator reset a payment network logo. Network ID: 5', '197.186.75.229', '2026-10-17 01:32:04');
INSERT INTO `security_logs` VALUES ('239', '2', 'PAYMENT_NETWORK_LOGO_RESET', 'Administrator reset a payment network logo. Network ID: 1', '197.186.75.229', '2026-10-17 01:32:06');
INSERT INTO `security_logs` VALUES ('240', '2', 'PAYMENT_NETWORK_LOGO_RESET', 'Administrator reset a payment network logo. Network ID: 3', '197.186.75.229', '2026-10-17 01:32:08');
INSERT INTO `security_logs` VALUES ('241', '2', 'PAYMENT_NETWORK_LOGO_UPDATED', 'Administrator updated a payment network logo. Network ID: 4', '197.186.75.229', '2026-10-17 01:32:28');
INSERT INTO `security_logs` VALUES ('242', '2', 'PAYMENT_NETWORK_LOGO_UPDATED', 'Administrator updated a payment network logo. Network ID: 2', '197.186.75.229', '2026-10-17 01:34:34');
INSERT INTO `security_logs` VALUES ('243', '2', 'PORTAL_SETTINGS_UPDATED', 'Administrator updated customer portal settings.', '197.186.75.229', '2026-10-17 01:41:31');
INSERT INTO `security_logs` VALUES ('244', '2', 'PORTAL_SETTINGS_UPDATED', 'Administrator updated customer portal settings.', '197.186.75.229', '2026-10-17 01:42:42');
INSERT INTO `security_logs` VALUES ('245', '2', 'PORTAL_SETTINGS_UPDATED', 'Administrator updated customer portal settings.', '197.186.75.229', '2026-10-17 01:43:16');
INSERT INTO `security_logs` VALUES ('246', '2', 'PORTAL_SETTINGS_UPDATED', 'Administrator updated customer portal settings.', '197.186.75.229', '2026-10-17 01:43:57');
INSERT INTO `security_logs` VALUES ('247', '2', 'PORTAL_SETTINGS_UPDATED', 'Administrator updated customer portal settings.', '197.186.75.229', '2026-10-17 01:53:21');
INSERT INTO `security_logs` VALUES ('248', '2', 'PORTAL_SETTINGS_UPDATED', 'Administrator updated customer portal settings.', '197.186.75.229', '2026-10-17 01:53:52');
INSERT INTO `security_logs` VALUES ('249', '2', 'PORTAL_SETTINGS_UPDATED', 'Administrator updated customer portal settings.', '197.186.75.229', '2026-10-17 01:56:56');
INSERT INTO `security_logs` VALUES ('250', '2', 'ADMIN_LOGIN', 'Administrator email and one-time code login successful.', '197.186.16.75', '2026-10-17 14:08:36');
INSERT INTO `security_logs` VALUES ('251', '2', 'PORTAL_SETTINGS_UPDATED', 'Administrator updated customer portal settings.', '197.186.16.75', '2026-10-17 14:20:00');
INSERT INTO `security_logs` VALUES ('252', '2', 'PORTAL_SETTINGS_UPDATED', 'Administrator updated customer portal settings.', '197.186.16.75', '2026-10-17 14:31:35');
INSERT INTO `security_logs` VALUES ('253', '2', 'ADMIN_LOGIN', 'Administrator email and one-time code login successful.', '197.186.16.75', '2026-10-17 14:46:28');
INSERT INTO `security_logs` VALUES ('254', '2', 'PORTAL_SETTINGS_UPDATED', 'Administrator updated customer portal settings.', '197.186.16.75', '2026-10-17 14:49:33');
INSERT INTO `security_logs` VALUES ('255', '2', 'ADMIN_USER_REQUEST_REJECTED', 'Rejected public admin account request #2.', '197.186.16.75', '2026-10-17 14:55:45');
INSERT INTO `security_logs` VALUES ('256', '2', 'DATABASE_BACKUP_STARTED', 'Administrator started a database backup.', '197.186.16.75', '2026-10-17 14:59:56');


-- --------------------------------------------------------
-- Table: sms_gateway_settings
-- --------------------------------------------------------

DROP TABLE IF EXISTS `sms_gateway_settings`;

CREATE TABLE `sms_gateway_settings` (
  `id` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `provider_name` varchar(100) DEFAULT NULL,
  `endpoint_url` varchar(500) DEFAULT NULL,
  `http_method` enum('POST','GET') NOT NULL DEFAULT 'POST',
  `auth_type` enum('none','bearer','api_key_header','basic') NOT NULL DEFAULT 'none',
  `auth_header_name` varchar(100) DEFAULT NULL,
  `auth_username` varchar(255) DEFAULT NULL,
  `auth_secret_enc` text DEFAULT NULL,
  `sender_id` varchar(50) DEFAULT NULL,
  `environment` enum('test','live') NOT NULL DEFAULT 'test',
  `configured` tinyint(1) NOT NULL DEFAULT 0,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sms_gateway_settings` VALUES ('1', NULL, NULL, 'POST', 'none', NULL, NULL, NULL, NULL, 'test', '0', '0', '2026-09-29 00:30:14', '2026-09-29 00:30:14');


-- --------------------------------------------------------
-- Table: sms_outbox
-- --------------------------------------------------------

DROP TABLE IF EXISTS `sms_outbox`;

CREATE TABLE `sms_outbox` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `idempotency_key` varchar(120) NOT NULL,
  `event_key` varchar(64) NOT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `voucher_id` int(11) DEFAULT NULL,
  `recipient_enc` text NOT NULL,
  `message_enc` mediumtext NOT NULL,
  `status` enum('queued','processing','pending','sent','failed') NOT NULL DEFAULT 'queued',
  `attempt_count` smallint(5) unsigned NOT NULL DEFAULT 0,
  `provider_reference` varchar(128) DEFAULT NULL,
  `error_code` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `sent_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_sms_idempotency_key` (`idempotency_key`),
  KEY `idx_sms_outbox_status_created` (`status`,`created_at`),
  KEY `idx_sms_outbox_payment` (`payment_id`),
  KEY `idx_sms_outbox_voucher` (`voucher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- --------------------------------------------------------
-- Table: sms_templates
-- --------------------------------------------------------

DROP TABLE IF EXISTS `sms_templates`;

CREATE TABLE `sms_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_key` varchar(64) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `language_code` varchar(12) NOT NULL DEFAULT 'sw',
  `body` text NOT NULL,
  `status` enum('enabled','disabled') NOT NULL DEFAULT 'disabled',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_sms_template_event` (`event_key`),
  KEY `idx_sms_templates_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sms_templates` VALUES ('1', 'voucher_auto_issued', 'Automatic voucher issued', 'sw', 'Malipo ya TZS {{amount}} yamepokelewa. Vocha: {{voucher_code}}. Kifurushi: {{package_name}}.', 'disabled', '2026-09-29 00:30:14', '2026-09-29 00:30:14');
INSERT INTO `sms_templates` VALUES ('2', 'voucher_manual_sale', 'Manual cash sale voucher', 'sw', 'Vocha yako: {{voucher_code}}. Kifurushi: {{package_name}}. Muda: {{duration}}. Asante kwa kununua.', 'disabled', '2026-09-29 00:30:14', '2026-09-29 00:30:14');
INSERT INTO `sms_templates` VALUES ('3', 'payment_failed', 'Payment failed notice', 'sw', 'Malipo ya {{amount}} hayajakamilika. Rejea: {{payment_reference}}. Tafadhali jaribu tena.', 'disabled', '2026-09-29 00:30:14', '2026-09-29 00:30:14');


-- --------------------------------------------------------
-- Table: system_settings
-- --------------------------------------------------------

DROP TABLE IF EXISTS `system_settings`;

CREATE TABLE `system_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` varchar(30) NOT NULL DEFAULT 'text',
  `setting_group` varchar(50) NOT NULL DEFAULT 'general',
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_setting_key` (`setting_key`),
  KEY `idx_setting_group` (`setting_group`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `system_settings` VALUES ('1', 'business_name', 'WiFi Voucher voucher', 'text', 'general', '1', '2026-10-01 18:56:22', '2026-10-01 18:58:59');
INSERT INTO `system_settings` VALUES ('2', 'business_phone', '0675409835', 'text', 'general', '1', '2026-10-01 18:56:22', '2026-10-01 18:58:59');
INSERT INTO `system_settings` VALUES ('3', 'business_email', 'georgenicodemus2003@gmail.com', 'email', 'general', '0', '2026-10-01 18:56:22', '2026-10-01 18:58:59');
INSERT INTO `system_settings` VALUES ('4', 'business_address', 'Dar es salaam Tanzania', 'textarea', 'general', '1', '2026-10-01 18:56:22', '2026-10-01 18:58:59');
INSERT INTO `system_settings` VALUES ('5', 'currency', 'TZS', 'text', 'general', '1', '2026-10-01 18:56:22', '2026-10-01 18:56:22');
INSERT INTO `system_settings` VALUES ('6', 'timezone', 'Africa/Dar_es_Salaam', 'text', 'general', '0', '2026-10-01 18:56:22', '2026-10-01 18:56:22');
INSERT INTO `system_settings` VALUES ('7', 'portal_name', 'WiFi Voucher', 'text', 'portal', '1', '2026-10-01 18:56:22', '2026-10-01 18:56:22');
INSERT INTO `system_settings` VALUES ('8', 'portal_welcome_message', 'Karibu. Chagua kifurushi chako na ulipie kupata Internet.', 'textarea', 'portal', '1', '2026-10-01 18:56:22', '2026-10-01 18:56:22');
INSERT INTO `system_settings` VALUES ('9', 'portal_support_phone', '', 'text', 'portal', '1', '2026-10-01 18:56:22', '2026-10-01 18:56:22');
INSERT INTO `system_settings` VALUES ('10', 'portal_footer', '© WiFi Voucher. All rights reserved.', 'text', 'portal', '1', '2026-10-01 18:56:22', '2026-10-01 18:56:22');
INSERT INTO `system_settings` VALUES ('11', 'voucher_auto_activation', '1', 'boolean', 'voucher', '0', '2026-10-01 18:56:22', '2026-10-01 18:56:22');
INSERT INTO `system_settings` VALUES ('12', 'voucher_code_length', '7', 'number', 'voucher', '0', '2026-10-01 18:56:22', '2026-10-01 18:58:59');
INSERT INTO `system_settings` VALUES ('13', 'voucher_prefix', 'WIFI', 'text', 'voucher', '0', '2026-10-01 18:56:22', '2026-10-01 18:56:22');
INSERT INTO `system_settings` VALUES ('14', 'voucher_device_limit', '1', 'number', 'voucher', '0', '2026-10-01 18:56:22', '2026-10-01 18:56:22');
INSERT INTO `system_settings` VALUES ('15', 'payment_timeout_minutes', '3', 'number', 'payment', '0', '2026-10-01 18:56:22', '2026-10-01 18:58:59');
INSERT INTO `system_settings` VALUES ('16', 'payment_auto_confirmation', '1', 'boolean', 'payment', '0', '2026-10-01 18:56:22', '2026-10-01 18:56:22');
INSERT INTO `system_settings` VALUES ('17', 'payment_auto_voucher', '1', 'boolean', 'payment', '0', '2026-10-01 18:56:22', '2026-10-01 18:56:22');
INSERT INTO `system_settings` VALUES ('18', 'notify_payment_success', '1', 'boolean', 'notifications', '0', '2026-10-01 18:56:22', '2026-10-01 18:56:22');
INSERT INTO `system_settings` VALUES ('19', 'notify_payment_failed', '1', 'boolean', 'notifications', '0', '2026-10-01 18:56:22', '2026-10-01 18:56:22');
INSERT INTO `system_settings` VALUES ('20', 'notify_voucher_expired', '1', 'boolean', 'notifications', '0', '2026-10-01 18:56:22', '2026-10-01 18:56:22');
INSERT INTO `system_settings` VALUES ('21', 'maintenance_mode', '0', 'boolean', 'system', '0', '2026-10-01 18:56:22', '2026-10-01 18:56:22');
INSERT INTO `system_settings` VALUES ('22', 'debug_mode', '0', 'boolean', 'system', '0', '2026-10-01 18:56:22', '2026-10-01 18:56:22');


-- --------------------------------------------------------
-- Table: transactions
-- --------------------------------------------------------

DROP TABLE IF EXISTS `transactions`;

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_reference` varchar(50) DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_reference` (`order_reference`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- --------------------------------------------------------
-- Table: trial_settings
-- --------------------------------------------------------

DROP TABLE IF EXISTS `trial_settings`;

CREATE TABLE `trial_settings` (
  `id` tinyint(3) unsigned NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `duration_minutes` smallint(5) unsigned NOT NULL DEFAULT 5,
  `cooldown_days` smallint(5) unsigned NOT NULL DEFAULT 7,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `trial_settings` VALUES ('1', '0', '5', '7', '2026-10-17 02:01:01');


-- --------------------------------------------------------
-- Table: trial_vouchers
-- --------------------------------------------------------

DROP TABLE IF EXISTS `trial_vouchers`;

CREATE TABLE `trial_vouchers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code_hash` char(64) NOT NULL,
  `code_encrypted` text NOT NULL,
  `device_token_hash` char(64) NOT NULL,
  `mac_hash` char(64) DEFAULT NULL,
  `issued_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `cooldown_until` datetime NOT NULL,
  `status` enum('pending_router','provisioned','active','expired','failed','revoked') NOT NULL DEFAULT 'pending_router',
  `router_provisioned_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_trial_code_hash` (`code_hash`),
  KEY `idx_trial_token_cooldown` (`device_token_hash`,`cooldown_until`),
  KEY `idx_trial_mac_cooldown` (`mac_hash`,`cooldown_until`),
  KEY `idx_trial_status_expiry` (`status`,`expires_at`),
  KEY `idx_trial_issued_at` (`issued_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `trial_vouchers` VALUES ('1', '7d57a10d3012b25b38beb66a09e2552a2c181168adb7fd21d1fec1daa5d10b7e', '183YVj/CjEbV7l4g6PsxrmH8R2JQdvYJ4yjdOS5JlBBEI1RQZj6K/1y+eQ==', '664fab530ac97007c2aeaf872c31a0804e05c85f55c26551af37e66371041b9e', NULL, '2026-10-03 23:24:22', '2026-10-03 23:29:22', '2026-10-10 23:24:22', 'expired', NULL, '2026-10-03 23:24:22');
INSERT INTO `trial_vouchers` VALUES ('2', 'a53b5dc71b9210543b8c0584395df5b3bceed28ff142fed930bed897748ef247', 'YNzK00u+XcxkmLcyfr0eMsZRS3/TWaYnCfPgF6zn3geKpEzFvMJVY5duhQ==', '3f831ad016be85efcfc1c2a8649ea8e4a18e362c5ec9af0145482a9eb0bda693', NULL, '2026-10-14 15:40:41', '2026-10-14 15:45:41', '2026-10-21 15:40:41', 'expired', NULL, '2026-10-14 15:40:42');
INSERT INTO `trial_vouchers` VALUES ('3', '5ba65c75bf07e9874e784f55d9e54c2e91360071afc97764b3a592b0db668d2f', 'N7e9tIq453zEKtXK6EDng3TDtGTtkW4OejjcpjM3dnUTQvzHlloqlotcKg==', '0d9cfbfdad063b6d0d9881d0b8972d39d4d652b0691d2c71cbcf9cc20c85ce3b', NULL, '2026-10-15 22:38:24', '2026-10-15 22:43:24', '2026-10-22 22:38:24', 'pending_router', NULL, '2026-10-15 22:38:23');


-- --------------------------------------------------------
-- Table: vouchers
-- --------------------------------------------------------

DROP TABLE IF EXISTS `vouchers`;

CREATE TABLE `vouchers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `package_id` int(11) NOT NULL,
  `status` enum('unused','active','expired','disabled') DEFAULT 'unused',
  `source` enum('auto','manual') NOT NULL DEFAULT 'manual',
  `username` varchar(100) DEFAULT NULL,
  `device_mac` varchar(50) DEFAULT NULL,
  `device_ip` varchar(45) DEFAULT NULL,
  `activated_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `sold_at` datetime DEFAULT NULL,
  `sold_price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_source` (`source`),
  KEY `idx_status_source` (`status`,`source`),
  KEY `vouchers_ibfk_1` (`package_id`),
  CONSTRAINT `vouchers_ibfk_1` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `vouchers` VALUES ('46', 'YZDTNSTFTG', '26', 'expired', 'manual', NULL, NULL, NULL, '2026-09-28 21:37:44', '2026-09-28 21:38:44', '2026-09-28 21:37:18', NULL, NULL);
INSERT INTO `vouchers` VALUES ('47', 'CWKBFN37W4', '26', 'expired', 'manual', NULL, NULL, NULL, '2026-09-30 06:54:33', '2026-09-30 06:55:33', '2026-09-29 09:09:45', NULL, NULL);
INSERT INTO `vouchers` VALUES ('48', '8GYFJSQUE5', '27', 'expired', 'manual', NULL, NULL, NULL, '2026-09-30 06:48:19', '2026-09-30 06:50:19', '2026-09-30 06:47:59', NULL, NULL);
INSERT INTO `vouchers` VALUES ('49', 'B4QV2TPZEG', '28', 'expired', 'manual', NULL, NULL, NULL, '2026-09-30 07:07:58', '2026-09-30 07:08:58', '2026-09-30 07:07:38', NULL, NULL);
INSERT INTO `vouchers` VALUES ('50', 'XYPDCJ6BM3', '28', 'expired', 'manual', NULL, NULL, NULL, '2026-09-30 07:16:39', '2026-09-30 07:17:39', '2026-09-30 07:16:16', NULL, NULL);
INSERT INTO `vouchers` VALUES ('51', 'MADTW66KTX', '27', 'expired', 'manual', NULL, NULL, NULL, '2026-09-30 19:48:34', '2026-09-30 19:50:34', '2026-09-30 19:47:55', NULL, NULL);
INSERT INTO `vouchers` VALUES ('52', 'KF6YS58DVL', '26', 'expired', 'manual', NULL, NULL, NULL, '2026-10-01 08:22:55', '2026-10-01 08:23:55', '2026-10-01 08:22:20', NULL, '500.00');
INSERT INTO `vouchers` VALUES ('53', 'WIFIW87XWDMP', '27', 'expired', 'auto', NULL, NULL, NULL, '2026-10-01 10:27:47', '2026-10-01 10:29:47', '2026-10-01 10:26:07', '2026-10-01 10:26:07', '500.00');
INSERT INTO `vouchers` VALUES ('54', 'WIFI4EFMT5KF', '27', 'expired', 'auto', NULL, NULL, NULL, '2026-10-01 18:31:58', '2026-10-01 18:33:58', '2026-10-01 14:56:17', '2026-10-01 14:56:17', '500.00');
INSERT INTO `vouchers` VALUES ('55', 'GW8H53WRTB', '26', 'expired', 'manual', NULL, NULL, NULL, '2026-10-01 15:15:33', '2026-10-01 15:16:33', '2026-10-01 15:15:15', NULL, '500.00');
INSERT INTO `vouchers` VALUES ('56', 'BKDG29RSN6', '27', 'expired', 'manual', NULL, NULL, NULL, '2026-10-03 21:19:36', '2026-10-03 21:21:36', '2026-10-03 21:19:18', NULL, '500.00');
INSERT INTO `vouchers` VALUES ('57', 'WIFILSZ3D38N', '27', 'expired', 'auto', NULL, NULL, NULL, '2026-10-07 10:50:16', '2026-10-07 10:52:16', '2026-10-04 11:32:21', '2026-10-04 11:32:21', '500.00');
INSERT INTO `vouchers` VALUES ('58', 'WIFIUSWX9JL3', '28', 'expired', 'auto', NULL, NULL, NULL, '2026-10-04 11:42:52', '2026-10-04 17:42:52', '2026-10-04 11:42:52', '2026-10-04 11:42:52', '500.00');
INSERT INTO `vouchers` VALUES ('59', 'LE9TZ2MC4S', '29', 'expired', 'manual', NULL, NULL, NULL, '2026-10-04 15:49:35', '2026-10-11 15:49:35', '2026-10-04 15:49:23', '2026-10-04 15:49:35', '5000.00');
INSERT INTO `vouchers` VALUES ('60', '4XVKLUKA5D', '27', 'expired', 'manual', NULL, NULL, NULL, '2026-10-04 15:51:09', '2026-10-04 15:53:09', '2026-10-04 15:50:55', '2026-10-04 15:51:09', '500.00');
INSERT INTO `vouchers` VALUES ('61', '94MYRFU482', '27', 'expired', 'manual', NULL, NULL, NULL, '2026-10-13 23:23:29', '2026-10-13 23:25:29', '2026-10-07 15:34:26', NULL, '500.00');
INSERT INTO `vouchers` VALUES ('62', '93GVF9HSH3', '26', 'unused', 'manual', NULL, NULL, NULL, NULL, NULL, '2026-10-14 18:14:58', NULL, NULL);


-- --------------------------------------------------------
-- Table: wifi_network_profiles
-- --------------------------------------------------------

DROP TABLE IF EXISTS `wifi_network_profiles`;

CREATE TABLE `wifi_network_profiles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `platform` enum('tp_link','omada','mikrotik') NOT NULL,
  `device_family` varchar(60) NOT NULL,
  `device_model` varchar(100) DEFAULT NULL,
  `hardware_version` varchar(50) DEFAULT NULL,
  `firmware_version` varchar(80) DEFAULT NULL,
  `ssid` varchar(32) NOT NULL,
  `access_mode` enum('voucher_portal','guest_wifi') NOT NULL DEFAULT 'voucher_portal',
  `vlan_id` smallint(5) unsigned DEFAULT NULL,
  `gateway_ip` varchar(45) DEFAULT NULL,
  `portal_url` varchar(500) DEFAULT NULL,
  `controller_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('draft','ready','archived') NOT NULL DEFAULT 'draft',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `wan_connection_type` enum('dhcp','static','pppoe') NOT NULL DEFAULT 'dhcp',
  `wan_ip_address` varchar(45) DEFAULT NULL,
  `wan_subnet_cidr` varchar(43) DEFAULT NULL,
  `wan_gateway_ip` varchar(45) DEFAULT NULL,
  `pppoe_username` varchar(190) DEFAULT NULL,
  `pppoe_password_enc` text DEFAULT NULL,
  `lan_subnet_cidr` varchar(43) DEFAULT NULL,
  `dhcp_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `dhcp_start_ip` varchar(45) DEFAULT NULL,
  `dhcp_end_ip` varchar(45) DEFAULT NULL,
  `dns_primary` varchar(45) DEFAULT NULL,
  `dns_secondary` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_wifi_profiles_platform_status` (`platform`,`status`),
  KEY `idx_wifi_profiles_controller` (`controller_id`),
  CONSTRAINT `fk_wifi_profile_controller` FOREIGN KEY (`controller_id`) REFERENCES `network_controllers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wifi_network_profiles` VALUES ('1', 'Jaribio Wi-Fi', 'tp_link', 'other', NULL, NULL, NULL, 'Voucher / Captive Portal', 'voucher_portal', NULL, '192.168.1.1', NULL, NULL, 'draft', '2026-10-04 20:25:37', '2026-10-04 20:25:37', 'dhcp', NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL);


-- --------------------------------------------------------
-- Table: withdrawals
-- --------------------------------------------------------

DROP TABLE IF EXISTS `withdrawals`;

CREATE TABLE `withdrawals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(12,2) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `admin_name` varchar(100) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
SET AUTOCOMMIT = 1;
