<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';

header('Location: ' . appUrl('customer/checkout.php'), true, 302);
exit;
