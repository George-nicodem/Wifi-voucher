<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/customer_auth.php';
customerAccountLogout();
header('Location: ' . appUrl('customer/checkout.php'), true, 303);
exit;
