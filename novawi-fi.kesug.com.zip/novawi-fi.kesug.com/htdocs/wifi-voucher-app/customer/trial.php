<?php
declare(strict_types=1);

ini_set('session.use_strict_mode', '1');
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'httponly' => true,
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'samesite' => 'Lax',
    ]);
    session_start();
}

require_once dirname(__DIR__) . '/includes/trial_voucher.php';
require_once dirname(__DIR__) . '/includes/portal_settings.php';

global $conn;
$portalSettings = wifiPortalSettings($conn);
$portalThemeKey = wifiPortalThemeKey($portalSettings['theme_key'] ?? 'ocean');
$portalThemeStyle = wifiPortalThemeStyle($portalSettings);
$maintenanceMode = (int)$portalSettings['maintenance_enabled'] === 1;
$maintenanceMessage = (string)$portalSettings['maintenance_message'];

function trialEscape(mixed $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

if (!isset($_SESSION['wifi_trial_csrf'])) {
    $_SESSION['wifi_trial_csrf'] = bin2hex(random_bytes(32));
}

$error = '';
$result = $_SESSION['wifi_trial_result'] ?? null;
unset($_SESSION['wifi_trial_result']);
$macInput = trim((string)($_GET['mac'] ?? $_POST['mac'] ?? ''));
$normalizedMac = wifiTrialNormalizeMac($macInput);

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $csrf = (string)($_POST['csrf_token'] ?? '');
    if (!hash_equals((string)$_SESSION['wifi_trial_csrf'], $csrf)) {
        $error = 'Fomu imepitwa na muda. Onyesha upya ukurasa, kisha ujaribu tena.';
    } elseif ($maintenanceMode) {
        $error = $maintenanceMessage;
    } else {
        try {
            global $conn;
            $result = wifiTrialIssue($conn, (string)($_POST['device_token'] ?? ''), $normalizedMac);
            $_SESSION['wifi_trial_result'] = $result;
            $_SESSION['wifi_trial_csrf'] = bin2hex(random_bytes(32));
            $path = strtok((string)($_SERVER['REQUEST_URI'] ?? 'trial.php'), '?');
            $query = $normalizedMac !== null ? '?mac=' . rawurlencode($normalizedMac) : '';
            header('Location: ' . $path . $query, true, 303);
            exit;
        } catch (Throwable $exception) {
            $error = $exception instanceof RuntimeException ? $exception->getMessage() : 'Imeshindikana kuanzisha trial. Jaribu tena au wasiliana na msimamizi.';
            error_log('Wi-Fi trial issue failed: ' . $exception->getMessage());
        }
    }
}

$appName = trim((string)($portalSettings['brand_name'] ?? '')) ?: (defined('APP_NAME') ? (string)APP_NAME : 'Wi-Fi');
$portalLogoPath = wifiPortalLogoPath($portalSettings);
$csrfToken = (string)$_SESSION['wifi_trial_csrf'];
?>
<!doctype html>
<html lang="sw">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Jaribu Wi-Fi | <?= trialEscape($appName) ?></title>
    <style>
        :root{color-scheme:light;--navy:#14213d;--blue:#2364d2;--muted:#667085;--line:#e5eaf2;--soft:#f4f7fc;--green:#16855b;--red:#b42318}
        *{box-sizing:border-box}body{margin:0;background:linear-gradient(135deg,#f4f7fc,#edf4ff);font:15px/1.55 Inter,Segoe UI,Arial,sans-serif;color:var(--navy);min-height:100vh;display:grid;place-items:center;padding:24px}
        .trial-shell{width:min(100%,560px)}.brand{display:flex;align-items:center;gap:12px;margin:0 0 18px 4px;font-weight:800;font-size:17px}.brand-mark{width:42px;height:42px;border-radius:14px;background:#e5efff;color:var(--blue);display:grid;place-items:center;font-size:21px;overflow:hidden}.brand-mark img{width:100%;height:100%;padding:3px;object-fit:contain;background:#fff}
        .trial-card{background:#fff;border:1px solid var(--line);border-radius:24px;padding:clamp(22px,5vw,38px);box-shadow:0 18px 55px #18356112}.eyebrow{margin:0 0 8px;color:var(--blue);font-size:12px;font-weight:800;letter-spacing:.12em;text-transform:uppercase}h1{font-size:clamp(25px,5vw,34px);line-height:1.15;margin:0 0 10px}.lead{color:var(--muted);margin:0 0 23px}
        .benefit{display:flex;gap:14px;align-items:center;background:var(--soft);border:1px solid #edf1f7;border-radius:16px;padding:15px;margin:20px 0 22px}.benefit-icon{width:46px;height:46px;border-radius:14px;background:#e2edff;color:var(--blue);display:grid;place-items:center;font-size:22px;flex:none}.benefit strong{display:block}.benefit span{color:var(--muted);font-size:13px}
        .message{border-radius:14px;padding:13px 15px;margin:0 0 17px}.message.error{color:var(--red);background:#fff1f0;border:1px solid #ffd8d5}.message.success{color:#175d45;background:#effaf5;border:1px solid #c9efdc}.message.pending{color:#684d09;background:#fff9e8;border:1px solid #f2dfa5;margin-top:14px}.message.maintenance{color:#765018;background:#fff8e7;border:1px solid #f1dfa9}
        .trial-code{font:800 24px/1.4 ui-monospace,Consolas,monospace;letter-spacing:.08em;display:block;margin-top:7px;word-break:break-all}.button{width:100%;border:0;border-radius:14px;background:var(--blue);color:white;font:800 15px/1.2 inherit;padding:15px 20px;cursor:pointer;box-shadow:0 8px 18px #2364d22b}.button:hover{background:#194eaa}.button:disabled{opacity:.55;cursor:wait}.fine{color:var(--muted);font-size:12px;text-align:center;margin:15px 0 0}.foot{color:var(--muted);font-size:12px;text-align:center;margin:15px 0 0}
        @media(max-width:480px){body{padding:15px}.trial-card{border-radius:19px}.brand{margin-left:3px}}
    </style>

    <link rel="stylesheet" href="<?= trialEscape(appUrl('customer/portal-theme.css?v=9')) ?>">
</head>
<body class="portal-page portal-trial portal-theme-<?= trialEscape($portalThemeKey) ?>" style="<?= trialEscape($portalThemeStyle) ?>">
<main class="trial-shell">
    <div class="brand"><span class="brand-mark" aria-hidden="true"><?php if ($portalLogoPath !== ''): ?><img src="<?= trialEscape(appUrl($portalLogoPath)) ?>" alt=""><?php else: ?>◉<?php endif; ?></span><span><?= trialEscape($appName) ?></span></div>
    <section class="trial-card" aria-labelledby="trialTitle">
        <p class="eyebrow">WI-FI YA BURE</p>
        <h1 id="trialTitle">Jaribu Wi-Fi</h1>
        <p class="lead">Muda huanza unapobonyeza kitufe.</p>
        <div class="benefit"><span class="benefit-icon" aria-hidden="true">◷</span><div><strong>Jaribio la Wi-Fi</strong><span>Muda na marudio huwekwa na msimamizi.</span></div></div>

        <?php if ($error !== '' && !($maintenanceMode && $error === $maintenanceMessage)): ?><div class="message error" role="alert"><?= trialEscape($error) ?></div><?php endif; ?>
        <?php if (is_array($result)): ?>
            <div class="message success"><strong>Voucher yako ya trial</strong><span class="trial-code"><?= trialEscape($result['code'] ?? '') ?></span><small>Inaisha: <?= trialEscape($result['expires_at'] ?? '') ?></small></div>
            <div class="message pending"><strong>Router haijaunganishwa bado.</strong> Intaneti itaanza baada ya router kuunganishwa.</div>
        <?php elseif ($maintenanceMode): ?>
            <div class="message maintenance" role="status"><strong>Huduma imesitishwa kwa muda.</strong><br><?= trialEscape($maintenanceMessage) ?></div>
            <p class="fine"><a href="<?= trialEscape(appUrl('customer/checkout.php')) ?>">Rudi</a></p>
        <?php else: ?>
            <form method="post" id="trialForm" autocomplete="off">
                <input type="hidden" name="csrf_token" value="<?= trialEscape($csrfToken) ?>">
                <input type="hidden" name="device_token" id="deviceToken" value="">
                <input type="hidden" name="mac" value="<?= trialEscape($normalizedMac ?? '') ?>">
                <button class="button" type="submit" id="trialButton">Anza jaribio</button>
            </form>
            <p class="fine">Jaribio jingine linaruhusiwa baada ya muda uliowekwa.</p>
        <?php endif; ?>
    </section>
</main>
<script>
(function(){
  const form=document.getElementById('trialForm'); if(!form)return;
  const field=document.getElementById('deviceToken'),button=document.getElementById('trialButton');
  try{
    let token=localStorage.getItem('wifi_trial_device_token');
    if(!token||!/^[a-f0-9]{64}$/i.test(token)){
      const bytes=new Uint8Array(32);crypto.getRandomValues(bytes);token=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
      localStorage.setItem('wifi_trial_device_token',token);
    }
    field.value=token;
  }catch(e){button.disabled=true;button.textContent='Washa local storage kwenye browser';}
  form.addEventListener('submit',function(){button.disabled=true;button.textContent='Tunatuma ombi…';});
})();
</script>
</body>
</html>
