<?php
declare(strict_types=1);

/* Customer portal contacts. Use Tanzanian numbers in 0XXXXXXXXX format. */
return [
    'call_phone' => '0675409835',
    'whatsapp_phone' => '0749509813',
];
