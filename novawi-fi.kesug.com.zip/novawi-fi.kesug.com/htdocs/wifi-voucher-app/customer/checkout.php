<?php
declare(strict_types=1);

ini_set('session.use_strict_mode', '1');
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'httponly' => true,
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'samesite' => 'Lax',
    ]);
    session_start();
}

require_once dirname(__DIR__) . '/includes/clickpesa_checkout.php';
require_once dirname(__DIR__) . '/includes/portal_settings.php';
$customerContactSettings = require __DIR__ . '/contact_config.php';

// Portal display settings come from the admin Portal Settings table.
// contact_config.php remains a safe fallback for phone numbers.
$portalSettings = [
    'brand_name' => (string)APP_NAME,
    'welcome_message' => 'Lipa kwa simu yako na upokee voucher baada ya malipo kuthibitishwa.',
    'call_phone' => trim((string)($customerContactSettings['call_phone'] ?? '')),
    'whatsapp_phone' => trim((string)($customerContactSettings['whatsapp_phone'] ?? '')),
];

function portalEscape(mixed $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function portalDurationLabel(int $minutes): string
{
    if ($minutes <= 0) return '';
    if ($minutes % 43200 === 0) {
        $months = intdiv($minutes, 43200);
        return $months === 1 ? 'mwezi 1' : 'miezi ' . $months;
    }
    if ($minutes % 10080 === 0) {
        $weeks = intdiv($minutes, 10080);
        return 'wiki ' . $weeks;
    }
    if ($minutes % 1440 === 0) {
        $days = intdiv($minutes, 1440);
        return 'siku ' . $days;
    }
    if ($minutes >= 60) {
        $hours = intdiv($minutes, 60);
        $remainingMinutes = $minutes % 60;
        return $remainingMinutes === 0
            ? 'saa ' . $hours
            : 'saa ' . $hours . ' na dakika ' . $remainingMinutes;
    }
    return 'dakika ' . $minutes;
}

function portalSpeedLabel(string $speed): string
{
    $speed = trim($speed);
    if ($speed === '') return '';

    if (preg_match('/^(\d+(?:\.\d+)?)\s*(?:m|mbps)$/i', $speed, $matches)) {
        return $matches[1] . ' Mbps';
    }
    if (preg_match('/^(\d+(?:\.\d+)?)\s*(?:k|kbps)$/i', $speed, $matches)) {
        return $matches[1] . ' Kbps';
    }
    if (preg_match('/^\d+(?:\.\d+)?$/', $speed)) {
        return $speed . ' Mbps';
    }

    return $speed;
}

function portalContactInternational(string $phone): string
{
    $digits = preg_replace('/\\D+/', '', $phone) ?? '';
    if (strlen($digits) === 10 && str_starts_with($digits, '0')) {
        return '255' . substr($digits, 1);
    }
    if (strlen($digits) === 12 && str_starts_with($digits, '255')) {
        return $digits;
    }
    return '';
}

$callPhoneDisplay = trim((string)$portalSettings['call_phone']);
$whatsappPhoneDisplay = trim((string)$portalSettings['whatsapp_phone']);
$callPhoneInternational = portalContactInternational($callPhoneDisplay);
$whatsappPhoneInternational = portalContactInternational($whatsappPhoneDisplay);

$db = $conn;
$portalSettings = wifiPortalSettings($db, $portalSettings);
$portalThemeKey = wifiPortalThemeKey($portalSettings['theme_key'] ?? 'ocean');
$portalThemeStyle = wifiPortalThemeStyle($portalSettings);
$maintenanceMode = (int)$portalSettings['maintenance_enabled'] === 1;
$maintenanceMessage = (string)$portalSettings['maintenance_message'];
$customerPaymentsEnabled = (int)($portalSettings['customer_payments_enabled'] ?? 1) === 1;
$paymentCheckoutBlocked = $maintenanceMode || !$customerPaymentsEnabled;

$callPhoneDisplay = trim((string)$portalSettings['call_phone']);
$whatsappPhoneDisplay = trim((string)$portalSettings['whatsapp_phone']);
$callPhoneInternational = portalContactInternational($callPhoneDisplay);
$whatsappPhoneInternational = portalContactInternational($whatsappPhoneDisplay);
$error = '';
$notice = '';
$resumeUrl = '';
$packages = [];
$networkOptions = [];
$phoneInput = '';
$selectedNetwork = '';
$selectedPackageId = '';
$buyerName = '';
$buyerEmail = '';
$contactRequired = false;
$voucherInput = '';
$voucherActivation = null;
$portalMac = preg_replace('/[^0-9A-Fa-f:.-]/', '', (string)($_GET['mac'] ?? $_POST['mac'] ?? '')) ?? '';
$activationFlash = $_SESSION['wifi_cp_manual_voucher_flash'] ?? null;
unset($_SESSION['wifi_cp_manual_voucher_flash']);
if (is_array($activationFlash) && trim((string)($activationFlash['code'] ?? '')) !== '') {
    $voucherActivation = [
        'code' => (string)$activationFlash['code'],
        'activated_at' => (string)($activationFlash['activated_at'] ?? ''),
        'expires_at' => (string)($activationFlash['expires_at'] ?? ''),
    ];
    $notice = 'Voucher yako imewezeshwa. Muda wa kifurushi umeanza kuhesabika sasa.';
}

if ($customerPaymentsEnabled) {
    try {
        $networkOptions = wifiCpCustomerNetworks($db);
    } catch (Throwable $exception) {
        error_log('Customer checkout payment networks: ' . $exception->getMessage());
    }
}

try {
    $packages = wifiCpActivePackages($db);
} catch (Throwable $exception) {
    $error = 'Imeshindikana kupakia vifurushi. Jaribu tena baadaye.';
    error_log('Customer checkout packages: ' . $exception->getMessage());
}

$trialEnabled = false;
$trialDurationText = '';
try {
    $trialSettingsResult = $db->query('SELECT enabled, duration_minutes FROM trial_settings WHERE id = 1 LIMIT 1');
    $trialSettings = $trialSettingsResult instanceof mysqli_result ? ($trialSettingsResult->fetch_assoc() ?: null) : null;
    if ($trialSettingsResult instanceof mysqli_result) $trialSettingsResult->free();
    if ($trialSettings && (int)($trialSettings['enabled'] ?? 0) === 1) {
        $trialEnabled = true;
        $trialMinutes = max(1, min(60, (int)($trialSettings['duration_minutes'] ?? 5)));
        $trialDurationText = portalDurationLabel($trialMinutes);
    }
} catch (Throwable $exception) {
    error_log('Customer checkout trial settings: ' . $exception->getMessage());
}

if (!isset($_SESSION['wifi_cp_checkout_csrf'])) {
    $_SESSION['wifi_cp_checkout_csrf'] = bin2hex(random_bytes(32));
}

$requestMethod = (string)($_SERVER['REQUEST_METHOD'] ?? 'GET');
$postAction = is_string($_POST['form_action'] ?? null) ? trim($_POST['form_action']) : 'purchase';

if ($requestMethod === 'POST' && $postAction === 'activate_voucher') {
    $rawVoucherCode = $_POST['voucher_code'] ?? '';
    $voucherInput = is_string($rawVoucherCode) ? strtoupper(trim($rawVoucherCode)) : '';
    $csrf = is_string($_POST['csrf_token'] ?? null) ? $_POST['csrf_token'] : '';
    $sessionCsrf = (string)($_SESSION['wifi_cp_checkout_csrf'] ?? '');

    if ($sessionCsrf === '' || !hash_equals($sessionCsrf, $csrf)) {
        $error = 'Fomu imepitwa na muda. Onyesha upya ukurasa kisha ujaribu tena.';
    } elseif ($voucherInput === '' || strlen($voucherInput) > 50) {
        $error = 'Weka code sahihi ya voucher uliyopewa.';
    } else {
        $attempts = $_SESSION['wifi_cp_manual_voucher_attempts'] ?? [];
        if (!is_array($attempts)) $attempts = [];
        $cutoff = time() - 900;
        $attempts = array_values(array_filter($attempts, static fn($at): bool => is_int($at) && $at >= $cutoff));

        if (count($attempts) >= 10) {
            $_SESSION['wifi_cp_manual_voucher_attempts'] = $attempts;
            $error = 'Umefanya majaribio mengi ya voucher. Subiri dakika 15 kisha ujaribu tena.';
        } else {
            $attempts[] = time();
            $_SESSION['wifi_cp_manual_voucher_attempts'] = $attempts;

            $activationTransactionStarted = false;
            try {
                if (!$db->begin_transaction()) throw new RuntimeException('Imeshindikana kuanza activation. Jaribu tena baadaye.');
                $activationTransactionStarted = true;

                $lookup = $db->prepare("SELECT v.id, v.code, v.status, v.source, v.package_id,
                        p.status AS package_status, p.duration_minutes
                    FROM vouchers AS v
                    INNER JOIN packages AS p ON p.id = v.package_id
                    WHERE v.code = ? AND v.source = 'manual'
                    LIMIT 1 FOR UPDATE");
                if (!$lookup) throw new RuntimeException('Imeshindikana kuangalia voucher. Jaribu tena baadaye.');
                $lookup->bind_param('s', $voucherInput);
                if (!$lookup->execute()) {
                    $lookup->close();
                    throw new RuntimeException('Imeshindikana kuangalia voucher. Jaribu tena baadaye.');
                }
                $voucher = $lookup->get_result()->fetch_assoc() ?: null;
                $lookup->close();

                if (!$voucher || (string)$voucher['status'] !== 'unused') {
                    throw new RuntimeException('Voucher haipo, tayari imetumika, au si voucher ya msimamizi. Hakiki code kisha ujaribu tena.');
                }
                if (strtolower((string)$voucher['package_status']) !== 'active') {
                    throw new RuntimeException('Kifurushi cha voucher hii hakitumiki kwa sasa. Wasiliana na msimamizi.');
                }

                $voucherId = (int)$voucher['id'];
                $activate = $db->prepare("UPDATE vouchers AS v
                    INNER JOIN packages AS p ON p.id = v.package_id
                    SET v.status = 'active',
                        v.activated_at = NOW(),
                        v.expires_at = CASE
                            WHEN p.duration_minutes > 0
                                THEN DATE_ADD(NOW(), INTERVAL p.duration_minutes MINUTE)
                            ELSE NULL
                        END,
                        v.sold_at = COALESCE(v.sold_at, NOW()),
                        v.sold_price = COALESCE(v.sold_price, p.price)
                    WHERE v.id = ?
                      AND v.source = 'manual'
                      AND v.status = 'unused'
                      AND p.status = 'active'");
                if (!$activate) throw new RuntimeException('Imeshindikana kuandaa activation ya voucher. Jaribu tena.');
                $activate->bind_param('i', $voucherId);
                if (!$activate->execute()) {
                    $activate->close();
                    throw new RuntimeException('Imeshindikana kuwezesha voucher. Jaribu tena baadaye.');
                }
                if ($activate->affected_rows !== 1) {
                    $activate->close();
                    throw new RuntimeException('Voucher hii tayari imebadilika au kifurushi kimezimwa. Wasiliana na msimamizi.');
                }
                $activate->close();

                $expiryQuery = $db->prepare('SELECT activated_at, expires_at FROM vouchers WHERE id = ? LIMIT 1');
                if (!$expiryQuery) throw new RuntimeException('Voucher imewezeshwa, lakini taarifa zake hazikupatikana.');
                $expiryQuery->bind_param('i', $voucherId);
                if (!$expiryQuery->execute()) {
                    $expiryQuery->close();
                    throw new RuntimeException('Imeshindikana kusoma muda wa voucher.');
                }
                $activationTimes = $expiryQuery->get_result()->fetch_assoc() ?: [];
                $expiryQuery->close();

                $activationResult = [
                    'code' => (string)$voucher['code'],
                    'activated_at' => (string)($activationTimes['activated_at'] ?? ''),
                    'expires_at' => (string)($activationTimes['expires_at'] ?? ''),
                ];
                $newCsrfToken = bin2hex(random_bytes(32));
                if (!$db->commit()) throw new RuntimeException('Activation haikuweza kuhifadhiwa. Jaribu tena.');
                $activationTransactionStarted = false;
                $_SESSION['wifi_cp_manual_voucher_attempts'] = [];
                $_SESSION['wifi_cp_checkout_csrf'] = $newCsrfToken;
                $_SESSION['wifi_cp_manual_voucher_flash'] = $activationResult;
                $redirectUrl = appUrl('customer/checkout.php') . ($portalMac !== '' ? '?mac=' . rawurlencode($portalMac) : '');
                header('Location: ' . $redirectUrl, true, 303);
                exit;
            } catch (RuntimeException $exception) {
                if ($activationTransactionStarted) $db->rollback();
                $error = $exception->getMessage();
            } catch (Throwable $exception) {
                if ($activationTransactionStarted) $db->rollback();
                error_log('Customer manual voucher activation failed: ' . $exception->getMessage());
                $error = 'Imeshindikana kuwezesha voucher kwa sasa. Jaribu tena baadaye.';
            }
        }
    }
} elseif ($requestMethod === 'POST' && !in_array($postAction, ['purchase', ''], true)) {
    $error = 'Ombi halijatambuliwa. Onyesha upya ukurasa kisha ujaribu tena.';
}

if ($requestMethod === 'POST' && $postAction !== 'activate_voucher' && in_array($postAction, ['purchase', ''], true) && $paymentCheckoutBlocked && $error === '') {
    $csrf = (string)($_POST['csrf_token'] ?? '');
    if (!hash_equals((string)$_SESSION['wifi_cp_checkout_csrf'], $csrf)) {
        $error = 'Fomu imepitwa na muda. Onyesha upya ukurasa kisha ujaribu tena.';
    } elseif (!$maintenanceMode && !$customerPaymentsEnabled) {
        $error = 'Malipo kwa simu yamezimwa kwa sasa. Ingiza code ya voucher ili uendelee.';
    }
}

if ($requestMethod === 'POST' && $postAction !== 'activate_voucher' && $error === '' && !$paymentCheckoutBlocked) {
    $phoneInput = trim((string)($_POST['phone'] ?? ''));
    $selectedNetwork = trim((string)($_POST['network'] ?? ''));
    $selectedPackageId = trim((string)($_POST['package_id'] ?? ''));
    $buyerName = trim((string)($_POST['buyer_name'] ?? ''));
    $buyerEmail = trim((string)($_POST['buyer_email'] ?? ''));
    $csrf = (string)($_POST['csrf_token'] ?? '');
    if (!hash_equals((string)$_SESSION['wifi_cp_checkout_csrf'], $csrf)) {
        $error = 'Fomu imepitwa na muda. Onyesha upya ukurasa kisha ujaribu tena.';
    } else {
        try {
            $phone = wifiCpNormalizePhone($phoneInput);
            if ($phone === null) {
                throw new RuntimeException('Weka namba sahihi ya Tanzania, mfano 0712345678.');
            }
            if (!isset($networkOptions[$selectedNetwork])) {
                throw new RuntimeException('Chagua mtandao wa SIM utakayotumia kulipia.');
            }
            $chosen = null;
            foreach ($packages as $candidate) {
                if ((string)$candidate['id'] === $selectedPackageId) {
                    $chosen = $candidate;
                    break;
                }
            }
            if (!is_array($chosen)) {
                throw new RuntimeException('Chagua kifurushi active kwenye orodha.');
            }
            $amount = (float)$chosen['price'];
            if ($amount <= 0 || $amount > 10000000) {
                throw new RuntimeException('Bei ya kifurushi si sahihi. Wasiliana na msimamizi.');
            }

            $oldReference = (string)($_SESSION['wifi_cp_checkout_reference'] ?? '');
            if ($oldReference !== '') {
                $oldPayment = wifiCpPaymentRow($db, $oldReference);
                $oldStatus = strtoupper((string)($oldPayment['status'] ?? ''));
                if (in_array($oldStatus, ['PENDING', 'PROCESSING'], true)) {
                    $resumeUrl = appUrl('customer/status.php?ref=' . rawurlencode($oldReference));
                    throw new RuntimeException('Ombi lako la awali bado linasubiri. Kamilisha au angalia ombi hilo kwanza ili kuepuka malipo mara mbili.');
                }
            }

            $networkChoice = $networkOptions[$selectedNetwork];
            if ((int)$networkChoice['method_id'] > 0) {
                // The customer selects only a mobile network. The admin's
                // primary/fallback route selects the provider server-side.
                $route = wifiCpResolveRoute($db, (int)$networkChoice['method_id']);
                $config = $route['config'];
                $channelId = (int)$route['channel']['id'];
                $channelName = (string)$route['channel']['name'];
                $providerKey = (string)$route['provider_key'];
                $selectedNetworkKey = wifiCpCanonicalNetwork(
                    (string)($route['method']['provider_code'] ?? ''),
                    (string)($route['method']['name'] ?? ''),
                    (string)($route['method']['display_name'] ?? '')
                );
            } else {
                throw new RuntimeException('No verified aggregator route is available for this network. Configure it in Admin > Payment Routing.');
            }
            if (wifiPaymentProviderNeedsContact($providerKey)) {
                if ($buyerName === '' || strlen($buyerName) > 160 || preg_match('/[\x00-\x1F\x7F]/', $buyerName)) {
                    throw new RuntimeException('Weka jina lako kamili kwa akaunti hii ya malipo.');
                }
                if (count(preg_split('/\s+/', $buyerName, -1, PREG_SPLIT_NO_EMPTY) ?: []) < 2) {
                    throw new RuntimeException('Weka jina la kwanza na la mwisho.');
                }
                if (filter_var($buyerEmail, FILTER_VALIDATE_EMAIL) === false || strlen($buyerEmail) > 190) {
                    throw new RuntimeException('Weka barua pepe sahihi kwa akaunti hii ya malipo.');
                }
            } else {
                $buyerName = '';
                $buyerEmail = '';
            }
            $reference = wifiCpNewReference();
            if ($providerKey !== 'clickpesa') {
                wifiCpCreatePendingPayment($db, $phone, (int)$chosen['id'], $amount, $reference, $channelId, $channelName);
                $_SESSION['wifi_cp_checkout_reference'] = $reference;
                $resumeUrl = appUrl('customer/status.php?ref=' . rawurlencode($reference));
                try {
                    $providerNetworkCode = trim((string)($route['channel']['channel_network_code'] ?? '')) ?: $selectedNetworkKey;
                    $init = wifiPaymentAdapterInitiate($config, $reference, $phone, $amount, $providerNetworkCode, $buyerName, $buyerEmail);
                    wifiPaymentPersistProviderReference($db, $reference, (string)($init['provider_reference'] ?? ''));
                    $initialStatus = wifiPaymentNormalizeStatus((string)($init['status'] ?? 'PENDING')) ?: 'PENDING';
                    wifiCpMarkPendingStatus($db, $reference, $initialStatus);
                    header('Location: ' . $resumeUrl, true, 303);
                    exit;
                } catch (Throwable $initError) {
                    error_log($providerKey . ' initiate reference ' . $reference . ': ' . $initError->getMessage());
                    // A multi-step provider may already have created an order.
                    // Keep ambiguous failures pending to prevent duplicate payment.
                    $notice = 'Ombi limehifadhiwa. Hali ya provider haijafika kikamilifu; fungua hali ya ombi kabla ya kujaribu tena ili kuepuka malipo mara mbili.';
                }
            } else {
            $token = wifiCpToken($config);
            $amountForApi = floor($amount) === $amount ? (string)(int)$amount : number_format($amount, 2, '.', '');
            $previewPayload = wifiCpSignPayload([
                'amount' => $amountForApi,
                'currency' => 'TZS',
                'orderReference' => $reference,
                'phoneNumber' => $phone,
                'fetchSenderDetails' => true,
            ], $config['checksum_key']);
            $preview = wifiCpRequest('/payments/preview-ussd-push-request', 'POST', $previewPayload, [
                'Authorization: ' . $token,
            ], (string)$config['api_base_url']);
            $methods = is_array($preview['activeMethods'] ?? null) ? $preview['activeMethods'] : [];
            $available = array_values(array_filter($methods, static fn($method): bool => is_array($method)
                && strtoupper((string)($method['status'] ?? '')) === 'AVAILABLE'));
            $provider = (string)($preview['sender']['accountProvider'] ?? '');
            $networkAvailable = $available !== [] && ($provider !== ''
                ? wifiCpMethodMatchesNetwork($provider, $selectedNetworkKey)
                : count(array_filter($available, static fn($method): bool => wifiCpMethodMatchesNetwork((string)($method['name'] ?? ''), $selectedNetworkKey))) > 0);
            if (!$networkAvailable) {
                throw new RuntimeException('ClickPesa haithibitishi mtandao huu kwa namba uliyoingiza. Hakiki SIM na mtandao, kisha ujaribu tena.');
            }

            $initPayload = wifiCpSignPayload([
                'amount' => $amountForApi,
                'currency' => 'TZS',
                'orderReference' => $reference,
                'phoneNumber' => $phone,
            ], $config['checksum_key']);
            wifiCpCreatePendingPayment($db, $phone, (int)$chosen['id'], $amount, $reference, $channelId, $channelName);
            $_SESSION['wifi_cp_checkout_reference'] = $reference;
            $resumeUrl = appUrl('customer/status.php?ref=' . rawurlencode($reference));

            $initResponse = null;
            try {
                // Reuse the token already acquired for preview. Catch only the
                // initiation request, never local processing of an accepted one.
                $initResponse = wifiCpRequest('/payments/initiate-ussd-push-request', 'POST', $initPayload, [
                    'Authorization: ' . $token,
                ], (string)$config['api_base_url']);
            } catch (Throwable $initError) {
                error_log('ClickPesa initiate reference ' . $reference . ': ' . $initError->getMessage());
                if (wifiCpIsDefinitiveInitiationRejection($initError)) {
                    wifiCpMarkPendingStatus($db, $reference, 'FAILED');
                    throw $initError;
                }
                // A timeout, rate limit, server error or unreadable success may
                // still have charged the customer. Keep this reference pending.
                $notice = 'Ombi limehifadhiwa. Jibu la ClickPesa halijafika kikamilifu; angalia hali ya ombi kabla ya kujaribu tena.';
            }
            if (is_array($initResponse)) {
                $initialStatus = strtoupper(trim((string)($initResponse['status'] ?? '')));
                if (in_array($initialStatus, ['PENDING', 'PROCESSING'], true)) {
                    wifiCpMarkPendingStatus($db, $reference, $initialStatus);
                }
                header('Location: ' . $resumeUrl, true, 303);
                exit;
            }
            }
        } catch (Throwable $exception) {
            $error = $exception->getMessage();
            if ($resumeUrl === '' && !empty($_SESSION['wifi_cp_checkout_reference'])) {
                $resumeUrl = appUrl('customer/status.php?ref=' . rawurlencode((string)$_SESSION['wifi_cp_checkout_reference']));
            }
        }
    }
}

$contactRequired = isset($networkOptions[$selectedNetwork])
    && !empty($networkOptions[$selectedNetwork]['requires_contact']);

$trialUrl = appUrl('customer/trial.php') . ($portalMac !== '' ? '?mac=' . rawurlencode($portalMac) : '');
$logoEndpoint = appUrl('assets/networks/logo.php');
$portalLogoPath = wifiPortalLogoPath($portalSettings);
$pageCss = appUrl('customer/checkout.css?v=11');
?>
<!doctype html>
<html lang="sw">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#071a2d">
    <title>Nunua Wi-Fi | <?= portalEscape($portalSettings['brand_name']) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="<?= portalEscape($pageCss) ?>">
    <link rel="stylesheet" href="<?= portalEscape(appUrl('customer/portal-theme.css?v=11')) ?>">
</head>
<body class="portal-page portal-checkout portal-theme-<?= portalEscape($portalThemeKey) ?>" style="<?= portalEscape($portalThemeStyle) ?>">
<main class="portal-shell">
    <header class="portal-header">
        <div class="brand-mark" aria-hidden="true"><?php if ($portalLogoPath !== ''): ?><img src="<?= portalEscape(appUrl($portalLogoPath)) ?>" alt=""><?php else: ?><i class="fa-solid fa-wifi">Wi</i><?php endif; ?></div>
        <div><strong><?= portalEscape($portalSettings['brand_name']) ?></strong><span>Wi-Fi ya kasi</span></div>
        <span class="online-pill"><i></i> Mtandaoni</span>
    </header>

    <section class="welcome-card">
        <div class="welcome-copy"><span class="eyebrow">KARIBU</span><h1><?= $customerPaymentsEnabled ? 'Nunua Wi-Fi' : 'Tumia voucher' ?></h1><p><?= portalEscape($customerPaymentsEnabled ? $portalSettings['welcome_message'] : 'Malipo kwa simu yamezimwa kwa sasa. Ingiza code ya voucher yako ili uendelee.') ?></p></div>
        <div class="welcome-symbol" aria-hidden="true"><i class="fa-solid fa-wifi"></i></div>
    </section>

    <?php if ($error !== ''): ?><div class="alert alert-error" role="alert"><?= portalEscape($error) ?><?php if ($resumeUrl !== ''): ?><br><a href="<?= portalEscape($resumeUrl) ?>">Angalia ombi linalosubiri</a><?php endif; ?></div><?php endif; ?>
    <?php if ($notice !== ''): ?><div class="alert alert-notice" role="status"><?= portalEscape($notice) ?><?php if ($resumeUrl !== ''): ?><br><a href="<?= portalEscape($resumeUrl) ?>">Angalia hali ya ombi</a><?php endif; ?></div><?php endif; ?>

    <?php if ($maintenanceMode): ?>
        <section class="portal-maintenance-card" role="status">
            <span class="portal-maintenance-icon" aria-hidden="true"><i class="fa-solid fa-screwdriver-wrench"></i></span>
            <div><span class="eyebrow">MATENGENEZO</span><h2>Manunuzi yamesitishwa</h2><p><?= portalEscape($maintenanceMessage) ?></p></div>
        </section>
    <?php endif; ?>

    <?php if (!$maintenanceMode && !$customerPaymentsEnabled): ?>
        <div class="alert alert-notice" role="status">Huduma za malipo kwa simu zimezimwa. Unaweza kuendelea kwa kutumia voucher uliyonayo.</div>
    <?php endif; ?>

    <?php if (!$paymentCheckoutBlocked): ?>
    <form method="post" action="" id="checkoutForm" class="checkout-form">
        <input type="hidden" name="form_action" value="purchase">
        <input type="hidden" name="csrf_token" value="<?= portalEscape((string)$_SESSION['wifi_cp_checkout_csrf']) ?>">
        <input type="hidden" name="mac" value="<?= portalEscape($portalMac) ?>">

        <section class="section-block">
            <div class="section-heading"><div><span class="eyebrow">HATUA 1</span><h2>Chagua mtandao</h2></div></div>
            <?php if ($networkOptions === []): ?>
                <div class="empty-packages">Malipo hayajapatikana kwa sasa.</div>
            <?php else: ?>
                <div class="network-grid">
                    <?php foreach ($networkOptions as $networkChoice => $network): ?>
                        <div class="network-choice">
                            <input type="radio" id="network-<?= portalEscape($networkChoice) ?>" name="network" value="<?= portalEscape($networkChoice) ?>" data-contact="<?= !empty($network['requires_contact']) ? '1' : '0' ?>" <?= $selectedNetwork === $networkChoice ? 'checked' : '' ?> required>
                            <label for="network-<?= portalEscape($networkChoice) ?>">
                                <img src="<?= portalEscape($logoEndpoint . '?file=' . rawurlencode($network['logo'])) ?>" alt="" onerror="this.hidden=true;this.nextElementSibling.hidden=false">
                                <span class="network-fallback <?= portalEscape($network['tone']) ?>" hidden><?= portalEscape($network['fallback']) ?></span>
                                <span class="network-name"><?= portalEscape($network['network_name']) ?></span>
                                <span class="selected-mark" aria-hidden="true">✓</span>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <section class="section-block">
            <div class="section-heading"><div><span class="eyebrow">HATUA 2</span><h2>Weka namba ya simu</h2></div></div>
            <label class="phone-label" for="phone">Namba ya simu</label>
            <input class="phone-input" id="phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="0712 345 678" value="<?= portalEscape($phoneInput) ?>" required>
            <p class="field-help">Ombi la malipo litatumwa kwa USSD.</p>
            <div id="buyerContactFields" class="buyer-contact-fields" <?= $contactRequired ? '' : 'hidden' ?>>
                <label class="phone-label" for="buyer_name">Jina kamili</label>
                <input class="phone-input" id="buyer_name" name="buyer_name" type="text" maxlength="160" autocomplete="name" placeholder="Jina la kwanza na la mwisho" value="<?= portalEscape($buyerName) ?>" <?= $contactRequired ? 'required' : '' ?>>
                <label class="phone-label" for="buyer_email">Barua pepe</label>
                <input class="phone-input" id="buyer_email" name="buyer_email" type="email" maxlength="190" autocomplete="email" placeholder="jina@example.com" value="<?= portalEscape($buyerEmail) ?>" <?= $contactRequired ? 'required' : '' ?>>
                <p class="field-help">Taarifa hizi zinahitajika na aggregator aliyechaguliwa.</p>
            </div>
        </section>

        <section class="section-block packages-section">
            <div class="section-heading"><div><span class="eyebrow">HATUA 3</span><h2>Chagua kifurushi</h2></div></div>
            <?php if ($packages === []): ?>
                <div class="empty-packages">Hakuna kifurushi cha kulipia kwa sasa<?= $trialEnabled ? ', unaweza kujaribu Wi-Fi bure.' : '.' ?></div>
            <?php endif; ?>
            <?php if ($packages !== [] || $trialEnabled): ?>
                <div class="package-list">
                    <?php if ($trialEnabled): ?>
                        <a class="package-card trial-package-choice" href="<?= portalEscape($trialUrl) ?>">
                            <span class="trial-package-icon" aria-hidden="true"><i class="fa-solid fa-gift"></i></span>
                            <span class="trial-package-info"><strong>Jaribu Wi-Fi</strong><small>Bure · <?= portalEscape($trialDurationText) ?> ya majaribio</small></span>
                            <span class="trial-package-action"><b>BURE</b><small>Jaribu sasa <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></small></span>
                        </a>
                    <?php endif; ?>
                    <?php foreach ($packages as $package): ?>
                        <?php
                            $duration = portalDurationLabel((int)($package['duration_minutes'] ?? 0));
                            $speed = portalSpeedLabel((string)($package['speed_limit'] ?? ''));
                            $dataAllowance = !empty($package['data_limit_mb']) ? wifiPackageDataLimitLabel((int)$package['data_limit_mb']) : '';
$details = array_values(array_filter([$duration, $speed, $dataAllowance]));
                            $selected = $selectedPackageId === (string)$package['id'];
                        ?>
                        <label class="package-card package-choice <?= $selected ? 'is-selected' : '' ?>">
                            <input type="radio" name="package_id" value="<?= portalEscape($package['id']) ?>" <?= $selected ? 'checked' : '' ?> required>
                            <span class="package-select-mark" aria-hidden="true"><i class="fa-solid fa-check"></i></span>
                            <span class="package-info"><strong><?= portalEscape($package['name']) ?></strong><span><?= portalEscape($details !== [] ? implode(' · ', $details) : 'Wi-Fi') ?></span></span>
                            <span class="package-price">TZS <?= number_format((float)$package['price'], 0) ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <?php if ($packages !== [] && $networkOptions !== []): ?>
        <button class="checkout-submit" type="submit" onclick="return confirm('Tuma ombi la malipo? Ukithibitisha PIN kwenye simu yako, kiasi ulichochagua kitalipwa.');">
            <span>Lipia kwa simu</span><i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
        </button>
        <p class="secure-hint"><i class="fa-solid fa-lock" aria-hidden="true"></i> PIN unaweka kwenye simu yako</p>
        <?php endif; ?>
    </form>

    <?php endif; ?>

    <details class="voucher-details" <?= is_array($voucherActivation) || !$customerPaymentsEnabled ? 'open' : '' ?>>
        <summary><i class="fa-solid fa-ticket" aria-hidden="true"></i> Nina voucher</summary>
        <form method="post" action="" class="voucher-activate-form" autocomplete="off">
            <input type="hidden" name="form_action" value="activate_voucher">
            <input type="hidden" name="csrf_token" value="<?= portalEscape((string)$_SESSION['wifi_cp_checkout_csrf']) ?>">
            <input type="hidden" name="mac" value="<?= portalEscape($portalMac) ?>">
            <label for="admin-voucher-code">Code ya voucher</label>
            <div class="voucher-activate-controls">
                <input id="admin-voucher-code" name="voucher_code" type="text" maxlength="50" minlength="4" required
                    autocapitalize="characters" spellcheck="false" placeholder="Mfano: WIFI8K2M4P7Q"
                    value="<?= $voucherActivation === null ? portalEscape($voucherInput) : '' ?>">
                <button class="voucher-activate-button" type="submit" onclick="return confirm('Wezesha voucher hii sasa? Muda wake utaanza sasa.');">
                    Wezesha
                </button>
            </div>
        </form>
        <?php if (is_array($voucherActivation)): ?>
            <div class="voucher-activated-result" role="status">
                <i class="fa-solid fa-circle-check" aria-hidden="true"></i>
                <div><strong>Voucher <?= portalEscape($voucherActivation['code']) ?> imewezeshwa</strong>
                    <p>Inaisha: <?= portalEscape($voucherActivation['expires_at'] ?: '—') ?></p>
                </div>
            </div>
        <?php endif; ?>
    </details>
    <section class="portal-contact" aria-label="Mawasiliano">
        <div class="portal-contact-heading"><span class="contact-icon" aria-hidden="true"><i class="fa-solid fa-headset"></i></span><div><strong>Msaada</strong></div></div>
        <div class="portal-contact-actions">
            <?php if ($callPhoneInternational !== ''): ?><a class="contact-action contact-call" href="tel:+<?= portalEscape($callPhoneInternational) ?>"><i class="fa-solid fa-phone" aria-hidden="true"></i><span>Piga simu<small><?= portalEscape($callPhoneDisplay) ?></small></span></a><?php endif; ?>
            <?php if ($whatsappPhoneInternational !== ''): ?><a class="contact-action contact-whatsapp" href="https://wa.me/<?= portalEscape($whatsappPhoneInternational) ?>" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-whatsapp" aria-hidden="true"></i><span>WhatsApp<small><?= portalEscape($whatsappPhoneDisplay) ?></small></span></a><?php endif; ?>
        </div>
    </section>
    <footer class="portal-footer">© <?= date('Y') ?> <?= portalEscape($portalSettings['brand_name']) ?></footer>
</main>
<script>
(() => {
    const contactFields = document.getElementById('buyerContactFields');
    const nameField = document.getElementById('buyer_name');
    const emailField = document.getElementById('buyer_email');
    const networkInputs = document.querySelectorAll('input[name="network"]');
    const updateContactFields = () => {
        const selected = document.querySelector('input[name="network"]:checked');
        const required = selected?.dataset.contact === '1';
        contactFields.hidden = !required;
        nameField.required = required;
        emailField.required = required;
    };
    networkInputs.forEach((input) => input.addEventListener('change', updateContactFields));
    updateContactFields();
})();
</script>
</body>
</html>
