<?php
declare(strict_types=1);

ini_set('session.use_strict_mode', '1');

session_set_cookie_params([
    'httponly' => true,
    'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'samesite' => 'Lax',
]);

session_start();

require_once dirname(__DIR__) . '/includes/clickpesa_checkout.php';
require_once dirname(__DIR__) . '/includes/portal_settings.php';

function statusEscape(mixed $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

$db = $conn;
$portalSettings = wifiPortalSettings($db);
$portalThemeKey = wifiPortalThemeKey($portalSettings['theme_key'] ?? 'ocean');
$portalThemeStyle = wifiPortalThemeStyle($portalSettings);
$portalBrandName = trim((string)($portalSettings['brand_name'] ?? '')) ?: (string)APP_NAME;
$portalLogoPath = wifiPortalLogoPath($portalSettings);

$reference = trim(
    (string)($_GET['ref'] ?? '')
);

$sessionReference = trim(
    (string)(
        $_SESSION['wifi_cp_checkout_reference']
        ?? ''
    )
);

/*
|--------------------------------------------------------------------------
| Prevent users from reading arbitrary payment references
|--------------------------------------------------------------------------
*/
if (
    $reference === ''
    || $sessionReference === ''
    || !hash_equals(
        $sessionReference,
        $reference
    )
) {

    http_response_code(404);

    exit(
        'Ombi halipatikani.'
    );
}

/*
|--------------------------------------------------------------------------
| JSON polling endpoint
|--------------------------------------------------------------------------
*/
if (
    ($_GET['format'] ?? '') === 'json'
) {

    header(
        'Content-Type: application/json; charset=utf-8'
    );

    header(
        'Cache-Control: no-store, no-cache, must-revalidate'
    );

    try {

        $row = wifiCpPaymentRow(
            $db,
            $reference
        );

        if (!$row) {

            http_response_code(404);

            echo json_encode(
                [
                    'ok' => false,
                    'message' => 'Ombi halipatikani.'
                ],
                JSON_UNESCAPED_UNICODE
                | JSON_UNESCAPED_SLASHES
            );

            exit;
        }

        $status = strtoupper(
            (string)(
                $row['status'] ?? ''
            )
        );

        /*
         * Query provider while payment is still open.
         */
        if (
            in_array(
                $status,
                ['PENDING', 'PROCESSING', 'EXPIRED'],
                true
            )
        ) {

            try {

                // The saved payment channel selects the matching provider adapter.
                $providerPayment = wifiPaymentProviderStatus($db, $row);
                $providerStatus = strtoupper(trim((string)($providerPayment['status'] ?? '')));

                /*
                 * Final success verification
                 */
                if (
                    in_array(
                        $providerStatus,
                        ['SUCCESS', 'SETTLED'],
                        true
                    )
                ) {

                    wifiPaymentConfirmNormalized($db, $reference, $providerPayment);

                } elseif (
                    in_array(
                        $providerStatus,
                        [
                            'PENDING',
                            'PROCESSING',
                            'FAILED',
                            'CANCELLED',
                            'CANCELED'
                        ],
                        true
                    )
                ) {

                    wifiCpMarkPendingStatus($db, $reference, $providerStatus);
                }

            } catch (Throwable $providerError) {

                /*
                 * Webhook may arrive later.
                 * Do not mark payment failed just because
                 * the status API temporarily failed.
                 */
                error_log(
                    'Payment status check ' .
                    $reference .
                    ': ' .
                    $providerError->getMessage()
                );
            }

            /*
             * Reload after provider processing.
             */
            $row =
                wifiCpPaymentRow(
                    $db,
                    $reference
                ) ?? $row;

            $status = strtoupper(
                (string)(
                    $row['status'] ?? ''
                )
            );
        }

        $messages = [

            'SUCCESS' =>
                (string)($row['voucher_status'] ?? '') === 'active'
                    ? 'Malipo yamethibitishwa. Voucher imewezeshwa na muda wa kifurushi umeanza sasa.'
                    : 'Malipo yamethibitishwa. Voucher yako iko tayari.',

            'FAILED' =>
                'Malipo hayajakamilika. Unaweza kuanza ombi jipya.',

            'CANCELLED' =>
                'Ombi la malipo limeghairiwa. Unaweza kuanza ombi jipya.',

            'CANCELED' =>
                'Ombi la malipo limeghairiwa. Unaweza kuanza ombi jipya.',

            'EXPIRED' =>
                'Muda wa ombi la malipo umeisha. Kama umelipa, subiri uthibitisho au wasiliana nasi.',

            'PROCESSING' =>
                'Ombi limetumwa. Thibitisha malipo kwenye simu yako.',

            'PENDING' =>
                'Tunasubiri uthibitisho wa malipo. ' .
                'Thibitisha ombi kwenye simu yako.',
        ];

        echo json_encode(
            [
                'ok' => true,

                'status' => $status,

                'message' =>
                    $messages[$status]
                    ?? 'Tunaangalia hali ya malipo.',

                'voucher' =>
                    $status === 'SUCCESS'
                        ? (string)(
                            $row['voucher_code'] ?? ''
                        )
                        : '',

                'voucher_active' =>
                    $status === 'SUCCESS'
                    && (string)($row['voucher_status'] ?? '') === 'active',

                'voucher_expires_at' =>
                    $status === 'SUCCESS'
                        ? (string)($row['voucher_expires_at'] ?? '')
                        : '',

                'package' =>
                    (string)(
                        $row['package_name'] ?? ''
                    ),

                'amount' =>
                    number_format(
                        (float)(
                            $row['amount'] ?? 0
                        ),
                        0
                    ),
            ],
            JSON_UNESCAPED_UNICODE
            | JSON_UNESCAPED_SLASHES
        );

    } catch (Throwable $exception) {

        error_log(
            'Customer payment status ' .
            $reference .
            ': ' .
            $exception->getMessage()
        );

        http_response_code(500);

        echo json_encode(
            [
                'ok' => false,
                'message' =>
                    'Imeshindikana kusoma hali ya malipo. Jaribu tena.'
            ],
            JSON_UNESCAPED_UNICODE
            | JSON_UNESCAPED_SLASHES
        );
    }

    exit;
}

/*
|--------------------------------------------------------------------------
| Initial page load
|--------------------------------------------------------------------------
*/
try {

    $row = wifiCpPaymentRow(
        $db,
        $reference
    );

    if (!$row) {

        http_response_code(404);

        exit(
            'Ombi halipatikani.'
        );
    }

} catch (Throwable $exception) {

    error_log(
        'Customer payment page ' .
        $reference .
        ': ' .
        $exception->getMessage()
    );

    http_response_code(500);

    exit(
        'Imeshindikana kusoma hali ya malipo.'
    );
}

$status = strtoupper(
    (string)(
        $row['status'] ?? ''
    )
);

$labels = [

    'SUCCESS' =>
        (string)($row['voucher_status'] ?? '') === 'active'
            ? 'Malipo yamethibitishwa. Voucher imewezeshwa na muda wa kifurushi umeanza sasa.'
            : 'Malipo yamethibitishwa. Voucher yako iko tayari.',

    'FAILED' =>
        'Malipo hayajakamilika. Unaweza kurudi na kuanza ombi jipya.',

    'CANCELLED' =>
        'Ombi la malipo limeghairiwa. Unaweza kurudi na kuanza ombi jipya.',

    'CANCELED' =>
        'Ombi la malipo limeghairiwa. Unaweza kurudi na kuanza ombi jipya.',

    'EXPIRED' =>
        'Muda wa ombi la malipo umeisha. Kama umelipa, subiri uthibitisho au wasiliana nasi.',

    'PROCESSING' =>
        'Ombi limetumwa. Thibitisha kwenye simu yako na subiri uthibitisho.',

    'PENDING' =>
        'Tunasubiri uthibitisho wa malipo. Angalia ombi la malipo kwenye simu yako.',
];

$label =
    $labels[$status]
    ?? 'Tunaangalia hali ya malipo.';

$hasVoucher =
    $status === 'SUCCESS'
    && trim(
        (string)(
            $row['voucher_code'] ?? ''
        )
    ) !== '';

$voucherExpiry = trim((string)($row['voucher_expires_at'] ?? ''));
$voucherExpiryText = $voucherExpiry !== '' ? $voucherExpiry : 'Hakuna kikomo cha muda';

?>
<!doctype html>
<html lang="sw">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <meta
        name="theme-color"
        content="#10233f"
    >

    <title>
        Hali ya malipo |
        <?= statusEscape($portalBrandName) ?>
    </title>

    <style>

        :root{
            --navy:#10233f;
            --ink:#18243a;
            --muted:#687790;
            --line:#e4eaf2;
            --teal:#079c8f;
            --bg:#f3f7fb;
            --red:#a72f3a
        }

        *{
            box-sizing:border-box
        }

        body{
            margin:0;
            min-height:100vh;
            background:
                radial-gradient(
                    ellipse at 12% 5%,
                    #dff8f2 0,
                    transparent 36%
                ),
                var(--bg);
            font-family:
                Inter,
                ui-sans-serif,
                system-ui,
                -apple-system,
                "Segoe UI",
                sans-serif;
            color:var(--ink)
        }

        .wrap{
            width:min(100% - 28px,620px);
            margin:0 auto;
            padding:32px 0
        }

        .brand{
            display:flex;
            align-items:center;
            gap:11px;
            margin-bottom:22px
        }

        .mark{
            width:44px;
            height:44px;
            border-radius:14px;
            background:var(--navy);
            color:white;
            display:grid;
            place-items:center;
            font-size:20px
        }

        .mark.has-logo{overflow:hidden;background:#fff;border:1px solid var(--line)}
        .mark.has-logo img{display:block;width:100%;height:100%;padding:3px;object-fit:contain}

        .brand small{
            display:block;
            color:var(--muted);
            margin-top:3px
        }

        .card{
            background:#fff;
            border:1px solid var(--line);
            border-radius:21px;
            padding:25px;
            box-shadow:0 15px 38px #18335a0c
        }

        .eyebrow{
            font-size:10px;
            color:var(--teal);
            font-weight:850;
            letter-spacing:.12em;
            text-transform:uppercase
        }

        .card h1{
            font-size:26px;
            letter-spacing:-.04em;
            margin:8px 0
        }

        .copy{
            font-size:14px;
            line-height:1.6;
            color:var(--muted);
            margin:0 0 18px
        }

        .rows{
            border-top:1px solid var(--line);
            margin-top:18px
        }

        .row{
            display:flex;
            justify-content:space-between;
            gap:12px;
            padding:12px 0;
            border-bottom:1px solid var(--line);
            font-size:13px
        }

        .row span{
            color:var(--muted)
        }

        .state{
            margin-top:17px;
            padding:13px 14px;
            border-radius:12px;
            background:#eff8ff;
            color:#24517c;
            font-size:13px;
            line-height:1.55
        }

        .state.success{
            background:#edfaf5;
            color:#166044
        }

        .state.failed{
            background:#fff0f1;
            color:var(--red)
        }

        .voucher{
            margin-top:17px;
            padding:18px;
            border:1px dashed #39a99f;
            border-radius:15px;
            background:#f2fcfa;
            text-align:center
        }

        .voucher small{
            display:block;
            color:var(--muted);
            font-size:11px;
            text-transform:uppercase;
            letter-spacing:.1em;
            font-weight:800
        }

        .voucher strong{
            display:block;
            font-size:28px;
            letter-spacing:.1em;
            margin:8px 0;
            color:#08796f;
            user-select:all
        }

        .btn{
            display:inline-flex;
            justify-content:center;
            align-items:center;
            min-height:46px;
            padding:0 16px;
            margin-top:18px;
            border-radius:12px;
            background:var(--navy);
            color:white;
            text-decoration:none;
            font-size:13px;
            font-weight:800
        }

        .wait{
            display:inline-block;
            width:14px;
            height:14px;
            border:2px solid #9fb3c9;
            border-top-color:#236da3;
            border-radius:50%;
            vertical-align:-2px;
            margin-right:6px;
            animation:spin .8s linear infinite
        }

        @keyframes spin{
            to{
                transform:rotate(360deg)
            }
        }

        .fine{
            font-size:11px;
            color:var(--muted);
            line-height:1.6;
            margin-top:16px
        }

        .footer{
            text-align:center;
            margin-top:18px;
            font-size:11px;
            color:var(--muted)
        }

        @media(max-width:480px){

            .wrap{
                padding-top:20px
            }

            .card{
                padding:20px
            }

            .card h1{
                font-size:23px
            }
        }

    </style>

    <link rel="stylesheet" href="<?= statusEscape(appUrl('customer/portal-theme.css?v=9')) ?>">

</head>

<body class="portal-page portal-status portal-theme-<?= statusEscape($portalThemeKey) ?>" style="<?= statusEscape($portalThemeStyle) ?>">

<main class="wrap">

    <header class="brand">

        <span
            class="mark<?= $portalLogoPath !== '' ? ' has-logo' : '' ?>"
            aria-hidden="true"
        >
            <?php if ($portalLogoPath !== ''): ?><img src="<?= statusEscape(appUrl($portalLogoPath)) ?>" alt=""><?php else: ?>⌁<?php endif; ?>
        </span>

        <div>

            <strong>
                <?= statusEscape($portalBrandName) ?>
            </strong>

            <small>
                Ufuatiliaji wa malipo
            </small>

        </div>

    </header>

    <section class="card">

        <span class="eyebrow">
            MALIPO YA SIMU
        </span>

        <h1>
            Hali ya malipo
        </h1>

        <p class="copy">
            Voucher itatolewa malipo yakithibitishwa.
        </p>

        <div class="rows">

            <div class="row">

                <span>
                    Kifurushi
                </span>

                <strong>
                    <?= statusEscape(
                        $row['package_name']
                        ?: 'Wi-Fi'
                    ) ?>
                </strong>

            </div>

            <div class="row">

                <span>
                    Kiasi
                </span>

                <strong>
                    <?= number_format(
                        (float)$row['amount'],
                        0
                    ) ?>
                    TZS
                </strong>

            </div>

            <div class="row">

                <span>
                    Reference
                </span>

                <strong>
                    <?= statusEscape($reference) ?>
                </strong>

            </div>

        </div>

        <div
            id="payment-state"
            class="state <?= $status === 'SUCCESS'
                ? 'success'
                : (
                    in_array(
                        $status,
                        ['FAILED', 'CANCELLED', 'CANCELED', 'EXPIRED'],
                        true
                    )
                        ? 'failed'
                        : ''
                ) ?>"
            aria-live="polite"
        >

            <?php if (
                in_array(
                    $status,
                    ['PENDING', 'PROCESSING'],
                    true
                )
            ): ?>

                <span
                    class="wait"
                    aria-hidden="true"
                ></span>

            <?php endif; ?>

            <?= statusEscape($label) ?>

        </div>

        <div
            id="voucher-box"
            class="voucher"
            <?= $hasVoucher ? '' : 'hidden' ?>
        >

            <small>
                Voucher yako ya intaneti
            </small>

            <strong id="voucher-code">
                <?= $hasVoucher
                    ? statusEscape($row['voucher_code'])
                    : '' ?>
            </strong>

            <span id="voucher-expiry-note">
                <?php if ((string)($row['voucher_status'] ?? '') === 'active'): ?>
                    Voucher imewezeshwa. Muda umeanza kuhesabika sasa.
                    Inaisha: <?= statusEscape($voucherExpiryText) ?>.
                <?php else: ?>
                    Tumia code hii kuunganisha Wi-Fi.
                <?php endif; ?>
            </span>

        </div>

        <a
            class="btn"
            href="<?= statusEscape(
                appUrl('customer/checkout.php')
            ) ?>"
        >
            Rudi kwenye vifurushi
        </a>

        <p class="fine">
            Umethibitisha PIN? Subiri ujumbe wa matokeo. PIN haiombwi hapa.
        </p>

    </section>

    <footer class="footer">
        <?= statusEscape($portalBrandName) ?>
    </footer>

</main>

<script>
(() => {

    const reference =
        <?= json_encode(
            $reference,
            JSON_HEX_TAG
            | JSON_HEX_AMP
            | JSON_HEX_APOS
            | JSON_HEX_QUOT
        ) ?>;

    let delay = 5000;
    let checks = 0;

    const state =
        document.getElementById(
            'payment-state'
        );

    const box =
        document.getElementById(
            'voucher-box'
        );

    const code =
        document.getElementById(
            'voucher-code'
        );

    const voucherExpiryNote =
        document.getElementById(
            'voucher-expiry-note'
        );

    const terminal = [
        'SUCCESS',
        'FAILED',
        'CANCELLED',
        'CANCELED',
        'EXPIRED'
    ];

    async function refresh() {

        if (checks >= 36) {
            return;
        }

        checks++;

        try {

            const url =
                new URL(
                    window.location.href
                );

            url.searchParams.set(
                'format',
                'json'
            );

            url.searchParams.set(
                'ref',
                reference
            );

            const response =
                await fetch(
                    url.toString(),
                    {
                        headers: {
                            'Accept':
                                'application/json'
                        },

                        cache: 'no-store',

                        credentials:
                            'same-origin'
                    }
                );

            const data =
                await response.json();

            if (data.ok) {

                state.textContent =
                    data.message;

                state.classList.toggle(
                    'success',
                    data.status === 'SUCCESS'
                );

                state.classList.toggle(
                    'failed',
                    [
                        'FAILED',
                        'CANCELLED',
                        'CANCELED',
                        'EXPIRED'
                    ].includes(
                        data.status
                    )
                );

                if (
                    data.status === 'SUCCESS'
                    && data.voucher
                ) {

                    code.textContent =
                        data.voucher;

                    if (voucherExpiryNote && data.voucher_active) {
                        voucherExpiryNote.textContent =
                            'Voucher imewezeshwa. Muda umeanza kuhesabika sasa. Inaisha: '
                            + (data.voucher_expires_at || 'Hakuna kikomo cha muda')
                            + '.';
                    }

                    box.hidden = false;
                }

                if (
                    terminal.includes(
                        data.status
                    )
                ) {
                    return;
                }
            }

        } catch (_) {

            /*
             * Temporary network/API error.
             * Try again later.
             */
        }

        delay =
            Math.min(
                Math.round(
                    delay * 1.35
                ),
                30000
            );

        window.setTimeout(
            refresh,
            delay
        );
    }

    const initialStatus =
        <?= json_encode($status) ?>;

    if (
        !terminal.includes(initialStatus)
        || initialStatus === 'EXPIRED'
    ) {

        window.setTimeout(
            refresh,
            delay
        );
    }

})();
</script>


<style>
.payment-progress{margin-top:17px;padding:16px;border:1px solid var(--line,#dce5ed);border-radius:14px;background:#fff}
.payment-progress[hidden]{display:none!important}
.payment-progress h2{margin:0 0 14px;font-size:15px;color:var(--navy,#153052)}
.payment-progress ol{list-style:none;margin:0;padding:0}
.payment-progress li{position:relative;display:grid;grid-template-columns:26px 1fr;gap:10px;padding:0 0 15px}
.payment-progress li:last-child{padding-bottom:0}
.payment-progress li:not(:last-child):before{content:'';position:absolute;left:12px;top:26px;bottom:-1px;width:2px;background:var(--line,#dce5ed)}
.payment-progress .pp-mark{position:relative;z-index:1;display:grid;place-items:center;width:25px;height:25px;border-radius:50%;background:#edf1f5;color:var(--muted,#66758a);font-size:12px;font-weight:800}
.payment-progress li.done .pp-mark{background:#e5f7ef;color:#138354}
.payment-progress li.active .pp-mark{background:#e8f2ff;color:#236da3;box-shadow:0 0 0 3px #e8f2ff}
.payment-progress .pp-title{font-size:13px;line-height:1.4;font-weight:800;color:var(--navy,#153052)}
.payment-progress .pp-note{margin-top:2px;font-size:12px;line-height:1.45;color:var(--muted,#66758a)}
</style>
<script>
(function(){
  var state=document.getElementById('payment-state');
  var voucherBox=document.getElementById('voucher-box');
  if(!state)return;
  var progress=document.createElement('section');
  progress.id='payment-progress';
  progress.className='payment-progress';
  progress.hidden=true;
  progress.setAttribute('aria-live','polite');
  progress.innerHTML='<h2>Maendeleo ya malipo</h2><ol><li data-step="1"><span class="pp-mark">1</span><div><div class="pp-title">Ombi la USSD limetumwa</div><div class="pp-note">Ombi la malipo limetumwa kwenye simu yako.</div></div></li><li data-step="2"><span class="pp-mark">2</span><div><div class="pp-title">Thibitisha kwenye simu yako</div><div class="pp-note">Weka PIN kwenye ujumbe wa USSD ili kukamilisha malipo. Usiandike PIN kwenye ukurasa huu.</div></div></li><li data-step="3"><span class="pp-mark">3</span><div><div class="pp-title">Pata voucher</div><div class="pp-note">Voucher itaonekana hapa malipo yakithibitishwa.</div></div></li></ol>';
  state.parentNode.insertBefore(progress,state);
  function sync(){
    var text=(state.textContent||'').toLowerCase();
    var success=state.classList.contains('success')||/malipo yamethibitishwa|payment confirmed|payment successful/.test(text);
    var failed=state.classList.contains('failed')||/failed|cancelled|canceled|expired|imeshindwa|imekatishwa|muda umeisha/.test(text);
    var waiting=!!state.querySelector('.wait')||/tunasubiri|ombi limetumwa|processing|pending|thibitisha malipo/.test(text);
    var code=document.getElementById('voucher-code');
    var voucherReady=!!(voucherBox&&code&&code.textContent.trim()&&!voucherBox.hidden&&voucherBox.getClientRects().length);
    progress.hidden=failed||!(waiting||success||voucherReady);
    var items=progress.querySelectorAll('li[data-step]');
    var done=[waiting||success,success, voucherReady];
    var active=[false,waiting,success&&!voucherReady];
    for(var i=0;i<items.length;i++){
      items[i].classList.toggle('done',!!done[i]);
      items[i].classList.toggle('active',!!active[i]&&!done[i]);
      items[i].querySelector('.pp-mark').textContent=done[i]?'✓':String(i+1);
    }
    if(success){items[1].querySelector('.pp-note').textContent='Malipo yamethibitishwa.';}
    if(voucherReady){items[2].querySelector('.pp-note').textContent='Voucher yako iko tayari hapa chini.';}
  }
  var observer=new MutationObserver(sync);
  observer.observe(state,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['class']});
  if(voucherBox)observer.observe(voucherBox,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['class','style','hidden']});
  sync();
})();
</script>
</body>
</html>

<style>
.payment-progress .pp-note{display:none!important}
.payment-progress li.active .pp-mark{font-size:0!important;color:transparent!important;border:2px solid #bdd1de;border-top-color:#236da3;background:transparent!important;box-shadow:none!important;animation:payment-progress-spin .8s linear infinite}
@keyframes payment-progress-spin{to{transform:rotate(360deg)}}
</style>
<script>
(function(){var progress=document.getElementById('payment-progress');if(progress){var heading=progress.querySelector('h2');if(heading)heading.textContent='Malipo yanaendelea';}})();
</script>
