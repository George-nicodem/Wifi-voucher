<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/admin_auth.php';
require_once __DIR__ . '/../../../includes/portal_settings.php';
requireAdminLogin();

global $conn;

$defaults = [
    'brand_name' => (string)APP_NAME,
    'welcome_message' => 'Lipa kwa simu yako na upokee voucher baada ya malipo kuthibitishwa.',
    'call_phone' => '0675409835',
    'whatsapp_phone' => '0749509813',
    'maintenance_enabled' => 0,
    'maintenance_message' => 'Manunuzi mapya yamesitishwa kwa muda kwa ajili ya matengenezo. Tafadhali jaribu tena baadaye.',
    'logo_path' => '',
    'theme_key' => 'ocean',
    'theme_accent_color' => '#08aebe',
    'theme_background_color' => '#f3f7fb',
    'theme_surface_color' => '#ffffff',
    'theme_text_color' => '#14283d',
    'theme_border_color' => '#e1e9f1',
    'theme_button_color' => '#e87537',
];
$portalSettings = $defaults;
$errors = [];
$success = '';
$tables = [];
$portalSettingsTableReady = false;
$tableResult = $conn->query('SHOW TABLES');
if ($tableResult instanceof mysqli_result) {
    while ($row = $tableResult->fetch_row()) {
        $tables[(string)$row[0]] = true;
    }
    $tableResult->free();
}
$portalSettingsTableReady = isset($tables['portal_settings']);
$portalSettingsColumns = [];
if ($portalSettingsTableReady) {
    $portalColumnResult = $conn->query('SHOW COLUMNS FROM portal_settings');
    if ($portalColumnResult instanceof mysqli_result) {
        while ($column = $portalColumnResult->fetch_assoc()) {
            $portalSettingsColumns[(string)($column['Field'] ?? '')] = true;
        }
        $portalColumnResult->free();
    }
}
$maintenanceSettingsReady = isset($portalSettingsColumns['maintenance_enabled'], $portalSettingsColumns['maintenance_message'], $portalSettingsColumns['logo_path']);
$portalThemeReady = isset($portalSettingsColumns['theme_key']);
$portalThemeOptions = wifiPortalThemeCatalog();
$portalPreviewPalettes = [
    'ocean' => ['background' => '#f3f7fb', 'surface' => '#ffffff', 'text' => '#14283d', 'border' => '#e1e9f1', 'accent' => '#08aebe', 'button' => '#e87537'],
    'midnight' => ['background' => '#071827', 'surface' => '#10263a', 'text' => '#eaf4fb', 'border' => '#29445b', 'accent' => '#22c7d5', 'button' => '#17aebd'],
    'sunset' => ['background' => '#fff7f0', 'surface' => '#fffdfa', 'text' => '#432d35', 'border' => '#f0ddd3', 'accent' => '#e87537', 'button' => '#e87551'],
    'forest' => ['background' => '#f2f8f2', 'surface' => '#ffffff', 'text' => '#193b31', 'border' => '#dce9df', 'accent' => '#2d9b66', 'button' => '#299b68'],
];
$portalThemeColorOptions = wifiPortalThemeColorCatalog();
$portalThemeColorsReady = count(array_filter(
    array_keys($portalThemeColorOptions),
    static fn(string $column): bool => isset($portalSettingsColumns[$column])
)) === count($portalThemeColorOptions);
$paymentMethodsTableReady = isset($tables['payment_methods']);
$paymentMethodsIconReady = false;
if ($paymentMethodsTableReady) {
    $methodColumns = $conn->query('SHOW COLUMNS FROM payment_methods');
    if ($methodColumns instanceof mysqli_result) {
        while ($column = $methodColumns->fetch_assoc()) {
            if ((string)($column['Field'] ?? '') === 'icon') {
                $paymentMethodsIconReady = true;
                break;
            }
        }
        $methodColumns->free();
    }
}
$backupPolicyTableReady = isset($tables['backup_policy']);
$adminSecurity = adminSecurityPolicy();
$adminSecurityPolicyReady = (bool)$adminSecurity['configured'];
$backupPolicy = [
    'enabled' => 0,
    'frequency' => 'daily',
    'run_time' => '02:00',
    'run_day' => 1,
    'retention_count' => 7,
    'last_run_at' => '',
];
if ($backupPolicyTableReady) {
    $backupPolicyResult = $conn->query('SELECT enabled, frequency, run_time, run_day, retention_count, last_run_at FROM backup_policy WHERE id = 1 LIMIT 1');
    if ($backupPolicyResult instanceof mysqli_result) {
        $backupPolicyRow = $backupPolicyResult->fetch_assoc() ?: [];
        foreach (array_keys($backupPolicy) as $key) {
            if (array_key_exists($key, $backupPolicyRow)) $backupPolicy[$key] = $backupPolicyRow[$key];
        }
        $backupPolicyResult->free();
        $backupPolicy['run_time'] = substr((string)$backupPolicy['run_time'], 0, 5);
    }
}

if ($portalSettingsTableReady) {
    $selectFields = 'brand_name, welcome_message, call_phone, whatsapp_phone';
    if ($maintenanceSettingsReady) {
        $selectFields .= ', maintenance_enabled, maintenance_message, logo_path';
    }
    if ($portalThemeReady) {
        $selectFields .= ', theme_key';
    }
    if ($portalThemeColorsReady) {
        $selectFields .= ', ' . implode(', ', array_keys($portalThemeColorOptions));
    }
    $result = $conn->query('SELECT ' . $selectFields . ' FROM portal_settings WHERE id = 1 LIMIT 1');
    if ($result instanceof mysqli_result) {
        $row = $result->fetch_assoc() ?: [];
        $result->free();
        foreach (array_keys($defaults) as $key) {
            if (array_key_exists($key, $row)) {
                $portalSettings[$key] = (string)$row[$key];
            }
        }
    }
}
$portalSettings['theme_key'] = wifiPortalThemeKey($portalSettings['theme_key'] ?? 'ocean');
foreach ($portalThemeColorOptions as $colorKey => $colorOption) {
    $colorValue = $portalSettings[$colorKey] ?? $colorOption['default'];
    $portalSettings[$colorKey] = is_string($colorValue) && preg_match('/^#[0-9a-f]{6}$/iD', $colorValue) === 1
        ? strtolower($colorValue)
        : $colorOption['default'];
}
$portalPreviewTheme = $portalSettings['theme_key'];
$portalPreviewInitialColors = $portalPreviewPalettes[$portalPreviewTheme] ?? $portalPreviewPalettes['ocean'];
if ($portalPreviewTheme === 'ocean') {
    $portalPreviewInitialColors = [
        'background' => $portalSettings['theme_background_color'],
        'surface' => $portalSettings['theme_surface_color'],
        'text' => $portalSettings['theme_text_color'],
        'border' => $portalSettings['theme_border_color'],
        'accent' => $portalSettings['theme_accent_color'],
        'button' => $portalSettings['theme_button_color'],
    ];
}

function settingsNormalizeTzPhone(string $phone): ?string
{
    $phone = preg_replace('/[\s().-]+/', '', trim($phone)) ?? '';
    if (preg_match('/^0[67][0-9]{8}$/D', $phone) === 1) {
        return $phone;
    }
    if (preg_match('/^\+?255[67][0-9]{8}$/D', $phone) === 1) {
        $international = ltrim($phone, '+');
        return '0' . substr($international, 3);
    }
    return null;
}

function settingsTextLength(string $value): int
{
    $length = preg_match_all('/./us', $value);
    return $length === false ? strlen($value) : $length;
}

function settingsIsManagedNetworkLogo(string $path): bool
{
    return preg_match('~^custom/network-[1-9][0-9]*-[a-f0-9]{16}\.(?:png|jpg|webp)$~D', $path) === 1;
}

function settingsDeleteManagedNetworkLogo(string $path, string $projectRoot): void
{
    if (!settingsIsManagedNetworkLogo($path)) {
        return;
    }
    $filename = basename($path);
    $absolutePath = $projectRoot . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'networks'
        . DIRECTORY_SEPARATOR . 'custom' . DIRECTORY_SEPARATOR . $filename;
    if (is_file($absolutePath)) {
        @unlink($absolutePath);
    }
}

function settingsDefaultNetworkLogo(array $method): string
{
    $identity = strtolower(implode(' ', [
        (string)($method['provider_code'] ?? ''),
        (string)($method['name'] ?? ''),
        (string)($method['display_name'] ?? ''),
    ]));
    if (str_contains($identity, 'mpesa') || str_contains($identity, 'm-pesa') || str_contains($identity, 'vodacom')) return 'M-pesa.svg';
    if (str_contains($identity, 'airtel')) return 'airtel-money.svg';
    if (str_contains($identity, 'tigo') || str_contains($identity, 'mixx') || str_contains($identity, 'yas')) return 'mixx-by-yas.svg';
    if (str_contains($identity, 'halotel') || str_contains($identity, 'halopesa')) return 'halopesa.svg';
    if (str_contains($identity, 'ttcl')) return 'TTCL.svg';
    return '';
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    requireAdminPostWithCsrf();

    if (in_array(($_POST['settings_action'] ?? ''), ['save_network_logo', 'reset_network_logo'], true)) {
        $networkAction = (string)$_POST['settings_action'];
        if (!$paymentMethodsTableReady || !$paymentMethodsIconReady) {
            $errors[] = 'Network logos require the payment_methods table and its icon field.';
        } else {
            $networkId = filter_var($_POST['network_id'] ?? null, FILTER_VALIDATE_INT);
            if ($networkId === false || $networkId < 1) {
                $errors[] = 'The selected network is invalid.';
            } else {
                $lookup = $conn->prepare('SELECT id, name, display_name, provider_code, icon FROM payment_methods WHERE id = ? LIMIT 1');
                if (!$lookup) {
                    $errors[] = 'Network details could not be read.';
                } else {
                    $lookup->bind_param('i', $networkId);
                    $lookup->execute();
                    $networkRow = $lookup->get_result()->fetch_assoc() ?: null;
                    $lookup->close();
                    if (!$networkRow) {
                        $errors[] = 'That network is no longer available.';
                    } elseif ($networkAction === 'reset_network_logo') {
                        $update = $conn->prepare("UPDATE payment_methods SET icon = '' WHERE id = ?");
                        if (!$update) {
                            $errors[] = 'The logo could not be restored.';
                        } else {
                            $update->bind_param('i', $networkId);
                            if ($update->execute()) {
                                settingsDeleteManagedNetworkLogo((string)($networkRow['icon'] ?? ''), dirname(__DIR__, 3));
                                $success = 'Logo for ' . (string)$networkRow['display_name'] . ' has been restored to the default logo.';
                                logAdminSecurityEvent('PAYMENT_NETWORK_LOGO_RESET', 'Administrator reset a payment network logo. Network ID: ' . $networkId);
                            } else {
                                $errors[] = 'The logo could not be restored.';
                                logDatabaseError($conn, 'Resetting payment network logo');
                            }
                            $update->close();
                        }
                    } else {
                        $upload = is_array($_FILES['network_logo'] ?? null) ? $_FILES['network_logo'] : null;
                        $uploadError = (int)($upload['error'] ?? UPLOAD_ERR_NO_FILE);
                        if ($uploadError !== UPLOAD_ERR_OK) {
                            $errors[] = $uploadError === UPLOAD_ERR_NO_FILE
                                ? 'Select a logo image first.'
                                : 'The logo could not be uploaded. Please select the image again.';
                        } elseif ((int)($upload['size'] ?? 0) < 1 || (int)$upload['size'] > 1024 * 1024) {
                            $errors[] = 'The logo must be an image no larger than 1 MB.';
                        } else {
                            $temporaryPath = (string)($upload['tmp_name'] ?? '');
                            $imageInfo = $temporaryPath !== '' ? @getimagesize($temporaryPath) : false;
                            $mime = $temporaryPath !== '' && class_exists('finfo')
                                ? (new finfo(FILEINFO_MIME_TYPE))->file($temporaryPath)
                                : false;
                            $imageMime = is_array($imageInfo) && isset($imageInfo[2])
                                ? image_type_to_mime_type((int)$imageInfo[2])
                                : '';
                            $allowedTypes = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp'];
                            if (!is_uploaded_file($temporaryPath) || !is_string($mime) || !isset($allowedTypes[$mime])
                                || $imageMime !== $mime || !is_array($imageInfo)
                                || (int)$imageInfo[0] < 1 || (int)$imageInfo[1] < 1
                                || (int)$imageInfo[0] > 2048 || (int)$imageInfo[1] > 2048) {
                                $errors[] = 'Use a valid PNG, JPG, or WebP image no larger than 2,048 pixels wide or tall. SVG hazikubaliwi.';
                            } else {
                                $projectRoot = dirname(__DIR__, 3);
                                $logoDirectory = $projectRoot . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'networks'
                                    . DIRECTORY_SEPARATOR . 'custom';
                                if (!is_dir($logoDirectory) && !mkdir($logoDirectory, 0755, true) && !is_dir($logoDirectory)) {
                                    $errors[] = 'The logo storage folder could not be created. Check permissions for assets/networks.';
                                } else {
                                    $extension = $allowedTypes[$mime];
                                    $filename = 'network-' . $networkId . '-' . bin2hex(random_bytes(8)) . '.' . $extension;
                                    $newAbsolutePath = $logoDirectory . DIRECTORY_SEPARATOR . $filename;
                                    if (!move_uploaded_file($temporaryPath, $newAbsolutePath)) {
                                        $errors[] = 'The logo could not be saved. Check permissions for assets/networks/custom.';
                                    } else {
                                        $newRelativePath = 'custom/' . $filename;
                                        $update = $conn->prepare('UPDATE payment_methods SET icon = ? WHERE id = ?');
                                        if (!$update) {
                                            @unlink($newAbsolutePath);
                                            $errors[] = 'The logo was uploaded but could not be linked to the network.';
                                        } else {
                                            $update->bind_param('si', $newRelativePath, $networkId);
                                            if ($update->execute()) {
                                                settingsDeleteManagedNetworkLogo((string)($networkRow['icon'] ?? ''), $projectRoot);
                                                $success = 'Logo for ' . (string)$networkRow['display_name'] . ' has been saved.';
                                                logAdminSecurityEvent('PAYMENT_NETWORK_LOGO_UPDATED', 'Administrator updated a payment network logo. Network ID: ' . $networkId);
                                            } else {
                                                @unlink($newAbsolutePath);
                                                $errors[] = 'The logo could not be linked to the network.';
                                                logDatabaseError($conn, 'Saving payment network logo');
                                            }
                                            $update->close();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    } elseif (($_POST['settings_action'] ?? '') === 'save_backup_policy') {
        if (!$backupPolicyTableReady) {
            $errors[] = 'The backup schedule cannot be saved until admin/database/backup_policy.sql has been run on the system database.';
        } else {
            $backupEnabled = isset($_POST['backup_enabled']) ? 1 : 0;
            $backupFrequency = is_string($_POST['backup_frequency'] ?? null) ? $_POST['backup_frequency'] : '';
            $backupRunTime = is_string($_POST['backup_run_time'] ?? null) ? $_POST['backup_run_time'] : '';
            $backupRunDay = filter_var($_POST['backup_run_day'] ?? null, FILTER_VALIDATE_INT);
            $backupRetention = filter_var($_POST['backup_retention_count'] ?? null, FILTER_VALIDATE_INT);
            if (!in_array($backupFrequency, ['daily', 'weekly'], true)) $errors[] = 'Choose a daily or weekly schedule.';
            if (preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $backupRunTime) !== 1) $errors[] = 'Enter a valid backup time.';
            if ($backupRunDay === false || $backupRunDay < 1 || $backupRunDay > 7) $errors[] = 'Choose a valid day of the week.';
            if ($backupRetention === false || $backupRetention < 1 || $backupRetention > 30) $errors[] = 'Keep between 1 and 30 backups.';

            $backupPolicy = [
                'enabled' => $backupEnabled,
                'frequency' => $backupFrequency,
                'run_time' => $backupRunTime,
                'run_day' => $backupRunDay === false ? 1 : $backupRunDay,
                'retention_count' => $backupRetention === false ? 7 : $backupRetention,
                'last_run_at' => (string)$backupPolicy['last_run_at'],
            ];
            if (!$errors) {
                $stmt = $conn->prepare("INSERT INTO backup_policy (id, enabled, frequency, run_time, run_day, retention_count)
                    VALUES (1, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE enabled = VALUES(enabled), frequency = VALUES(frequency),
                        run_time = VALUES(run_time), run_day = VALUES(run_day), retention_count = VALUES(retention_count)");
                if (!$stmt) {
                    $errors[] = 'The backup schedule could not be saved.';
                } else {
                    $timeForDatabase = $backupRunTime . ':00';
                    $backupRunDayValue = (int)$backupPolicy['run_day'];
                    $backupRetentionValue = (int)$backupPolicy['retention_count'];
                    $stmt->bind_param('issii', $backupEnabled, $backupFrequency, $timeForDatabase, $backupRunDayValue, $backupRetentionValue);
                    if ($stmt->execute()) {
                        $success = 'The backup policy has been saved. The schedule will start after you configure a Scheduled Task or Cron Job on the server.';
                        logAdminSecurityEvent('BACKUP_POLICY_UPDATED', 'Administrator updated scheduled backup policy.');
                    } else {
                        $errors[] = 'The backup schedule could not be saved.';
                        logDatabaseError($conn, 'Saving scheduled backup policy');
                    }
                    $stmt->close();
                }
            }
        }
    } elseif (($_POST['settings_action'] ?? '') === 'save_admin_security') {
        if (!$adminSecurityPolicyReady) {
            $errors[] = 'Administrator security settings require admin/database/admin_security_policy.sql to be run on the system database.';
        } else {
            $sessionTimeout = filter_var($_POST['session_timeout_minutes'] ?? null, FILTER_VALIDATE_INT);
            $maxLoginAttempts = filter_var($_POST['max_login_attempts'] ?? null, FILTER_VALIDATE_INT);
            $lockoutMinutes = filter_var($_POST['lockout_minutes'] ?? null, FILTER_VALIDATE_INT);
            if ($sessionTimeout === false || $sessionTimeout < 5 || $sessionTimeout > 480) $errors[] = 'Session timeout must be between 5 and 480 minutes.';
            if ($maxLoginAttempts === false || $maxLoginAttempts < 3 || $maxLoginAttempts > 20) $errors[] = 'The sign-in attempt limit must be between 3 and 20.';
            if ($lockoutMinutes === false || $lockoutMinutes < 1 || $lockoutMinutes > 1440) $errors[] = 'Lockout must be between 1 and 1,440 minutes.';
            if (!$errors) {
                $stmt = $conn->prepare('INSERT INTO admin_security_policy (id, session_timeout_minutes, max_login_attempts, lockout_minutes)
                    VALUES (1, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE session_timeout_minutes = VALUES(session_timeout_minutes),
                        max_login_attempts = VALUES(max_login_attempts), lockout_minutes = VALUES(lockout_minutes)');
                if (!$stmt) {
                    $errors[] = 'The administrator security policy could not be saved.';
                } else {
                    $sessionTimeoutValue = (int)$sessionTimeout;
                    $maxLoginAttemptsValue = (int)$maxLoginAttempts;
                    $lockoutMinutesValue = (int)$lockoutMinutes;
                    $stmt->bind_param('iii', $sessionTimeoutValue, $maxLoginAttemptsValue, $lockoutMinutesValue);
                    if ($stmt->execute()) {
                        $adminSecurity = [
                            'session_timeout_minutes' => $sessionTimeoutValue,
                            'max_login_attempts' => $maxLoginAttemptsValue,
                            'lockout_minutes' => $lockoutMinutesValue,
                            'configured' => true,
                            'login_protection_enabled' => $adminSecurity['login_protection_enabled'],
                        ];
                        $success = 'Session and sign-in protection settings have been saved.';
                        logAdminSecurityEvent('ADMIN_SECURITY_POLICY_UPDATED', 'Administrator updated admin session and login protection policy.');
                    } else {
                        $errors[] = 'The administrator security policy could not be saved.';
                        logDatabaseError($conn, 'Saving admin security policy');
                    }
                    $stmt->close();
                }
            }
        }
    } elseif (!$portalSettingsTableReady) {
        $errors[] = 'The settings table is missing. Run the SQL in admin/database/portal_settings.sql, then reopen Settings.';
    } else {
        $brandName = is_string($_POST['brand_name'] ?? null) ? trim($_POST['brand_name']) : '';
        $welcomeMessage = is_string($_POST['welcome_message'] ?? null) ? trim($_POST['welcome_message']) : '';
        $callPhoneInput = is_string($_POST['call_phone'] ?? null) ? trim($_POST['call_phone']) : '';
        $whatsappPhoneInput = is_string($_POST['whatsapp_phone'] ?? null) ? trim($_POST['whatsapp_phone']) : '';
        $maintenanceEnabled = $maintenanceSettingsReady && isset($_POST['maintenance_enabled']) ? 1 : 0;
        $maintenanceMessage = $maintenanceSettingsReady && is_string($_POST['maintenance_message'] ?? null)
            ? trim($_POST['maintenance_message'])
            : (string)$portalSettings['maintenance_message'];
        $submittedTheme = $_POST['portal_theme'] ?? null;
        $themeKey = $portalThemeReady && is_string($submittedTheme)
            ? wifiPortalThemeKey($submittedTheme)
            : (string)$portalSettings['theme_key'];
        if ($portalThemeReady && (!is_string($submittedTheme) || !array_key_exists($submittedTheme, $portalThemeOptions))) {
            $errors[] = 'Choose one of the available customer portal themes.';
        }
        $submittedThemeColors = [];
        foreach ($portalThemeColorOptions as $colorKey => $colorOption) {
            $colorValue = $_POST[$colorKey] ?? null;
            if ($portalThemeColorsReady && (!is_string($colorValue) || preg_match('/^#[0-9a-f]{6}$/iD', $colorValue) !== 1)) {
                $errors[] = 'Choose valid colors for the white theme.';
                $submittedThemeColors[$colorKey] = (string)$portalSettings[$colorKey];
            } else {
                $submittedThemeColors[$colorKey] = $portalThemeColorsReady
                    ? strtolower((string)$colorValue)
                    : (string)$portalSettings[$colorKey];
            }
        }
        $logoPath = (string)$portalSettings['logo_path'];
        $oldLogoPath = $logoPath;
        $newLogoDestination = null;

        if ($brandName === '' || settingsTextLength($brandName) > 100) {
            $errors[] = 'The business name must be between 1 and 100 characters.';
        }
        if ($welcomeMessage === '' || settingsTextLength($welcomeMessage) > 200) {
            $errors[] = 'The welcome message must be between 1 and 200 characters.';
        }

        $callPhone = $callPhoneInput === '' ? '' : settingsNormalizeTzPhone($callPhoneInput);
        $whatsappPhone = $whatsappPhoneInput === '' ? '' : settingsNormalizeTzPhone($whatsappPhoneInput);
        if ($callPhone === null) {
            $errors[] = 'The phone number is invalid. Use 0XXXXXXXXX or +255XXXXXXXXX.';
        }
        if ($whatsappPhone === null) {
            $errors[] = 'The WhatsApp number is invalid. Use 0XXXXXXXXX or +255XXXXXXXXX.';
        }
        if ($maintenanceSettingsReady && (settingsTextLength($maintenanceMessage) < 5 || settingsTextLength($maintenanceMessage) > 250)) {
            $errors[] = 'The maintenance message must be between 5 and 250 characters.';
        }

        $logoUpload = $_FILES['portal_logo'] ?? null;
        $logoUploadRequested = is_array($logoUpload) && (int)($logoUpload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
        if ($logoUploadRequested) {
            if (!$maintenanceSettingsReady) {
                $errors[] = 'Run the portal settings SQL first to enable logo storage.';
            } elseif ((int)($logoUpload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
                $errors[] = 'The logo could not be uploaded. Please select the image again.';
            } elseif ((int)($logoUpload['size'] ?? 0) < 1 || (int)$logoUpload['size'] > 1024 * 1024) {
                $errors[] = 'The logo must be an image no larger than 1 MB.';
            } else {
                $tmpName = (string)($logoUpload['tmp_name'] ?? '');
                $imageInfo = $tmpName !== '' ? @getimagesize($tmpName) : false;
                $mime = $tmpName !== '' && class_exists('finfo')
                    ? (new finfo(FILEINFO_MIME_TYPE))->file($tmpName)
                    : false;
                $allowedLogoTypes = [
                    'image/png' => 'png',
                    'image/jpeg' => 'jpg',
                    'image/webp' => 'webp',
                ];
                $imageMime = is_array($imageInfo) && isset($imageInfo[2]) ? image_type_to_mime_type((int)$imageInfo[2]) : '';
                if (!is_string($mime) || !isset($allowedLogoTypes[$mime]) || $imageMime !== $mime
                    || !is_array($imageInfo) || (int)$imageInfo[0] < 1 || (int)$imageInfo[1] < 1
                    || (int)$imageInfo[0] > 4096 || (int)$imageInfo[1] > 4096) {
                    $errors[] = 'Use a valid PNG, JPG, or WebP image; SVG and other formats are not allowed.';
                } else {
                    $uploadDirectory = dirname(__DIR__, 3) . DIRECTORY_SEPARATOR . 'customer' . DIRECTORY_SEPARATOR . 'uploads';
                    if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0755, true) && !is_dir($uploadDirectory)) {
                        $errors[] = 'The logo storage folder could not be created.';
                    } else {
                        $fileName = 'portal-logo-' . bin2hex(random_bytes(8)) . '.' . $allowedLogoTypes[$mime];
                        $newLogoDestination = $uploadDirectory . DIRECTORY_SEPARATOR . $fileName;
                        if (!move_uploaded_file($tmpName, $newLogoDestination)) {
                            $newLogoDestination = null;
                            $errors[] = 'The logo could not be saved. Check permissions for customer/uploads.';
                        } else {
                            $logoPath = 'customer/uploads/' . $fileName;
                        }
                    }
                }
            }
        }

        if (!$errors) {
            $fieldList = ['brand_name', 'welcome_message', 'call_phone', 'whatsapp_phone'];
            $fieldValues = [$brandName, $welcomeMessage, $callPhone, $whatsappPhone];
            $fieldTypes = 'ssss';
            if ($maintenanceSettingsReady) {
                $fieldList = array_merge($fieldList, ['maintenance_enabled', 'maintenance_message', 'logo_path']);
                $fieldValues[] = $maintenanceEnabled;
                $fieldValues[] = $maintenanceMessage;
                $fieldValues[] = $logoPath;
                $fieldTypes .= 'iss';
            }
            if ($portalThemeReady) {
                $fieldList[] = 'theme_key';
                $fieldValues[] = $themeKey;
                $fieldTypes .= 's';
            }
            if ($portalThemeColorsReady) {
                foreach (array_keys($portalThemeColorOptions) as $colorKey) {
                    $fieldList[] = $colorKey;
                    $fieldValues[] = $submittedThemeColors[$colorKey];
                    $fieldTypes .= 's';
                }
            }
            $insertFields = implode(', ', array_merge(['id'], $fieldList));
            $placeholders = implode(', ', array_merge(['1'], array_fill(0, count($fieldList), '?')));
            $updates = implode(', ', array_map(static fn(string $field): string => $field . ' = VALUES(' . $field . ')', $fieldList));
            $saveSql = 'INSERT INTO portal_settings (' . $insertFields . ') VALUES (' . $placeholders . ')
                ON DUPLICATE KEY UPDATE ' . $updates;
            $stmt = $conn->prepare($saveSql);
            if (!$stmt) {
                $errors[] = 'The settings could not be saved. Check the database settings and try again.';
            } else {
                $bindArguments = [$fieldTypes];
                foreach ($fieldValues as $fieldIndex => &$fieldValue) {
                    $bindArguments[] = &$fieldValue;
                }
                $bound = call_user_func_array([$stmt, 'bind_param'], $bindArguments);
                unset($fieldValue);
                if (!$bound) {
                    $errors[] = 'The settings could not be locked for saving.';
                }
                if (!$errors && $stmt->execute()) {
                    $portalSettings = [
                        'brand_name' => $brandName,
                        'welcome_message' => $welcomeMessage,
                        'call_phone' => $callPhone,
                        'whatsapp_phone' => $whatsappPhone,
                        'maintenance_enabled' => $maintenanceEnabled,
                        'maintenance_message' => $maintenanceMessage,
                        'logo_path' => $logoPath,
                        'theme_key' => $themeKey,
                    ];
                    foreach ($submittedThemeColors as $colorKey => $colorValue) {
                        $portalSettings[$colorKey] = $colorValue;
                    }
                    if ($newLogoDestination !== null && preg_match('/^customer\/uploads\/portal-logo-[a-f0-9]{16}\.(?:png|jpe?g|webp)$/iD', $oldLogoPath) === 1) {
                        $oldLogoAbsolute = dirname(__DIR__, 3) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $oldLogoPath);
                        if (is_file($oldLogoAbsolute)) {
                            @unlink($oldLogoAbsolute);
                        }
                    }
                    $success = 'Business and portal settings have been saved.';
                    logAdminSecurityEvent('PORTAL_SETTINGS_UPDATED', 'Administrator updated customer portal settings.');
                } elseif (!$errors) {
                    $errors[] = 'The settings could not be saved. Check the database settings and try again.';
                    logDatabaseError($conn, 'Saving customer portal settings');
                }
                $stmt->close();
            }
            if ($errors && $newLogoDestination !== null && is_file($newLogoDestination)) {
                @unlink($newLogoDestination);
            }
        } else {
            $portalSettings = [
                'brand_name' => $brandName,
                'welcome_message' => $welcomeMessage,
                'call_phone' => $callPhoneInput,
                'whatsapp_phone' => $whatsappPhoneInput,
                'maintenance_enabled' => $maintenanceEnabled,
                'maintenance_message' => $maintenanceMessage,
                'logo_path' => $logoPath,
                'theme_key' => $themeKey,
            ];
            foreach ($submittedThemeColors as $colorKey => $colorValue) {
                $portalSettings[$colorKey] = $colorValue;
            }
        }
    }
}

$knownTables = [
    'admin_users', 'packages', 'vouchers', 'payments', 'transactions',
    'payment_methods', 'payment_channels', 'payment_routing',
    'network_devices', 'network_controllers', 'network_gateway_settings', 'network_deployments',
    'network_sites', 'trial_settings', 'wifi_network_profiles', 'security_logs',
    'portal_settings', 'backup_policy', 'admin_security_policy', 'admin_login_throttle',
];
$tableCounts = [];
foreach ($knownTables as $tableName) {
    if (!isset($tables[$tableName])) {
        $tableCounts[$tableName] = null;
        continue;
    }
    $countResult = $conn->query('SELECT COUNT(*) AS total FROM `' . $tableName . '`');
    $countRow = $countResult instanceof mysqli_result ? $countResult->fetch_assoc() : null;
    if ($countResult instanceof mysqli_result) {
        $countResult->free();
    }
    $tableCounts[$tableName] = $countRow ? (int)$countRow['total'] : null;
}

$requiredTables = ['admin_users', 'packages', 'vouchers', 'payments'];
$missingRequiredTables = array_values(array_filter(
    $requiredTables,
    static fn(string $table): bool => !isset($tables[$table])
));
$channelSummary = ['total' => 0, 'enabled' => 0, 'ready' => 0];
if (isset($tables['payment_channels'])) {
    $channelResult = $conn->query("SELECT COUNT(*) AS total,
        COALESCE(SUM(status = 'enabled'), 0) AS enabled,
        COALESCE(SUM(status = 'enabled' AND configured = 1), 0) AS ready
        FROM payment_channels");
    if ($channelResult instanceof mysqli_result) {
        $channelRow = $channelResult->fetch_assoc() ?: [];
        foreach (array_keys($channelSummary) as $key) {
            $channelSummary[$key] = (int)($channelRow[$key] ?? 0);
        }
        $channelResult->free();
    }
}
$paymentMethodSummary = ['total' => 0, 'enabled' => 0];
if (isset($tables['payment_methods'])) {
    $paymentMethodResult = $conn->query("SELECT COUNT(*) AS total,
        COALESCE(SUM(status = 'enabled'), 0) AS enabled
        FROM payment_methods");
    if ($paymentMethodResult instanceof mysqli_result) {
        $paymentMethodRow = $paymentMethodResult->fetch_assoc() ?: [];
        foreach (array_keys($paymentMethodSummary) as $key) {
            $paymentMethodSummary[$key] = (int)($paymentMethodRow[$key] ?? 0);
        }
        $paymentMethodResult->free();
    }
}
$networkMethods = [];
if ($paymentMethodsTableReady && $paymentMethodsIconReady) {
    $networkMethodResult = $conn->query('SELECT id, name, display_name, provider_code, icon, status FROM payment_methods ORDER BY COALESCE(display_order, 0) ASC, display_name ASC, id ASC');
    if ($networkMethodResult instanceof mysqli_result) {
        while ($networkMethod = $networkMethodResult->fetch_assoc()) {
            $networkMethods[] = $networkMethod;
        }
        $networkMethodResult->free();
    }
}
$portalPreviewNetworks = array_values(array_filter(
    $networkMethods,
    static fn(array $method): bool => strtolower((string)($method['status'] ?? '')) === 'enabled'
));
$portalPreviewPackages = [];
if (isset($tables['packages'])) {
    $previewPackageResult = $conn->query("SELECT name, price, duration_minutes, speed_limit FROM packages WHERE LOWER(status) IN ('active', 'enabled', '1') ORDER BY price ASC, id ASC LIMIT 4");
    if ($previewPackageResult instanceof mysqli_result) {
        while ($previewPackage = $previewPackageResult->fetch_assoc()) {
            $portalPreviewPackages[] = $previewPackage;
        }
        $previewPackageResult->free();
    }
}
$portalPreviewTrialEnabled = false;
$portalPreviewTrialMinutes = 5;
if (isset($tables['trial_settings'])) {
    $previewTrialResult = $conn->query('SELECT enabled, duration_minutes FROM trial_settings WHERE id = 1 LIMIT 1');
    if ($previewTrialResult instanceof mysqli_result) {
        $previewTrial = $previewTrialResult->fetch_assoc() ?: [];
        $previewTrialResult->free();
        $portalPreviewTrialEnabled = (int)($previewTrial['enabled'] ?? 0) === 1;
        $portalPreviewTrialMinutes = max(1, min(60, (int)($previewTrial['duration_minutes'] ?? 5)));
    }
}
$encryptionKey = (string)($_ENV['APP_ENCRYPTION_KEY'] ?? '');
$encryptionKeyReady = preg_match('/^[a-fA-F0-9]{64}$/D', $encryptionKey) === 1;
$environment = defined('APP_ENV') ? (string)APP_ENV : 'unknown';
$isDevelopment = strtolower($environment) === 'development';
$hasHttps = stripos((string)APP_URL, 'https://') === 0;
$adminSessionTimeoutMinutes = (int)$adminSecurity['session_timeout_minutes'];
$logoPathForDisplay = preg_match('/^customer\/uploads\/portal-logo-[a-f0-9]{16}\.(?:png|jpe?g|webp)$/iD', (string)$portalSettings['logo_path']) === 1
    ? (string)$portalSettings['logo_path']
    : '';

$cssUrl = appUrl('admin/modules/settings/settings.css?v=15');
echo '<link rel="stylesheet" href="' . e($cssUrl) . '">';
?>

<main class="system-settings-page">
    <header class="settings-hero">
        <div>
            <span class="settings-eyebrow">SYSTEM ADMINISTRATION</span>
            <h1>System Settings</h1>
            <p>Open a section to manage the portal, trials, backups, and secure system settings.</p>
        </div>
        <a class="settings-back" href="<?= e(appUrl('admin/dashboard.php?page=dashboard')) ?>"><i class="fa-solid fa-arrow-left"></i> Dashboard</a>
    </header>

    <?php if ($errors): ?>
        <div class="settings-alert is-error" role="alert"><i class="fa-solid fa-triangle-exclamation"></i><div><?php foreach ($errors as $error): ?><p><?= e($error) ?></p><?php endforeach; ?></div></div>
    <?php elseif ($success !== ''): ?>
        <div class="settings-alert is-success" role="status"><i class="fa-solid fa-circle-check"></i><span><?= e($success) ?></span></div>
    <?php endif; ?>
    <?php if ($missingRequiredTables): ?>
        <div class="settings-alert is-error" role="alert"><i class="fa-solid fa-database"></i><span>These required tables are missing: <?= e(implode(', ', $missingRequiredTables)) ?>. Check the database before using the affected modules.</span></div>
    <?php endif; ?>

    <section class="settings-status-grid" aria-label="System Status">
        <article class="settings-status-card"><span class="settings-status-icon is-green"><i class="fa-solid fa-database"></i></span><div><small>Database</small><strong><?= $conn instanceof mysqli && !$conn->connect_errno ? 'Connected' : 'Not connected' ?></strong><p><?= number_format(count($tables)) ?> tables found</p></div></article>
        <article class="settings-status-card"><span class="settings-status-icon is-blue"><i class="fa-solid fa-money-bill-transfer"></i></span><div><small>Payment aggregators</small><strong><?= number_format($channelSummary['ready']) ?> ready</strong><p><?= number_format($channelSummary['enabled']) ?> enabled / <?= number_format($channelSummary['total']) ?> total</p></div></article>
        <article class="settings-status-card"><span class="settings-status-icon is-teal"><i class="fa-solid fa-mobile-screen-button"></i></span><div><small>Mobile Networks</small><strong><?= number_format($paymentMethodSummary['enabled']) ?> enabled</strong><p><?= number_format($paymentMethodSummary['total']) ?> total shown on checkout</p></div></article>
        <article class="settings-status-card"><span class="settings-status-icon is-purple"><i class="fa-solid fa-globe"></i></span><div><small>Customer portal</small><strong><?= $maintenanceSettingsReady ? ((int)$portalSettings['maintenance_enabled'] === 1 ? 'Maintenance' : 'Operational') : ($portalSettingsTableReady ? 'Basic settings' : 'Setup required') ?></strong><p><?= $maintenanceSettingsReady ? 'Branding, contact details, and sales' : 'Additional settings require SQL setup' ?></p></div></article>
        <article class="settings-status-card"><span class="settings-status-icon <?= $encryptionKeyReady && $hasHttps ? 'is-green' : 'is-orange' ?>"><i class="fa-solid fa-shield-halved"></i></span><div><small>Basic Security</small><strong><?= $encryptionKeyReady && $hasHttps ? 'Ready' : 'Action Required' ?></strong><p><?= !$encryptionKeyReady ? 'Check the encryption key in .env' : (!$hasHttps ? 'HTTPS is not enabled' : 'HTTPS and the encryption key are configured') ?></p></div></article>
    </section>

    <section class="settings-shortcuts" aria-labelledby="settings-shortcuts-title">
        <header class="settings-shortcuts-heading">
            <div><h2 id="settings-shortcuts-title">Quick Settings</h2><p>Open a section to change or review its settings.</p></div>
            <i class="fa-solid fa-sliders" aria-hidden="true"></i>
        </header>
        <div class="settings-shortcut-grid">
            <a class="settings-shortcut-card" href="#portal-settings" data-settings-detail="portal-settings">
                <span class="settings-shortcut-icon is-blue"><i class="fa-solid fa-store" aria-hidden="true"></i></span>
                <span class="settings-shortcut-copy"><strong>Portal and Maintenance</strong><small>Name, contact details, and sales availability</small></span>
                <i class="fa-solid fa-chevron-right settings-shortcut-arrow" aria-hidden="true"></i>
            </a>
            <a class="settings-shortcut-card" href="<?= e(appUrl('admin/dashboard.php?page=trial_settings')) ?>">
                <span class="settings-shortcut-icon is-teal"><i class="fa-solid fa-stopwatch" aria-hidden="true"></i></span>
                <span class="settings-shortcut-copy"><strong>Trial Wi-Fi</strong><small>Duration and cooldown period</small></span>
                <i class="fa-solid fa-chevron-right settings-shortcut-arrow" aria-hidden="true"></i>
            </a>
            <a class="settings-shortcut-card" href="<?= e(appUrl('admin/dashboard.php?page=backup')) ?>">
                <span class="settings-shortcut-icon is-orange"><i class="fa-solid fa-database" aria-hidden="true"></i></span>
                <span class="settings-shortcut-copy"><strong>Backup and Restore</strong><small>Create, download, or restore backups</small></span>
                <i class="fa-solid fa-chevron-right settings-shortcut-arrow" aria-hidden="true"></i>
            </a>
            <a class="settings-shortcut-card" href="<?= e(appUrl('admin/dashboard.php?page=payment_methods')) ?>">
                <span class="settings-shortcut-icon is-teal"><i class="fa-solid fa-mobile-screen-button" aria-hidden="true"></i></span>
                <span class="settings-shortcut-copy"><strong>Mobile Networks</strong><small>Add, edit, enable, or disable a checkout network</small></span>
                <i class="fa-solid fa-chevron-right settings-shortcut-arrow" aria-hidden="true"></i>
            </a>
            <a class="settings-shortcut-card" href="#network-logos" data-settings-detail="network-logos">
                <span class="settings-shortcut-icon is-purple"><i class="fa-solid fa-image" aria-hidden="true"></i></span>
                <span class="settings-shortcut-copy"><strong>Network Logos</strong><small>Upload or restore images shown to customers</small></span>
                <i class="fa-solid fa-chevron-right settings-shortcut-arrow" aria-hidden="true"></i>
            </a>
            <a class="settings-shortcut-card" href="#backup-policy" data-settings-detail="backup-policy">
                <span class="settings-shortcut-icon is-orange"><i class="fa-solid fa-calendar-check" aria-hidden="true"></i></span>
                <span class="settings-shortcut-copy"><strong>Backup Schedule and Retention</strong><small>Choose the schedule and number of backups to keep</small></span>
                <i class="fa-solid fa-chevron-right settings-shortcut-arrow" aria-hidden="true"></i>
            </a>
            <a class="settings-shortcut-card" href="#settings-security" data-settings-detail="settings-security">
                <span class="settings-shortcut-icon is-purple"><i class="fa-solid fa-user-shield" aria-hidden="true"></i></span>
                <span class="settings-shortcut-copy"><strong>Administrator Security</strong><small>Session duration and sign-in protection</small></span>
                <i class="fa-solid fa-chevron-right settings-shortcut-arrow" aria-hidden="true"></i>
            </a>
            <a class="settings-shortcut-card" href="#settings-network" data-settings-detail="settings-network">
                <span class="settings-shortcut-icon is-green"><i class="fa-solid fa-wifi" aria-hidden="true"></i></span>
                <span class="settings-shortcut-copy"><strong>Wi-Fi Security</strong><small>Device limits and router idle timeout</small></span>
                <i class="fa-solid fa-chevron-right settings-shortcut-arrow" aria-hidden="true"></i>
            </a>
            <a class="settings-shortcut-card" href="#settings-env" data-settings-detail="settings-env">
                <span class="settings-shortcut-icon is-purple"><i class="fa-solid fa-gears" aria-hidden="true"></i></span>
                <span class="settings-shortcut-copy"><strong>Application Configuration</strong><small>Timezone, currency, and secure settings</small></span>
                <i class="fa-solid fa-chevron-right settings-shortcut-arrow" aria-hidden="true"></i>
            </a>
            <a class="settings-shortcut-card" href="#settings-tables" data-settings-detail="settings-tables">
                <span class="settings-shortcut-icon is-green"><i class="fa-solid fa-table-list" aria-hidden="true"></i></span>
                <span class="settings-shortcut-copy"><strong>Database Check</strong><small>Key tables and record counts</small></span>
                <i class="fa-solid fa-chevron-right settings-shortcut-arrow" aria-hidden="true"></i>
            </a>
        </div>
    </section>

    <?php if (!$portalSettingsTableReady): ?>
        <div class="settings-alert is-warning" role="alert"><i class="fa-solid fa-circle-info"></i><span>The portal settings form will be available after you run <code>admin/database/portal_settings.sql</code> on the system database.</span></div>
    <?php endif; ?>
    <?php if ($portalSettingsTableReady && !$maintenanceSettingsReady): ?>
        <div class="settings-alert is-warning" role="alert"><i class="fa-solid fa-screwdriver-wrench"></i><span>Maintenance and logos require additional portal fields. Run <code>admin/database/portal_settings.sql</code> on the system database; existing data will be preserved.</span></div>
    <?php endif; ?>

    <details class="settings-section-card settings-profile" id="portal-settings" open>
        <summary>
            <span class="settings-section-icon is-blue"><i class="fa-solid fa-store"></i></span>
            <span><strong>Customer Portal and Maintenance</strong><small>Name, contact details, logo, and maintenance</small></span>
            <i class="fa-solid fa-chevron-down" aria-hidden="true"></i>
        </summary>
        <div class="settings-profile-content">
        <div class="portal-settings-layout">
        <form method="post" enctype="multipart/form-data" action="<?= e(appUrl('admin/dashboard.php?page=settings')) ?>" class="settings-form portal-settings-form">
            <?= csrfField() ?>
            <div class="settings-field"><label for="portal_brand_name">Business / Wi-Fi name</label><input id="portal_brand_name" name="brand_name" type="text" maxlength="100" value="<?= e($portalSettings['brand_name']) ?>" required <?= !$portalSettingsTableReady ? 'disabled' : '' ?>><small>Shown on checkout, the payment status page, and the trial page.</small></div>
            <div class="settings-field settings-field-wide"><label for="portal_welcome_message">Short welcome message</label><textarea id="portal_welcome_message" name="welcome_message" rows="3" maxlength="200" required <?= !$portalSettingsTableReady ? 'disabled' : '' ?>><?= e($portalSettings['welcome_message']) ?></textarea><small>This message appears on customer checkout.</small></div>
            <div class="settings-field"><label for="portal_call_phone">Phone number</label><input id="portal_call_phone" name="call_phone" type="tel" inputmode="tel" maxlength="20" placeholder="0675409835" value="<?= e($portalSettings['call_phone']) ?>" <?= !$portalSettingsTableReady ? 'disabled' : '' ?>><small>Leave blank to hide the call button.</small></div>
            <div class="settings-field"><label for="portal_whatsapp_phone">WhatsApp number</label><input id="portal_whatsapp_phone" name="whatsapp_phone" type="tel" inputmode="tel" maxlength="20" placeholder="0749509813" value="<?= e($portalSettings['whatsapp_phone']) ?>" <?= !$portalSettingsTableReady ? 'disabled' : '' ?>><small>Use a 10-digit Tanzanian number or +255.</small></div>
            <fieldset class="settings-field settings-field-wide portal-theme-field" <?= !$portalThemeReady ? 'disabled' : '' ?>>
                <legend>Customer portal theme</legend>
                <p class="portal-theme-help">Choose a look for checkout, payment status, and the trial page.</p>
                <div class="portal-theme-grid">
                    <?php foreach ($portalThemeOptions as $themeKey => $themeOption): ?>
                        <label class="portal-theme-option<?= $portalSettings['theme_key'] === $themeKey ? ' is-selected' : '' ?>">
                            <input type="radio" name="portal_theme" value="<?= e($themeKey) ?>" data-preview-background="<?= e($portalPreviewPalettes[$themeKey]['background']) ?>" data-preview-surface="<?= e($portalPreviewPalettes[$themeKey]['surface']) ?>" data-preview-text="<?= e($portalPreviewPalettes[$themeKey]['text']) ?>" data-preview-border="<?= e($portalPreviewPalettes[$themeKey]['border']) ?>" data-preview-accent="<?= e($portalPreviewPalettes[$themeKey]['accent']) ?>" data-preview-button="<?= e($portalPreviewPalettes[$themeKey]['button']) ?>" <?= $portalSettings['theme_key'] === $themeKey ? 'checked' : '' ?> <?= !$portalThemeReady ? 'disabled' : '' ?>>
                            <span class="portal-theme-preview" aria-hidden="true" style="--theme-bg:<?= e($themeOption['swatches'][0]) ?>;--theme-accent:<?= e($themeOption['swatches'][1]) ?>;--theme-ink:<?= e($themeOption['swatches'][2]) ?>">
                                <span class="portal-theme-preview-brand"></span><span class="portal-theme-preview-card"><i></i><i></i><b></b></span>
                            </span>
                            <span class="portal-theme-copy"><strong><?= e($themeOption['name']) ?></strong><small><?= e($themeOption['description']) ?></small></span>
                            <span class="portal-theme-check" aria-hidden="true"><i class="fa-solid fa-check"></i></span>
                        </label>
                    <?php endforeach; ?>
                </div>
                <?php if (!$portalThemeReady): ?><small>Run <code>admin/database/portal_settings.sql</code> to enable theme selection.</small><?php endif; ?>
            </fieldset>
            <fieldset class="settings-field settings-field-wide portal-color-field" <?= !$portalThemeColorsReady ? 'disabled' : '' ?>>
                <legend>Customize Ocean theme colors</legend>
                <p>These colors apply when Ocean is selected. Choose a theme above, adjust the colors, then save.</p>
                <div class="portal-color-grid">
                    <?php foreach ($portalThemeColorOptions as $colorKey => $colorOption): ?>
                        <label class="portal-color-control" for="<?= e($colorKey) ?>">
                            <span><?= e($colorOption['name']) ?></span>
                            <input id="<?= e($colorKey) ?>" name="<?= e($colorKey) ?>" type="color" value="<?= e($portalSettings[$colorKey]) ?>" <?= !$portalThemeColorsReady ? 'disabled' : '' ?>>
                        </label>
                    <?php endforeach; ?>
                </div>
                <?php if (!$portalThemeColorsReady): ?><small>Run <code>admin/database/portal_settings.sql</code> to enable custom theme colors.</small><?php endif; ?>
            </fieldset>


            <div class="settings-field settings-field-wide settings-logo-control">
                <label for="portal_logo">Customer portal logo</label>
                <div class="settings-logo-row">
                    <?php if ($logoPathForDisplay !== ''): ?><img class="settings-logo-preview" src="<?= e(appUrl($logoPathForDisplay)) ?>" alt="Current logo">
                    <?php else: ?><span class="settings-logo-placeholder"><i class="fa-solid fa-image" aria-hidden="true"></i></span><?php endif; ?>
                    <div><input id="portal_logo" name="portal_logo" type="file" accept="image/png,image/jpeg,image/webp" <?= !$maintenanceSettingsReady ? 'disabled' : '' ?>><small>Use PNG, JPG, or WebP image files up to 1 MB. SVG is not allowed for security reasons.</small></div>
                </div>
            </div>
            <div class="settings-field settings-field-wide settings-maintenance-control">
                <div class="settings-maintenance-toggle-row">
                    <div><label for="portal_maintenance_enabled">Customer portal maintenance mode</label><small>Prevents new purchases and trial requests. Pending payments and voucher activation continue to work.</small></div>
                    <label class="settings-toggle" for="portal_maintenance_enabled"><input id="portal_maintenance_enabled" name="maintenance_enabled" type="checkbox" value="1" <?= (int)$portalSettings['maintenance_enabled'] === 1 ? 'checked' : '' ?> <?= !$maintenanceSettingsReady ? 'disabled' : '' ?>><span aria-hidden="true"></span></label>
                </div>
                <label for="portal_maintenance_message">Maintenance message</label>
                <textarea id="portal_maintenance_message" name="maintenance_message" rows="2" maxlength="250" <?= !$maintenanceSettingsReady ? 'disabled' : '' ?>><?= e($portalSettings['maintenance_message']) ?></textarea>
                <small>This message appears on checkout and the trial page. It must be between 5 and 250 characters.</small>
            </div>
            <div class="settings-form-footer"><span><i class="fa-solid fa-lock"></i> POST requests, administrator authorization, and CSRF are protected.</span><button type="submit" <?= !$portalSettingsTableReady ? 'disabled' : '' ?>><i class="fa-solid fa-floppy-disk"></i> Save Details</button></div>
        </form>
        <aside class="portal-live-preview" aria-labelledby="portal-preview-title">
            <div class="portal-preview-heading">
                <div><span class="portal-preview-kicker"><i class="fa-solid fa-eye" aria-hidden="true"></i> CUSTOMER VIEW</span><h3 id="portal-preview-title">Live portal preview</h3></div>
                <span class="portal-preview-unsaved">Live preview</span>
            </div>
            <p class="portal-preview-help">This shows customers’ checkout page. Theme, colors, business name, welcome message, and logo update as you edit. Save Details to publish the changes.</p>
            <div class="portal-preview-canvas" id="portalLivePreview" data-theme="<?= e($portalPreviewTheme) ?>" style="--preview-background:<?= e($portalPreviewInitialColors['background']) ?>;--preview-surface:<?= e($portalPreviewInitialColors['surface']) ?>;--preview-text:<?= e($portalPreviewInitialColors['text']) ?>;--preview-border:<?= e($portalPreviewInitialColors['border']) ?>;--preview-accent:<?= e($portalPreviewInitialColors['accent']) ?>;--preview-button:<?= e($portalPreviewInitialColors['button']) ?>">
                <div class="portal-preview-browser"><span><i></i><i></i><i></i></span><small>Customer portal</small><i class="fa-solid fa-wifi" aria-hidden="true"></i></div>
                <div class="portal-preview-page">
                    <div class="portal-preview-brand">
                        <?php if ($logoPathForDisplay !== ''): ?>
                            <img id="portalPreviewLogo" src="<?= e(appUrl($logoPathForDisplay)) ?>" alt="" onerror="this.hidden=true;document.getElementById('portalPreviewLogoFallback').hidden=false">
                            <span class="portal-preview-brand-mark" id="portalPreviewLogoFallback" hidden><i class="fa-solid fa-wifi" aria-hidden="true"></i></span>
                        <?php else: ?>
                            <img id="portalPreviewLogo" src="" alt="" hidden>
                            <span class="portal-preview-brand-mark" id="portalPreviewLogoFallback"><i class="fa-solid fa-wifi" aria-hidden="true"></i></span>
                        <?php endif; ?>
                        <div><strong id="portalPreviewName"><?= e($portalSettings['brand_name']) ?></strong><small>Wi-Fi ya kasi</small></div>
                        <span class="portal-preview-online"><i></i> Mtandaoni</span>
                    </div>
                    <section class="portal-preview-welcome">
                        <div><span class="portal-preview-eyebrow">KARIBU</span><strong>Nunua Wi-Fi</strong><p id="portalPreviewWelcome"><?= e($portalSettings['welcome_message']) ?></p></div>
                        <i class="fa-solid fa-wifi" aria-hidden="true"></i>
                    </section>
                    <section class="portal-preview-section">
                        <div class="portal-preview-step"><span>1</span><div><strong>Chagua mtandao</strong><small>Chagua mtandao wa simu wa kulipia</small></div></div>
                        <div class="portal-preview-networks">
                            <?php foreach (array_slice($portalPreviewNetworks, 0, 4) as $previewNetwork): ?>
                                <?php
                                    $previewNetworkName = trim((string)($previewNetwork['display_name'] ?? '')) ?: (string)($previewNetwork['name'] ?? 'Network');
                                    $previewNetworkIcon = trim((string)($previewNetwork['icon'] ?? ''));
                                    if (!settingsIsManagedNetworkLogo($previewNetworkIcon)) {
                                        $previewNetworkIcon = settingsDefaultNetworkLogo($previewNetwork);
                                    }
                                    $previewNetworkLogoUrl = $previewNetworkIcon !== ''
                                        ? appUrl('assets/networks/logo.php?file=' . rawurlencode($previewNetworkIcon))
                                        : '';
                                ?>
                                <button type="button" class="portal-preview-network<?= count($portalPreviewNetworks) > 0 && (int)($previewNetwork['id'] ?? 0) === (int)($portalPreviewNetworks[0]['id'] ?? 0) ? ' is-selected' : '' ?>" aria-pressed="<?= count($portalPreviewNetworks) > 0 && (int)($previewNetwork['id'] ?? 0) === (int)($portalPreviewNetworks[0]['id'] ?? 0) ? 'true' : 'false' ?>">
                                    <?php if ($previewNetworkLogoUrl !== ''): ?><img src="<?= e($previewNetworkLogoUrl) ?>" alt="" onerror="this.hidden=true;this.nextElementSibling.hidden=false"><span class="portal-preview-network-fallback" hidden><?= e(strtoupper(substr($previewNetworkName, 0, 1))) ?></span>
                                    <?php else: ?><span class="portal-preview-network-fallback"><?= e(strtoupper(substr($previewNetworkName, 0, 1))) ?></span><?php endif; ?>
                                    <strong><?= e($previewNetworkName) ?></strong>
                                </button>
                            <?php endforeach; ?>
                            <?php if ($portalPreviewNetworks === []): ?>
                                <div class="portal-preview-empty">No enabled mobile networks yet.</div>
                            <?php endif; ?>
                        </div>
                    </section>
                    <section class="portal-preview-section portal-preview-phone-section">
                        <div class="portal-preview-step"><span>2</span><div><strong>Weka namba ya simu</strong><small>Utapokea ombi la malipo kwa simu</small></div></div>
                        <label class="portal-preview-phone"><i class="fa-solid fa-phone" aria-hidden="true"></i><small>0712 345 678</small></label>
                    </section>
                    <section class="portal-preview-section">
                        <div class="portal-preview-step"><span>3</span><div><strong>Chagua kifurushi</strong><small><?= $portalPreviewTrialEnabled ? 'Jaribio na vifurushi vinavyopatikana' : 'Vifurushi vinavyopatikana' ?></small></div></div>
                        <div class="portal-preview-packages">
                            <?php if ($portalPreviewTrialEnabled): ?><article class="portal-preview-package portal-preview-trial"><span><strong>Jaribu Wi-Fi</strong><small>Bure · <?= e((string)$portalPreviewTrialMinutes) ?> min</small></span><b>BURE</b></article><?php endif; ?>
                            <?php foreach ($portalPreviewPackages as $packageIndex => $previewPackage): ?>
                                <?php
                                    $previewMinutes = max(0, (int)($previewPackage['duration_minutes'] ?? 0));
                                    if ($previewMinutes >= 1440 && $previewMinutes % 1440 === 0) {
                                        $previewDuration = (string)($previewMinutes / 1440) . ' day' . ($previewMinutes === 1440 ? '' : 's');
                                    } elseif ($previewMinutes >= 60 && $previewMinutes % 60 === 0) {
                                        $previewDuration = (string)($previewMinutes / 60) . ' hour' . ($previewMinutes === 60 ? '' : 's');
                                    } else {
                                        $previewDuration = $previewMinutes . ' min';
                                    }
                                    $previewSpeed = trim((string)($previewPackage['speed_limit'] ?? ''));
                                ?>
                                <article class="portal-preview-package<?= $packageIndex === 0 ? ' is-selected' : '' ?>"><span><strong><?= e((string)$previewPackage['name']) ?></strong><small><?= e($previewDuration) ?><?= $previewSpeed !== '' ? ' · ' . e($previewSpeed) : '' ?></small></span><b>TZS <?= number_format((float)$previewPackage['price'], 0) ?></b></article>
                            <?php endforeach; ?>
                            <?php if ($portalPreviewPackages === []): ?><div class="portal-preview-empty">No active packages yet.</div><?php endif; ?>
                        </div>
                    </section>
                    <div class="portal-preview-action"><span>Lipia kwa simu</span><i class="fa-solid fa-arrow-right" aria-hidden="true"></i></div>
                    <small class="portal-preview-foot"><i class="fa-solid fa-lock" aria-hidden="true"></i> PIN utaweka kwenye simu yako</small>
                </div>
            </div>
        </aside>

        </div>
        </div>
    </details>

    <details class="settings-section-card settings-network-logos" id="network-logos" <?= ($errors || $success !== '') && (($_POST['settings_action'] ?? '') === 'save_network_logo' || ($_POST['settings_action'] ?? '') === 'reset_network_logo') ? 'open' : '' ?>>
        <summary><span class="settings-section-icon is-purple"><i class="fa-solid fa-image"></i></span><span><strong>Mobile Network Logos</strong><small>Choose images for Airtel, M-Pesa, Mixx, HaloPesa, and other networks</small></span><i class="fa-solid fa-chevron-down" aria-hidden="true"></i></summary>
        <div class="settings-network-logo-content">
            <p class="settings-network-logo-note">Logos uploaded here appear on customer checkout. Use PNG, JPG, or WebP files up to 1 MB; SVG is not allowed.</p>
            <?php if (!$paymentMethodsTableReady): ?>
                <div class="settings-alert is-warning" role="alert"><i class="fa-solid fa-circle-info"></i><span>Table <code>payment_methods</code> is missing. Add mobile networks first.</span></div>
            <?php elseif (!$paymentMethodsIconReady): ?>
                <div class="settings-alert is-warning" role="alert"><i class="fa-solid fa-circle-info"></i><span>The <code>icon</code> field is missing from payment_methods. Review the existing schema; no SQL is needed if you already use the Payment Methods module.</span></div>
            <?php elseif ($networkMethods === []): ?>
                <div class="settings-alert is-warning" role="status"><i class="fa-solid fa-mobile-screen-button"></i><span>No networks have been added yet. Add a network from <a href="<?= e(appUrl('admin/dashboard.php?page=payment_methods')) ?>">Payment Methods</a>, then return here to upload logos.</span></div>
            <?php else: ?>
                <div class="settings-network-logo-grid">
                    <?php foreach ($networkMethods as $networkMethod): ?>
                        <?php
                            $networkId = (int)$networkMethod['id'];
                            $networkName = trim((string)($networkMethod['display_name'] ?? '')) ?: (string)($networkMethod['name'] ?? 'Network');
                            $storedIcon = trim((string)($networkMethod['icon'] ?? ''));
                            $hasCustomLogo = settingsIsManagedNetworkLogo($storedIcon);
                            $previewLogo = $hasCustomLogo ? $storedIcon : settingsDefaultNetworkLogo($networkMethod);
                            $networkStatus = strtolower((string)($networkMethod['status'] ?? '')) === 'enabled' ? 'Imewashwa' : 'Imezimwa';
                            $networkLogoUrl = $previewLogo !== '' ? appUrl('assets/networks/logo.php?file=' . rawurlencode($previewLogo)) : '';
                        ?>
                        <article class="settings-network-logo-card">
                            <div class="settings-network-logo-heading">
                                <?php if ($networkLogoUrl !== ''): ?>
                                    <img src="<?= e($networkLogoUrl) ?>" alt="Logo for <?= e($networkName) ?>" class="settings-network-logo-preview" onerror="this.hidden=true;this.nextElementSibling.hidden=false">
                                    <span class="settings-network-logo-placeholder" hidden><i class="fa-solid fa-mobile-screen-button" aria-hidden="true"></i></span>
                                <?php else: ?>
                                    <span class="settings-network-logo-placeholder"><i class="fa-solid fa-mobile-screen-button" aria-hidden="true"></i></span>
                                <?php endif; ?>
                                <div><strong><?= e($networkName) ?></strong><small><?= e((string)($networkMethod['provider_code'] ?? '')) ?> · <?= e($networkStatus) ?></small></div>
                            </div>
                            <form method="post" enctype="multipart/form-data" action="<?= e(appUrl('admin/dashboard.php?page=settings#network-logos')) ?>" class="settings-network-logo-form">
                                <?= csrfField() ?>
                                <input type="hidden" name="settings_action" value="save_network_logo">
                                <input type="hidden" name="network_id" value="<?= $networkId ?>">
                                <label for="network_logo_<?= $networkId ?>">Choose Image</label>
                                <input id="network_logo_<?= $networkId ?>" name="network_logo" type="file" accept="image/png,image/jpeg,image/webp" required>
                                <button type="submit"><i class="fa-solid fa-upload" aria-hidden="true"></i> Save Logo</button>
                            </form>
                            <?php if ($hasCustomLogo): ?>
                                <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=settings#network-logos')) ?>" class="settings-network-logo-reset">
                                    <?= csrfField() ?>
                                    <input type="hidden" name="settings_action" value="reset_network_logo">
                                    <input type="hidden" name="network_id" value="<?= $networkId ?>">
                                    <button type="submit"><i class="fa-solid fa-rotate-left" aria-hidden="true"></i> Restore Default Logo</button>
                                </form>
                            <?php endif; ?>
                        </article>
                    <?php endforeach; ?>
                </div>
                <p class="settings-network-logo-security"><i class="fa-solid fa-lock" aria-hidden="true"></i> Administrator authorization, POST, and CSRF are enforced. Images are checked for type and size before they are saved.</p>
            <?php endif; ?>
        </div>
    </details>

    <details class="settings-section-card settings-env" id="settings-env">
        <summary><span class="settings-section-icon is-teal"><i class="fa-solid fa-gears"></i></span><span><strong>Technical Configuration (.env)</strong><small>Current environment values, URL, timezone, currency, and session</small></span><i class="fa-solid fa-chevron-down"></i></summary>
        <div class="settings-env-grid">
            <div><small>APP_NAME</small><strong><?= e((string)APP_NAME) ?></strong></div>
            <div><small>APP_ENV</small><strong><?= e($environment) ?><?= $isDevelopment ? ' · Development' : '' ?></strong></div>
            <div><small>APP_URL</small><strong class="settings-break-word"><?= e((string)APP_URL) ?></strong></div>
            <div><small>APP_TIMEZONE</small><strong><?= e((string)APP_TIMEZONE) ?></strong></div>
            <div><small>APP_CURRENCY</small><strong><?= e((string)APP_CURRENCY) ?></strong></div>
            <div><small>SESSION_NAME</small><strong><?= e((string)SESSION_NAME) ?></strong></div>
            <div><small>APP_ENCRYPTION_KEY</small><strong><?= $encryptionKeyReady ? 'Configured · value hidden' : 'Not configured or incomplete' ?></strong></div>
        </div>
        <p class="settings-env-note"><i class="fa-solid fa-circle-info"></i> Change these settings in the <code>.env</code>. Do not change the URL, database credentials, session, or encryption key in the browser; changes could interrupt service or make saved secrets unreadable.</p>
    </details>

    <details class="settings-section-card settings-env" id="backup-policy">
        <summary><span class="settings-section-icon is-orange"><i class="fa-solid fa-calendar-check"></i></span><span><strong>Backup Schedule and Retention</strong><small>Automatically back up the database</small></span><i class="fa-solid fa-chevron-down"></i></summary>
        <div class="settings-policy-content">
            <?php if (!$backupPolicyTableReady): ?>
                <div class="settings-alert is-warning" role="alert"><i class="fa-solid fa-circle-info"></i><span>First run <code>admin/database/backup_policy.sql</code> on the system database.</span></div>
            <?php endif; ?>
            <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=settings')) ?>" class="settings-backup-form">
                <?= csrfField() ?>
                <input type="hidden" name="settings_action" value="save_backup_policy">
                <label class="settings-backup-enable"><input type="checkbox" name="backup_enabled" value="1" <?= (int)$backupPolicy['enabled'] === 1 ? 'checked' : '' ?> <?= !$backupPolicyTableReady ? 'disabled' : '' ?>><span><strong>Enable scheduled backups</strong><small>Disables the schedule without deleting existing backups.</small></span></label>
                <div class="settings-backup-fields">
                    <div class="settings-field"><label for="backup_frequency">Frequency</label><select id="backup_frequency" name="backup_frequency" <?= !$backupPolicyTableReady ? 'disabled' : '' ?>><option value="daily" <?= $backupPolicy['frequency'] === 'daily' ? 'selected' : '' ?>>Daily</option><option value="weekly" <?= $backupPolicy['frequency'] === 'weekly' ? 'selected' : '' ?>>Weekly</option></select></div>
                    <div class="settings-field"><label for="backup_run_time">Backup time</label><input id="backup_run_time" name="backup_run_time" type="time" value="<?= e((string)$backupPolicy['run_time']) ?>" required <?= !$backupPolicyTableReady ? 'disabled' : '' ?>><small>Dar es Salaam time.</small></div>
                    <div class="settings-field"><label for="backup_run_day">Day of the week</label><select id="backup_run_day" name="backup_run_day" <?= !$backupPolicyTableReady ? 'disabled' : '' ?>><?php foreach ([1 => 'Jumatatu', 2 => 'Jumanne', 3 => 'Jumatano', 4 => 'Alhamisi', 5 => 'Ijumaa', 6 => 'Jumamosi', 7 => 'Jumapili'] as $dayNumber => $dayName): ?><option value="<?= $dayNumber ?>" <?= (int)$backupPolicy['run_day'] === $dayNumber ? 'selected' : '' ?>><?= e($dayName) ?></option><?php endforeach; ?></select><small>Used when weekly is selected.</small></div>
                    <div class="settings-field"><label for="backup_retention_count">Backups to keep</label><input id="backup_retention_count" name="backup_retention_count" type="number" min="1" max="30" value="<?= e((string)$backupPolicy['retention_count']) ?>" required <?= !$backupPolicyTableReady ? 'disabled' : '' ?>><small>Older scheduled backups are deleted after a new backup succeeds.</small></div>
                </div>
                <div class="settings-policy-actions"><span><?php if ($backupPolicy['last_run_at'] !== ''): ?>Last backup: <?= e((string)$backupPolicy['last_run_at']) ?><?php else: ?>No scheduled backup has been recorded yet.<?php endif; ?></span><button type="submit" <?= !$backupPolicyTableReady ? 'disabled' : '' ?>><i class="fa-solid fa-floppy-disk"></i> Save Policy</button></div>
            </form>
            <div class="settings-scheduler-note"><strong><i class="fa-solid fa-circle-info"></i> Setting Up Scheduled Backups</strong><p>Set up a Scheduled Task on your XAMPP computer or a Cron Job on hosting that supports scheduled tasks. It should run <code>admin/backup_scheduler.php</code> via PHP CLI every 15 minutes; the script will create a backup only on the selected days and times. The PHP CLI path depends on your server. The script does not run when opened in a browser. Without a scheduler, you can still create backups manually on this page.</p><p>Backups are stored outside the server's public web root. Retention applies only to scheduled backups; this policy does not delete backups you created manually.</p></div>
        </div>
    </details>

    <details class="settings-section-card settings-env" id="settings-security">
        <summary><span class="settings-section-icon is-purple"><i class="fa-solid fa-user-shield"></i></span><span><strong>Administrator Security</strong><small>Current session and sign-in protection status</small></span><i class="fa-solid fa-chevron-down"></i></summary>
        <?php if (!$adminSecurityPolicyReady): ?><div class="settings-policy-content"><div class="settings-alert is-warning" role="alert"><i class="fa-solid fa-circle-info"></i><span>Enable these settings by running <code>admin/database/admin_security_policy.sql</code> on the system database. The session timeout is currently 30 minutes, and sign-in lockout is disabled.</span></div></div><?php endif; ?>
        <?php if ($adminSecurityPolicyReady && !$adminSecurity['login_protection_enabled']): ?><div class="settings-policy-content"><div class="settings-alert is-warning" role="alert"><i class="fa-solid fa-triangle-exclamation"></i><span>Session timeout is active, but the sign-in protection table is missing. Run the administrator security SQL again to enable lockout.</span></div></div><?php endif; ?>
        <form method="post" action="<?= e(appUrl('admin/dashboard.php?page=settings')) ?>" class="settings-policy-content">
            <?= csrfField() ?>
            <input type="hidden" name="settings_action" value="save_admin_security">
            <div class="settings-backup-form">
                <div class="settings-backup-fields">
                    <div class="settings-field"><label for="session_timeout_minutes">Session timeout (minutes)</label><input id="session_timeout_minutes" name="session_timeout_minutes" type="number" min="5" max="480" value="<?= e((string)$adminSecurity['session_timeout_minutes']) ?>" required <?= !$adminSecurityPolicyReady ? 'disabled' : '' ?>><small>Between 5 and 480 minutes of inactivity.</small></div>
                    <div class="settings-field"><label for="max_login_attempts">Sign-in attempts before lockout</label><input id="max_login_attempts" name="max_login_attempts" type="number" min="3" max="20" value="<?= e((string)$adminSecurity['max_login_attempts']) ?>" required <?= !$adminSecurityPolicyReady ? 'disabled' : '' ?>><small>Activity is tracked by username and device address.</small></div>
                    <div class="settings-field"><label for="lockout_minutes">Lockout duration (minutes)</label><input id="lockout_minutes" name="lockout_minutes" type="number" min="1" max="1440" value="<?= e((string)$adminSecurity['lockout_minutes']) ?>" required <?= !$adminSecurityPolicyReady ? 'disabled' : '' ?>><small>Between 1 and 1,440 minutes.</small></div>
                </div>
                <div class="settings-policy-actions"><span><?= $adminSecurity['login_protection_enabled'] ? 'Session timeout and lockout are enforced.' : 'Sign-in lockout will start after the SQL is applied.' ?></span><button type="submit" <?= !$adminSecurityPolicyReady ? 'disabled' : '' ?>><i class="fa-solid fa-floppy-disk"></i> Save Security Settings</button></div>
            </div>
        </form>
    </details>

    <details class="settings-section-card settings-env" id="settings-network">
        <summary><span class="settings-section-icon is-teal"><i class="fa-solid fa-shield-halved"></i></span><span><strong>Wi-Fi Security</strong><small>Device limits and disconnecting idle devices</small></span><i class="fa-solid fa-chevron-down"></i></summary>
        <div class="settings-policy-grid">
            <div><small>Router integration</small><strong>Waiting for devices and an adapter</strong><p>Device limits per voucher and idle timeouts will be managed after the router is connected and tested.</p></div>
            <div><small>Network Profiles</small><strong>Drafts only</strong><p>Existing Wi-Fi profiles are not sent to the router automatically.</p><a href="<?= e(appUrl('admin/dashboard.php?page=router')) ?>">Open Routers & Wi-Fi <i class="fa-solid fa-arrow-right"></i></a></div>
        </div>
    </details>

    <details class="settings-section-card settings-tables" id="settings-tables">
        <summary><span class="settings-section-icon is-purple"><i class="fa-solid fa-table-list"></i></span><span><strong>Database Check</strong><small><?= count($tables) ?> tables found · status of key tables</small></span><i class="fa-solid fa-chevron-down"></i></summary>
        <div class="settings-table-grid">
            <?php foreach ($tableCounts as $tableName => $count): ?>
                <?php $exists = isset($tables[$tableName]); ?>
                <div class="settings-table-row"><span><i class="fa-solid <?= $exists ? 'fa-circle-check is-good' : 'fa-circle-minus is-missing' ?>"></i><?= e($tableName) ?></span><strong><?= $exists ? ($count === null ? 'Unreadable' : number_format($count) . ' records') : 'Not available' ?></strong></div>
            <?php endforeach; ?>
        </div>
    </details>

    <div class="settings-footnote"><i class="fa-solid fa-circle-info"></i><span>Payment webhooks require a publicly reachable HTTPS URL. Router integration requires physical hardware and an adapter before providing internet access or configuring a device automatically.</span></div>
</main>
<script>
(function () {
    document.querySelectorAll('[data-settings-detail]').forEach(function (link) {
        link.addEventListener('click', function () {
            var detailId = link.getAttribute('data-settings-detail');
            var detail = detailId ? document.getElementById(detailId) : null;
            if (detail && detail.tagName.toLowerCase() === 'details') {
                detail.open = true;
            }
        });
    });

    var portalPreview = document.getElementById('portalLivePreview');
    if (portalPreview) {
        var themeInputs = Array.prototype.slice.call(document.querySelectorAll('input[name="portal_theme"]'));
        var brandInput = document.getElementById('portal_brand_name');
        var welcomeInput = document.getElementById('portal_welcome_message');
        var logoInput = document.getElementById('portal_logo');
        var previewName = document.getElementById('portalPreviewName');
        var previewWelcome = document.getElementById('portalPreviewWelcome');
        var previewLogo = document.getElementById('portalPreviewLogo');
        var previewLogoFallback = document.getElementById('portalPreviewLogoFallback');

        function updatePortalPreview() {
            var selectedTheme = themeInputs.find(function (input) { return input.checked; });
            var theme = selectedTheme ? selectedTheme.value : 'ocean';
            var colors = {
                background: selectedTheme ? selectedTheme.dataset.previewBackground : '#f3f7fb',
                surface: selectedTheme ? selectedTheme.dataset.previewSurface : '#ffffff',
                text: selectedTheme ? selectedTheme.dataset.previewText : '#14283d',
                border: selectedTheme ? selectedTheme.dataset.previewBorder : '#e1e9f1',
                accent: selectedTheme ? selectedTheme.dataset.previewAccent : '#08aebe',
                button: selectedTheme ? selectedTheme.dataset.previewButton : '#e87537'
            };

            if (theme === 'ocean') {
                ['accent', 'background', 'surface', 'text', 'border', 'button'].forEach(function (key) {
                    var field = document.querySelector('[name="theme_' + key + '_color"]');
                    if (field && /^#[0-9a-f]{6}$/i.test(field.value)) colors[key] = field.value;
                });
            }

            portalPreview.dataset.theme = theme;
            Object.keys(colors).forEach(function (key) {
                portalPreview.style.setProperty('--preview-' + key, colors[key]);
            });
            document.querySelectorAll('.portal-theme-option').forEach(function (card) {
                var radio = card.querySelector('input[name="portal_theme"]');
                card.classList.toggle('is-selected', !!radio && radio.checked);
            });
            if (previewName && brandInput) previewName.textContent = brandInput.value.trim() || 'Wi-Fi Name';
            if (previewWelcome && welcomeInput) previewWelcome.textContent = welcomeInput.value.trim() || 'Welcome. Choose a network and package to connect.';
        }

        themeInputs.forEach(function (input) { input.addEventListener('change', updatePortalPreview); });
        document.querySelectorAll('.portal-color-control input[type="color"]').forEach(function (input) {
            input.addEventListener('input', updatePortalPreview);
            input.addEventListener('change', updatePortalPreview);
        });
        if (brandInput) brandInput.addEventListener('input', updatePortalPreview);
        if (welcomeInput) welcomeInput.addEventListener('input', updatePortalPreview);

        if (logoInput && previewLogo) {
            var previewObjectUrl = '';
            logoInput.addEventListener('change', function () {
                var file = logoInput.files && logoInput.files[0];
                if (!file || !/^image\/(png|jpeg|webp)$/.test(file.type) || file.size > 1024 * 1024) return;
                if (previewObjectUrl) URL.revokeObjectURL(previewObjectUrl);
                previewObjectUrl = URL.createObjectURL(file);
                previewLogo.onload = function () {
                    previewLogo.hidden = false;
                    if (previewLogoFallback) previewLogoFallback.hidden = true;
                };
                previewLogo.onerror = function () {
                    previewLogo.hidden = true;
                    if (previewLogoFallback) previewLogoFallback.hidden = false;
                };
                previewLogo.src = previewObjectUrl;
            });
        }

        document.querySelectorAll('.portal-preview-network').forEach(function (button) {
            button.addEventListener('click', function () {
                document.querySelectorAll('.portal-preview-network').forEach(function (item) {
                    var chosen = item === button;
                    item.classList.toggle('is-selected', chosen);
                    item.setAttribute('aria-pressed', chosen ? 'true' : 'false');
                });
            });
        });

        updatePortalPreview();
    }
})();
</script>
